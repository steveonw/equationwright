from playwright.sync_api import sync_playwright
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'dist/Math_Worksheet_Builder_v7_3_0_FULL_CATALOG.html').read_text(encoding='utf-8')
INIT=r'''(()=>{
window.__row=(n,u,t,res,m=null)=>({n,unit:u,topicKey:t,generatorKey:'g'+n,question:'Q'+n,correctAnswer:'C'+n,chosenAnswer:res==='unanswered'?null:(res==='correct'?'C'+n:'W'+n),result:res,mistakeType:m});
window.__result=(rows,opt={})=>{const mode=opt.mode||'CA',seed=opt.seed||'ADV';const counts={};unitsForMode(mode).forEach(u=>counts[u.id]=0);Object.assign(counts,opt.counts||{CA_Linear:2,CA_Quadratics:2});const score=rows.filter(x=>x.result==='correct').length,answered=rows.filter(x=>x.result!=='unanswered').length,unanswered=rows.length-answered;return {format:'mw-quiz-results-v1',studentAlias:opt.alias,exportedAt:opt.date||'2026-01-01T00:00:00Z',seed,mode,score,total:rows.length,answered,unanswered,summary:{},questions:rows,blueprint:{format:MW_BLUEPRINT_FORMAT,appVersion:opt.version||MW_APP_VERSION,seed,mode,quizMode:true,counts,variety:2,pages:{answers:false,workedSolutions:false}}};};
})();'''
MOCK_STORAGE=r'''(()=>{const mk=()=>{const m=new Map();return {getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),_m:m};};window.__ls=mk();window.__ss=mk();Object.defineProperty(window,'localStorage',{value:window.__ls,configurable:true});Object.defineProperty(window,'sessionStorage',{value:window.__ss,configurable:true});})()'''
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium')
 pg=b.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
 # Opaque set_content origin cannot use browser Storage, so install deterministic mock Storage before app JS executes.
 pg.evaluate(MOCK_STORAGE)
 pg.route('**/*',lambda r:r.abort())
 pg.set_content(html,wait_until='domcontentloaded',timeout=30000);pg.wait_for_function("typeof buildLocalRemediationBlueprint==='function'")
 pg.evaluate(INIT)
 out={}

 # D1 provider isolation: remembered Anthropic key never crosses into blank custom; explicit custom stays custom only.
 out['provider_isolation']=pg.evaluate(r'''(async()=>{
   __ls.clear();__ss.clear();
   const sel=document.getElementById('aiProviderSel'), keyEl=document.getElementById('aiKeyInput'), rem=document.getElementById('aiKeyRemember'), ep=document.getElementById('aiEndpointInput');
   sel.value='anthropic';sel.dispatchEvent(new Event('change'));keyEl.value='HOSTED-SECRET';rem.checked=true;aiPersistKey('anthropic','HOSTED-SECRET');
   const storedAnth=mwAIStoredKey('anthropic');
   sel.value='openai_compat';sel.dispatchEvent(new Event('change'));ep.value='http://local.invalid/v1/chat/completions';
   const blankCfg=aiProviderCfg();
   const seen=[];const oldFetch=fetch;window.fetch=async(u,o)=>{seen.push({url:u,headers:{...o.headers}});return {ok:true,json:async()=>({choices:[{message:{content:'{"diagnosis":"x","blueprint":null}'}}]})};};
   try{await aiCallTutor({format:'x'});}catch(e){}
   keyEl.value='CUSTOM-SECRET';rem.checked=true;try{await aiCallTutor({format:'x'});}catch(e){}
   sel.value='openrouter';sel.dispatchEvent(new Event('change'));const openrouterCfg=aiProviderCfg();
   sel.value='anthropic';sel.dispatchEvent(new Event('change'));const anthCfg=aiProviderCfg();
   window.fetch=oldFetch;
   return {storedAnth,blankCustomKey:blankCfg.key,blankCustomAuth:seen[0]?.headers?.Authorization||null,customAuth:seen[1]?.headers?.Authorization||null,storedCustom:mwAIStoredKey('openai_compat'),openrouterKey:openrouterCfg.key,anthropicKey:anthCfg.key,legacyGeneric:__ls.getItem('MW_AI_KEY')};
 })()''')

 # D2 exit states + timeout constant + plain message.
 out['ai_exit_states']=pg.evaluate(r'''(()=>{
   const r=__result([__row(1,'CA_Linear','ineq','incorrect','A'),__row(2,'CA_Linear','ineq','incorrect','A')]);
   const timeout=mwEvaluateTutorFailure(r,new DOMException('Aborted','AbortError'),false,true);
   const http=mwEvaluateTutorFailure(r,new Error('HTTP 503'),false,false);
   const cancel=mwEvaluateTutorFailure(r,new DOMException('Aborted','AbortError'),true,false);
   const invalid=mwEvaluateTutorReply(r,{diagnosis:'Useful diagnosis',blueprint:{mode:'BAD'}});
   const panel=document.createElement('div');document.body.appendChild(panel);mwRenderTutorPlan(panel,invalid);const text=panel.textContent;panel.remove();
   return {timeout:{state:timeout.state,reason:timeout.reason,seed:timeout.review?.blueprint?.seed},http:{state:http.state,reason:http.reason,seed:http.review?.blueprint?.seed},cancel:{state:cancel.state,reason:cancel.reason},invalid:{state:invalid.state,reason:invalid.reason,text,rawCodeVisible:text.includes('sanitizer-rejection')},constant:MW_AI_MAIN_TIMEOUT_MS,qaHasTimer:/setTimeout/.test(String(qaAskTutorFn)),qaClears:/clearTimeout/.test(String(qaAskTutorFn))};
 })()''')

 out['timeout_flow']=pg.evaluate(r'''(async()=>{
   const r=__result([__row(1,'CA_Linear','ineq','incorrect','A'),__row(2,'CA_Linear','ineq','incorrect','A')]);
   const oldBuild=buildResultsJSON, oldCall=aiCallTutor, oldRender=mwRenderTutorPlan, oldSet=setTimeout, oldClear=clearTimeout;
   let seenMs=null, rendered=null;
   buildResultsJSON=()=>r;
   window.setTimeout=(fn,ms)=>{seenMs=ms; queueMicrotask(fn); return 991;};
   window.clearTimeout=(id)=>{};
   aiCallTutor=(obj,opt={})=>new Promise((resolve,reject)=>{ if(opt.signal?.aborted) return reject(new DOMException('Aborted','AbortError')); opt.signal?.addEventListener('abort',()=>reject(new DOMException('Aborted','AbortError')),{once:true}); });
   mwRenderTutorPlan=(panel,plan)=>{rendered={state:plan.state,reason:plan.reason,seed:plan.review?.blueprint?.seed};};
   try{await qaAskTutorFn();}finally{buildResultsJSON=oldBuild;aiCallTutor=oldCall;mwRenderTutorPlan=oldRender;window.setTimeout=oldSet;window.clearTimeout=oldClear;}
   return {seenMs,rendered};
 })()''')

 # D3 zero answer and summary branches.
 out['smart_review_ui']=pg.evaluate(r'''(()=>{
   document.getElementById('modeSelect').value='CA';buildUnitControls();document.querySelectorAll('.count-in').forEach(x=>x.value='0');document.querySelector('.count-in').value='5';document.getElementById('toggleQuizMode').checked=true;document.getElementById('seedInput').value='ZERO-UI';renderSheet();updateQuizActions();
   const before={answered:QUIZ_DATA.answered,panel:document.getElementById('quizActions').style.display,buttonVisible:!!document.getElementById('qaTrySimilar')?.offsetParent};
   qaTrySimilarFn();
   const after={notice:document.getElementById('smartReviewNotice')?.textContent||'',seed:document.getElementById('seedInput').value,total:(QUIZ_DATA?.questions||[]).filter(q=>q.type==='mc').length};
   const branches={};
   const fixtures={pacing:__result([__row(1,'CA_Linear','ineq','correct'),__row(2,'CA_Quadratics','app','unanswered')]),perfect:__result([__row(1,'CA_Linear','ineq','correct'),__row(2,'CA_Quadratics','app','correct')]),low:__result([__row(1,'CA_Linear','ineq','incorrect','A')]),medium:__result([__row(1,'CA_Linear','ineq','incorrect',null),__row(2,'CA_Linear','ineq','incorrect',null)]),high:__result([__row(1,'CA_Linear','ineq','incorrect','A'),__row(2,'CA_Linear','ineq','incorrect','A')])};
   for(const [k,v] of Object.entries(fixtures)){const rv=buildLocalRemediationBlueprint(v);branches[k]={ok:rv.ok,text:mwSmartReviewSummaryText(rv),meta:rv.meta};}
   return {before,after,branches};
 })()''')

 # D4 complete history fixture: Alice has old version + comparable current attempts with topic/mistake trend; Bob hits different-mix boundary; invalid file produces stable code.
 out['history_ui']=pg.evaluate(r'''(()=>{
   const aOld=__result([__row(1,'CA_Linear','ineq','correct'),__row(2,'CA_Linear','ineq','correct')],{alias:'Alice',date:'2025-12-01T00:00:00Z',version:'v7.1.2_full_catalog_scratchpad'});
   const a1=__result([__row(1,'CA_Linear','ineq','incorrect','Pattern A'),__row(2,'CA_Linear','ineq','incorrect','Pattern A'),__row(3,'CA_Quadratics','app','correct'),__row(4,'CA_Quadratics','app','unanswered')],{alias:'Alice',date:'2026-01-01T00:00:00Z'});
   const a2=__result([__row(1,'CA_Linear','ineq','correct'),__row(2,'CA_Linear','ineq','correct'),__row(3,'CA_Quadratics','app','correct'),__row(4,'CA_Quadratics','app','correct')],{alias:'Alice',date:'2026-02-01T00:00:00Z'});
   const b1=__result([__row(1,'CA_Linear','ineq','incorrect','B'),__row(2,'CA_Linear','ineq','correct')],{alias:'Bob',date:'2026-01-01T00:00:00Z',counts:{CA_Linear:2,CA_Quadratics:0}});
   const b2=__result([__row(1,'CA_Quadratics','app','correct'),__row(2,'CA_Quadratics','app','correct')],{alias:'Bob',date:'2026-03-01T00:00:00Z',counts:{CA_Linear:0,CA_Quadratics:2}});
   const bad={format:'mw-quiz-results-v1',blueprint:null,questions:[]};
   PERSONAL_HISTORY_RAW=[b2,a2,bad,aOld,a1,b1];PERSONAL_HISTORY_IMPORT_SKIPPED={};mwRenderPersonalHistory();
   const text=document.getElementById('personalHistoryDash').textContent;
   return {text,hasDates:['2025-12-01','2026-01-01','2026-02-01','2026-03-01'].every(x=>text.includes(x)),hasVersions:text.includes('Version v7.1.2_full_catalog_scratchpad')&&text.includes('Version '+MW_APP_VERSION),hasDeltas:/Accuracy delta:/.test(text)&&/Completion delta:/.test(text),hasTopic:/Topic trends:/.test(text)&&/Precalculus|Linear/i.test(text),hasMistake:/Mistake patterns:/.test(text)&&/Resolved in latest|Recurring/.test(text),hasDifferentMix:text.includes('Different practice mix — no direct trend label.'),hasSkipped:text.includes('missing-or-invalid-blueprint')};
 })()''')

 # D5 unit-scoped topic summary in result and class object.
 out['topic_scope']=pg.evaluate(r'''(()=>{
   const q1={type:'mc',cat:'P283_Continuous',topicKey:'prob',topicLabel:'Prob',key:'g1',q:'Q1',a:'A1',choices:['A1','B1'],correctIndex:0,_answered:true,_chosen:1,_wasCorrect:false,trapWhys:{}};
   const q2={type:'mc',cat:'S245_Probability',topicKey:'prob',topicLabel:'Prob',key:'g2',q:'Q2',a:'A2',choices:['A2','B2'],correctIndex:0,_answered:true,_chosen:1,_wasCorrect:false,trapWhys:{}};
   window.QUIZ_DATA={questions:[q1,q2],score:0,answered:2};document.getElementById('modeSelect').value='MIX';document.getElementById('seedInput').value='TOPIC-SCOPE';window.LAST_BLUEPRINT={format:MW_BLUEPRINT_FORMAT,appVersion:MW_APP_VERSION,seed:'TOPIC-SCOPE',mode:'MIX',quizMode:true,counts:{P283_Continuous:1,S245_Probability:1},variety:2,pages:{answers:false,workedSolutions:false}};
   const result=buildResultsJSON();
   const r1=__result([__row(1,'P283_Continuous','prob','incorrect','P')],{mode:'MIX',seed:'C1',alias:'A',counts:{P283_Continuous:1,S245_Probability:0}});
   const r2=__result([__row(1,'S245_Probability','prob','incorrect','P')],{mode:'MIX',seed:'C2',alias:'B',counts:{P283_Continuous:0,S245_Probability:1}});
   CLASS_RESULTS=[r1,r2];document.getElementById('classGroupView').value='attempts';const cls=buildClassSummaryObj();
   return {resultNested:result.summary.missedByUnitTopic,resultLegacy:result.summary.missedByTopic,resultScope:result.summary.missedByTopicScope,classNested:cls.missedByUnitTopic,classScope:cls.missedByTopicScope,promptScoped:/missedByUnitTopic/.test(TUTOR_SYSTEM_PROMPT)};
 })()''')

 # D6 denominators and terminology, including unaliased attempt.
 out['class_denominators']=pg.evaluate(r'''(()=>{
   const a=__result([__row(1,'CA_Linear','ineq','incorrect','A')],{alias:'Student A',date:'2026-01-01T00:00:00Z',seed:'D6A',counts:{CA_Linear:1}});
   const b=__result([__row(1,'CA_Linear','ineq','correct')],{alias:'Student A',date:'2026-02-01T00:00:00Z',seed:'D6B',counts:{CA_Linear:1}});
   const c=__result([__row(1,'CA_Linear','ineq','incorrect','A')],{alias:'Student B',date:'2026-01-15T00:00:00Z',seed:'D6C',counts:{CA_Linear:1}});
   const d=__result([__row(1,'CA_Linear','ineq','correct')],{date:'2026-02-15T00:00:00Z',seed:'D6D',counts:{CA_Linear:1}});
   CLASS_RESULTS=[a,b,c,d];document.getElementById('classGroupView').value='attempts';const at=buildClassSummaryObj();renderClassDash();const dashA=document.getElementById('classDash').textContent;document.getElementById('classGroupView').value='unique';const un=buildClassSummaryObj();renderClassDash();const dashU=document.getElementById('classDash').textContent;
   return {attempts:{studentCount:at.studentCount,attemptCount:at.attemptCount,uniqueAliasCount:at.uniqueAliasCount,unaliasedAttemptCount:at.unaliasedAttemptCount,countedRecordCount:at.countedRecordCount,learnerAliases:at.learnerAliases.length,students:at.students.length},unique:{studentCount:un.studentCount,attemptCount:un.attemptCount,uniqueAliasCount:un.uniqueAliasCount,unaliasedAttemptCount:un.unaliasedAttemptCount,countedRecordCount:un.countedRecordCount},prompt:{attempt:/attemptCount/.test(TUTOR_SYSTEM_PROMPT),unique:/uniqueAliasCount/.test(TUTOR_SYSTEM_PROMPT),view:/selected view|Attempts view|Unique-alias view/.test(TUTOR_SYSTEM_PROMPT),noStudents:/Never call attempts "students"/.test(TUTOR_SYSTEM_PROMPT)},dashA,dashU};
 })()''')

 out['pageErrors']=errs
 # High-level gates for the six defects.
 out['checks']={
   'D1': out['provider_isolation']['storedAnth']=='HOSTED-SECRET' and out['provider_isolation']['blankCustomKey']=='' and out['provider_isolation']['blankCustomAuth'] is None and out['provider_isolation']['customAuth']=='Bearer CUSTOM-SECRET' and out['provider_isolation']['storedCustom']=='CUSTOM-SECRET' and out['provider_isolation']['openrouterKey']=='' and out['provider_isolation']['anthropicKey']=='HOSTED-SECRET',
   'D2': out['ai_exit_states']['constant']==180000 and out['ai_exit_states']['timeout']['state']=='local-review' and out['ai_exit_states']['timeout']['reason']=='timeout' and out['ai_exit_states']['timeout']['seed']==out['ai_exit_states']['http']['seed'] and out['ai_exit_states']['cancel']['state']=='failure-only' and not out['ai_exit_states']['invalid']['rawCodeVisible'] and out['ai_exit_states']['qaHasTimer'] and out['ai_exit_states']['qaClears'] and out['timeout_flow']['seenMs']==180000 and out['timeout_flow']['rendered']['state']=='local-review' and out['timeout_flow']['rendered']['reason']=='timeout',
   'D3': out['smart_review_ui']['before']['panel']=='block' and out['smart_review_ui']['before']['buttonVisible'] and 'starter diagnostic' in out['smart_review_ui']['after']['notice'].lower() and out['smart_review_ui']['after']['total']==5 and all(v['ok'] and v['text'] for v in out['smart_review_ui']['branches'].values()),
   'D4': all(out['history_ui'][k] for k in ['hasDates','hasVersions','hasDeltas','hasTopic','hasMistake','hasDifferentMix','hasSkipped']),
   'D5': out['topic_scope']['resultNested'].get('P283_Continuous',{}).get('prob')==1 and out['topic_scope']['resultNested'].get('S245_Probability',{}).get('prob')==1 and out['topic_scope']['classNested'].get('P283_Continuous',{}).get('prob')==1 and out['topic_scope']['classNested'].get('S245_Probability',{}).get('prob')==1 and out['topic_scope']['promptScoped'],
   'D6': out['class_denominators']['attempts']['studentCount']==2 and out['class_denominators']['attempts']['attemptCount']==4 and out['class_denominators']['attempts']['uniqueAliasCount']==2 and out['class_denominators']['attempts']['unaliasedAttemptCount']==1 and out['class_denominators']['unique']['studentCount']==2 and out['class_denominators']['unique']['countedRecordCount']==2 and all(out['class_denominators']['prompt'].values())
 }
 (ROOT/'dist/test-evidence').mkdir(parents=True,exist_ok=True)
 (ROOT/'dist/test-evidence/EquationWright_Pass_4B_Stage3_D1_D6.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
 print(json.dumps({'checks':out['checks'],'pageErrors':errs,'provider':out['provider_isolation'],'exit':out['ai_exit_states'],'history':{k:v for k,v in out['history_ui'].items() if k!='text'},'class':out['class_denominators']},indent=2,ensure_ascii=False))
 b.close()
