#!/usr/bin/env python3
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist'
ONLINE=(DIST/'Math_Worksheet_Builder_v7_3_0_FULL_CATALOG.html').read_text(encoding='utf-8')
OFFLINE=(DIST/'Math_Worksheet_Builder_v7_3_0_FULL_CATALOG_OFFLINE.html').read_text(encoding='utf-8')
OUT=DIST/'test-evidence/EquationWright_v7_3_Cross_Variant_Strict_Replay.json'
MOCK=r'''(()=>{const mk=()=>{const m=new Map();return {getItem:k=>m.has(String(k))?m.get(String(k)):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),key:i=>[...m.keys()][i]??null,get length(){return m.size;}}};Object.defineProperty(window,'localStorage',{value:mk(),configurable:true});Object.defineProperty(window,'sessionStorage',{value:mk(),configurable:true});})()'''
SETUP=r'''(()=>{mwActivateProfile('edu.vccs.nvcc.math','1.0.0',{preserveMode:false});document.getElementById('modeSelect').value='C2';buildCoveragePills();buildUnitControls();countInputs.forEach(x=>x.value=0);countInputs[0].value=2;countInputs[2].value=2;document.getElementById('seedInput').value='P4B-CROSS-REPLAY';document.getElementById('toggleQuizMode').checked=true;document.getElementById('varietyInput').value=3;renderSheet();return mwBuildArchiveBlueprint({includeDelivery:false});})()'''

def page(browser,text):
    p=browser.new_page(); errors=[]
    p.on('pageerror',lambda e: errors.append(str(e)))
    p.evaluate(MOCK); p.route('**/*',lambda r:r.abort()); p.set_content(text,wait_until='domcontentloaded',timeout=30000)
    p.wait_for_function("typeof mwReplayArchive==='function' && typeof mwBuildArchiveBlueprint==='function'",timeout=30000)
    return p,errors

def main():
    OUT.parent.mkdir(parents=True,exist_ok=True)
    with sync_playwright() as w:
        b=w.chromium.launch(headless=True,executable_path='/usr/bin/chromium')
        po,eo=page(b,ONLINE); pf,ef=page(b,OFFLINE)
        a=po.evaluate(SETUP); r1=pf.evaluate('(a)=>mwReplayArchive(a,"strict")',a)
        a2=pf.evaluate(SETUP); r2=po.evaluate('(a)=>mwReplayArchive(a,"strict")',a2)
        passed=(r1['status']=='exact' and r2['status']=='exact' and r1['guarantee']=='guaranteed' and r2['guarantee']=='guaranteed' and r1['assessmentExact'] and r2['assessmentExact'] and not eo and not ef)
        out={'format':'equationwright-pass4b-cross-variant-strict-replay-v1','onlineToOffline':r1,'offlineToOnline':r2,'pageErrors':{'online':eo,'offline':ef},'passed':passed}
        OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
        print(json.dumps({'passed':passed,'onlineToOffline':{k:r1[k] for k in ('status','guarantee','assessmentExact','presentationExact','replayedItemCount')},'offlineToOnline':{k:r2[k] for k in ('status','guarantee','assessmentExact','presentationExact','replayedItemCount')},'pageErrors':out['pageErrors']},indent=2))
        b.close()
        return 0 if passed else 1

if __name__=='__main__': raise SystemExit(main())
