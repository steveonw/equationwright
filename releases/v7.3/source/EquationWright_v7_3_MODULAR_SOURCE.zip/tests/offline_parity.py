#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import socket
import subprocess
import tempfile
import time
from pathlib import Path

import requests
import websocket

REPO = Path(__file__).resolve().parents[1]
ROOT = REPO / 'dist'
ONLINE = ROOT / 'Math_Worksheet_Builder_v7_3_0_FULL_CATALOG.html'
OFFLINE = ROOT / 'Math_Worksheet_Builder_v7_3_0_FULL_CATALOG_OFFLINE.html'
OUT = ROOT / 'test-evidence/EquationWright_v7_3_Offline_Packaging_Smoke_Results.json'
MODES = ['HP','QR','CA','TRIG','PC','C1','C2','C3','LA','AC1','AC2','S155','S245','P283','ST2','DE','DM','D289','MIX']


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def free_port() -> int:
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


class CDP:
    def __init__(self, html: str):
        self.port = free_port()
        self.tmp = tempfile.TemporaryDirectory(prefix='ew-chrome-')
        self.proc = subprocess.Popen([
            '/usr/bin/chromium', '--headless=new', '--no-sandbox', '--disable-gpu',
            '--disable-dev-shm-usage', '--remote-allow-origins=*',
            f'--remote-debugging-port={self.port}', f'--user-data-dir={self.tmp.name}',
            'about:blank'
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        deadline = time.time() + 20
        pages = None
        while time.time() < deadline:
            try:
                pages = requests.get(f'http://127.0.0.1:{self.port}/json', timeout=1).json()
                if pages:
                    break
            except Exception:
                time.sleep(0.1)
        if not pages:
            self.close()
            raise RuntimeError('Chromium DevTools did not become ready')
        self.ws = websocket.create_connection(pages[0]['webSocketDebuggerUrl'], timeout=60)
        self.next_id = 0
        self.call('Page.enable')
        self.call('Runtime.enable')
        self.call('Network.enable')
        self.call('Network.setBlockedURLs', {'urls': ['http://*/*', 'https://*/*', 'file://*/*']})
        tree = self.call('Page.getFrameTree')
        frame_id = tree['frameTree']['frame']['id']
        self.call('Page.setDocumentContent', {'frameId': frame_id, 'html': html})
        self.wait_js("document.readyState === 'complete' && typeof window.renderSheet === 'function'", 30)

    def call(self, method: str, params: dict | None = None) -> dict:
        self.next_id += 1
        ident = self.next_id
        self.ws.send(json.dumps({'id': ident, 'method': method, 'params': params or {}}))
        while True:
            raw = self.ws.recv()
            msg = json.loads(raw)
            if msg.get('id') == ident:
                if 'error' in msg:
                    raise RuntimeError(f"CDP {method}: {msg['error']}")
                return msg.get('result', {})

    def eval(self, expression: str, await_promise: bool = False):
        result = self.call('Runtime.evaluate', {
            'expression': expression,
            'returnByValue': True,
            'awaitPromise': await_promise,
        })
        if 'exceptionDetails' in result:
            raise RuntimeError(json.dumps(result['exceptionDetails']))
        obj = result.get('result', {})
        if obj.get('subtype') == 'error':
            raise RuntimeError(obj.get('description', 'JS error'))
        return obj.get('value')

    def wait_js(self, expression: str, timeout: float):
        deadline = time.time() + timeout
        last = None
        while time.time() < deadline:
            try:
                last = self.eval(expression)
                if last:
                    return
            except Exception as exc:
                last = str(exc)
            time.sleep(0.1)
        raise TimeoutError(f'wait_js timed out: {expression}; last={last}')

    def close(self):
        try:
            if hasattr(self, 'ws'):
                self.ws.close()
        except Exception:
            pass
        try:
            if hasattr(self, 'proc'):
                self.proc.terminate()
                self.proc.wait(timeout=5)
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass
        try:
            if hasattr(self, 'tmp'):
                self.tmp.cleanup()
        except Exception:
            pass


def snapshot_all(cdp: CDP):
    cdp.eval("window.scheduleTypeset = function(){ return Promise.resolve(); }; true")
    modes_json = json.dumps(MODES)
    js = r'''(() => {
      const modes = MODES_JSON;
      const fields = ['type','cat','key','q','a','steps','vec','traps','answerSpec','logicSpec','deSpec','answerKey','choiceFamily','answerModel','questionModel','_seed','_genIdx','topicKey','topicLabel','choices','correctIndex','trapWhys','__mcMeta','num'];
      function clean(v){ const s=JSON.stringify(v); return s===undefined ? null : JSON.parse(s); }
      function qClean(q){
        const o={};
        for(const k of fields){ if(Object.prototype.hasOwnProperty.call(q,k)) o[k]=clean(q[k]); }
        return o;
      }
      const out=[];
      for(const mode of modes){
        for(const quizMode of [false,true]){
          const us=unitsForMode(mode);
          const counts={};
          us.forEach(u=>counts[u.id]=0);
          us.slice(0,Math.min(3,us.length)).forEach(u=>counts[u.id]=1);
          const seed=`Packaging-${mode}-${quizMode?'Q':'W'}`;
          const bp={format:MW_BLUEPRINT_FORMAT,appVersion:MW_APP_VERSION,seed,mode,quizMode,counts,variety:3,pages:{answers:false,workedSolutions:false},topics:{}};
          applyBlueprint(bp);
          const lb=window.LAST_BLUEPRINT||{};
          out.push({
            mode, quizMode,
            appVersion:MW_APP_VERSION,
            catalog:{units:UNITS.length,generators:Object.values(Gens).reduce((a,x)=>a+x.length,0)},
            blueprint:{seed:lb.seed,mode:lb.mode,quizMode:lb.quizMode,counts:clean(lb.counts||{}),variety:lb.variety,topics:clean(lb.topics||{}),picks:clean(lb.picks||[])},
            questions:(window.LAST_QUESTIONS||[]).map(qClean)
          });
        }
      }
      return out;
    })()'''.replace('MODES_JSON', modes_json)
    return cdp.eval(js)


def inspect_build(path: Path, actual_mathjax: bool):
    html = path.read_text(encoding='utf-8')
    cdp = CDP(html)
    try:
        base = cdp.eval("({title:document.title, appVersion:MW_APP_VERSION, units:UNITS.length, generators:Object.values(Gens).reduce((a,x)=>a+x.length,0), buildVariant:document.querySelector('meta[name=\"equationwright-build-variant\"]')?.content||null})")
        mj = None
        if actual_mathjax:
            cdp.wait_js("window.MathJax && MathJax.version === '3.2.2' && typeof MathJax.typesetPromise === 'function'", 30)
            mj = cdp.eval(r'''(async()=>{
              const d=document.createElement('div');
              d.id='packaging-mathjax-smoke';
              d.textContent='\\(x^2+1\\)';
              document.body.appendChild(d);
              await MathJax.typesetPromise([d]);
              return {version:MathJax.version, svg:!!d.querySelector('svg'), jax:d.querySelector('mjx-container')?.getAttribute('jax')||null, text:d.textContent};
            })()''', await_promise=True)
        snaps = snapshot_all(cdp)
        return base, mj, snaps
    finally:
        cdp.close()


def main():
    OUT.parent.mkdir(parents=True,exist_ok=True)
    online_text = ONLINE.read_text(encoding='utf-8')
    offline_text = OFFLINE.read_text(encoding='utf-8')
    static = {
        'onlineSha256': sha256(ONLINE),
        'offlineSha256': sha256(OFFLINE),
        'onlineBytes': ONLINE.stat().st_size,
        'offlineBytes': OFFLINE.stat().st_size,
        'offlineLoaderMarkers': offline_text.count('Math engine loader'),
        'offlineCdnMathJaxRefs': offline_text.count('cdn.jsdelivr.net/npm/mathjax'),
        'offlineBuildVariantMarkers': offline_text.count('equationwright-build-variant'),
        'sameAppVersionLiteral': "const MW_APP_VERSION = 'v7.3_full_catalog_protocols'" in online_text and "const MW_APP_VERSION = 'v7.3_full_catalog_protocols'" in offline_text,
    }
    online_base, _, online_snaps = inspect_build(ONLINE, False)
    offline_base, mj, offline_snaps = inspect_build(OFFLINE, True)

    bad=[]
    for a,b in zip(online_snaps, offline_snaps):
        if a != b:
            bad.append({'mode':a.get('mode'),'quizMode':a.get('quizMode'),'online':a,'offline':b})
    result={
        'format':'equationwright-v7.3-offline-packaging-smoke-v1',
        'static':static,
        'onlineRuntime':online_base,
        'offlineRuntime':offline_base,
        'mathJaxSmoke':mj,
        'parity':{
            'cases':len(online_snaps),
            'expectedCases':len(MODES)*2,
            'badCount':len(bad),
            'bad':bad[:3],
            'passed':len(online_snaps)==len(offline_snaps)==len(MODES)*2 and not bad,
        },
        'passed': bool(
            static['offlineLoaderMarkers']==0 and
            static['offlineCdnMathJaxRefs']==0 and
            static['offlineBuildVariantMarkers']>=1 and
            static['sameAppVersionLiteral'] and
            online_base.get('appVersion')=='v7.3_full_catalog_protocols' and
            offline_base.get('appVersion')=='v7.3_full_catalog_protocols' and
            online_base.get('units')==offline_base.get('units')==81 and
            online_base.get('generators')==offline_base.get('generators')==424 and
            mj and mj.get('version')=='3.2.2' and mj.get('svg') and
            len(online_snaps)==len(offline_snaps)==38 and not bad
        )
    }
    OUT.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    print(json.dumps({
        'passed':result['passed'],
        'onlineRuntime':online_base,
        'offlineRuntime':offline_base,
        'mathJaxSmoke':mj,
        'parity':result['parity'],
        'static':static,
        'results':str(OUT),
    }, indent=2, ensure_ascii=False))
    return 0 if result['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
