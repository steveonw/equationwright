#!/usr/bin/env python3
from __future__ import annotations
import copy, hashlib, importlib.util, json, shutil, tempfile
from pathlib import Path
from jsonschema import Draft202012Validator
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT/'dist'
APP=DIST/'Math_Worksheet_Builder_v7_3_0_FULL_CATALOG.html'
EVID=DIST/'test-evidence'
OUT=EVID/'EquationWright_Pass_4C_HIGH_Focused_D1_D9.json'

def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()
def load_build_module():
    spec=importlib.util.spec_from_file_location('ew_build_release',ROOT/'build_release.py')
    mod=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(mod); return mod

def d1_static():
    br=load_build_module(); order,reg,profiles,bindings=br.load_inputs(ROOT)
    baseline,baseinfo=br.compute_assessment_compatibility_id(ROOT,order,reg,profiles)
    with tempfile.TemporaryDirectory(prefix='ew-p4c-d1-') as td:
        t=Path(td)
        for name in ['src','profiles','registry','build','schemas','examples']:
            shutil.copytree(ROOT/name,t/name)
        # Determinism-critical mutation must change the compatibility ID.
        det=t/'src/core/determinism.js'; text=det.read_text(); assert 'x << 13' in text
        det.write_text(text.replace('x << 13','x << 12',1))
        o,r,p,b=br.load_inputs(t); mutated,_=br.compute_assessment_compatibility_id(t,o,r,p)
        changed=(mutated!=baseline)
        # Reordering two published registrations must fail stable binding validation.
        shutil.copy2(ROOT/'src/core/determinism.js',det)
        hp=t/'src/generators/hp.js'; hpt=hp.read_text(); blocks=br.extract_register_blocks(hpt)
        assert len(blocks)>=2 and blocks[0][0]=='HP_Conversion' and blocks[1][0]=='HP_Conversion'
        b1,b2=blocks[0][1],blocks[1][1]; token='/*__P4C_SWAP__*/\n'
        hpt=hpt.replace(b1,token,1).replace(b2,b1,1).replace(token,b2,1); hp.write_text(hpt)
        o,r,p,b=br.load_inputs(t)
        reorder_failed=False; reorder_error=''
        try: br.validate_source(t,o,r,p,b)
        except Exception as e: reorder_failed=True; reorder_error=str(e)
    manifest=json.loads((DIST/'EquationWright_Build_Manifest_v1.json').read_text())
    ext=manifest.get('extensions',{}).get('org.equationwright.build-inputs-v1',{})
    files={x['path']:x['sha256'] for x in ext.get('files',[])}
    required=['build/module-order.json','registry/EquationWright_Generator_Registry_v1.json','build/generator-bindings-v1.json']
    hashes_ok=all(k in files and files[k]=='sha256:'+sha(ROOT/k) for k in required)
    return {'baselineCompatibilityId':baseline,'mutatedCompatibilityId':mutated,'criticalMutationChangesId':changed,'generatorReorderRejected':reorder_failed,'reorderError':reorder_error,'manifestInputHashes':hashes_ok,'rawDigest':baseinfo['rawDigest']}

def browser_probe():
    app=APP.read_text(encoding='utf-8')
    mock="""(()=>{const mk=()=>{const m=new Map();return {getItem:k=>m.has(String(k))?m.get(String(k)):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),key:i=>[...m.keys()][i]??null,get length(){return m.size;}}};Object.defineProperty(window,'localStorage',{value:mk(),configurable:true});Object.defineProperty(window,'sessionStorage',{value:mk(),configurable:true});window.alert=()=>{};window.confirm=()=>true;window.prompt=()=> 'Audit-Alias';})()"""
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium')
        page=browser.new_page(viewport={'width':1440,'height':1000}); errs=[]; page.on('pageerror',lambda e:errs.append(str(e)))
        page.evaluate(mock); page.route('**/*',lambda r:r.abort()); page.set_content(app,wait_until='domcontentloaded',timeout=30000); page.wait_for_function("typeof EW==='object' && window.LAST_BLUEPRINT && EW_ACTIVE_PROFILE",timeout=30000)
        out=page.evaluate(r'''async()=>{
          const clone=x=>JSON.parse(JSON.stringify(x));
          window.alert=()=>{}; window.prompt=()=> 'Audit-Alias';
          const setAssessment=(mode,seed,counts,quiz=true,variety=2)=>{mwActivateProfile('edu.vccs.nvcc.math','1.0.0',{preserveMode:false});const ms=document.getElementById('modeSelect');ms.value=mode;buildCoveragePills();buildUnitControls();document.getElementById('seedInput').value=seed;document.getElementById('varietyInput').value=variety;updateVarietyLabel();document.getElementById('toggleQuizMode').checked=!!quiz;document.getElementById('toggleAnswers').checked=!quiz;document.getElementById('toggleSolutions').checked=false;countInputs.forEach(inp=>inp.value=counts[inp.dataset.unit]||0);for(const u of visibleUnits()){const s=ensureTopicSet(u.id);s.clear();delete s.__none;}renderSheet();return clone(window.LAST_BLUEPRINT);};
          const recompute=(a)=>{const slim=clone(a.blueprint);delete slim.delivery;a.archive.assessmentDigest=mwAssessmentDigestForArchive(slim,a.archive.items);a.archive.archiveDigest=mwDigestValue({blueprint:slim,sourceEngine:a.source.engine,items:a.archive.items});return a;};
          const out={};
          // D2 format/schema/extension dispatch and no mutation on refusal.
          setAssessment('CA','P4C-D2-BASE',{CA_Linear:1},true,2); const seed0=document.getElementById('seedInput').value;
          let u=clone(window.LAST_BLUEPRINT);u.format='equationwright-blueprint-slim-v2';u.seed='SHOULD-NOT-APPLY';const ur=applyBlueprint(u);out.unknownMajor={returnValue:ur,unchanged:document.getElementById('seedInput').value===seed0};
          setAssessment('CA','P4C-D2-SLIM',{CA_Linear:1,CA_Quadratics:1},true,2);const slim=mwBuildSlimBlueprint(window.LAST_BLUEPRINT,{includeDelivery:false});let sx=clone(slim);sx.unexpectedTopLevel={x:1};out.slimExtra=mwValidateSlimBlueprint(sx);let sr=clone(slim);sr.requiresExtensions=['future.required.ext'];out.slimRequiredExt=mwValidateSlimBlueprint(sr);
          let si=clone(slim);si.engine.assessmentCompatibilityId='ewac:sha256:'+'0'.repeat(64);si.engine.catalogDigest='sha256:'+'1'.repeat(64);si.engine.appVersion='future';out.slimCompat=mwValidateSlimBlueprint(si);let confirmSeen=false;window.confirm=()=>{confirmSeen=true;return false;};const beforeApply=document.getElementById('seedInput').value;out.slimCompatApply=mwApplySlimBlueprint(si);out.slimCompatDecision={confirmSeen,unchanged:document.getElementById('seedInput').value===beforeApply};window.confirm=()=>true;
          // D3/D4 archive consistency, strict/verify, presentation context.
          setAssessment('CA','P4C-D3',{CA_Linear:2,CA_Quadratics:1},true,2);const base=mwBuildArchiveBlueprint({includeDelivery:false});out.archiveBase=mwReplayArchive(base,'strict');let a;
          a=clone(base);a.blueprint.assessment.counts={CA_Linear:1,CA_Quadratics:2};recompute(a);out.counts=mwReplayArchive(a,'strict');
          a=clone(base);a.blueprint.assessment.unitOrder=[...a.blueprint.assessment.unitOrder].reverse();recompute(a);out.unitOrder=mwReplayArchive(a,'strict');
          a=clone(base);a.archive.items=[a.archive.items[2],a.archive.items[0],a.archive.items[1]];recompute(a);out.itemOrder=mwReplayArchive(a,'strict');
          a=clone(base);a.source.engine.determinismProtocol='equationwright-determinism-v999';out.badProtocol=mwReplayArchive(a,'strict');
          a=clone(base);delete a.source.engine.determinismProtocol;out.missingProtocol=mwReplayArchive(a,'strict');
          a=clone(base);a.unexpectedTopLevel='x';out.archiveExtra=mwReplayArchive(a,'strict');
          a=clone(base);a.blueprint.engine.assessmentCompatibilityId='ewac:sha256:'+'0'.repeat(64);out.engineInternalMismatch=mwReplayArchive(a,'strict');
          a=clone(base);const z='ewac:sha256:'+'0'.repeat(64);a.source.engine.assessmentCompatibilityId=z;a.blueprint.engine.assessmentCompatibilityId=z;recompute(a);out.incompatible=mwReplayArchive(a,'strict');out.verify=mwReplayArchive(a,'verify-current');
          a=clone(base);const uid=a.blueprint.assessment.unitOrder[0],tid=Object.keys(a.archive.presentation.topicLabels[uid]||{})[0];a.archive.presentation.topicLabels[uid][tid]='CHANGED';out.topicPresentation=mwReplayArchive(a,'strict');
          mwActivateProfile('edu.vccs.nvcc.math','1.0.0',{preserveMode:false});document.getElementById('modeSelect').value='C2';buildCoveragePills();buildUnitControls();out.ambientC2=mwReplayArchive(base,'strict');document.getElementById('modeSelect').value='CA';buildCoveragePills();buildUnitControls();out.ambientCA=mwReplayArchive(base,'strict');
          // D5 transport privacy: normal submit, no-CORS retry, main/help/class path.
          setAssessment('CA','P4C-D5',{CA_Linear:1},true,2);document.getElementById('ewDiagnosticsLevel').value='full';const rd=buildResultsJSON();document.getElementById('submitUrlInput').value='https://collector.invalid/x';let bodies=[];let calls=0;window.fetch=async(url,opts={})=>{bodies.push(opts.body||'');calls++;if(calls===1)throw new Error('cors');return {ok:true,status:200,json:async()=>({}),text:async()=>''};};await qaSubmitResultsFn();out.submitBodies=bodies.map(x=>({hasDiagnostics:String(x).includes('"diagnostics"'),mode:calls>1?'retry-observed':'normal'}));
          document.getElementById('aiProviderSel').value='openai_compat';document.getElementById('aiEndpointInput').value='http://127.0.0.1:11434/v1/chat/completions';document.getElementById('aiKeyInput').value='';let aiBodies=[];window.fetch=async(url,opts={})=>{aiBodies.push(opts.body||'');return {ok:true,status:200,json:async()=>({choices:[{message:{content:'ok'}}]})};};await aiCallHelp(rd,'test');out.helpTransport=aiBodies.pop();window.fetch=async(url,opts={})=>{aiBodies.push(opts.body||'');return {ok:true,status:200,json:async()=>({choices:[{message:{content:'{\"diagnosis\":\"ok\",\"blueprint\":null}'}}]})};};await aiCallTutor(rd);out.mainTransport=aiBodies.pop();const cls={format:'mw-class-results-v1',diagnostics:{secret:true},students:[]};window.fetch=async(url,opts={})=>{aiBodies.push(opts.body||'');return {ok:true,status:200,json:async()=>({choices:[{message:{content:'{\"diagnosis\":\"ok\",\"blueprint\":null}'}}]})};};await aiCallTutor(cls);out.classTransport=aiBodies.pop();document.getElementById('ewDiagnosticsLevel').value='off';
          // D6 individual provenance mutations.
          setAssessment('CA','P4C-D6',{CA_Linear:2},true,2);const diag=mwBuildDiagnosticProvenance('replay');const mutations={runtimeIndex:d=>d.items[0].runtimeIndex=999,problemKey:d=>d.items[0].problemKey='tampered',vector:d=>d.items[0].vector=[999],topicId:d=>d.items[0].topicId='tampered',n:d=>d.items[0].n=2,unitId:d=>d.items[0].unitId='C2_Tech',engine:d=>d.engine.assessmentCompatibilityId='ewac:sha256:'+'0'.repeat(64),assessmentDigest:d=>d.assessmentDigest='sha256:'+'0'.repeat(64)};out.diagMutations={};for(const [k,fn] of Object.entries(mutations)){const d=clone(diag);fn(d);out.diagMutations[k]=mwReplayDiagnosticProvenance(d);}
          // D7 manifest metadata provenance exact expected set for current source.
          const cap=mwBuildCapabilitiesManifest();out.metadataSources=cap.catalog.generators.filter(g=>g.metadataSource!=='derived').map(g=>[g.id,g.metadataSource]);
          // D8 schema, alias, change classification and version enforcement.
          const generic=clone(EW_BUILTIN_PROFILES.find(p=>p.profileId==='org.equationwright.generic'));
          let p=clone(generic);p.profileId='local.missing-required';delete p.label;delete p.locale;p.profileDigest=mwProfileDigest(p);out.profileMissing=mwValidateCurriculumProfile(p);
          p=clone(generic);p.profileId='local.alias-collision';const alias=p.courses[0].legacyModeAliases[0];p.courses[1].legacyModeAliases=[alias];p.profileDigest=mwProfileDigest(p);out.profileAlias=mwValidateCurriculumProfile(p);
          const oldP=clone(EW_BUILTIN_PROFILES.find(p=>p.profileId==='edu.vccs.nvcc.math'));const newP=clone(oldP);newP.crosswalks[0].entries[0].coverage='primary';out.crosswalkClass=mwClassifyProfileChange(oldP,newP);
          p=clone(generic);p.profileId='local.version-test';p.profileVersion='1.0.0';p.profileDigest=mwProfileDigest(p);out.profileVersionFirst=mwRegisterCustomProfile(p);const p2=clone(p);p2.profileVersion='1.0.1';const c=p2.courses.find(x=>x.unitOrder.length>1);[c.unitOrder[0],c.unitOrder[1]]=[c.unitOrder[1],c.unitOrder[0]];p2.profileDigest=mwProfileDigest(p2);out.profileVersionClass=mwClassifyProfileChange(p,p2);out.profileVersionSecond=mwRegisterCustomProfile(p2);
          return out;
        }''')
        browser.close(); out['pageErrors']=errs; return out

def report_schema_checks(probe):
    schema=json.loads((ROOT/'schemas/equationwright-replay-report-v1.schema.json').read_text()); v=Draft202012Validator(schema)
    keys=['archiveBase','counts','unitOrder','itemOrder','badProtocol','missingProtocol','archiveExtra','engineInternalMismatch','incompatible','verify','topicPresentation','ambientC2','ambientCA']
    return {k:[e.message for e in v.iter_errors(probe[k])] for k in keys}

def main():
    EVID.mkdir(parents=True,exist_ok=True)
    d1=d1_static(); probe=browser_probe(); schemas=report_schema_checks(probe)
    expected_explicit={
      'ewg.dm_logic.001','ewg.dm_logic.002','ewg.d289_firstorder.001','ewg.d289_firstorder.002',
      'ewg.ca_systems.001','ewg.c2_series.001','ewg.c2_appsint.002','ewg.c2_appsint.003'
    }
    actual_explicit={x[0] for x in probe['metadataSources'] if x[1] in ('explicit','mixed')}
    d2=(probe['unknownMajor']['returnValue'] is False and probe['unknownMajor']['unchanged'] and not probe['slimExtra']['ok'] and probe['slimRequiredExt'].get('code')=='required-extension-unsupported' and probe['slimCompat']['ok'] and not probe['slimCompat']['compatibility']['same'] and probe['slimCompatDecision']['confirmSeen'] and probe['slimCompatDecision']['unchanged'])
    d3=(probe['archiveBase']['status']=='exact' and all(probe[k]['status']!='exact' for k in ['counts','unitOrder','itemOrder','badProtocol','missingProtocol','archiveExtra','engineInternalMismatch']) and probe['incompatible']['status']=='incompatible' and probe['verify']['status']=='verified-exact' and all(not e for e in schemas.values()))
    d4=(probe['topicPresentation']['assessmentExact'] is True and probe['topicPresentation']['presentationExact'] is False and probe['ambientC2']['presentationExact']==probe['ambientCA']['presentationExact']==True)
    transport_text=''.join([probe['helpTransport'],probe['mainTransport'],probe['classTransport']]); d5=(all(not x['hasDiagnostics'] for x in probe['submitBodies']) and '"diagnostics"' not in transport_text)
    d6=all(v.get('ok') is False and v.get('mismatches') for v in probe['diagMutations'].values())
    d7=(actual_explicit==expected_explicit and all(src in ('explicit','mixed') for gid,src in probe['metadataSources']) and len(probe['metadataSources'])==8)
    d8=(not probe['profileMissing']['ok'] and not probe['profileAlias']['ok'] and probe['crosswalkClass']=='major' and probe['profileVersionFirst']['ok'] and probe['profileVersionClass']=='major' and not probe['profileVersionSecond']['ok'] and probe['profileVersionSecond'].get('code')=='profile-version-understates-change')
    manifest=json.loads((DIST/'EquationWright_Build_Manifest_v1.json').read_text()); extfiles={x['path'] for x in manifest.get('extensions',{}).get('org.equationwright.build-inputs-v1',{}).get('files',[])}
    d9=(ROOT/'RELEASE_NOTES_v7_3.md').is_file() and (DIST/'RELEASE_NOTES_v7_3.md').is_file() and 'RELEASE_NOTES_v7_3.md' in extfiles
    checks={
      'P4C-D1': d1['criticalMutationChangesId'] and d1['generatorReorderRejected'] and d1['manifestInputHashes'],
      'P4C-D2': d2,'P4C-D3':d3,'P4C-D4':d4,'P4C-D5':d5,'P4C-D6':d6,'P4C-D7':d7,'P4C-D8':d8,'P4C-D9':d9,
    }
    out={'format':'equationwright-pass4c-high-focused-d1-d9-v1','candidate':APP.name,'candidateSha256':sha(APP),'checks':checks,'passed':sum(checks.values()),'failed':sum(not x for x in checks.values()),'detail':{'d1':d1,'browser':probe,'replayReportSchemaErrors':schemas,'expectedExplicitMetadataSourceIds':sorted(expected_explicit),'releaseNotes':{'source':str(ROOT/'RELEASE_NOTES_v7_3.md'),'dist':str(DIST/'RELEASE_NOTES_v7_3.md'),'manifestReferenced':'RELEASE_NOTES_v7_3.md' in extfiles}}}
    OUT.write_text(json.dumps(out,indent=2),encoding='utf-8'); print(json.dumps({'passed':out['passed'],'failed':out['failed'],'checks':checks,'pageErrors':probe['pageErrors'],'d1':d1},indent=2))
    return 0 if out['failed']==0 and not probe['pageErrors'] else 1
if __name__=='__main__': raise SystemExit(main())
