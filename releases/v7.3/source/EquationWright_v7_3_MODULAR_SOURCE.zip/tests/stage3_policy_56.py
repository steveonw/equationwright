from playwright.sync_api import sync_playwright
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'dist/Math_Worksheet_Builder_v7_3_0_FULL_CATALOG.html').read_text(encoding='utf-8')
js=(ROOT/'tests/data/pass3c_policy_matrix.js').read_text(encoding='utf-8')
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium')
 pg=b.new_page(); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)));pg.route('**/*',lambda r:r.abort());pg.set_content(html,wait_until='domcontentloaded',timeout=30000);pg.wait_for_function("typeof buildLocalRemediationBlueprint==='function'")
 out=pg.evaluate(js);out['pageErrors']=errs
 (ROOT/'dist/test-evidence').mkdir(parents=True,exist_ok=True)
 (ROOT/'dist/test-evidence/EquationWright_Pass_4B_Stage3_Policy_1_56.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
 print(json.dumps({'passed':out['passed'],'failed':out['failed'],'failures':[x for x in out['results'] if not x['pass']],'pageErrors':errs},indent=2,ensure_ascii=False))
 b.close()
