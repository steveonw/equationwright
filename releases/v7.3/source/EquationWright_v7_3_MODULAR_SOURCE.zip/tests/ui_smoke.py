#!/usr/bin/env python3
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'dist/Math_Worksheet_Builder_v7_3_0_FULL_CATALOG.html').read_text(encoding='utf-8')
OUT=ROOT/'dist/test-evidence/EquationWright_Pass_4B_UI_Smoke.json'
MOCK=r'''(()=>{const mk=()=>{const m=new Map();return {getItem:k=>m.has(String(k))?m.get(String(k)):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),key:i=>[...m.keys()][i]??null,get length(){return m.size;}}};Object.defineProperty(window,'localStorage',{value:mk(),configurable:true});Object.defineProperty(window,'sessionStorage',{value:mk(),configurable:true});})()'''

def main():
    OUT.parent.mkdir(parents=True,exist_ok=True)
    with sync_playwright() as w:
        b=w.chromium.launch(headless=True,executable_path='/usr/bin/chromium')
        p=b.new_page(viewport={'width':1440,'height':1000}); errors=[]
        p.on('pageerror',lambda e:errors.append(str(e))); p.evaluate(MOCK); p.route('**/*',lambda r:r.abort())
        p.set_content(APP,wait_until='domcontentloaded',timeout=30000); p.wait_for_function("typeof renderSheet==='function' && typeof aiCallTutor==='function'",timeout=30000)
        out={}
        # Teacher/Student mode and ordinary quiz generation.
        out['teacherInitial']=p.evaluate("!document.body.classList.contains('studentMode') && document.getElementById('userModeTeacher').classList.contains('active')")
        p.click('#userModeStudent'); out['student']=p.evaluate("document.body.classList.contains('studentMode') && document.getElementById('toggleQuizMode').checked && !document.getElementById('toggleAnswers').checked && !document.getElementById('toggleSolutions').checked")
        p.click('#userModeTeacher'); out['teacherReturn']=p.evaluate("!document.body.classList.contains('studentMode') && document.getElementById('userModeTeacher').classList.contains('active')")
        out['quiz']=p.evaluate(r'''(()=>{document.getElementById('modeSelect').value='CA';buildCoveragePills();buildUnitControls();countInputs.forEach(x=>x.value=0);countInputs[0].value=2;countInputs[1].value=1;document.getElementById('seedInput').value='P4B-UI-SMOKE';document.getElementById('toggleQuizMode').checked=true;document.getElementById('toggleAnswers').checked=false;document.getElementById('toggleSolutions').checked=false;renderSheet();return {count:LAST_QUESTIONS.length,mc:LAST_QUESTIONS.every(x=>x.type==='mc'),actions:!!document.getElementById('quizActions'),score:!!document.getElementById('quizScore')};})()''')
        # Scratchpad open/close.
        p.click('#scratchLaunch'); p.wait_for_timeout(50); out['scratchOpen']=p.evaluate("getComputedStyle(document.getElementById('scratchPanel')).display !== 'none' && document.getElementById('scratchCanvas').width>0")
        p.click('#spClose'); out['scratchClosed']=p.evaluate("getComputedStyle(document.getElementById('scratchPanel')).display === 'none'")
        # Print hook and print CSS smoke.
        out['print']=p.evaluate(r'''(()=>{let n=0;window.print=()=>n++;document.getElementById('printBtn').click();return {called:n===1,questions:!!document.getElementById('pageQuestions')};})()''')
        p.emulate_media(media='print'); out['printCss']=p.evaluate("getComputedStyle(document.getElementById('quizActions')).display==='none'"); p.emulate_media(media='screen')
        # Keyless local OpenAI-compatible transport.
        out['localAI']=p.evaluate(r'''(async()=>{const sel=document.getElementById('aiProviderSel');sel.value='openai_compat';sel.dispatchEvent(new Event('change',{bubbles:true}));document.getElementById('aiEndpointInput').value='http://127.0.0.1:11434/v1/chat/completions';document.getElementById('aiKeyInput').value='';let seen=null;const old=fetch;window.fetch=async(u,o)=>{seen={url:String(u),auth:o.headers.Authorization||null};return {ok:true,status:200,json:async()=>({choices:[{message:{content:'{"diagnosis":"Local smoke ok","blueprint":null}'}}]})};};let reply=null,err=null;try{reply=await aiCallTutor(buildResultsJSON())}catch(e){err=String(e)}finally{window.fetch=old}return {seen,reply,err};})()''')
        # Hosted provider UI/config remains present (transport itself already covered by D1-D6).
        out['aiUI']=p.evaluate("!!document.getElementById('aiProviderSel') && !!document.getElementById('aiKeyInput') && !!document.getElementById('qaAskTutor')")
        # Mobile layout after switching viewport.
        p.set_viewport_size({'width':390,'height':844}); p.wait_for_timeout(100)
        out['mobile']=p.evaluate("({scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth,scratchLaunch:!!document.getElementById('scratchLaunch'),genVisible:getComputedStyle(document.getElementById('genBtn')).display!=='none'})")
        out['pageErrors']=errors
        passed=(out['teacherInitial'] and out['student'] and out['teacherReturn'] and out['quiz']['count']==3 and out['quiz']['mc'] and out['quiz']['actions'] and out['quiz']['score'] and out['scratchOpen'] and out['scratchClosed'] and out['print']['called'] and out['printCss'] and out['localAI']['err'] is None and out['localAI']['seen']['auth'] is None and out['localAI']['reply']['diagnosis']=='Local smoke ok' and out['aiUI'] and out['mobile']['scrollWidth']<=out['mobile']['clientWidth']+2 and out['mobile']['genVisible'] and not errors)
        out['passed']=passed
        OUT.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
        print(json.dumps({'passed':passed,'teacherStudent':{'teacherInitial':out['teacherInitial'],'student':out['student'],'teacherReturn':out['teacherReturn']},'quiz':out['quiz'],'scratch':{'open':out['scratchOpen'],'closed':out['scratchClosed']},'print':out['print'],'printCss':out['printCss'],'localAI':out['localAI'],'mobile':out['mobile'],'pageErrors':errors},indent=2,ensure_ascii=False))
        b.close(); return 0 if passed else 1

if __name__=='__main__': raise SystemExit(main())
