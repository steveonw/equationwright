function humanizeTopicId(id){
  const s = (id||'').toString().trim();
  if(!s) return 'Misc';
  const overrides = {
    rr:'Related Rates',
    mvt:'Mean Value Theorem',
    ibp:'Integration by Parts',
    trigsub:'Trig Substitution',
    partial:'Partial Fractions',
    diffq:'Differential Equations',
    taylor:'Taylor/Maclaurin',
    polar:'Polar',
    param:'Parametric',
    arc:'Arc Length',
    unit:'Unit Circle',
    coterminal:'Coterminal Angles',
    pythag:'Pythagorean Identities'
  };
  const key = s.toLowerCase();
  if(overrides[key]) return overrides[key];
  return s.replace(/[-_]+/g,' ').replace(/\b\w/g, ch => ch.toUpperCase());
}
const UNIT_TOPIC_LABEL_OVERRIDES = Object.freeze({
  'AC2_Multivar|partial': 'Partial Derivatives',
  'D289_Transforms|unit': 'Unit-Step Functions',
  'PC_Vectors|unit': 'Unit Vectors'
});
function topicLabelFor(unitId, topicId, fallback=''){
  const override = UNIT_TOPIC_LABEL_OVERRIDES[`${unitId}|${topicId}`];
  return override || fallback || humanizeTopicId(topicId);
}
function ensureTopicSet(unitId){
  if(!topicFilters[unitId]) topicFilters[unitId] = new Set();
  return topicFilters[unitId];
}
function inferUnitTopicScheme(unitId){
  if(UNIT_TOPIC_SCHEME[unitId]) return UNIT_TOPIC_SCHEME[unitId];
  const gens = Gens[unitId] || [];
  const majors = new Set();
  for(const fn of gens){
    try{
      const rng = xorshift32(fnv1a('meta|' + unitId + '|' + (fn.name||'anon')));
      const p = fn(rng);
      const key = (p && p.key) ? String(p.key) : '';
      const parts = key.split('_').filter(Boolean);
      if(parts.length >= 2) majors.add(parts[1]);
    }catch(e){}
  }
  const dropMajor = (majors.size <= 2) && gens.length >= 4;
  UNIT_TOPIC_SCHEME[unitId] = { dropMajor };
  return UNIT_TOPIC_SCHEME[unitId];
}
function deriveTopicKeyFromKey(unitId, key){
  const parts = String(key||'').split('_').filter(Boolean);
  if(parts.length < 2) return (parts[0] || 'misc');
  const scheme = inferUnitTopicScheme(unitId);
  if(scheme.dropMajor && parts.length >= 3) return parts[2];
  return parts[1];
}
function ensureGenTopicMeta(unitId, fn){
  if(!fn) return 'misc';

  // Explicit generator metadata is authoritative. Returned problem metadata is
  // next-best; key-name inference is only the fallback. Always register the
  // result in TOPIC_META so manually tagged generators appear in the UI.
  const declaredMeta = !!(fn.meta && fn.meta.topicId);
  let topicId = declaredMeta ? String(fn.meta.topicId) : '';
  let topicLabel = declaredMeta && fn.meta.topicLabel ? String(fn.meta.topicLabel) : '';

  if(!topicId){
    try{
      const rng = xorshift32(fnv1a('meta2|' + unitId + '|' + (fn.name||'anon')));
      const p = fn(rng);
      if(p && p.meta && p.meta.topicId){
        topicId = String(p.meta.topicId);
        topicLabel = p.meta.topicLabel ? String(p.meta.topicLabel) : humanizeTopicId(topicId);
      }else{
        const key = (p && p.key) ? String(p.key) : '';
        topicId = deriveTopicKeyFromKey(unitId, key);
        topicLabel = humanizeTopicId(topicId);
      }
    }catch(e){}
  }

  topicId = topicId || 'misc';
  topicLabel = topicLabelFor(unitId, topicId, topicLabel) || 'Misc';
  // Keep fn.meta reserved for metadata that was authored on the generator.
  // Derived or returned-problem metadata is registered in TOPIC_META without
  // masquerading as function-declared metadata.
  if(declaredMeta){
    fn.meta.topicId = topicId;
    fn.meta.topicLabel = topicLabel;
  }

  if(!TOPIC_META[unitId]) TOPIC_META[unitId] = {};
  if(!TOPIC_META[unitId][topicId]){
    TOPIC_META[unitId][topicId] = { id: topicId, label: topicLabel };
  }
  return topicId;
}
function ensureUnitTopics(unitId){
  const gens = Gens[unitId] || [];
  for(const fn of gens) ensureGenTopicMeta(unitId, fn);
  const topicsObj = TOPIC_META[unitId] || {};
  const topics = Object.values(topicsObj).sort((a,b)=>a.label.localeCompare(b.label));
  return topics;
}


for(const u of UNITS) Gens[u.id] = [];

function registerGen(unitId, genFn){
  if(!Gens[unitId]) Gens[unitId] = [];
  // Preserve whether topic metadata was explicitly attached by source code before
  // ensureGenTopicMeta() fills the runtime cache. Capability discovery uses this
  // immutable observation rather than mistaking inferred cache metadata for authored metadata.
  try{ genFn._ewDeclaredTopicMetaAtRegistration = !!(genFn.meta && genFn.meta.topicId); }catch(e){}
  Gens[unitId].push(genFn);
}

function unitIndex(unitId){
  const idx = UNITS.findIndex(u => u.id === unitId);
  return idx >= 0 ? idx : 99;
}
function unitLabel(id){
  if(typeof mwProfileUnitLabel === 'function' && typeof EW_ACTIVE_PROFILE !== 'undefined' && EW_ACTIVE_PROFILE) return mwProfileUnitLabel(id);
  const u = UNITS.find(x=>x.id===id);
  return u ? u.label : id;
}

// =======================================================
// CALC 1 GENERATORS (merged + expanded)
// =======================================================

// Limits: polynomial substitution
