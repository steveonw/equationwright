const UNITS = [
  // ---- Math for Health Professions (MTH 133) ----
  { course:'HP', id:'HP_Conversion', label:'Dimensional Analysis & Conversions', defaultCount:2 },
  { course:'HP', id:'HP_Dosage',     label:'Dosage Calculations',                defaultCount:2 },
  { course:'HP', id:'HP_IVRates',    label:'IV Rates & Solutions',               defaultCount:2 },
  // ---- Probability & Statistics (MTH 283) ----
  { course:'P283', id:'P283_Continuous', label:'Continuous Random Variables',      defaultCount:2 },
  { course:'P283', id:'P283_ExpNormal',  label:'Exponential & Normal Models',      defaultCount:2 },
  { course:'P283', id:'P283_CLT_Est',    label:'CLT & Estimation',                 defaultCount:2 },
  { course:'P283', id:'P283_LSQ',        label:'Least Squares & Correlation',      defaultCount:2 },
  // ---- Statistics I (MTH 245) ----
  { course:'S245', id:'S245_Probability', label:'Probability Rules',                defaultCount:2 },
  { course:'S245', id:'S245_Binomial',    label:'Binomial Distribution',            defaultCount:2 },
  { course:'S245', id:'S245_Sampling',    label:'Sampling Distributions & CLT',     defaultCount:2 },
  { course:'S245', id:'S245_Inference',   label:'Confidence Intervals & Tests',     defaultCount:2 },
  // ---- Statistical Reasoning (MTH 155) ----
  { course:'S155', id:'S155_Descriptive', label:'Descriptive Statistics',          defaultCount:2 },
  { course:'S155', id:'S155_Normal',      label:'Normal Distribution & z-Scores',  defaultCount:3 },
  { course:'S155', id:'S155_Correlation', label:'Correlation & Causation',         defaultCount:2 },
  { course:'S155', id:'S155_Inference',   label:'Intervals & p-Values',            defaultCount:2 },
  // ---- Statistics II (MTH 246) ----
  { course:'ST2', id:'ST2_ChiSquare',  label:'Chi-Square Tests',                 defaultCount:2 },
  { course:'ST2', id:'ST2_ANOVA',      label:'Analysis of Variance',             defaultCount:2 },
  { course:'ST2', id:'ST2_Regression', label:'Regression & r²',                  defaultCount:2 },
  { course:'ST2', id:'ST2_Design',     label:'Experimental Design & Non-Parametrics', defaultCount:2 },
  // ---- Quantitative Reasoning (MTH 154) ----
  { course:'QR', id:'QR_Proportion', label:'Proportional Reasoning',        defaultCount:2 },
  { course:'QR', id:'QR_Finance',    label:'Financial Literacy',            defaultCount:2 },
  { course:'QR', id:'QR_Logic',      label:'Logic & Sets (Validity)',       defaultCount:2 },
  { course:'QR', id:'QR_Modeling',   label:'Linear Modeling',               defaultCount:2 },
  // ---- Applied Calculus I (MTH 261) ----
  { course:'AC1', id:'AC1_Marginal',   label:'Marginal Analysis',              defaultCount:2 },
  { course:'AC1', id:'AC1_Elasticity', label:'Elasticity of Demand',           defaultCount:2 },
  { course:'AC1', id:'AC1_Finance',    label:'Continuous Growth & Finance',    defaultCount:2 },
  // ---- Applied Calculus II (MTH 262) ----
  { course:'AC2', id:'AC2_IntApps',    label:'Integration Applications',       defaultCount:2 },
  { course:'AC2', id:'AC2_Multivar',   label:'Multivariable Basics',           defaultCount:2 },
  // ---- Differential Equations (MTH 267) ----
  { course:'DE', id:'DE_Basics',       label:'Classification & Qualitative Behavior', defaultCount:2 },
  { course:'DE', id:'DE_Methods',      label:'Separable & Linear Methods',            defaultCount:3 },
  { course:'DE', id:'DE_AppsNum',      label:"Applications & Euler's Method",         defaultCount:2 },
  { course:'DE', id:'DE_SecondOrder',  label:'Second-Order Linear Equations',         defaultCount:2 },
  { course:'DE', id:'DE_Laplace',      label:'Laplace Transforms',                    defaultCount:2 },
  // ---- Discrete Mathematics (MTH 288) ----
  { course:'DM', id:'DM_Logic',        label:'Logic, Truth Tables & Quantifiers',       defaultCount:2 },
  { course:'DM', id:'DM_Sets',         label:'Sets & Set Operations',                  defaultCount:2 },
  { course:'DM', id:'DM_Counting',     label:'Counting & Combinatorics',               defaultCount:2 },
  { course:'DM', id:'DM_RelFunc',      label:'Relations & Functions',                  defaultCount:2 },
  { course:'DM', id:'DM_Graphs',       label:'Graphs & Trees',                         defaultCount:2 },
  { course:'DM', id:'DM_ProofRec',     label:'Proofs, Growth & Recurrences',            defaultCount:2 },
  // ---- Differential Equations of Mathematical Physics (MTH 289) ----
  { course:'D289', id:'D289_FirstOrder', label:'Typed First-Order IVP Review',          defaultCount:2 },
  { course:'D289', id:'D289_Systems',    label:'Systems of Differential Equations',     defaultCount:2 },
  { course:'D289', id:'D289_Series',     label:'Power-Series Solutions',                defaultCount:2 },
  { course:'D289', id:'D289_Fourier',    label:'Fourier Series',                        defaultCount:2 },
  { course:'D289', id:'D289_Transforms', label:'Laplace Transforms II',                 defaultCount:2 },
  { course:'D289', id:'D289_PDE',        label:'PDE Classification & Separation',       defaultCount:2 },
  { course:'D289', id:'D289_BVP',        label:'Boundary-Value Eigenproblems',           defaultCount:2 },
  // ---- Linear Algebra (MTH 266) ----
  { course:'LA', id:'LA_Systems',      label:'Solving Linear Systems',                defaultCount:2 },
  { course:'LA', id:'LA_RowRed',       label:'Row Operations & RREF',                 defaultCount:2 },
  { course:'LA', id:'LA_SolutionSets', label:'Solution Sets & Rank',                  defaultCount:2 },
  { course:'LA', id:'LA_MatrixAlg',    label:'Matrix Algebra & Determinants',         defaultCount:2 },
  { course:'LA', id:'LA_Eigen',        label:'Eigenvalues & Vector Spaces',           defaultCount:2 },
  // ---- College Algebra ----
  { course:'CA', id:'CA_Linear',         label:'Linear Equations & Inequalities',  defaultCount:2 },
  { course:'CA', id:'CA_Quadratics',     label:'Quadratic Functions',              defaultCount:3 },
  { course:'CA', id:'CA_Polynomials',    label:'Polynomial Functions',             defaultCount:2 },
  { course:'CA', id:'CA_Rational',       label:'Rational Functions',               defaultCount:2 },
  { course:'CA', id:'CA_ExpLog',         label:'Exponential & Logarithmic',        defaultCount:3 },
  { course:'CA', id:'CA_Systems',        label:'Systems of Equations',             defaultCount:2 },
  { course:'CA', id:'CA_Functions',      label:'Function Operations',              defaultCount:2 },

  // ---- Trigonometry ----
  { course:'TRIG', id:'TRIG_Angles',     label:'Angle Conversions',                defaultCount:2 },
  { course:'TRIG', id:'TRIG_UnitCircle', label:'Unit Circle & Trig Values',        defaultCount:3 },
  { course:'TRIG', id:'TRIG_Identities', label:'Trig Identities',                  defaultCount:3 },
  { course:'TRIG', id:'TRIG_Equations',  label:'Solving Trig Equations',           defaultCount:2 },
  { course:'TRIG', id:'TRIG_Triangle',   label:'Law of Sines & Cosines',           defaultCount:2 },
  { course:'TRIG', id:'TRIG_Polar',      label:'Polar Coordinates',                defaultCount:2 },

  // ---- Pre-Calculus (combines above + adds topics) ----
  { course:'PC', id:'PC_Conics',         label:'Conic Sections',                   defaultCount:2, also:['TRIG'] },
  { course:'PC', id:'PC_Sequences',      label:'Sequences & Series',               defaultCount:2 },
  { course:'PC', id:'PC_Vectors',        label:'Vectors (Intro)',                  defaultCount:2 },

  // ---- Calc 1 ----
  { course:'C1', id:'C1_Limits',        label:'Limits',                 defaultCount:2 },
  { course:'C1', id:'C1_Continuity',    label:'Continuity',             defaultCount:1 },
  { course:'C1', id:'C1_Derivatives',   label:'Derivatives',            defaultCount:3 },
  { course:'C1', id:'C1_Apps',          label:'Derivative Applications',defaultCount:2 },
  { course:'C1', id:'C1_Integrals',     label:'Integrals (Intro)',      defaultCount:3 },

  // ---- Calc 2 ----
  { course:'C2', id:'C2_Tech',          label:'Integration Techniques',  defaultCount:3 },
  { course:'C2', id:'C2_Improper',      label:'Improper Integrals',      defaultCount:2 },
  { course:'C2', id:'C2_Series',        label:'Sequences & Series',      defaultCount:3 },
  { course:'C2', id:'C2_ParamPolar',    label:'Parametric / Polar',      defaultCount:2 },
  { course:'C2', id:'C2_AppsInt',       label:'Applications of Integration', defaultCount:2 },

  // ---- Calc 3 ----
  { course:'C3', id:'C3_Vectors',       label:'Vectors & Geometry',      defaultCount:3 },
  { course:'C3', id:'C3_Partials',      label:'Partial Derivatives',     defaultCount:3 },
  { course:'C3', id:'C3_MultInt',       label:'Multiple Integrals',      defaultCount:2 },
  { course:'C3', id:'C3_VecCalc',       label:'Vector Calculus',         defaultCount:2 },
];

// Problem banks live here
const Gens = Object.create(null);

const TOPIC_META = {};

// Generator error tracking (prevents one bad generator from breaking the whole worksheet)
let GEN_ERROR_COUNT = 0;
let GEN_ERROR_SAMPLES = [];
          // { unitId: { topicId: {id,label} } }
const UNIT_TOPIC_SCHEME = {};   // { unitId: { dropMajor: boolean } }
const topicFilters = Object.create(null); // { unitId: Set(topicId) }, empty Set => "all"
const countInputs = []; // refs to unit count <input> elements
let activeTopicUnit = null;

