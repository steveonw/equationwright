// Build-time data injection. registry/ is the source of truth.
const EW_GENERATOR_REGISTRY = /*__EW_GENERATOR_REGISTRY__*/ null;
const EW_OBSERVED_GENERATORS = /*__EW_OBSERVED_GENERATORS__*/ null;
