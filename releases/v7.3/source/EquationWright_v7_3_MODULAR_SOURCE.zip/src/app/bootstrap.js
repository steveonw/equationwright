function mwInstallStage4UI(){
  mwInstallGeneratorRegistry(); mwAssertCatalogDigest(); mwInstallBuiltInProfiles();
  const modeSel=document.getElementById('modeSelect'); const startingMode=modeSel?.value||'C2'; mwRefreshProfileSelect(); mwRefreshModeOptions(startingMode);
  const profileSel=document.getElementById('ewProfileSelect'); if(profileSel)profileSel.addEventListener('change',()=>{const [id,...rest]=profileSel.value.split('@');mwActivateProfile(id,rest.join('@')||'1.0.0',{preserveMode:true});renderSheet();});
  document.getElementById('ewImportProfileBtn')?.addEventListener('click',()=>document.getElementById('ewImportProfileFile')?.click());
  document.getElementById('ewImportProfileFile')?.addEventListener('change',async ev=>{const files=[...(ev.target.files||[])];const parsed=[];for(const f of files){try{parsed.push(JSON.parse(await f.text()));}catch(e){alert(`Could not parse ${f.name}.`);}} parsed.sort((a,b)=>mwLexCompare(a.profileId||'',b.profileId||'')||mwLexCompare(a.profileVersion||'',b.profileVersion||'')||mwLexCompare(a.profileDigest||'',b.profileDigest||''));for(const p of parsed){const v=mwRegisterCustomProfile(p);if(!v.ok)alert('Profile rejected: '+v.message);}ev.target.value='';});
  document.getElementById('ewExportCapabilitiesBtn')?.addEventListener('click',mwExportCapabilities);
  document.getElementById('ewExportArchiveBtn')?.addEventListener('click',mwExportArchive);
  document.getElementById('ewImportArchiveBtn')?.addEventListener('click',()=>document.getElementById('ewImportArchiveFile')?.click());
  document.getElementById('ewImportArchiveFile')?.addEventListener('change',ev=>{const f=ev.target.files?.[0];if(f)mwImportArchiveFile(f);ev.target.value='';});
  document.getElementById('ewVerifyCurrentBtn')?.addEventListener('click',mwVerifyCurrentArchive);
}


EW.protocol={canonicalJSON:mwCanonicalJSON,digestValue:mwDigestValue,engineFingerprint:mwEngineFingerprint,buildCapabilities:mwBuildCapabilitiesManifest,buildSlim:mwBuildSlimBlueprint,buildArchive:mwBuildArchiveBlueprint,buildDiagnostics:mwBuildDiagnosticProvenance,replayDiagnostics:mwReplayDiagnosticProvenance,replay:mwReplayArchive,validateProfile:mwValidateCurriculumProfile,classifyProfileChange:mwClassifyProfileChange,generatorById:mwGeneratorById};

document.getElementById('selfTestBtn').addEventListener('click', runSelfTest);
document.getElementById('selfTestReplayBtn')?.addEventListener('click', ()=>selfTestReplayFailure(0));
document.getElementById('selfTestCopyBtn')?.addEventListener('click', selfTestCopyFirstFailure);
document.getElementById('randomBtn').addEventListener('click', () => {
  document.getElementById('seedInput').value = "Seed-" + Math.floor(Math.random()*1e9);
  renderSheet();
});
document.getElementById('varietyInput').addEventListener('input', () => { updateVarietyLabel(); renderSheet(); });

// Re-render on mode/page toggles
if(document.getElementById('toggleQuizMode')) document.getElementById('toggleQuizMode').addEventListener('change', renderSheet);
if(document.getElementById('toggleAnswers')) document.getElementById('toggleAnswers').addEventListener('change', renderSheet);
if(document.getElementById('toggleSolutions')) document.getElementById('toggleSolutions').addEventListener('change', renderSheet);


document.getElementById('modeSelect').addEventListener('change', () => {
  buildCoveragePills();
  buildUnitControls();
  renderSheet();
});
document.addEventListener('input', (e)=>{ if(e.target && e.target.classList && e.target.classList.contains('count-in')) renderSheet(); });

// Quiz mode (MC) answer clicks
document.addEventListener('click', (e)=>{
  const btn = (e.target && e.target.closest) ? e.target.closest('.quiz-choice-btn') : null;
  if(!btn) return;
  const q = parseInt(btn.dataset.q||'-1', 10);
  const c = parseInt(btn.dataset.choice||'-1', 10);
  if(q>=0 && c>=0) checkQuizAnswer(q, c);
});

// =====================
// localStorage Persistence
// =====================
function getEls(){
  return {
    seedInput: document.getElementById('seedInput'),
    modeSelect: document.getElementById('modeSelect'),
    varietyInput: document.getElementById('varietyInput'),
    toggleQuizMode: document.getElementById('toggleQuizMode'),
    toggleAnswers: document.getElementById('toggleAnswers'),
    toggleSolutions: document.getElementById('toggleSolutions')
  };
}

function saveState(){
  const { seedInput, modeSelect, varietyInput, toggleQuizMode, toggleAnswers, toggleSolutions } = getEls();

  const counts = {};
  countInputs.forEach(inp => counts[inp.dataset.unit] = +inp.value||0);

  const topicsOut = {};
  for(const [unitId, set] of Object.entries(topicFilters)){
    const sel = ensureTopicSet(unitId);
    topicsOut[unitId] = { list: Array.from(sel), none: !!sel.__none };
  }

  const state = {
    seed: (seedInput?.value || '').trim(),
    mode: modeSelect?.value || 'MIX',
    variety: +(varietyInput?.value || 1) || 1,
    showAnswers: !!(toggleAnswers?.checked),
    showSolutions: !!(toggleSolutions?.checked),
    quizMode: !!(toggleQuizMode?.checked),
    counts,
    topics: topicsOut
  };
  try{ localStorage.setItem('worksheetState', JSON.stringify(state)); }catch(e){}
}


function loadState(){
  let raw = null;
  try{ raw = localStorage.getItem('worksheetState'); }catch(e){ raw = null; }
  if(!raw) return false;
  try{
    const s = JSON.parse(raw);
    const { seedInput, modeSelect, varietyInput, toggleQuizMode, toggleAnswers, toggleSolutions } = getEls();

    if(s.seed!=null && seedInput) seedInput.value = s.seed;
    if(s.mode && modeSelect) modeSelect.value = s.mode;

    // Build pills & unit controls for the selected course first so inputs exist
    buildCoveragePills();
    buildUnitControls();

    if(s.variety!=null && varietyInput) varietyInput.value = s.variety;
    if(toggleAnswers) toggleAnswers.checked = !!s.showAnswers;
    if(toggleSolutions) toggleSolutions.checked = !!s.showSolutions;
    if(toggleQuizMode) toggleQuizMode.checked = !!s.quizMode;

    if(s.counts){
      countInputs.forEach(inp=>{
        const v = s.counts[inp.dataset.unit];
        if(v!=null) inp.value = v;
      });
    }

    if(s.topics){
      for(const [unitId, rec] of Object.entries(s.topics)){
        const sel = ensureTopicSet(unitId);
        sel.clear();
        if(rec && Array.isArray(rec.list)) rec.list.forEach(x=>sel.add(x));
        if(rec && rec.none) sel.__none = true;
        else delete sel.__none;
      }
    }

    // Update topic pills for visible units
    visibleUnits().forEach(u=>updateTopicUI(u.id));

    return true;
  }catch(e){
    console.warn('Failed to load state', e);
    return false;
  }
}


// Auto-save on changes
window.addEventListener('beforeunload', saveState);
document.addEventListener('change', saveState);

// init
updateVarietyLabel();
if(typeof mwInstallStage4UI === 'function') mwInstallStage4UI();
const stateLoaded = loadState();
if(!stateLoaded){
  buildCoveragePills();
  buildUnitControls();
}
renderSheet();

// Student mode must win over any stale saved toggles (loadState runs after the
// early mode restore, so re-enforce here — the change listeners are wired now).
try{
  if(localStorage.getItem('MW_USER_MODE') === 'student'){
    const needsRerender = !document.getElementById('toggleQuizMode').checked
      || document.getElementById('toggleAnswers').checked
      || document.getElementById('toggleSolutions').checked;
    setUserMode('student');
    if(needsRerender) renderSheet();
  }
}catch(e){}
