// C1 generator registrations — order frozen by the published registry.
registerGen('C1_Limits', (rng)=> {
  const a = randInt(rng,-3,4);
  const b = randInt(rng,1,7);
  const c = randInt(rng,0,7);
  const val = a*a + b*a + c;
  return {
    q: `Compute \\(\\lim_{x\\to ${a}}(x^2+${b}x+${c})\\).`,
    a: `\\(${val}\\)`,
    steps: [
      `Polynomials are continuous; substitute \\(x=${a}\\).`,
      `\\(${a}^2+${b}\\cdot${a}+${c}=${val}\\).`
    ],
    vec: [unitIndex('C1_Limits'), 1, a, b, c],
    key:'c1_limit_poly'
  };
});
registerGen('C1_Limits', (rng)=> {
  const a = (randInt(rng,-4,5) || 2);
  const m = randInt(rng,1,5);
  const xa = parenXMinus(a);
  const val = a + m;
  return {
    q: `Compute \\(\\lim_{x\\to ${a}} \\frac{${xa}(x+${m})}{${xa}}\\).`,
    a: `\\(${val}\\)`,
    steps: [
      `For \\(x\\ne ${a}\\), cancel ${xa}.`,
      `Then substitute \\(x=${a}\\): \\(${a}+${m}=${val}\\).`
    ],
    vec: [unitIndex('C1_Limits'), 2, a, m],
    key:'c1_limit_cancel'
  };
});
registerGen('C1_Limits', (rng)=> {
  const a = randInt(rng,1,6);
  const b = randInt(rng,1,9);
  const c = randInt(rng,1,6);
  const d = randInt(rng,1,9);
  // (ax^2 + bx + ...)/(cx^2 + dx + ...) -> a/c
  const g = gcd(a,c);
  const num = a/g, den = c/g;
  return {
    q: `Compute \\(\\lim_{x\\to\\infty}\\frac{${a}x^2+${b}x+1}{${c}x^2+${d}x+1}\\).`,
    a: simpFrac(a,c),
    steps: [
      `Divide numerator and denominator by \\(x^2\\).`,
      `As \\(x\\to\\infty\\), the lower-order terms go to 0.`,
      `Limit is ratio of leading coefficients: \\(${a}/${c}\\).`
    ],
    vec: [unitIndex('C1_Limits'), 3, a, b, c, d],
    key:'c1_limit_infty'
  };
});
registerGen('C1_Continuity', (rng)=> {
  const a = (randInt(rng,-3,4) || 2);
  const xa = parenXMinus(a);
  const xpa = termXPlus(a);
  const k = 2*a;
  const aSquared = Math.abs(a * a);
  
  return {
    q: `Let \\(f(x)=\\begin{cases}\\frac{x^2-${aSquared}}{${xa}}, & x\\ne ${a}\\\\ k, & x=${a}\\end{cases}\\). Find \\(k\\) so that \\(f\\) is continuous at \\(x=${a}\\).`,
    a: `\\(${k}\\)`,
    steps: [
      `Continuity needs \\(k=\\lim_{x\\to ${a}}\\frac{x^2-${aSquared}}{${xa}}\\).`,
      `Factor: \\(x^2-${aSquared}=${xa}(${xpa})\\); cancel.`,
      `Limit becomes \\(\\lim_{x\\to ${a}}(x${fmtSigned(a)})=${a}${fmtSigned(a)}=${k}\\).`
    ],
    vec: [unitIndex('C1_Continuity'), 1, a],
    key:'c1_cont_piecewise'
  };
});
registerGen('C1_Derivatives', (rng)=> {
  const m = randInt(rng,2,6);
  const a = randInt(rng,2,7);
  const mMinus1 = m - 1;
  const expStr = mMinus1 === 1 ? '' : `^{${mMinus1}}`;  // Don't show ^{1}
  
  return {
    q: `Find \\(\\frac{d}{dx}\\big(x^{${m}}\\sin(${a}x)\\big)\\).`,
    a: `\\(${m}x^{${m-1}}\\sin(${a}x)+${a}x^{${m}}\\cos(${a}x)\\)`,
    steps: [
      `Product rule: \\((uv)'=u'v+uv'\\).`,
      `\\(u=x^{${m}}\\Rightarrow u'=${m}x${expStr}\\), \\(v=\\sin(${a}x)\\Rightarrow v'=${a}\\cos(${a}x)\\).`,
      `Combine terms.`
    ],
    vec: [unitIndex('C1_Derivatives'), 1, m, a],
    key:'c1_deriv_product'
  };
});
registerGen('C1_Derivatives', (rng)=> {
  const a = randInt(rng,1,5);
  let c = randInt(rng,1,5);
  if (c === 1) c = 2;
  // f(x) = e^{ax} ln(cx)
  return {
    q: `Differentiate \\(f(x)=e^{${a}x}\\ln(${c}x)\\).`,
    a: `\\(f'(x)=e^{${a}x}\\left(${a}\\ln(${c}x)+\\frac{1}{x}\\right)\\)`,
    steps: [
      `Use product rule with \\(u=e^{${a}x}\\) and \\(v=\\ln(${c}x)\\).`,
      `\\(u'=${a}e^{${a}x}\\), \\(v'=\\frac{1}{x}\\).`,
      `So \\(f'=u'v+uv'=e^{${a}x}\\left(${a}\\ln(${c}x)+\\frac{1}{x}\\right)\\).`
    ],
    vec: [unitIndex('C1_Derivatives'), 2, a, c],
    key:'c1_deriv_explog'
  };
});
registerGen('C1_Derivatives', (rng)=> {
  let a = randInt(rng,1,4);
  if (a === 2) a = 3;
  const b = randInt(rng,1,5);
  return {
    q: `Given \\(x^2+${a}xy+y^2=${b}\\), find \\(\\frac{dy}{dx}\\) in terms of \\(x\\) and \\(y\\).`,
    a: `\\(\\frac{dy}{dx}=-\\frac{2x+${a}y}{${a}x+2y}\\)`,
    steps: [
      `Differentiate: \\(2x+${a}(x y' + y)+2y y'=0\\).`,
      `Group \\(y'\\): \\((${a}x+2y)y'=-(2x+${a}y)\\).`,
      `Solve for \\(y'\\).`
    ],
    vec: [unitIndex('C1_Derivatives'), 3, a, b],
    key:'c1_deriv_implicit'
  };
});
registerGen('C1_Derivatives', (rng)=> {
  const a = randInt(rng, 1, 7);
  const q = `Let \\(F(x)=\\int_{1}^{x} (t^2+${a})\\,dt\\). Find \\(F'(x)\\).`;
  const aStr = `\\(F'(x)=x^2+${a}\\)`;
  const steps = [
    `By the Fundamental Theorem of Calculus, if \\(F(x)=\\int_{1}^{x} f(t)\\,dt\\), then \\(F'(x)=f(x)\\).`,
    `Here \\(f(t)=t^2+${a}\\), so \\(F'(x)=x^2+${a}\\).`
  ];
  return { q, a:aStr, steps, vec:[unitIndex('C1_Derivatives'), 301, a], key:'c1_ftc_basic' };
});
registerGen('C1_Derivatives', (rng)=> {
  const trig = pick(rng, ['\\sin','\\cos']);
  const q = `Let \\(G(x)=\\int_{0}^{x^2} ${trig}(t)\\,dt\\). Find \\(G'(x)\\).`;
  const aStr = trig === '\\sin'
    ? `\\(G'(x)=\\sin(x^2)\\cdot 2x\\)`
    : `\\(G'(x)=\\cos(x^2)\\cdot 2x\\)`;
  const steps = [
    `Use the chain-rule version of FTC: if \\(G(x)=\\int_{0}^{g(x)} f(t)\\,dt\\), then \\(G'(x)=f(g(x))\\,g'(x)\\).`,
    `Here \\(g(x)=x^2\\Rightarrow g'(x)=2x\\).`,
    `So \\(G'(x)=${trig}(x^2)\\cdot 2x\\).`
  ];
  return { q, a:aStr, steps, vec:[unitIndex('C1_Derivatives'), 302, trig==='\\sin'?1:2], key:'c1_ftc_chain' };
});
registerGen('C1_Derivatives', (rng)=> {
  const q = `Let \\(H(x)=\\int_{\\sin x}^{\\cos x} (t^2+1)\\,dt\\). Find \\(H'(x)\\).`;
  const aStr = `\\(H'(x)=(\\cos^2x+1)(-\\sin x)-(\\sin^2x+1)(\\cos x)\\)`;
  const steps = [
    `Use Leibniz rule: if \\(H(x)=\\int_{a(x)}^{b(x)} f(t)\\,dt\\), then \\(H'(x)=f(b(x))b'(x)-f(a(x))a'(x)\\).`,
    `Here \\(f(t)=t^2+1\\), \\(a(x)=\\sin x\\Rightarrow a'(x)=\\cos x\\), and \\(b(x)=\\cos x\\Rightarrow b'(x)=-\\sin x\\).`,
    `So \\(H'(x)=(\\cos^2x+1)(-\\sin x)-(\\sin^2x+1)(\\cos x)\\).`
  ];
  return { q, a:aStr, steps, vec:[unitIndex('C1_Derivatives'), 303, 1], key:'c1_ftc_leibniz' };
});
registerGen('C1_Apps', (rng)=> {
  const kind = pick(rng, ['poly','exp','trig','rad']);
  if(kind === 'poly'){
    const A = pick(rng, [-3,-2,-1,1,2,3]);
    const B = randInt(rng, -5, 5);
    const C = randInt(rng, -8, 8);
    const a0 = pick(rng, [-1,0,1,2]);
    const h = pick(rng, [-0.2,-0.1,0.1,0.2]);
    const fa = A*a0*a0 + B*a0 + C;
    const fpa = 2*A*a0 + B;
    const approx = fa + fpa*h;
    return {
      q: `Find the linearization \\(L(x)\\) of \\(f(x)=${mwPoly2Tex(A,B,C)}\\) at \\(x=${a0}\\). Use it to approximate \\(f(${fmtDec(a0+h,1)})\\).`,
      a: `\\(L(x)= ${fa} + ${fpa}(x-${a0})\\), so \\(f(${fmtDec(a0+h,1)})\\approx ${fmtDec(approx,3)}\\).`,
      steps: [
        `Linearization formula: \\(L(x)=f(a)+f'(a)(x-a)\\).`,
        `Here \\(f(${a0})=${fa}\\).`,
        `\\(f'(x)=${2*A}x${fmtSigned(B)}\\Rightarrow f'(${a0})=${fpa}\\).`,
        `So \\(L(x)=${fa}+${fpa}(x-${a0})\\) and \\(L(${fmtDec(a0+h,1)})=${fa}+${fpa}(${fmtDec(h,1)})=${fmtDec(approx,3)}\\).`
      ],
      vec: [unitIndex('C1_Apps'), 91, A,B,C,a0, Math.round(h*10)],
      key:'c1_linearization_poly'
    };
  }
  if(kind === 'exp'){
    const a0 = pick(rng, [-1,0,1]);
    const h = pick(rng, [-0.1,0.1,0.2]);
    const fa = Math.exp(a0);
    const approx = fa + fa*h;
    return {
      q: `Find the linearization of \\(f(x)=e^x\\) at \\(x=${a0}\\). Use it to approximate \\(e^{${fmtDec(a0+h,1)}}\\).`,
      a: `\\(L(x)=e^{${a0}}+e^{${a0}}(x-${a0})\\), so \\(e^{${fmtDec(a0+h,1)}}\\approx ${fmtDec(approx,3)}\\).`,
      steps: [
        `For \\(f(x)=e^x\\), we have \\(f'(x)=e^x\\).`,
        `\\(f(${a0})=e^{${a0}}\\approx ${fmtDec(fa,3)}\\) and \\(f'(${a0})=e^{${a0}}\\).`,
        `So \\(L(x)=e^{${a0}}+e^{${a0}}(x-${a0})\\).`,
        `Evaluate: \\(L(${fmtDec(a0+h,1)})\\approx ${fmtDec(approx,3)}\\).`
      ],
      vec: [unitIndex('C1_Apps'), 92, a0, Math.round(h*10), 0,0],
      key:'c1_linearization_exp'
    };
  }
  if(kind === 'trig'){
    const aPick = pick(rng, ['0','pi/6','pi/4','pi/3']);
    const a0 = (aPick==='0')?0:(aPick==='pi/6'?Math.PI/6:(aPick==='pi/4'?Math.PI/4:Math.PI/3));
    const aTex = (aPick==='0')?'0':(aPick==='pi/6'?'\\frac{\\pi}{6}':(aPick==='pi/4'?'\\frac{\\pi}{4}':'\\frac{\\pi}{3}'));
    const h = 0.1;
    const fa = Math.sin(a0);
    const fpa = Math.cos(a0);
    const approx = fa + fpa*h;
    return {
      q: `Find the linearization of \\(f(x)=\\sin x\\) at \\(x=${aTex}\\). Use it to approximate \\(\\sin(${aTex}+0.1)\\).`,
      a: `\\(L(x)=${fmtDec(fa,3)}+${fmtDec(fpa,3)}(x-${aTex})\\), so \\(\\sin(${aTex}+0.1)\\approx ${fmtDec(approx,3)}\\).`,
      steps: [
        `\\(f'(x)=\\cos x\\).`,
        `\\(f(${aTex})=\\sin(${aTex})=${fmtDec(fa,3)}\\), \\(f'(${aTex})=\\cos(${aTex})=${fmtDec(fpa,3)}\\).`,
        `So \\(L(x)=f(a)+f'(a)(x-a)=${fmtDec(fa,3)}+${fmtDec(fpa,3)}(x-${aTex})\\).`,
        `Evaluate: \\(L(${aTex}+0.1)\\approx ${fmtDec(approx,3)}\\).`
      ],
      vec: [unitIndex('C1_Apps'), 93, aPick==='0'?0:(aPick==='pi/6'?1:(aPick==='pi/4'?2:3)), 0,0,0],
      key:'c1_linearization_trig'
    };
  }
  // radical
  const a0 = pick(rng, [4,9,16,25]);
  const h = pick(rng, [-1,1,2]);
  const fa = Math.sqrt(a0);
  const fpa = 1/(2*fa);
  const approx = fa + fpa*h;
  return {
    q: `Find the linearization of \\(f(x)=\\sqrt{x}\\) at \\(x=${a0}\\). Use it to approximate \\(\\sqrt{${a0+h}}\\).`,
    a: `\\(L(x)=${fa}+${exactFrac(1, 2*fa)}(x-${a0})\\), so \\(\\sqrt{${a0+h}}\\approx ${fmtDec(approx,3)}\\).`,
    steps: [
      `\\(f'(x)=\\frac{1}{2\\sqrt{x}}\\).`,
      `\\(f(${a0})=\\sqrt{${a0}}=${fa}\\), \\(f'(${a0})=\\frac{1}{2\\sqrt{${a0}}}=${exactFrac(1,2*fa)}\\).`,
      `So \\(L(x)=${fa}+${exactFrac(1,2*fa)}(x-${a0})\\).`,
      `Evaluate \\(L(${a0+h})=${fa}+${exactFrac(1,2*fa)}(${h})\\approx ${fmtDec(approx,3)}\\).`
    ],
    vec: [unitIndex('C1_Apps'), 94, a0, h, 0,0],
    key:'c1_linearization_sqrt'
  };
});
registerGen('C1_Apps', (rng)=> {
  const a = randInt(rng,-2,0);
  const b = randInt(rng,2,4);
  // f(x)=x^2. Average slope = (b^2-a^2)/(b-a)=a+b. f'(c)=2c => c=(a+b)/2
  const c = (a+b)/2;
  return {
    q: `For \\(f(x)=x^2\\) on \\([${a},${b}]\\), find a value \\(c\\) guaranteed by the Mean Value Theorem.`,
    a: `\\(c=\\frac{${a}+${b}}{2}=${c}\\)`,
    steps: [
      `MVT: \\(f'(c)=\\frac{f(b)-f(a)}{b-a}\\).`,
      `\\(\\frac{b^2-a^2}{b-a}=a+b\\).`,
      `Since \\(f'(x)=2x\\), set \\(2c=a+b\\Rightarrow c=\\frac{a+b}{2}\\).`
    ],
    vec: [unitIndex('C1_Apps'), 1, a, b],
    key:'c1_mvt_x2'
  };
});
registerGen('C1_Apps', (rng)=> {
  const L = pick(rng, [10,13,15,17,20,25]);
  const x = randInt(rng, 3, L-2);
  const dx = pick(rng, [1,2,3]);
  const y = Math.sqrt(L*L - x*x);
  const dy = -(x/y)*dx;
  return {
    q: `A ${L}-ft ladder leans against a wall. The bottom slides away at \\(\\frac{dx}{dt}=${dx}\\) ft/s when the bottom is ${x} ft from the wall. How fast is the top sliding down?`,
    a: `\\(\\frac{dy}{dt}\\approx ${dy.toFixed(3)}\\) ft/s (downward)`,
    steps: [
      `\\(x^2+y^2=${L}^2\\). Differentiate: \\(2x\\frac{dx}{dt}+2y\\frac{dy}{dt}=0\\).`,
      `\\(\\frac{dy}{dt}=-(x/y)\\frac{dx}{dt}\\).`,
      `At \\(x=${x}\\), \\(y\\approx ${y.toFixed(3)}\\) so \\(dy/dt\\approx ${dy.toFixed(3)}\\).`
    ],
    vec: [unitIndex('C1_Apps'), 2, L, x, dx],
    key:'c1_rr_ladder'
  };
});
registerGen('C1_Apps', (rng)=> {
  const F = pick(rng, [120,160,200,240]);
  const q = `A rectangular pen is built using ${F} ft of fencing on three sides (one side is along a river and needs no fence). What dimensions maximize the area?`;
  const x = F/4;
  const y = F/2;
  const aStr = `Maximum area occurs when the two equal sides are \\(${fmtDec(x)}\\) ft and the third side is \\(${fmtDec(y)}\\) ft.`;
  const steps = [
    `Let \\(x\\) be the length of each side perpendicular to the river, and \\(y\\) the side parallel to the river (the fenced side).`,
    `Constraint: \\(2x+y=${F}\\Rightarrow y=${F}-2x\\).`,
    `Area: \\(A(x)=xy=x(${F}-2x)=${F}x-2x^2\\).`,
    `Differentiate: \\(A'(x)=${F}-4x\\). Set \\(A'(x)=0\\Rightarrow x=${F}/4=${fmtDec(x)}\\).`,
    `Then \\(y=${F}-2x=${F}-2(${fmtDec(x)})=${fmtDec(y)}\\). (Second derivative \\(A''(x)=-4<0\\), so this is a maximum.)`
  ];
  return { q, a:aStr, steps, vec:[unitIndex('C1_Apps'), 311, F], key:'c1_opt_river_fence' };
});
registerGen('C1_Apps', (rng)=> {
  const L = pick(rng, [18,24,30,36]);
  const xStar = L/6;
  const base = L - 2*xStar;
  const Vmax = xStar * base * base;

  const q = `A square sheet of cardboard is ${L} in by ${L} in. Squares of side \\(x\\) are cut from each corner and the sides are folded up to make an open-top box. Find \\(x\\) that maximizes the volume, and the resulting box dimensions.`;
  const aStr = `Cut \\(x=${fmtDec(xStar)}\\) in. Box: base \\(${fmtDec(base)}\\) in by \\(${fmtDec(base)}\\) in, height \\(${fmtDec(xStar)}\\) in.`;

  const steps = [
    `After cutting, base side length is \\(L-2x\\), height is \\(x\\).`,
    `Volume: \\(V(x)=x(L-2x)^2\\). Here \\(L=${L}\\), so \\(V(x)=x(${L}-2x)^2\\).`,
    `Differentiate (product rule): \\(V'(x)=(L-2x)^2 + x\\cdot 2(L-2x)(-2)\\).`,
    `Factor: \\(V'(x)=(L-2x)(L-6x)\\).`,
    `Set \\(V'(x)=0\\): \\(x=L/2\\) gives zero base (reject). Use \\(L-6x=0\\Rightarrow x=L/6=${fmtDec(xStar)}\\).`,
    `Then base side is \\(L-2x=${L}-2(${fmtDec(xStar)})=${fmtDec(base)}\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C1_Apps'), 312, L], key:'c1_opt_open_box' };
});
registerGen('C1_Apps', (rng)=> {
  const r = pick(rng, [2,3,4,5]);
  const Vcoef = 2 * (r**3); // so V = 2π r^3 gives nice optimum at this r
  const h = 2*r;

  const q = `A closed cylinder must have volume \\(V=${Vcoef}\\pi\\). Find the radius and height that minimize surface area.`;
  const aStr = `Minimum surface area occurs at \\(r=${r}\\) and \\(h=${h}\\).`;

  const steps = [
    `Volume constraint: \\(V=\\pi r^2 h=${Vcoef}\\pi\\Rightarrow h=\\frac{${Vcoef}}{r^2}\\).`,
    `Surface area (closed): \\(S=2\\pi r^2+2\\pi r h\\). Substitute \\(h\\):`,
    `\\(S(r)=2\\pi r^2+2\\pi r\\cdot\\frac{${Vcoef}}{r^2}=2\\pi r^2+\\frac{2\\pi\\cdot ${Vcoef}}{r}\\).`,
    `Differentiate: \\(S'(r)=4\\pi r-\\frac{2\\pi\\cdot ${Vcoef}}{r^2}\\). Set \\(S'(r)=0\\):`,
    `\\(4\\pi r=\\frac{2\\pi\\cdot ${Vcoef}}{r^2}\\Rightarrow 4r^3=2\\cdot ${Vcoef}\\Rightarrow r^3=${Vcoef}/2\\Rightarrow r=${r}\\).`,
    `Then \\(h=\\frac{${Vcoef}}{r^2}=\\frac{${Vcoef}}{${r*r}}=${h}\\). (This gives the classic result \\(h=2r\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C1_Apps'), 313, Vcoef], key:'c1_opt_cylinder_minSA' };
});
registerGen('C1_Apps', (rng)=> {
  const c = randInt(rng, -2, 2);
  const q = `For \\(f(x)=x^3-3x${fmtSigned(c)}\\), find critical points, intervals of increase/decrease, and where the graph is concave up/down.`;
  const fneg1 = 2 + c;
  const f1 = -2 + c;

  const aStr = [
    `Critical points at \\(x=-1\\) and \\(x=1\\).`,
    `Increasing on \\(( -\\infty,-1)\\) and \\((1,\\infty)\\); decreasing on \\((-1,1)\\).`,
    `Concave down on \\(( -\\infty,0)\\); concave up on \\((0,\\infty)\\).`
  ].join('<br>');

  const steps = [
    `Compute derivative: \\(f'(x)=3x^2-3=3(x^2-1)\\).`,
    `Set \\(f'(x)=0\\Rightarrow x^2-1=0\\Rightarrow x=\\pm 1\\).`,
    `Sign of \\(f'(x)\\): positive for \\(|x|>1\\) and negative for \\(|x|<1\\). So increasing on \\(( -\\infty,-1)\\) and \\((1,\\infty)\\), decreasing on \\((-1,1)\\).`,
    `Second derivative: \\(f''(x)=6x\\).`,
    `Concavity: \\(f''(x)<0\\) for \\(x<0\\) (concave down) and \\(f''(x)>0\\) for \\(x>0\\) (concave up).`,
    `Optional point values: \\(f(-1)=2${fmtSigned(c)}=${fneg1}\\), \\(f(1)=-2${fmtSigned(c)}=${f1}\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C1_Apps'), 314, c], key:'c1_curve_sketch_cubic' };
});
registerGen('C1_Apps', (rng)=> {
  const q = `For \\(f(x)=\\frac{x+1}{x-2}\\), find vertical/horizontal asymptotes and determine where \\(f\\) is increasing or decreasing.`;

  const aStr = [
    `Vertical asymptote: \\(x=2\\). Horizontal asymptote: \\(y=1\\).`,
    `Derivative \\(f'(x)=\\frac{-3}{(x-2)^2}<0\\) for all \\(x\\ne 2\\), so \\(f\\) is decreasing on \\(( -\\infty,2)\\) and \\((2,\\infty)\\).`
  ].join('<br>');

  const steps = [
    `Vertical asymptote occurs where denominator is 0 (and not canceled): \\(x-2=0\\Rightarrow x=2\\).`,
    `Degrees are equal; horizontal asymptote is ratio of leading coefficients: \\(y=1\\).`,
    `Differentiate using quotient rule:`,
    `\\(f'(x)=\\frac{(x-2)\\cdot 1-(x+1)\\cdot 1}{(x-2)^2}=\\frac{x-2-x-1}{(x-2)^2}=\\frac{-3}{(x-2)^2}\\).`,
    `Since \\( (x-2)^2>0\\) for \\(x\\ne 2\\), we have \\(f'(x)<0\\), so \\(f\\) is decreasing on both intervals.`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C1_Apps'), 315, 1], key:'c1_curve_sketch_rational' };
});
registerGen('C1_Integrals', (rng)=> ({
  q: `Write the limit as a definite integral, then evaluate: \\(\\lim_{n\\to\\infty}\\sum_{i=1}^{n}\\left(\\frac{i}{n}\\right)^2\\cdot\\frac{1}{n}\\).`,
  a: `\\(\\int_0^1 x^2\\,dx=\\frac{1}{3}\\)`,
  steps: [
    `Here \\(\\Delta x=1/n\\), \\(x_i=i/n\\).`,
    `So the sum is \\(\\int_0^1 x^2 dx\\).`,
    `Compute: \\([x^3/3]_0^1=1/3\\).`
  ],
  vec: [unitIndex('C1_Integrals'), 1, 0,0,0],
  key:'c1_int_riemann'
}));
registerGen('C1_Integrals', (rng)=> {
  const a = randInt(rng,2,6);
  const n = randInt(rng,2,5);
  // ∫ (ax+1)^n dx = (ax+1)^{n+1}/(a(n+1))
  return {
    q: `Evaluate \\(\\int (${a}x+1)^{${n}}\\,dx\\).`,
    a: `\\(\\frac{(${a}x+1)^{${n+1}}}{${a*(n+1)}}+C\\)`,
    steps: [
      `Let \\(u=${a}x+1\\Rightarrow du=${a}\\,dx\\Rightarrow dx=du/${a}\\).`,
      `\\(\\int u^{${n}}\\frac{1}{${a}}du=\\frac{1}{${a}}\\cdot\\frac{u^{${n+1}}}{${n+1}}+C\\).`,
      `Back-substitute \\(u=${a}x+1\\).`
    ],
    vec: [unitIndex('C1_Integrals'), 2, a, n],
    key:'c1_int_usub'
  };
});
registerGen('C1_Integrals', (rng)=> {
  const a = pick(rng, [1,2,3]);
  const b = pick(rng, [2,3,4]);
  const c = randInt(rng, -3, 3);
  // f(x)=a x^2 + c on [0,b]
  const avg_num = (a*(b**3)/3) + c*b
  const avg = avg_num / b

  const q = `Find the average value of \\(f(x)=${a}x^2${fmtSigned(c)}\\) on the interval \\([0,${b}]\\).`;
  const aStr = `\\(f_{avg}=\\frac{1}{${b}-0}\\int_0^{${b}} (${a}x^2${fmtSigned(c)})\\,dx = ${fmtDec(avg)}\\)`;

  const steps = [
    `Average value on \\([a,b]\\) is \\(f_{avg}=\\frac{1}{b-a}\\int_a^b f(x)\\,dx\\).`,
    `Here: \\(f_{avg}=\\frac{1}{${b}}\\int_0^{${b}} (${a}x^2${fmtSigned(c)})\\,dx\\).`,
    `Compute the integral: \\(\\int_0^{${b}} ${a}x^2\\,dx=${a}\\cdot\\frac{x^3}{3}\\Big|_0^{${b}}=${a}\\cdot\\frac{${b}^3}{3}\\) and \\(\\int_0^{${b}} ${c}\\,dx=${c}x\\Big|_0^{${b}}=${c*b}\\).`,
    `So \\(\\int_0^{${b}} f(x)\\,dx=${fmtDec(avg_num)}\\), and \\(f_{avg}=\\frac{${fmtDec(avg_num)}}{${b}}=${fmtDec(avg)}\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C1_Integrals'), 321, a, b, c], key:'c1_avg_value_poly' };
});
registerGen('C1_Integrals', (rng)=> {
  const q = `Find the average value of \\(f(x)=\\sin x\\) on the interval \\([0,\\pi]\\).`;
  const aStr = `\\(f_{avg}=\\frac{1}{\\pi}\\int_0^{\\pi} \\sin x\\,dx=\\frac{2}{\\pi}\\)`;

  const steps = [
    `Use \\(f_{avg}=\\frac{1}{b-a}\\int_a^b f(x)\\,dx\\) with \\(a=0\\), \\(b=\\pi\\).`,
    `\\(\\int_0^{\\pi} \\sin x\\,dx = [-\\cos x]_0^{\\pi}=(-\\cos\\pi)-(-\\cos 0)=1-(-1)=2\\).`,
    `So \\(f_{avg}=\\frac{1}{\\pi}\\cdot 2=\\frac{2}{\\pi}\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C1_Integrals'), 322, 1], key:'c1_avg_value_sin' };
});
registerGen('C1_Derivatives', (rng)=>{
  const a = pick(rng,[2,3,4,5]);
  return {
    q: `Differentiate \\(f(x)=\\arctan(${a}x)\\).`,
    a: `\\(f'(x)=\\dfrac{${a}}{1+${a*a}x^2}\\)`,
    steps: [
      `\\(\\frac{d}{dx}\\arctan(u)=\\frac{u'}{1+u^2}\\) with \\(u=${a}x\\).`,
      `\\(u'=${a}\\), \\(u^2=${a*a}x^2\\): \\(f'(x)=\\dfrac{${a}}{1+${a*a}x^2}\\).`
    ],
    traps: [
      {ans:`\\(f'(x)=\\dfrac{1}{1+${a*a}x^2}\\)`, why:`Chain rule: multiply by u′ = ${a}.`},
      {ans:`\\(f'(x)=\\dfrac{${a}}{1+${a}x^2}\\)`, why:`u² = (${a}x)² = ${a*a}x², not ${a}x².`},
      {ans:`\\(f'(x)=\\dfrac{${a}}{\\sqrt{1-${a*a}x^2}}\\)`, why:'That denominator belongs to arcsin, not arctan.'}
    ],
    vec: [unitIndex('C1_Derivatives'), 25, a],
    key: 'c1_deriv_invtrig'
  };
});
registerGen('C1_Apps', (rng)=>{
  const k = randInt(rng,2,6);   // dr/dt
  const R = randInt(rng,3,10);  // radius at the moment
  return {
    q: `The radius of a circle increases at \\(${k}\\) cm/s. How fast is the area increasing when the radius is \\(${R}\\) cm?`,
    a: `\\(${2*R*k}\\pi\\) cm\\(^2\\)/s`,
    steps: [
      `\\(A=\\pi r^2\\Rightarrow \\dfrac{dA}{dt}=2\\pi r\\dfrac{dr}{dt}\\).`,
      `At \\(r=${R}\\) with \\(\\dfrac{dr}{dt}=${k}\\): \\(\\dfrac{dA}{dt}=2\\pi(${R})(${k})=${2*R*k}\\pi\\) cm\\(^2\\)/s.`
    ],
    traps: [
      {ans:`\\(${R*k}\\pi\\) cm\\(^2\\)/s`, why:'d/dt of r² is 2r·(dr/dt) — do not drop the 2.'},
      {ans:`\\(${R*R*k}\\pi\\) cm\\(^2\\)/s`, why:'Differentiate BEFORE substituting: dA/dt = 2πr·dr/dt, not πr²·dr/dt.'},
      {ans:`\\(${2*k}\\pi\\) cm\\(^2\\)/s`, why:'Evaluate 2πr·dr/dt at the given radius r = '+R+'.'}
    ],
    vec: [unitIndex('C1_Apps'), 20, k, R],
    key: 'c1_rr_second'
  };
});
registerGen('C1_Integrals', (rng)=>{
  const a = pick(rng,[2,4,6]);
  const bcoef = randInt(rng,-6,6);
  const T = pick(rng,[2,3,4]);
  const disp = a*T*T/2 + bcoef*T;
  return {
    q: `A particle moves with velocity \\(v(t)=${a}t${fmtSigned(bcoef)}\\) m/s. Use the Net Change Theorem to find its displacement over \\([0, ${T}]\\).`,
    a: `\\(${disp}\\) m`,
    steps: [
      `Displacement \\(=\\int_0^{${T}} v(t)\\,dt=\\left[${a/2===1?'':a/2}t^2${fmtSigned(bcoef)}t\\right]_0^{${T}}\\).`,
      `\\(=${a/2}(${T})^2${fmtSigned(bcoef)}(${T})=${disp}\\) m.`
    ],
    traps: [
      {ans:`\\(${a*T*T + bcoef*T}\\) m`, why:'The antiderivative of at is at²/2 — do not forget the half.'},
      {ans:`\\(${a*T + bcoef}\\) m`, why:'That is v(T), the velocity at time T — displacement is the INTEGRAL of v.'},
      {ans:`\\(${a*T*T/2 - bcoef*T}\\) m`, why:'Sign of the constant term: it integrates to bt with the same sign.'}
    ],
    vec: [unitIndex('C1_Integrals'), 21, a, bcoef, T],
    key: 'c1_net_change'
  };
});
registerGen('C1_Limits', (rng)=>{
  const c = randInt(rng,-2,3);
  const a = mwNZ(rng,-3,3);
  const m = mwNZ(rng,-3,3);
  const d = randInt(rng,-4,4);
  const leftVal = c + a;          // left branch: x + a
  const rightVal = m*c + d;       // right branch: mx + d
  const side = pick(rng,['-','+']);
  const ans = side==='-' ? leftVal : rightVal;
  const other = side==='-' ? rightVal : leftVal;
  const traps = [
    {ans:`\\(${other}\\)`, why:`That is the limit from the other side. For \\(x\\to ${c}^${side}\\), use the branch on that side of ${c}.`}
  ];
  if(leftVal !== rightVal) traps.push({ans:`DNE`, why:'A ONE-sided limit can exist even when the two-sided limit does not.'});
  return {
    q: `Let \\(f(x)=\\begin{cases} x${fmtSigned(a)} & x<${c}\\\\ ${m===1?'':m===-1?'-':m}x${fmtSigned(d)} & x\\ge ${c}\\end{cases}\\). Compute \\(\\displaystyle\\lim_{x\\to ${c}^${side}} f(x)\\).`,
    a: `\\(${ans}\\)`,
    steps: [
      `For \\(x\\to ${c}^${side}\\), \\(x\\) approaches ${c} from the ${side==='-'?'left, so use the branch for \\(x<'+c+'\\)':'right, so use the branch for \\(x\\ge '+c+'\\)'}.`,
      `Substitute \\(x=${c}\\) into that branch: \\(${ans}\\).`
    ],
    traps,
    vec: [unitIndex('C1_Limits'), 20, c, a, m, d, side==='-'?0:1],
    key: 'c1_limit_one_sided'
  };
});
registerGen('C1_Derivatives', (rng)=>{
  const b = mwNZ(rng,-5,5);
  return {
    q: `Use the limit definition \\(f'(x)=\\displaystyle\\lim_{h\\to 0}\\frac{f(x+h)-f(x)}{h}\\) to find \\(f'(x)\\) for \\(f(x)=x^2${fmtSigned(b)}x\\).`,
    a: `\\(f'(x)=2x${fmtSigned(b)}\\)`,
    steps: [
      `\\(f(x+h)=(x+h)^2${fmtSigned(b)}(x+h)=x^2+2xh+h^2${fmtSigned(b)}x${fmtSigned(b)}h\\).`,
      `\\(f(x+h)-f(x)=2xh+h^2${fmtSigned(b)}h\\).`,
      `Divide by \\(h\\): \\(2x+h${fmtSigned(b)}\\), then let \\(h\\to 0\\): \\(f'(x)=2x${fmtSigned(b)}\\).`
    ],
    traps: [
      {ans:`\\(f'(x)=2x+h${fmtSigned(b)}\\)`, why:'The last step is taking the limit h→0 — the h must disappear.'},
      {ans:`\\(f'(x)=2x${fmtSigned(-b)}\\)`, why:'Sign slip on the linear term: the derivative of bx is b.'},
      {ans:`\\(f'(x)=x${fmtSigned(b)}\\)`, why:'The power rule gives 2x from x^2 — check the expansion of (x+h)^2.'}
    ],
    vec: [unitIndex('C1_Derivatives'), 20, b],
    key: 'c1_deriv_definition'
  };
});
registerGen('C1_Derivatives', (rng)=>{
  const b = randInt(rng,-4,4);
  const c = randInt(rng,-5,5);
  const p = randInt(rng,-3,3);
  const fp = p*p + b*p + c;
  const m = 2*p + b;
  const k = fp - m*p;
  const line = (mm,kk)=> `y=${mm===0?'':(mm===1?'':(mm===-1?'-':mm))+'x'}${mm===0?kk:fmtSigned(kk)}`;
  return {
    q: `Find the equation of the tangent line to \\(f(x)=x^2${fmtSigned(b)}x${fmtSigned(c)}\\) at \\(x=${p}\\).`,
    a: `\\(${line(m,k)}\\)`,
    steps: [
      `Point: \\(f(${p})=${fp}\\), so the line passes through \\((${p}, ${fp})\\).`,
      `Slope: \\(f'(x)=2x${fmtSigned(b)}\\), so \\(m=f'(${p})=${m}\\).`,
      `Point-slope: \\(y-${fp}=${m}(x-${p})\\Rightarrow ${line(m,k)}\\).`
    ],
    traps: [
      {ans:`\\(${line(m,fp)}\\)`, why:'y = mx + f(p) only works when p = 0. Use point-slope: y - f(p) = m(x - p).'},
      {ans:`\\(${line(fp,k)}\\)`, why:'f(p) is the y-VALUE at the point; the slope is f′(p).'},
      {ans:`\\(${line(m, k + (m===0?1:m))}\\)`, why:'Arithmetic slip distributing m(x - p): the intercept is f(p) - m*p.'}
    ],
    vec: [unitIndex('C1_Derivatives'), 21, b, c, p],
    key: 'c1_tangent_line'
  };
});
registerGen('C1_Derivatives', (rng)=>{
  let a,b,c,d,det;
  do {
    a = mwNZ(rng,-4,4); b = randInt(rng,-5,5);
    c = mwNZ(rng,-4,4); d = randInt(rng,-5,5);
    det = a*d - b*c;
  } while(det === 0);
  const co = (n)=> n===1?'':(n===-1?'-':`${n}`);
  const lin = (u,v)=> `${co(u)}x${fmtSigned(v)}`;
  return {
    q: `Differentiate \\(f(x)=\\dfrac{${lin(a,b)}}{${lin(c,d)}}\\).`,
    a: `\\(f'(x)=\\dfrac{${det}}{(${lin(c,d)})^2}\\)`,
    steps: [
      `Quotient rule: \\(f'=\\dfrac{u'v-uv'}{v^2}\\) with \\(u=${lin(a,b)}\\), \\(v=${lin(c,d)}\\).`,
      `\\(u'=${a}\\), \\(v'=${c}\\): numerator \\(=${a}(${lin(c,d)})-${c}(${lin(a,b)})=${det}\\).`,
      `\\(f'(x)=\\dfrac{${det}}{(${lin(c,d)})^2}\\).`
    ],
    traps: [
      {ans:`\\(f'(x)=\\dfrac{${-det}}{(${lin(c,d)})^2}\\)`, why:"Order matters: it is u'v - uv' (low d-high minus high d-low), not the reverse."},
      {ans:`\\(f'(x)=\\dfrac{${a*d+b*c}}{(${lin(c,d)})^2}\\)`, why:'The numerator is a DIFFERENCE, not a sum.'},
      {ans:`\\(f'(x)=${mwFracTex(a,c)}\\)`, why:'You cannot differentiate the top and bottom separately — that is not the quotient rule.'}
    ],
    vec: [unitIndex('C1_Derivatives'), 22, a, b, c, d],
    key: 'c1_deriv_quotient'
  };
});
registerGen('C1_Derivatives', (rng)=>{
  const a = mwNZ(rng,-3,3);
  const b = mwNZ(rng,-5,5);
  const n = pick(rng,[3,4,5]);
  const co = (u)=> u===1?'':(u===-1?'-':`${u}`);
  const inner = `${co(a)}x${fmtSigned(b)}`;
  return {
    q: `Differentiate \\(f(x)=(${inner})^{${n}}\\).`,
    a: `\\(f'(x)=${n*a}(${inner})^{${n-1}}\\)`,
    steps: [
      `Chain rule: outer power rule times inner derivative.`,
      `\\(f'(x)=${n}(${inner})^{${n-1}}\\cdot ${a}=${n*a}(${inner})^{${n-1}}\\).`
    ],
    traps: [
      {ans:`\\(f'(x)=${n}(${inner})^{${n-1}}\\)`, why:`Do not forget the inner derivative: multiply by d/dx(${inner}) = ${a}.`},
      {ans:`\\(f'(x)=${n*a}(${inner})^{${n}}\\)`, why:'The power rule reduces the exponent by 1.'},
      {ans:`\\(f'(x)=(${co(n)}x${fmtSigned(b)})^{${n-1}}\\)`, why:'Differentiate the whole composition — do not alter the inside function.'}
    ],
    vec: [unitIndex('C1_Derivatives'), 23, a, b, n],
    key: 'c1_deriv_chain'
  };
});
registerGen('C1_Derivatives', (rng)=>{
  const a = mwNZ(rng,-5,5);
  const b = mwNZ(rng,-5,5);
  const co = (u)=> u===1?'':(u===-1?'-':`${u}`);
  const expr = (s,cc)=> `${co(s)}\\cos x${cc>=0?'+':''}${co(cc)===''&&cc>0?'':co(cc)}\\sin x`;
  const F  = `${co(a)}\\sin x${b>=0?'+':''}${co(b)===''&&b>0?'':co(b)}\\cos x`;
  const mk = (s,cc)=> `\\(f'(x)=${co(s)}\\cos x${cc>=0?'+':''}${co(cc)===''&&cc>0?'':co(cc)}\\sin x\\)`;
  return {
    q: `Differentiate \\(f(x)=${F}\\).`,
    a: mk(a,-b),
    steps: [
      `\\(\\frac{d}{dx}\\sin x=\\cos x\\) and \\(\\frac{d}{dx}\\cos x=-\\sin x\\).`,
      `So \\(f'(x)=${co(a)}\\cos x${-b>=0?'+':''}${co(-b)===''&&-b>0?'':co(-b)}\\sin x\\).`
    ],
    traps: [
      {ans: mk(a,b),  why:'The derivative of cos x is NEGATIVE sin x.'},
      {ans: mk(-a,-b), why:'The derivative of sin x is +cos x (no sign change on that term).'},
      {ans: mk(-a,b), why:'Both signs are off — d/dx sin x = cos x, d/dx cos x = -sin x.'}
    ],
    vec: [unitIndex('C1_Derivatives'), 24, a, b],
    key: 'c1_deriv_trig'
  };
});
registerGen('C1_Integrals', (rng)=>{
  const a = pick(rng,[2,3,4,5,6]);
  const num = a*a*a, den = 6;
  return {
    q: `Find the area of the region bounded by \\(y=${a}x\\) and \\(y=x^2\\).`,
    a: `\\(${mwFracTex(num,den)}\\)`,
    steps: [
      `Intersections: \\(${a}x=x^2\\Rightarrow x=0\\) and \\(x=${a}\\); the line is on top on \\([0,${a}]\\).`,
      `\\(A=\\int_0^{${a}}(${a}x-x^2)\\,dx=\\left[\\frac{${a}x^2}{2}-\\frac{x^3}{3}\\right]_0^{${a}}\\).`,
      `\\(A=\\frac{${a*a*a}}{2}-\\frac{${a*a*a}}{3}=${mwFracTex(num,den)}\\).`
    ],
    traps: [
      {ans:`\\(${mwFracTex(num,3)}\\)`, why:'Integrate the DIFFERENCE top minus bottom, not just one curve.'},
      {ans:`\\(${mwFracTex(-num,6).startsWith('-')? mwFracTex(-num,6) : '-'+mwFracTex(num,6)}\\)`, why:'Area is positive: put the upper curve first in the integrand.'},
      {ans:`\\(${mwFracTex(num,2)}\\)`, why:'Check the antiderivatives: ax integrates to ax^2/2 and x^2 to x^3/3.'}
    ],
    vec: [unitIndex('C1_Integrals'), 20, a],
    key: 'c1_area_between_curves'
  };
});
