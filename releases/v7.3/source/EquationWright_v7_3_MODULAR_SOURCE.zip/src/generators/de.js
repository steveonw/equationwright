// DE generator registrations — order frozen by the published registry.
registerGen('DE_SecondOrder', (rng)=>{
  const r1 = mwNZ(rng,-4,-1), r2 = mwNZ(rng,1,4);
  const b = -(r1+r2), c = r1*r2;
  return {
    q: `Find the roots of the characteristic equation for \\(y'' ${b<0?'-':'+'} ${Math.abs(b)}y' ${c<0?'-':'+'} ${Math.abs(c)}y = 0\\).`,
    a: `\\(r = ${r1}\\) and \\(r = ${r2}\\)`,
    steps: [
      `Characteristic equation: \\(r^2 ${b<0?'-':'+'} ${Math.abs(b)}r ${c<0?'-':'+'} ${Math.abs(c)} = 0\\).`,
      `Factor: \\((r - (${r1}))(r - (${r2})) = 0 \\Rightarrow r = ${r1},\\ ${r2}\\).`
    ],
    traps: [
      {ans: `\\(r = ${-r1}\\) and \\(r = ${-r2}\\)`, why: 'The factors are (r − root): sign slips while factoring flip both roots.'},
      {ans: `\\(r = ${b}\\) and \\(r = ${c}\\)`, why: 'The coefficients are not the roots — b is minus their SUM and c their PRODUCT.'}
    ],
    vec: [unitIndex('DE_SecondOrder'), 1, r1, r2, b, c],
    key: 'de2_char_roots'
  };
});
registerGen('DE_SecondOrder', (rng)=>{
  const r1 = mwNZ(rng,-4,-1), r2 = mwNZ(rng,1,3);
  const b = -(r1+r2), c = r1*r2;
  return {
    q: `Write the general solution of \\(y'' ${b<0?'-':'+'} ${Math.abs(b)}y' ${c<0?'-':'+'} ${Math.abs(c)}y = 0\\).`,
    a: `\\(y = C_1 e^{${r1}x} + C_2 e^{${r2}x}\\)`,
    steps: [
      `Characteristic roots: \\(r = ${r1},\\ ${r2}\\) (real and distinct).`,
      `Each root contributes an exponential: \\(y = C_1 e^{${r1}x} + C_2 e^{${r2}x}\\).`
    ],
    traps: [
      {ans: `\\(y = C_1 e^{${-r1}x} + C_2 e^{${-r2}x}\\)`, why: 'The exponents ARE the roots, signs included — check by substituting e^{rx} back.'},
      {ans: `\\(y = (C_1 + C_2 x)e^{${r1}x}\\)`, why: 'The (C₁ + C₂x) form is for a REPEATED root; these roots are distinct.'}
    ],
    vec: [unitIndex('DE_SecondOrder'), 2, r1, r2],
    key: 'de2_gen_real'
  };
});
registerGen('DE_SecondOrder', (rng)=>{
  const a = mwNZ(rng,-3,-1);
  return {
    q: `Write the general solution of \\(y'' ${-2*a<0?'-':'+'} ${Math.abs(2*a)}y' + ${a*a}y = 0\\).`,
    a: `\\(y = (C_1 + C_2 x)e^{${a}x}\\)`,
    steps: [
      `Characteristic: \\(r^2 - ${2*a}r + ${a*a} = (r - (${a}))^2 = 0\\) — a REPEATED root \\(r = ${a}\\).`,
      `A repeated root needs the extra factor of \\(x\\): \\(y = (C_1 + C_2 x)e^{${a}x}\\).`
    ],
    traps: [
      {ans: `\\(y = C_1 e^{${a}x} + C_2 e^{${a}x}\\)`, why: 'Those two terms collapse into one constant — a repeated root needs x·e^{rx} as the independent second solution.'},
      {ans: `\\(y = C_1 e^{${a}x} + C_2 e^{${-a}x}\\)`, why: 'The discriminant is zero: one root, twice. There is no second distinct root.'}
    ],
    vec: [unitIndex('DE_SecondOrder'), 3, a],
    key: 'de2_gen_repeated'
  };
});
registerGen('DE_SecondOrder', (rng)=>{
  const w = pick(rng,[2,3,4,5]);
  return {
    q: `Write the general solution of \\(y'' + ${w*w}y = 0\\).`,
    a: `\\(y = C_1\\cos(${w}x) + C_2\\sin(${w}x)\\)`,
    steps: [
      `Characteristic: \\(r^2 + ${w*w} = 0 \\Rightarrow r = \\pm ${w}i\\) (pure imaginary).`,
      `Complex roots \\(\\pm\\omega i\\) give oscillation: \\(y = C_1\\cos(${w}x) + C_2\\sin(${w}x)\\).`
    ],
    traps: [
      {ans: `\\(y = C_1 e^{${w}x} + C_2 e^{${-w}x}\\)`, why: 'r² = −' + (w*w) + ' has IMAGINARY roots — real exponentials come from r² = +' + (w*w) + '.'},
      {ans: `\\(y = C_1\\cos(${w*w}x) + C_2\\sin(${w*w}x)\\)`, why: 'The frequency is √' + (w*w) + ' = ' + w + ', not ' + (w*w) + ' — the root of the characteristic equation, not the coefficient.'}
    ],
    vec: [unitIndex('DE_SecondOrder'), 4, w],
    key: 'de2_gen_complex'
  };
});
registerGen('DE_SecondOrder', (rng)=>{
  const r1 = -1, r2 = mwNZ(rng,1,3);
  const C1 = mwNZ(rng,1,3), C2 = mwNZ(rng,1,3);
  const A = C1 + C2, B = r1*C1 + r2*C2;
  const b = -(r1+r2), c = r1*r2;
  return {
    q: `Solve the IVP \\(y'' ${b<0?'-':'+'} ${Math.abs(b)}y' ${c<0?'-':'+'} ${Math.abs(c)}y = 0\\), \\(y(0) = ${A}\\), \\(y'(0) = ${B}\\).`,
    a: `\\(y = ${C1}e^{-x} + ${C2}e^{${r2}x}\\)`,
    steps: [
      `Roots \\(r = -1, ${r2}\\): general solution \\(y = C_1 e^{-x} + C_2 e^{${r2}x}\\).`,
      `\\(y(0) = C_1 + C_2 = ${A}\\); \\(y'(0) = -C_1 + ${r2}C_2 = ${B}\\).`,
      `Solve the 2×2 system: \\(C_1 = ${C1}\\), \\(C_2 = ${C2}\\).`
    ],
    traps: [
      {ans: `\\(y = ${A}e^{-x} + ${B}e^{${r2}x}\\)`, why: 'y(0) and y′(0) are CONDITIONS, not the constants — solve the two-equation system for C₁, C₂.'},
      {ans: `\\(y = ${C2}e^{-x} + ${C1}e^{${r2}x}\\)`, why: 'Each constant pairs with its own root — keep C₁ with e^{−x} and C₂ with e^{' + r2 + 'x} when solving.'}
    ],
    vec: [unitIndex('DE_SecondOrder'), 5, r2, C1, C2, A, B],
    key: 'de2_ivp'
  };
});
registerGen('DE_SecondOrder', (rng)=>{
  const kind = pick(rng,[0,1,2]);
  const kk = mwNZ(rng,2,4), w = pick(rng,[2,3]);
  const rhs = kind===0 ? `e^{${kk}x}` : kind===1 ? `${mwNZ(rng,2,5)}x` : `\\sin(${w}x)`;
  const forms = [`\\(y_p = Ae^{${kk}x}\\)`, `\\(y_p = Ax + B\\)`, `\\(y_p = A\\cos(${w}x) + B\\sin(${w}x)\\)`];
  const a = forms[kind];
  const others = forms.filter((_,i)=>i!==kind);
  return {
    q: `For \\(y'' + 5y' + 6y = ${rhs}\\), what is the correct FORM of the particular solution (undetermined coefficients)? (Note: the characteristic roots are \\(-2, -3\\).)`,
    a: a,
    steps: [
      `Match the guess to the forcing term: exponential → \\(Ae^{kx}\\); polynomial → same-degree polynomial; sine/cosine → BOTH \\(A\\cos + B\\sin\\).`,
      `No resonance here: ${kind===0 ? kk : kind===2 ? '\\(\\pm '+w+'i\\)' : '0'} is not a characteristic root \\((-2, -3)\\), so no extra factor of \\(x\\).`
    ],
    traps: [
      {ans: others[0], why: 'The guess mirrors the forcing function’s family — exponential begets exponential, sine begets sine AND cosine.'},
      {ans: kind===2 ? `\\(y_p = A\\sin(${w}x)\\)` : `\\(y_p = Axe^{${kk}x}\\)`, why: kind===2 ? 'Sine forcing needs BOTH sin and cos in the guess — differentiation mixes them.' : 'The x-factor is only added when the forcing matches a characteristic root (resonance) — not the case here.'}
    ],
    vec: [unitIndex('DE_SecondOrder'), 6, kind, kk, w],
    key: 'de2_undetermined_form'
  };
});
registerGen('DE_SecondOrder', (rng)=>{
  const m = pick(rng,[1,4]), w = pick(rng,[2,3,5]);
  const kspr = m*w*w;
  return {
    q: `A spring-mass system satisfies \\(${m===1?'':m}y'' + ${kspr}y = 0\\) (mass ${m}, spring constant ${kspr}). Find the angular frequency of oscillation.`,
    a: `\\(\\omega = ${w}\\)`,
    steps: [
      `Standard form: \\(y'' + \\frac{k}{m}y = 0\\) with \\(\\omega = \\sqrt{k/m}\\).`,
      `\\(\\omega = \\sqrt{${kspr}/${m}} = \\sqrt{${w*w}} = ${w}\\).`,
      `Solutions oscillate as \\(\\cos(${w}t)\\), \\(\\sin(${w}t)\\).`
    ],
    traps: [
      {ans: `\\(\\omega = ${w*w}\\)`, why: 'ω is the SQUARE ROOT of k/m — the characteristic roots are ±√(k/m)·i.'},
      {ans: `\\(\\omega = ${kspr}\\)`, why: 'Divide by the mass first: ω² = k/m, then take the root.'}
    ],
    vec: [unitIndex('DE_SecondOrder'), 7, m, kspr, w],
    key: 'de2_spring'
  };
});
registerGen('DE_Laplace', (rng)=>{
  const kind = pick(rng,[0,1,2]);
  const a = mwNZ(rng,1,4), n = pick(rng,[2,3]), b = pick(rng,[2,3]);
  const fact = n===2 ? 2 : 6;
  const qs = [`e^{${a}t}`, `t^${n}`, `\\sin(${b}t)`];
  const ans = [`\\(\\dfrac{1}{s-${a}}\\)`, `\\(\\dfrac{${fact}}{s^{${n+1}}}\\)`, `\\(\\dfrac{${b}}{s^2+${b*b}}\\)`];
  const traps2 = [
    [{ans:`\\(\\dfrac{1}{s+${a}}\\)`, why:'L{e^{at}} = 1/(s − a): the sign of a carries through — s MINUS a for positive exponent.'},
     {ans:`\\(\\dfrac{${a}}{s}\\)`, why:'1/s is the transform of the constant 1; an exponential shifts s by a.'}],
    [{ans:`\\(\\dfrac{${n}}{s^{${n+1}}}\\)`, why:'L{tⁿ} = n!/s^{n+1} — the numerator is the FACTORIAL, ' + fact + ', not n.'},
     {ans:`\\(\\dfrac{${fact}}{s^{${n}}}\\)`, why:'The power of s is n + 1 = ' + (n+1) + '.'}],
    [{ans:`\\(\\dfrac{s}{s^2+${b*b}}\\)`, why:'s/(s²+b²) is COSINE; sine has the constant b on top.'},
     {ans:`\\(\\dfrac{${b}}{s^2-${b*b}}\\)`, why:'Trig transforms have s² PLUS b²; the minus version belongs to hyperbolic functions.'}]
  ][kind];
  return {
    q: `Find the Laplace transform \\(\\mathcal{L}\\{${qs[kind]}\\}\\).`,
    a: ans[kind],
    steps: [
      `Standard table: \\(\\mathcal{L}\\{e^{at}\\} = \\frac{1}{s-a}\\), \\(\\mathcal{L}\\{t^n\\} = \\frac{n!}{s^{n+1}}\\), \\(\\mathcal{L}\\{\\sin bt\\} = \\frac{b}{s^2+b^2}\\).`,
      `Apply with the given constants.`
    ],
    traps: traps2,
    vec: [unitIndex('DE_Laplace'), 1, kind, a, n, b],
    key: 'de3_laplace_basic'
  };
});
registerGen('DE_Laplace', (rng)=>{
  const A = mwNZ(rng,2,5), B = mwNZ(rng,2,4), a = mwNZ(rng,1,4);
  return {
    q: `Find \\(\\mathcal{L}\\{${A} + ${B}e^{${a}t}\\}\\).`,
    a: `\\(\\dfrac{${A}}{s} + \\dfrac{${B}}{s-${a}}\\)`,
    steps: [
      `Laplace is linear: transform each term and keep the constants.`,
      `\\(\\mathcal{L}\\{${A}\\} = \\frac{${A}}{s}\\); \\(\\mathcal{L}\\{${B}e^{${a}t}\\} = \\frac{${B}}{s-${a}}\\).`
    ],
    traps: [
      {ans: `\\(\\dfrac{${A+B}}{s-${a}}\\)`, why: 'Transform term by term — the constant ' + A + ' transforms to ' + A + '/s, not into the exponential’s fraction.'},
      {ans: `\\(\\dfrac{${A}}{s} + \\dfrac{${B}}{s+${a}}\\)`, why: 'e^{+at} shifts to s − a; the s + a version is e^{−at}.'}
    ],
    vec: [unitIndex('DE_Laplace'), 2, A, B, a],
    key: 'de3_laplace_linear'
  };
});
registerGen('DE_Laplace', (rng)=>{
  const kind = pick(rng,[0,1]);
  const cc = mwNZ(rng,2,5), a = mwNZ(rng,1,4), b = pick(rng,[2,3,4]);
  const Ftex = kind===0 ? `\\dfrac{${cc}}{s-${a}}` : `\\dfrac{${b}}{s^2+${b*b}}`;
  const ans = kind===0 ? `\\(${cc}e^{${a}t}\\)` : `\\(\\sin(${b}t)\\)`;
  return {
    q: `Find the inverse Laplace transform \\(\\mathcal{L}^{-1}\\left\\{${Ftex}\\right\\}\\).`,
    a: ans,
    steps: [
      kind===0 ? `\\(\\frac{1}{s-a}\\) inverts to \\(e^{at}\\); the constant ${cc} rides along.`
               : `\\(\\frac{b}{s^2+b^2}\\) is exactly the sine pattern with \\(b = ${b}\\).`
    ],
    traps: kind===0 ? [
      {ans: `\\(${cc}e^{${-a}t}\\)`, why: 's − ' + a + ' in the denominator means e^{+' + a + 't} — the sign flips only for s + a.'},
      {ans: `\\(${cc}t e^{${a}t}\\)`, why: 'The t-factor appears for (s−a)² (a squared denominator); first power inverts to a plain exponential.'}
    ] : [
      {ans: `\\(\\cos(${b}t)\\)`, why: 'Cosine has s in the numerator; a constant on top is sine.'},
      {ans: `\\(\\sin(${b*b}t)\\)`, why: 'The frequency is b = ' + b + ' (from b² = ' + (b*b) + ' in the denominator), matching the numerator.'}
    ],
    vec: [unitIndex('DE_Laplace'), 3, kind, cc, a, b],
    key: 'de3_inverse'
  };
});
registerGen('DE_Laplace', (rng)=>{
  const y0 = mwNZ(rng,1,4);
  return {
    q: `If \\(\\mathcal{L}\\{y(t)\\} = Y(s)\\) and \\(y(0) = ${y0}\\), express \\(\\mathcal{L}\\{y'(t)\\}\\).`,
    a: `\\(sY(s) - ${y0}\\)`,
    steps: [
      `Derivative rule: \\(\\mathcal{L}\\{y'\\} = sY(s) - y(0)\\).`,
      `This is what converts a differential equation into ALGEBRA in s.`
    ],
    traps: [
      {ans: `\\(sY(s) + ${y0}\\)`, why: 'The initial value is SUBTRACTED — it comes from the boundary term of integration by parts.'},
      {ans: `\\(\\dfrac{Y(s)}{s} - ${y0}\\)`, why: 'Differentiation MULTIPLIES by s; dividing by s corresponds to integration.'}
    ],
    vec: [unitIndex('DE_Laplace'), 4, y0],
    key: 'de3_laplace_deriv'
  };
});
registerGen('DE_Laplace', (rng)=>{
  const a = mwNZ(rng,1,4), y0 = mwNZ(rng,1,5);
  return {
    q: `Use Laplace transforms on \\(y' + ${a}y = 0\\), \\(y(0) = ${y0}\\): find \\(Y(s)\\).`,
    a: `\\(Y(s) = \\dfrac{${y0}}{s+${a}}\\)`,
    steps: [
      `Transform: \\(sY - ${y0} + ${a}Y = 0\\).`,
      `Solve for Y: \\((s + ${a})Y = ${y0} \\Rightarrow Y = \\frac{${y0}}{s+${a}}\\).`,
      `(Inverting gives \\(y = ${y0}e^{-${a}t}\\) — matching the separable-method answer.)`
    ],
    traps: [
      {ans: `\\(Y(s) = \\dfrac{${y0}}{s-${a}}\\)`, why: 'The +' + a + 'y term joins s as (s + ' + a + ') — the sign follows the equation.'},
      {ans: `\\(Y(s) = \\dfrac{1}{s(s+${a})}\\)`, why: 'The initial condition y(0) = ' + y0 + ' enters through L{y′} = sY − y(0) — it becomes the numerator.'}
    ],
    vec: [unitIndex('DE_Laplace'), 5, a, y0],
    key: 'de3_laplace_solve'
  };
});
registerGen('DE_Basics', (rng)=>{
  const kind = pick(rng, ['lin1','lin2','nonlin_y2','nonlin_yy']);
  const a = mwNZ(rng,2,5), b = mwNZ(rng,2,6);
  let tex, label, why;
  if(kind==='lin1'){ tex = `y' + ${a}y = ${b}x`; label = 'First order, linear'; why = `highest derivative is \\(y'\\) and \\(y\\) appears only to the first power with coefficients in \\(x\\)`; }
  else if(kind==='lin2'){ tex = `y'' + ${a}y' + ${b}y = 0`; label = 'Second order, linear'; why = `highest derivative is \\(y''\\); every \\(y\\)-term is first power`; }
  else if(kind==='nonlin_y2'){ tex = `y' + ${a}y^2 = ${b}x`; label = 'First order, nonlinear'; why = `the \\(y^2\\) term makes it nonlinear — linear means \\(y\\) and its derivatives appear only to the first power`; }
  else { tex = `y\\,y' = ${a}x + ${b}`; label = 'First order, nonlinear'; why = `the product \\(y\\,y'\\) is nonlinear`; }
  const all = ['First order, linear','First order, nonlinear','Second order, linear','Second order, nonlinear'];
  const others = all.filter(s=>s!==label);
  return {
    q: `Classify the differential equation \\(${tex}\\) by order and linearity.`,
    a: label,
    steps: [
      `Order = highest derivative present.`,
      `Linear = expressible as \\(y' + P(x)y = Q(x)\\) (or its higher-order analog): \\(y\\) and its derivatives only to the first power, never multiplied together.`,
      `Here ${why}. So: ${label.toLowerCase()}.`
    ],
    traps: [
      {ans: others[0], why: 'Order counts the HIGHEST derivative; linearity fails the moment y or a derivative is squared or multiplied by another.'},
      {ans: others[1], why: 'Coefficients may depend on x freely — that does not break linearity. Powers/products of y do.'}
    ],
    vec: [unitIndex('DE_Basics'), 1, ['lin1','lin2','nonlin_y2','nonlin_yy'].indexOf(kind), a, b],
    key: 'de_classify'
  };
});
registerGen('DE_Basics', (rng)=>{
  const k = mwNZ(rng,2,5), C = mwNZ(rng,2,4);
  return {
    q: `Which function is a solution of \\(\\frac{dy}{dx} = ${k}y\\)?`,
    a: `\\(y = ${C}e^{${k}x}\\)`,
    steps: [
      `Test by substitution: if \\(y = ${C}e^{${k}x}\\), then \\(y' = ${C*k}e^{${k}x} = ${k}\\cdot(${C}e^{${k}x}) = ${k}y\\). ✓`,
      `Any constant multiple \\(Ce^{${k}x}\\) works — exponentials are the functions whose derivative is proportional to themselves.`
    ],
    traps: [
      {ans: `\\(y = ${C}e^{${-k}x}\\)`, why: 'Sign of the exponent must MATCH k: differentiating e^{-kx} brings down −k, giving y′ = −ky.'},
      {ans: `\\(y = ${C}x^{${k}}\\)`, why: 'Power functions give y′ = kx^{k−1}, which is k·y/x, not k·y — the proportionality constant would depend on x.'}
    ],
    vec: [unitIndex('DE_Basics'), 2, k, C],
    key: 'de_which_solution'
  };
});
registerGen('DE_Methods', (rng)=>{
  const a = pick(rng,[2,4,6,8]);
  return {
    q: `Solve the separable equation \\(y\\,\\frac{dy}{dx} = ${a}x\\). Give the general solution.`,
    a: `\\(y^2 = ${a}x^2 + C\\)`,
    steps: [
      `Separate: \\(y\\,dy = ${a}x\\,dx\\).`,
      `Integrate both sides: \\(\\frac{y^2}{2} = \\frac{${a}x^2}{2} + C_1\\).`,
      `Multiply by 2 and absorb the constant: \\(y^2 = ${a}x^2 + C\\).`
    ],
    traps: [
      {ans: `\\(y^2 = ${a/2}x^2 + C\\)`, why: 'Both sides get divided by 2 when integrating — the 2s cancel, so the coefficient of x² stays ' + a + '.'},
      {ans: `\\(y = ${a}x + C\\)`, why: 'You cannot just "cancel" dy/dx — separate the variables and integrate each side.'}
    ],
    vec: [unitIndex('DE_Methods'), 3, a],
    key: 'de_sep_general'
  };
});
registerGen('DE_Methods', (rng)=>{
  const a = mwNZ(rng,2,4), y0 = mwNZ(rng,2,5);
  return {
    q: `Solve the initial value problem \\(\\frac{dy}{dx} = ${a}y\\), \\(y(0) = ${y0}\\).`,
    a: `\\(y = ${y0}e^{${a}x}\\)`,
    steps: [
      `Separate: \\(\\frac{dy}{y} = ${a}\\,dx\\), integrate: \\(\\ln|y| = ${a}x + C_1\\).`,
      `Exponentiate: \\(y = Ce^{${a}x}\\).`,
      `Apply \\(y(0)=${y0}\\): \\(C = ${y0}\\). So \\(y = ${y0}e^{${a}x}\\).`
    ],
    traps: [
      {ans: `\\(y = e^{${a}x} + ${y0-1}\\)`, why: 'The constant multiplies the exponential (y = Ce^{ax}); it is not added. Adding a constant does not satisfy y′ = ay.'},
      {ans: `\\(y = ${y0}e^{${-a}x}\\)`, why: 'Sign of the growth rate a carries straight into the exponent — check by substituting back.'}
    ],
    vec: [unitIndex('DE_Methods'), 4, a, y0],
    key: 'de_sep_ivp'
  };
});
registerGen('DE_Methods', (rng)=>{
  const a = mwNZ(rng,2,6), b = mwNZ(rng,1,5);
  return {
    q: `Find the integrating factor for the linear equation \\(y' + ${a}y = ${b}x\\).`,
    a: `\\(\\mu(x) = e^{${a}x}\\)`,
    steps: [
      `For \\(y' + P(x)y = Q(x)\\), the integrating factor is \\(\\mu = e^{\\int P\\,dx}\\).`,
      `Here \\(P(x) = ${a}\\), so \\(\\mu = e^{\\int ${a}\\,dx} = e^{${a}x}\\).`,
      `Check: \\((\\mu y)' = \\mu y' + ${a}\\mu y = \\mu(y' + ${a}y)\\). ✓`
    ],
    traps: [
      {ans: `\\(\\mu(x) = e^{${b}x}\\)`, why: 'μ uses P (the coefficient of y), not Q (the right-hand side).'},
      {ans: `\\(\\mu(x) = ${a}x\\)`, why: 'μ = e^{∫P dx} — the exponential of the integral, not the integral itself.'}
    ],
    vec: [unitIndex('DE_Methods'), 5, a, b],
    key: 'de_linear_if'
  };
});
registerGen('DE_Methods', (rng)=>{
  const a = mwNZ(rng,2,5);
  const yp = mwNZ(rng,1,4);            // choose the particular value, keep b/a integer
  const b = a * yp;
  return {
    q: `Find the general solution of \\(y' + ${a}y = ${b}\\).`,
    a: `\\(y = ${yp} + Ce^{${-a}x}\\)`,
    steps: [
      `Equilibrium (particular) solution: set \\(y' = 0\\): \\(y = ${b}/${a} = ${yp}\\).`,
      `Homogeneous part: \\(y' + ${a}y = 0\\) gives \\(Ce^{${-a}x}\\).`,
      `General solution = particular + homogeneous: \\(y = ${yp} + Ce^{${-a}x}\\).`
    ],
    traps: [
      {ans: `\\(y = ${yp} + Ce^{${a}x}\\)`, why: 'The homogeneous solution of y′ + ay = 0 decays: y = Ce^{−ax}. Positive exponent would blow up and fails substitution.'},
      {ans: `\\(y = ${b} + Ce^{${-a}x}\\)`, why: 'The equilibrium is b/a (set y′ = 0 and solve), not b itself.'}
    ],
    vec: [unitIndex('DE_Methods'), 6, a, b, yp],
    key: 'de_linear_solve'
  };
});
registerGen('DE_Methods', (rng)=>{
  const a = mwNZ(rng,2,4), yp = mwNZ(rng,1,4), b = a*yp;
  let y0 = mwNZ(rng,-3,6); if(y0 === yp) y0 += 1;
  const C = y0 - yp;
  return {
    q: `Solve \\(y' + ${a}y = ${b}\\) with \\(y(0) = ${y0}\\).`,
    a: `\\(y = ${yp} + ${C}e^{${-a}x}\\)`,
    steps: [
      `General solution: \\(y = ${yp} + Ce^{${-a}x}\\) (equilibrium ${yp} plus decaying homogeneous part).`,
      `Apply \\(y(0) = ${y0}\\): \\(${y0} = ${yp} + C \\Rightarrow C = ${C}\\).`,
      `So \\(y = ${yp} + ${C}e^{${-a}x}\\); as \\(x \\to \\infty\\), \\(y \\to ${yp}\\).`
    ],
    traps: [
      {ans: `\\(y = ${yp} + ${y0}e^{${-a}x}\\)`, why: 'C is y(0) MINUS the equilibrium value, not y(0) itself — substitute x = 0 carefully.'},
      {ans: `\\(y = ${y0} + ${C}e^{${-a}x}\\)`, why: 'The constant term of the solution is the equilibrium b/a; the initial condition only sets C.'}
    ],
    vec: [unitIndex('DE_Methods'), 7, a, b, y0, yp, C],
    key: 'de_linear_ivp'
  };
});
registerGen('DE_AppsNum', (rng)=>{
  const d = pick(rng,[20,25,50,100]);   // k = 1/d
  return {
    q: `A population grows by \\(\\frac{dP}{dt} = \\frac{1}{${d}}P\\). How long until the population doubles?`,
    a: `\\(t = ${d}\\ln 2\\)`,
    steps: [
      `Solution: \\(P = P_0 e^{t/${d}}\\).`,
      `Doubling: \\(2P_0 = P_0 e^{t/${d}} \\Rightarrow e^{t/${d}} = 2\\).`,
      `Take logs: \\(t/${d} = \\ln 2 \\Rightarrow t = ${d}\\ln 2 \\approx ${(d*0.693).toFixed(1)}\\).`
    ],
    traps: [
      {ans: `\\(t = \\dfrac{\\ln 2}{${d}}\\)`, why: 'k = 1/' + d + ', so t = ln2 / k = ' + d + '·ln2 — dividing by k means MULTIPLYING by ' + d + '.'},
      {ans: `\\(t = ${2*d}\\)`, why: 'Doubling time involves ln 2 ≈ 0.693, not the factor 2 itself — exponential growth is not linear.'}
    ],
    vec: [unitIndex('DE_AppsNum'), 8, d],
    key: 'de_growth_double'
  };
});
registerGen('DE_AppsNum', (rng)=>{
  const T = pick(rng,[10,20,30,50]);
  return {
    q: `A radioactive substance decays by \\(\\frac{dy}{dt} = -ky\\) and has half-life ${T} years. Find \\(k\\).`,
    a: `\\(k = \\dfrac{\\ln 2}{${T}}\\)`,
    steps: [
      `Solution: \\(y = y_0 e^{-kt}\\).`,
      `Half-life: \\(\\tfrac{1}{2}y_0 = y_0 e^{-k(${T})} \\Rightarrow e^{-${T}k} = \\tfrac{1}{2}\\).`,
      `Logs: \\(-${T}k = \\ln\\tfrac{1}{2} = -\\ln 2 \\Rightarrow k = \\dfrac{\\ln 2}{${T}}\\).`
    ],
    traps: [
      {ans: `\\(k = ${T}\\ln 2\\)`, why: 'Solving −Tk = −ln2 gives k = ln2 / T — divide by the half-life, not multiply.'},
      {ans: `\\(k = \\dfrac{1}{${T}}\\)`, why: 'Half-life relates to k through ln 2: k = ln2/T ≈ 0.693/T, not 1/T.'}
    ],
    vec: [unitIndex('DE_AppsNum'), 9, T],
    key: 'de_decay_halflife'
  };
});
registerGen('DE_AppsNum', (rng)=>{
  const y0 = mwNZ(rng,1,4), c = mwNZ(rng,1,3);          // f(x,y) = x + c*y ; h = 0.5, start x=0
  const h = 0.5;
  const f = (x,y)=> x + c*y;
  const y1 = y0 + h*f(0, y0);
  const y2 = y1 + h*f(0.5, y1);
  const fmt = (v)=> Number.isInteger(v) ? String(v) : v.toFixed(v*100 % 10 === 0 ? 2 : 3).replace(/0+$/,'').replace(/\.$/,'');
  const wrong1 = y0 + 2*h*f(0, y0);                      // one big step
  const wrong2 = y1 + h*f(0, y1);                        // forgot to advance x
  return {
    q: `Use Euler's method with step size \\(h = 0.5\\) to approximate \\(y(1)\\) for \\(y' = x + ${c}y\\), \\(y(0) = ${y0}\\). (Two steps.)`,
    a: `\\(y(1) \\approx ${fmt(y2)}\\)`,
    steps: [
      `Step 1: \\(y_1 = y_0 + h\\,f(x_0, y_0) = ${y0} + 0.5(0 + ${c}\\cdot${y0}) = ${fmt(y1)}\\).`,
      `Step 2: \\(y_2 = y_1 + h\\,f(x_1, y_1) = ${fmt(y1)} + 0.5(0.5 + ${c}\\cdot${fmt(y1)}) = ${fmt(y2)}\\).`,
      `Each step uses the CURRENT point \\((x_n, y_n)\\) — both coordinates advance.`
    ],
    traps: [
      {ans: `\\(y(1) \\approx ${fmt(wrong1)}\\)`, why: 'That is one step of size 1 — Euler with h = 0.5 needs two updates, recomputing the slope at each new point.'},
      {ans: `\\(y(1) \\approx ${fmt(wrong2)}\\)`, why: 'x advances too: the second slope is f(0.5, y₁), not f(0, y₁).'}
    ],
    vec: [unitIndex('DE_AppsNum'), 10, y0, c],
    key: 'de_euler_step'
  };
});
registerGen('DE_Basics', (rng)=>{
  const a = mwNZ(rng,2,5), b = mwNZ(rng,2,5), c = mwNZ(rng,2,5);
  const exact = pick(rng,[true,false]);
  const b2 = exact ? b : b + mwNZ(rng,1,3);
  const M = `${a}x + ${b}y`, N = `${b2}x + ${c}y`;
  const label = exact ? 'Exact' : 'Not exact';
  return {
    q: `Is the equation \\((${M})\\,dx + (${N})\\,dy = 0\\) exact?`,
    a: label,
    steps: [
      `Test: exact \\(\\iff \\dfrac{\\partial M}{\\partial y} = \\dfrac{\\partial N}{\\partial x}\\).`,
      `\\(M_y = ${b}\\) and \\(N_x = ${b2}\\).`,
      exact ? `They match — exact.` : `\\(${b} \\ne ${b2}\\) — not exact.`
    ],
    traps: [
      {ans: exact ? 'Not exact' : 'Exact', why: 'Compare M_y with N_x (cross partials) — not M_x with N_y.'},
      {ans: exact ? 'Cannot be determined' : 'Cannot be determined', why: 'The test is decisive for continuously differentiable M, N: check the two partials.'}
    ],
    vec: [unitIndex('DE_Basics'), 11, exact?1:0, a, b, b2, c],
    key: 'de_exact_test'
  };
});
registerGen('DE_Basics', (rng)=>{
  const a = mwNZ(rng,2,6);
  return {
    q: `Find all equilibrium solutions of the autonomous equation \\(\\frac{dy}{dt} = y(${a} - y)\\).`,
    a: `\\(y = 0\\) and \\(y = ${a}\\)`,
    steps: [
      `Equilibria are constant solutions: set \\(\\frac{dy}{dt} = 0\\).`,
      `\\(y(${a} - y) = 0 \\Rightarrow y = 0\\) or \\(y = ${a}\\).`,
      `(Direction-field check: \\(y' > 0\\) between them, so \\(y = ${a}\\) is the stable one — solutions flow toward it.)`
    ],
    traps: [
      {ans: `\\(y = ${a}\\) only`, why: 'y = 0 also makes the product zero — a factor set to zero is still a solution even when it looks trivial.'},
      {ans: `\\(y = 0\\) and \\(y = ${-a}\\)`, why: 'Solve a − y = 0 carefully: y = +' + a + '. Watch the sign when moving y across.'}
    ],
    vec: [unitIndex('DE_Basics'), 12, a],
    key: 'de_equilibria'
  };
});
