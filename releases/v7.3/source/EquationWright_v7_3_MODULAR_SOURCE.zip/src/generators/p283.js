// P283 generator registrations — order frozen by the published registry.
registerGen('P283_Continuous', (rng)=>{
  const n = pick(rng,[2,3,4,5]);   // f(x) = k x^{n-1} on [0,1] -> k = n
  return {
    q: `Find \\(k\\) so that \\(f(x) = kx^{${n-1}}\\) on \\([0, 1]\\) is a valid probability density function.`,
    a: `\\(k = ${n}\\)`,
    steps: [
      `A pdf must integrate to 1: \\(\\int_0^1 kx^{${n-1}}\\,dx = \\dfrac{k}{${n}} = 1\\).`,
      `So \\(k = ${n}\\). (Also \\(f \\ge 0\\) on the interval. ✓)`
    ],
    traps: [
      {ans: `\\(k = \\dfrac{1}{${n}}\\)`, why: 'The integral gives k/' + n + ' = 1, so k = ' + n + ' — solve for k, do not just invert the exponent.'},
      {ans: `\\(k = 1\\)`, why: 'x^{' + (n-1) + '} alone integrates to 1/' + n + ' on [0,1] — the constant rescales the total area to 1.'}
    ],
    vec: [unitIndex('P283_Continuous'), 1, n],
    key: 'p283_pdf_valid'
  };
});
registerGen('P283_Continuous', (rng)=>{
  const n = pick(rng,[2,3]);       // f = n x^{n-1}, P(X <= c) = c^n
  const cd = pick(rng,[[1,2],[1,3],[2,3],[3,4],[1,4]]);
  const [cn, cdn] = cd;
  const num = Math.pow(cn, n), den = Math.pow(cdn, n);
  return {
    q: `A random variable has pdf \\(f(x) = ${n}x^{${n-1}}\\) on \\([0,1]\\). Find \\(P\\left(X \\le \\tfrac{${cn}}{${cdn}}\\right)\\). (Exact.)`,
    a: `\\(\\dfrac{${num}}{${den}}\\)`,
    steps: [
      `\\(P(X \\le c) = \\int_0^{c} ${n}x^{${n-1}}\\,dx = c^{${n}}\\).`,
      `\\(= \\left(\\tfrac{${cn}}{${cdn}}\\right)^{${n}} = \\tfrac{${num}}{${den}}\\).`
    ],
    traps: [
      {ans: `\\(\\dfrac{${cn}}{${cdn}}\\)`, why: 'Probability is the INTEGRAL of the density up to c, which is c^' + n + ' here — not c itself.'},
      {ans: `\\(\\dfrac{${den-num}}{${den}}\\)`, why: 'That is P(X > c), the complement — check the inequality direction.'}
    ],
    vec: [unitIndex('P283_Continuous'), 2, n, cn, cdn],
    key: 'p283_prob_integral'
  };
});
registerGen('P283_Continuous', (rng)=>{
  const n = pick(rng,[1,2,3,4,5]);  // f = (n+1)x^n on [0,1], E[X] = (n+1)/(n+2)
  return {
    q: `For the pdf \\(f(x) = ${n+1}x^{${n}}\\) on \\([0,1]\\), compute \\(E[X]\\). (Exact fraction.)`,
    a: `\\(E[X] = \\dfrac{${n+1}}{${n+2}}\\)`,
    steps: [
      `\\(E[X] = \\int_0^1 x\\,f(x)\\,dx = \\int_0^1 ${n+1}x^{${n+1}}\\,dx\\).`,
      `\\(= \\dfrac{${n+1}}{${n+2}}\\).`
    ],
    traps: [
      {ans: `\\(E[X] = \\dfrac{1}{2}\\)`, why: '1/2 is the mean of the UNIFORM density; this density piles weight toward 1, pulling the mean right.'},
      {ans: `\\(E[X] = \\dfrac{${n+1}}{${n+1+2}}\\)` === `\\(E[X] = \\dfrac{${n+1}}{${n+2}}\\)` ? `\\(E[X] = \\dfrac{${n}}{${n+1}}\\)` : `\\(E[X] = \\dfrac{${n+1}}{${n+3}}\\)`, why: 'Multiplying by x raises the exponent to ' + (n+1) + ', so the integral is (n+1)/(n+2) — track the powers carefully.'}
    ],
    vec: [unitIndex('P283_Continuous'), 3, n],
    key: 'p283_expectation'
  };
});
registerGen('P283_Continuous', (rng)=>{
  const b = pick(rng,[2,4,6,12]);
  const varv = b*b/12;
  const varTex = Number.isInteger(varv) ? String(varv) : `\\dfrac{${b*b}}{12}`;
  return {
    q: `\\(X\\) is uniform on \\([0, ${b}]\\). Find \\(E[X]\\) and \\(\\text{Var}(X)\\). (Exact.)`,
    a: `\\(E[X] = ${b/2}\\), \\(\\text{Var}(X) = ${varTex}\\)`,
    steps: [
      `Uniform on \\([0,b]\\): \\(E[X] = b/2 = ${b/2}\\).`,
      `\\(\\text{Var} = \\dfrac{b^2}{12} = \\dfrac{${b*b}}{12}${Number.isInteger(varv)?' = '+varv:''}\\) — derived from \\(E[X^2] - (E[X])^2 = \\tfrac{b^2}{3} - \\tfrac{b^2}{4}\\).`
    ],
    traps: [
      {ans: `\\(E[X] = ${b/2}\\), \\(\\text{Var}(X) = ${Number.isInteger(b*b/4)? b*b/4 : '\\\\dfrac{'+b*b+'}{4}'}\\)`, why: 'b²/4 is (E[X])² — the variance subtracts it FROM E[X²] = b²/3, leaving b²/12.'},
      {ans: `\\(E[X] = ${b}\\), \\(\\text{Var}(X) = ${varTex}\\)`, why: 'The uniform mean is the MIDPOINT b/2, not the endpoint.'}
    ],
    vec: [unitIndex('P283_Continuous'), 4, b],
    key: 'p283_uniform_var'
  };
});
registerGen('P283_ExpNormal', (rng)=>{
  const d = pick(rng,[2,4,5,10]);   // lambda = 1/d
  const t = d * pick(rng,[1,2,3,4,5]);
  const k = t/d;
  return {
    q: `Lifetimes are exponential with rate \\(\\lambda = \\tfrac{1}{${d}}\\) per year. Find \\(P(X > ${t})\\). (Exact.)`,
    a: `\\(e^{-${k}}` .replace('e^{-1}','e^{-1}') + `\\)`,
    steps: [
      `Exponential survival: \\(P(X > t) = e^{-\\lambda t}\\).`,
      `\\(= e^{-${t}/${d}} = e^{-${k}} \\approx ${Math.exp(-k).toFixed(4)}\\).`
    ],
    traps: [
      {ans: `\\(1 - e^{-${k}}\\)`, why: 'That is P(X ≤ ' + t + '), the CDF — "greater than" is the survival function e^{−λt}.'},
      {ans: `\\(e^{-${t*d}}\\)`, why: 'λt = t/' + d + ' = ' + k + ' — the rate is 1/' + d + ', so divide, do not multiply by ' + d + '.'}
    ],
    vec: [unitIndex('P283_ExpNormal'), 1, d, t],
    key: 'p283_exponential_sf'
  };
});
registerGen('P283_ExpNormal', (rng)=>{
  const d = pick(rng,[2,4,5,8,10,20]);
  return {
    q: `\\(X\\) is exponential with \\(\\lambda = \\tfrac{1}{${d}}\\). Find the mean and standard deviation.`,
    a: `\\(\\mu = ${d}\\), \\(\\sigma = ${d}\\)`,
    steps: [
      `Exponential: \\(\\mu = 1/\\lambda = ${d}\\).`,
      `Its standard deviation EQUALS its mean: \\(\\sigma = 1/\\lambda = ${d}\\) — a signature property of the exponential.`
    ],
    traps: [
      {ans: `\\(\\mu = ${d}\\), \\(\\sigma = ${d*d}\\)`, why: (d*d) + ' is the VARIANCE 1/λ²; σ is its square root, 1/λ = ' + d + '.'},
      {ans: `\\(\\mu = \\tfrac{1}{${d}}\\), \\(\\sigma = \\tfrac{1}{${d}}\\)`, why: 'The mean is the RECIPROCAL of the rate: 1/λ = ' + d + '. A slow rate means a long average wait.'}
    ],
    vec: [unitIndex('P283_ExpNormal'), 2, d],
    key: 'p283_expo_mean'
  };
});
registerGen('P283_ExpNormal', (rng)=>{
  const pairs = [[-2,-0.5],[-1.5,0.5],[-1,1.5],[-0.5,2],[0.5,1.75],[-2.25,0],[0,2.25],[-1.75,-0.25],[0.25,1.25],[-1.25,2.5]];
  const [za, zb] = pick(rng, pairs);
  const mu = pick(rng,[40,75,300]), sd = pick(rng,[4,10,20]);
  const a = mu + za*sd, b = mu + zb*sd;
  const p = mwNormInterval(za, zb);
  return {
    q: `\\(X \\sim N(${mu}, ${sd}^2)\\). Compute \\(P(${a} < X < ${b})\\). (4 decimals.)`,
    a: `\\(${p.toFixed(4)}\\)`,
    steps: [
      `Standardize: \\(z_1 = ${za}\\), \\(z_2 = ${zb}\\).`,
      `\\(P = \\Phi(${zb}) - \\Phi(${za}) = ${p.toFixed(4)}\\).`
    ],
    traps: [
      {ans: `\\(${mwNormCdf(zb).toFixed(4)}\\)`, why: 'Everything below the upper bound still includes the region below the LOWER bound — subtract Φ(z₁).'},
      {ans: `\\(${Math.abs(zb-za).toFixed(4)}\\)`, why: 'The z-distance is not a probability — convert both endpoints through Φ first.'}
    ],
    vec: [unitIndex('P283_ExpNormal'), 3, mu, sd, Math.round(za*100), Math.round(zb*100)],
    key: 'p283_norm_between'
  };
});
registerGen('P283_CLT_Est', (rng)=>{
  const mu = pick(rng,[5,10,20]), sigma = pick(rng,[2,3,5]);
  const n = pick(rng,[4,9,16,25,36]);
  return {
    q: `Let \\(S = X_1 + \\cdots + X_{${n}}\\) with each \\(X_i\\) iid, mean ${mu}, SD ${sigma}. Find the mean and SD of \\(S\\).`,
    a: `\\(E[S] = ${n*mu}\\), \\(SD(S) = ${sigma*Math.sqrt(n)}\\)`,
    steps: [
      `Means add: \\(E[S] = n\\mu = ${n}\\times${mu} = ${n*mu}\\).`,
      `VARIANCES add (independence): \\(\\text{Var}(S) = n\\sigma^2 = ${n*sigma*sigma}\\), so \\(SD = \\sigma\\sqrt{n} = ${sigma}\\sqrt{${n}} = ${sigma*Math.sqrt(n)}\\).`
    ],
    traps: [
      {ans: `\\(E[S] = ${n*mu}\\), \\(SD(S) = ${n*sigma}\\)`, why: 'Standard deviations do NOT add — variances do. SD(S) = σ√n, not nσ.'},
      {ans: `\\(E[S] = ${mu}\\), \\(SD(S) = ${sigma*Math.sqrt(n)}\\)`, why: 'The SUM grows with n: E[S] = nμ. (The sample MEAN keeps μ — different animal.)'}
    ],
    vec: [unitIndex('P283_CLT_Est'), 1, mu, sigma, n],
    key: 'p283_clt_sum'
  };
});
registerGen('P283_CLT_Est', (rng)=>{
  const i = pick(rng,[0,1,2]);
  const items = [
    {q:'the sample mean \\(\\bar{x}\\) as an estimator of \\(\\mu\\)', a:'Unbiased', why:'E[x̄] = μ exactly — its expected value hits the target'},
    {q:'the sample variance with divisor \\(n\\) as an estimator of \\(\\sigma^2\\)', a:'Biased (it underestimates σ²)', why:'dividing by n shrinks it; the n−1 divisor is exactly the correction that makes it unbiased'},
    {q:'the sample variance \\(s^2\\) with divisor \\(n-1\\) as an estimator of \\(\\sigma^2\\)', a:'Unbiased', why:'E[s²] = σ² — that is why the n−1 exists'}
  ];
  const it2 = items[i];
  return {
    q: `Classify ${it2.q}: unbiased or biased?`,
    a: it2.a,
    steps: [
      `An estimator is unbiased when its EXPECTED value equals the parameter.`,
      `Here: ${it2.why}.`
    ],
    traps: [
      {ans: i===1 ? 'Unbiased' : 'Biased (it underestimates σ²)', why: 'Check E[estimator] against the parameter: the n divisor systematically undershoots σ²; x̄ and the n−1 version hit exactly.'},
      {ans: 'Cannot be determined without data', why: 'Bias is a property of the ESTIMATOR (a formula), provable with expectation algebra — no data needed.'}
    ],
    vec: [unitIndex('P283_CLT_Est'), 2, i],
    key: 'p283_unbiased'
  };
});
registerGen('P283_CLT_Est', (rng)=>{
  const xbar = pick(rng,[64,150,32]), sigma = pick(rng,[6,10,15]);
  const n = pick(rng,[9,25,36].filter(v=>sigma % Math.sqrt(v)===0 || Number.isInteger(sigma/Math.sqrt(v)))) || 25;
  const se = sigma/Math.sqrt(n);
  const zs = Math.round(mwInvNorm(0.995)*1000)/1000;   // 2.576
  const moe = Math.round(zs*se*1000)/1000;
  const lo = Math.round((xbar-moe)*1000)/1000, hi = Math.round((xbar+moe)*1000)/1000;
  return {
    q: `A sample of \\(n = ${n}\\) gives \\(\\bar{x} = ${xbar}\\), known \\(\\sigma = ${sigma}\\). Build a 99\\% confidence interval (\\(z^* = ${zs}\\)).`,
    a: `\\((${lo},\\ ${hi})\\)`,
    steps: [
      `99\\% leaves 0.5\\% per tail: \\(z^* = \\Phi^{-1}(0.995) = ${zs}\\).`,
      `Margin: \\(${zs} \\times ${sigma}/\\sqrt{${n}} = ${moe}\\).`,
      `\\(${xbar} \\pm ${moe} = (${lo},\\ ${hi})\\).`
    ],
    traps: [
      {ans: `\\((${Math.round((xbar-1.96*se)*1000)/1000},\\ ${Math.round((xbar+1.96*se)*1000)/1000})\\)`, why: '1.96 is the 95% critical value — 99% needs 2.576, a wider interval for higher confidence.'},
      {ans: `\\((${Math.round((xbar-zs*sigma)*1000)/1000},\\ ${Math.round((xbar+zs*sigma)*1000)/1000})\\)`, why: 'The margin uses σ/√n — the standard error of the mean, not σ.'}
    ],
    vec: [unitIndex('P283_CLT_Est'), 3, xbar, sigma, n],
    key: 'p283_ci_99'
  };
});
registerGen('P283_LSQ', (rng)=>{
  const b = pick(rng,[2,3,-2]);           // slope
  const sxx = pick(rng,[5,10,20]);
  const sxy = b*sxx;
  const xm = pick(rng,[4,6,10]), ym0 = pick(rng,[20,30,50]);
  const a0 = ym0 - b*xm;
  return {
    q: `A least-squares fit has \\(S_{xy} = ${sxy}\\), \\(S_{xx} = ${sxx}\\), \\(\\bar{x} = ${xm}\\), \\(\\bar{y} = ${ym0}\\). Find the slope and intercept of \\(\\hat{y} = a + bx\\).`,
    a: `\\(b = ${b}\\), \\(a = ${a0}\\)`,
    steps: [
      `Slope: \\(b = S_{xy}/S_{xx} = ${sxy}/${sxx} = ${b}\\).`,
      `The line passes through \\((\\bar{x}, \\bar{y})\\): \\(a = \\bar{y} - b\\bar{x} = ${ym0} - ${b}(${xm}) = ${a0}\\).`
    ],
    traps: [
      {ans: `\\(b = ${sxx === sxy ? b+1 : (sxx/sxy % 1 === 0 ? sxx/sxy : Math.round(sxx/sxy*100)/100)}\\), \\(a = ${a0}\\)`, why: 'The slope is S_xy OVER S_xx — the covariance term on top.'},
      {ans: `\\(b = ${b}\\), \\(a = ${ym0}\\)`, why: 'The intercept is ȳ MINUS b·x̄ — the fitted line pivots through the mean point, so a = ȳ only if x̄ = 0.'}
    ],
    vec: [unitIndex('P283_LSQ'), 1, sxy, sxx, xm, ym0, b, a0],
    key: 'p283_lsq_fit'
  };
});
registerGen('P283_LSQ', (rng)=>{
  const combos = [[6,9,16],[12,9,25],[-9,9,25],[15,16,25],[-18,16,25],[5,16,25]];
  const [sxy, sxx, syy] = pick(rng, combos);
  const r = sxy/Math.sqrt(sxx*syy);
  const rTex = Number.isInteger(r*100) ? (r).toFixed(2).replace(/0$/,'') : r.toFixed(3);
  return {
    q: `Given \\(S_{xy} = ${sxy}\\), \\(S_{xx} = ${sxx}\\), \\(S_{yy} = ${syy}\\), compute the correlation coefficient \\(r\\). (Exact decimal.)`,
    a: `\\(r = ${rTex}\\)`,
    steps: [
      `\\(r = \\dfrac{S_{xy}}{\\sqrt{S_{xx}S_{yy}}} = \\dfrac{${sxy}}{\\sqrt{${sxx}\\times${syy}}} = \\dfrac{${sxy}}{${Math.sqrt(sxx*syy)}} = ${rTex}\\).`,
      sxy < 0 ? `Negative S_xy means a negative association.` : `Positive S_xy means a positive association.`
    ],
    traps: [
      {ans: `\\(r = ${(sxy/(sxx*syy)).toFixed(3)}\\)`, why: 'The denominator is the SQUARE ROOT of S_xx·S_yy — without it, r loses its −1..1 scale.'},
      {ans: `\\(r = ${Math.abs(Number(rTex))}\\)` === `\\(r = ${rTex}\\)` ? `\\(r = ${(sxy/sxx).toFixed(2)}\\)` : `\\(r = ${Math.abs(Number(rTex))}\\)`, why: sxy<0 ? 'r inherits the SIGN of S_xy — a negative association has negative r.' : 'S_xy/S_xx is the SLOPE, not the correlation.'}
    ],
    vec: [unitIndex('P283_LSQ'), 2, sxy, sxx, syy],
    key: 'p283_correlation'
  };
});
