// S245 generator registrations — order frozen by the published registry.
registerGen('S245_Probability', (rng)=>{
  const pa = pick(rng,[30,40,50]), pb = pick(rng,[20,30,40]), pab = pick(rng,[10,15,20]);
  const un = pa + pb - pab;
  return {
    q: `Given \\(P(A) = 0.${pa}\\), \\(P(B) = 0.${pb}\\), and \\(P(A \\text{ and } B) = 0.${pab}\\), find \\(P(A \\text{ or } B)\\).`,
    a: `\\(0.${un}\\)`,
    steps: [ `Addition rule: \\(P(A \\cup B) = P(A) + P(B) - P(A \\cap B) = 0.${pa} + 0.${pb} - 0.${pab} = 0.${un}\\).` ],
    traps: [
      {ans: `\\(0.${pa+pb}\\)`, why: 'Adding alone double-counts the overlap — subtract P(A and B) once.'},
      {ans: `\\(0.${Math.round(pa*pb/100)}\\)`, why: 'Multiplying gives P(A and B) for INDEPENDENT events; "or" uses the addition rule.'}
    ],
    vec: [unitIndex('S245_Probability'), 1, pa, pb, pab],
    key: 's245_prob_or'
  };
});
registerGen('S245_Probability', (rng)=>{
  const pa = pick(rng,[20,30,40,50,60]), pb = pick(rng,[10,20,25,50]);
  const both = pa*pb/100;
  const bothR = (both/100).toFixed(both%10===0?2:4).replace(/0+$/,'').replace(/\.$/,'');
  return {
    q: `Events A and B are independent with \\(P(A) = 0.${pa}\\) and \\(P(B) = 0.${pb}\\). Find \\(P(A \\text{ and } B)\\).`,
    a: `\\(${(pa*pb/10000)}\\)`,
    steps: [ `Independence: \\(P(A \\cap B) = P(A)\\,P(B) = 0.${pa} \\times 0.${pb} = ${(pa*pb/10000)}\\).` ],
    traps: [
      {ans: `\\(${((pa+pb)/100)}\\)`, why: 'Adding is for "or" (mutually exclusive) — independent "and" MULTIPLIES.'},
      {ans: `\\(0.${Math.min(pa,pb)}\\)`, why: 'The joint probability of independent events is the product, smaller than either alone.'}
    ],
    vec: [unitIndex('S245_Probability'), 2, pa, pb],
    key: 's245_prob_and_indep'
  };
});
registerGen('S245_Probability', (rng)=>{
  const b = pick(rng,[40,50,60]);
  const ab = pick(rng,[10,20,30].filter(v=>v<b));
  return {
    q: `In a survey, \\(${ab}\\) people like both coffee and tea, and \\(${b}\\) like tea. Find \\(P(\\text{coffee} \\mid \\text{tea})\\).`,
    a: `\\(${ab}/${b} = ${(ab/b).toFixed(2).replace(/0$/,'')}\\)`,
    steps: [
      `Conditional probability restricts to the tea group: \\(P(C \\mid T) = \\dfrac{n(C \\cap T)}{n(T)} = \\dfrac{${ab}}{${b}}\\).`
    ],
    traps: [
      {ans: `\\(${b}/${ab} = ${(b/ab).toFixed(2)}\\)`, why: 'The GIVEN event goes in the denominator — condition on tea means divide by the tea count.'},
      {ans: `\\(${ab}/100\\)`, why: 'Conditioning shrinks the sample space to the ' + b + ' tea drinkers, not the whole survey.'}
    ],
    vec: [unitIndex('S245_Probability'), 3, ab, b],
    key: 's245_prob_conditional'
  };
});
registerGen('S245_Binomial', (rng)=>{
  const n = pick(rng,[5,6,8,10]), p100 = pick(rng,[20,30,50,70]), k = pick(rng,[1,2,3]);
  const p = p100/100;
  const prob = mwBinomialPmf(n, p, k);
  return {
    q: `A basketball player makes ${p100}\\% of free throws. In ${n} attempts, find \\(P(X = ${k})\\) exactly ${k} made. (4 decimals.)`,
    a: `\\(${prob.toFixed(4)}\\)`,
    steps: [
      `Binomial: \\(P(X=${k}) = \\binom{${n}}{${k}} (${p})^{${k}} (${1-p})^{${n-k}}\\).`,
      `\\(= ${mwCombination(n,k)} \\times ${Math.pow(p,k).toFixed(4)} \\times ${Math.pow(1-p,n-k).toFixed(4)} = ${prob.toFixed(4)}\\).`
    ],
    traps: [
      {ans: `\\(${(mwCombination(n,k)*Math.pow(p,k)).toFixed(4)}\\)`, why: 'The failures need their factor too: (1 − p)^{n−k} multiplies in.'},
      {ans: `\\(${(Math.pow(p,k)*Math.pow(1-p,n-k)).toFixed(4)}\\)`, why: 'The binomial coefficient counts the ' + mwCombination(n,k) + ' orders the makes can occur in — without it you have only ONE sequence.'}
    ],
    vec: [unitIndex('S245_Binomial'), 1, n, p100, k],
    key: 's245_binom_pmf'
  };
});
registerGen('S245_Binomial', (rng)=>{
  const combo = pick(rng,[[16,50,8,2],[25,20,5,2],[25,80,20,2],[64,50,32,4],[100,10,10,3],[36,50,18,3]]);
  const [n, p100, mu, sig] = combo;
  return {
    q: `For a binomial distribution with \\(n = ${n}\\) and \\(p = ${p100/100}\\), find the mean and standard deviation.`,
    a: `\\(\\mu = ${mu}\\), \\(\\sigma = ${sig}\\)`,
    steps: [
      `\\(\\mu = np = ${n} \\times ${p100/100} = ${mu}\\).`,
      `\\(\\sigma = \\sqrt{np(1-p)} = \\sqrt{${n} \\times ${p100/100} \\times ${(100-p100)/100}} = \\sqrt{${sig*sig}} = ${sig}\\).`
    ],
    traps: [
      {ans: `\\(\\mu = ${mu}\\), \\(\\sigma = ${sig*sig}\\)`, why: (sig*sig) + ' is the VARIANCE np(1−p); σ is its square root.'},
      {ans: `\\(\\mu = ${mu}\\), \\(\\sigma = ${Math.round(Math.sqrt(mu)*100)/100}\\)`, why: 'The variance is np(1−p), not np — the (1−p) factor matters.'}
    ],
    vec: [unitIndex('S245_Binomial'), 2, n, p100, mu, sig],
    key: 's245_binom_meansd'
  };
});
registerGen('S245_Binomial', (rng)=>{
  const n = pick(rng,[5,6,8]), p100 = pick(rng,[30,40,50,60]), k = pick(rng,[1,2,3]);
  const p = p100/100;
  const prob = mwBinomialCdf(n, p, k);
  return {
    q: `With \\(n = ${n}\\) trials and success probability \\(p = ${p}\\), find \\(P(X \\le ${k})\\). (4 decimals.)`,
    a: `\\(${prob.toFixed(4)}\\)`,
    steps: [
      `Cumulative: sum the PMF from 0 to ${k}: \\(P(X \\le ${k}) = \\sum_{x=0}^{${k}} \\binom{${n}}{x} p^x (1-p)^{${n}-x} = ${prob.toFixed(4)}\\).`
    ],
    traps: [
      {ans: `\\(${mwBinomialPmf(n,p,k).toFixed(4)}\\)`, why: 'P(X ≤ ' + k + ') accumulates ALL values from 0 through ' + k + ', not just X = ' + k + '.'},
      {ans: `\\(${mwBinomialSf(n,p,k+1).toFixed(4)}\\)`, why: 'That is the complement P(X > ' + k + ') — check the inequality direction.'}
    ],
    vec: [unitIndex('S245_Binomial'), 3, n, p100, k],
    key: 's245_binom_cdf'
  };
});
registerGen('S245_Sampling', (rng)=>{
  const mu = pick(rng,[80,100,240]), sigma = pick(rng,[12,20,30]);
  const n = pick(rng,[9,16,25,36].filter(v=>sigma % Math.sqrt(v) === 0)) || 25;
  const se = sigma/Math.sqrt(n);
  return {
    q: `A population has \\(\\mu = ${mu}\\), \\(\\sigma = ${sigma}\\). For samples of size \\(n = ${n}\\), describe the sampling distribution of \\(\\bar{x}\\).`,
    a: `Mean \\(${mu}\\), standard error \\(${se}\\), approximately normal`,
    steps: [
      `The mean of \\(\\bar{x}\\) equals the population mean: ${mu}.`,
      `Standard error: \\(\\sigma/\\sqrt{n} = ${sigma}/${Math.sqrt(n)} = ${se}\\).`,
      `CLT: for this sample size the shape is approximately normal.`
    ],
    traps: [
      {ans: `Mean \\(${mu}\\), standard error \\(${sigma}\\), approximately normal`, why: 'Averages vary LESS than individuals — the SE divides σ by √n.'},
      {ans: `Mean \\(${Math.round(mu/n)}\\), standard error \\(${se}\\), approximately normal`, why: 'The mean of sample means IS the population mean — sampling does not shrink the center, only the spread.'}
    ],
    vec: [unitIndex('S245_Sampling'), 1, mu, sigma, n],
    key: 's245_clt_se'
  };
});
registerGen('S245_Sampling', (rng)=>{
  const mu = pick(rng,[100,50,200]), sigma = pick(rng,[10,20]);
  const n = pick(rng,[16,25,100]);
  const se = sigma/Math.sqrt(n);
  const z = pick(rng,[-2.5,-2,-1.5,-1,1,1.5,2,2.5]);
  const v = Math.round((mu + z*se)*100)/100;
  const p = mwNormSf(z);
  return {
    q: `Scores have \\(\\mu = ${mu}\\), \\(\\sigma = ${sigma}\\). For a sample of \\(n = ${n}\\), find \\(P(\\bar{x} > ${v})\\). (4 decimals.)`,
    a: `\\(${p.toFixed(4)}\\)`,
    steps: [
      `Standard error: \\(${sigma}/\\sqrt{${n}} = ${se}\\).`,
      `\\(z = (${v} - ${mu})/${se} = ${z}\\).`,
      `Right tail: \\(P(Z > ${z}) = ${p.toFixed(4)}\\).`
    ],
    traps: [
      {ans: `\\(${mwNormCdf(z).toFixed(4)}\\)`, why: '"Greater than" is the RIGHT tail — 1 minus the table value Φ(z).'},
      {ans: `\\(${mwNormSf((v-mu)/sigma).toFixed(4)}\\)`, why: 'The sample MEAN uses the standard error σ/√n, not σ — averages are less variable than individuals.'}
    ],
    vec: [unitIndex('S245_Sampling'), 2, mu, sigma, n, Math.round(z*100)],
    key: 's245_clt_prob'
  };
});
registerGen('S245_Sampling', (rng)=>{
  const n = pick(rng,[40,50,100]);
  const shape = pick(rng,['strongly right-skewed','bimodal','uniform']);
  return {
    q: `A population is ${shape}. For samples of size \\(n = ${n}\\), what is the approximate shape of the sampling distribution of \\(\\bar{x}\\)?`,
    a: `Approximately normal by the CLT (n = ${n} is large enough)`,
    steps: [
      `The CLT: for large \\(n\\) (${n} qualifies), the distribution of \\(\\bar{x}\\) is approximately normal REGARDLESS of the population shape.`,
      `That is what makes z and t inference possible for non-normal populations.`
    ],
    traps: [
      {ans: `${shape.charAt(0).toUpperCase()+shape.slice(1)}, matching the population`, why: 'Individual values keep the population shape; AVERAGES normalize — that is the whole content of the CLT.'},
      {ans: `Cannot be determined without the data`, why: 'The CLT is a theorem: large-sample means are approximately normal no matter the source shape.'}
    ],
    vec: [unitIndex('S245_Sampling'), 3, n, ['strongly right-skewed','bimodal','uniform'].indexOf(shape)],
    key: 's245_clt_shape'
  };
});
registerGen('S245_Inference', (rng)=>{
  const df = pick(rng,[9,15,20,25]);
  const n = df + 1;
  const xbar = pick(rng,[50,72,120]);
  const s = pick(rng,[Math.sqrt(n)*2, Math.sqrt(n)*3].filter(v=>Number.isInteger(v)))||Math.sqrt(n)*2;
  const se = s/Math.sqrt(n);
  const t = mwTCrit(df, 0.025);
  const moe = Math.round(t*se*1000)/1000;
  const lo = Math.round((xbar-moe)*1000)/1000, hi = Math.round((xbar+moe)*1000)/1000;
  return {
    q: `A sample of \\(n = ${n}\\) gives \\(\\bar{x} = ${xbar}\\), \\(s = ${s}\\) (population σ unknown). Build a 95\\% t-interval for \\(\\mu\\). (\\(t^*_{${df}} = ${t}\\))`,
    a: `\\((${lo},\\ ${hi})\\)`,
    steps: [
      `σ unknown → use t with \\(df = n - 1 = ${df}\\).`,
      `SE: \\(s/\\sqrt{n} = ${s}/${Math.sqrt(n)} = ${se}\\); margin: \\(${t} \\times ${se} = ${moe}\\).`,
      `Interval: \\(${xbar} \\pm ${moe} = (${lo},\\ ${hi})\\).`
    ],
    traps: [
      {ans: `\\((${Math.round((xbar-1.96*se)*1000)/1000},\\ ${Math.round((xbar+1.96*se)*1000)/1000})\\)`, why: 'With σ unknown and a small sample, use t* = ' + t + ' (wider than z = 1.96) to pay for estimating σ with s.'},
      {ans: `\\((${xbar-Math.round(t*s*1000)/1000},\\ ${xbar+Math.round(t*s*1000)/1000})\\)`, why: 'The margin multiplies the STANDARD ERROR s/√n, not s itself.'}
    ],
    vec: [unitIndex('S245_Inference'), 1, n, xbar, s, Math.round(t*1000)],
    key: 's245_ci_t'
  };
});
registerGen('S245_Inference', (rng)=>{
  const mu0 = pick(rng,[50,100,75]), sigma = pick(rng,[10,20]);
  const n = pick(rng,[25,100]);
  const se = sigma/Math.sqrt(n);
  const z = pick(rng,[-3,-2.5,-1.5,-1,1,1.5,2.5,3]);
  const xbar = Math.round((mu0 + z*se)*100)/100;
  const reject = Math.abs(z) > 1.96;
  return {
    q: `Test \\(H_0: \\mu = ${mu0}\\) vs \\(H_a: \\mu \\ne ${mu0}\\) with \\(\\bar{x} = ${xbar}\\), \\(\\sigma = ${sigma}\\), \\(n = ${n}\\), \\(\\alpha = 0.05\\) (critical \\(\\pm 1.96\\)). Compute z and decide.`,
    a: `\\(z = ${z}\\); ${reject ? 'Reject' : 'Fail to reject'} \\(H_0\\)`,
    steps: [
      `\\(z = \\dfrac{\\bar{x} - \\mu_0}{\\sigma/\\sqrt{n}} = \\dfrac{${xbar} - ${mu0}}{${se}} = ${z}\\).`,
      `Two-tailed at \\(\\alpha = 0.05\\): reject when \\(|z| > 1.96\\). Here \\(|${z}| ${reject?'>':'<'} 1.96\\): ${reject?'reject.':'fail to reject.'}`
    ],
    traps: [
      {ans: `\\(z = ${z}\\); ${reject ? 'Fail to reject' : 'Reject'} \\(H_0\\)`, why: 'Reject when the statistic EXCEEDS the critical value in magnitude — compare |z| = ' + Math.abs(z) + ' with 1.96.'},
      {ans: `\\(z = ${Math.round((xbar-mu0)/sigma*100)/100}\\); ${reject ? 'Reject' : 'Fail to reject'} \\(H_0\\)`, why: 'The test statistic divides by the standard error σ/√n, not σ.'}
    ],
    vec: [unitIndex('S245_Inference'), 2, mu0, sigma, n, Math.round(z*100), reject?1:0],
    key: 's245_ht_z'
  };
});
registerGen('S245_Inference', (rng)=>{
  const z = pick(rng,[-2.8,-2.2,-1.8,-1.2,1.2,1.6,2,2.4,2.8,3.2]);
  const p = 2*mwNormSf(Math.abs(z));
  const reject = p < 0.05;
  return {
    q: `A two-tailed z test gives \\(z = ${z}\\). Find the p-value and decide at \\(\\alpha = 0.05\\). (4 decimals.)`,
    a: `\\(p = ${p.toFixed(4)}\\); ${reject ? 'Reject' : 'Fail to reject'} \\(H_0\\)`,
    steps: [
      `Two-tailed: \\(p = 2\\,P(Z > |${z}|) = 2 \\times ${mwNormSf(Math.abs(z)).toFixed(4)} = ${p.toFixed(4)}\\).`,
      `\\(${p.toFixed(4)} ${reject?'<':'>'} 0.05\\): ${reject?'reject':'fail to reject'} \\(H_0\\).`
    ],
    traps: [
      {ans: `\\(p = ${mwNormSf(Math.abs(z)).toFixed(4)}\\); ${reject ? 'Reject' : 'Fail to reject'} \\(H_0\\)`, why: 'TWO-tailed doubles the one-tail area — extreme in either direction counts.'},
      {ans: `\\(p = ${p.toFixed(4)}\\); ${reject ? 'Fail to reject' : 'Reject'} \\(H_0\\)`, why: 'Small p rejects: p ' + (reject?'<':'>') + ' α means the data are ' + (reject?'surprising':'unsurprising') + ' under H₀.'}
    ],
    vec: [unitIndex('S245_Inference'), 3, Math.round(z*10)],
    key: 's245_ht_pvalue'
  };
});
