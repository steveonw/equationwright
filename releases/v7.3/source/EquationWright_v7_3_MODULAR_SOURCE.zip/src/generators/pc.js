// PC generator registrations — order frozen by the published registry.
registerGen('PC_Conics', (rng)=> {
  const h = randInt(rng, -5, 5);
  const k = randInt(rng, -5, 5);
  const r = pick(rng, [2,3,4,5,6]);

  // Standard: (x-h)^2 + (y-k)^2 = r^2
  // Expand: x^2 -2hx + h^2 + y^2 -2ky + k^2 = r^2
  // Bring all: x^2 + y^2 + Dx + Ey + F = 0 where D=-2h, E=-2k, F=h^2+k^2-r^2
  const D = -2*h;
  const E = -2*k;
  const F = h*h + k*k - r*r;

  const genEq = `x^2 + y^2 ${fmtSigned(D)}x ${fmtSigned(E)}y ${fmtSigned(F)} = 0`;

  const hx = (h>=0)?`(x-${h})^2`:`(x+${Math.abs(h)})^2`;
  const ky = (k>=0)?`(y-${k})^2`:`(y+${Math.abs(k)})^2`;

  return {
    q: `Rewrite the circle in standard form and give its center and radius:\n\\[${genEq}\\]`,
    a: `\\(${hx} + ${ky} = ${r*r}\\), center \\((${h},${k})\\), radius \\(${r}\\).`,
    steps: [
      `Group x-terms and y-terms: \\((x^2 ${fmtSigned(D)}x) + (y^2 ${fmtSigned(E)}y) = ${-F}\\).`,
      `Complete the square for x: add \\(\\left(\\frac{${D}}{2}\\right)^2=${h*h}\\).`,
      `Complete the square for y: add \\(\\left(\\frac{${E}}{2}\\right)^2=${k*k}\\).`,
      `Add the same values to the right: RHS becomes \\(${ -F } + ${h*h} + ${k*k} = ${r*r}\\).`,
      `So the standard form is \\(${hx}+${ky}=${r*r}\\).`
    ],
    vec: [unitIndex('PC_Conics'), 81, h,k,r,0,0],
    key:'pc_circle_general_to_standard'
  };
});
registerGen('PC_Conics', (rng)=> {
  const h = randInt(rng, -5, 5);
  const k = randInt(rng, -5, 5);
  const r = pick(rng, [2, 3, 4, 5, 6]);
  
  return {
    q: `Write the equation of a circle with center \\((${h}, ${k})\\) and radius ${r}.`,
    a: `\\((x - ${h})^2 + (y - ${k})^2 = ${r*r}\\)`,
    steps: [
      `Standard form of circle: \\((x-h)^2 + (y-k)^2 = r^2\\).`,
      `Substitute \\(h = ${h}\\), \\(k = ${k}\\), \\(r = ${r}\\).`,
      `Result: \\((x - ${h})^2 + (y - ${k})^2 = ${r*r}\\).`
    ],
    vec: [unitIndex('PC_Conics'), 1, h, k, r],
    key: 'pc_circle_standard'
  };
});
registerGen('PC_Conics', (rng)=> {
  const h = randInt(rng, -4, 4);
  const k = randInt(rng, -4, 4);
  const a = pick(rng, [1, 2, -1, -2]);
  
  return {
    q: `Find the vertex and direction of opening for \\(y = ${a}(x - ${h})^2 + ${k}\\).`,
    a: `Vertex: \\((${h}, ${k})\\), Opens ${a > 0 ? 'upward' : 'downward'}`,
    steps: [
      `Vertex form: \\(y = a(x-h)^2 + k\\).`,
      `Vertex is \\((h, k) = (${h}, ${k})\\).`,
      `Since \\(a = ${a}\\) ${a > 0 ? '> 0' : '< 0'}, parabola opens ${a > 0 ? 'upward' : 'downward'}.`
    ],
    vec: [unitIndex('PC_Conics'), 2, h, k, a],
    key: 'pc_parabola_vertex'
  };
});
registerGen('PC_Conics', (rng)=> {
  const h = randInt(rng, -3, 3);
  const k = randInt(rng, -3, 3);
  const a = pick(rng, [4, 5, 6]);
  const b = pick(rng, [2, 3]);
  
  return {
    q: `Identify the center and lengths of axes for \\(\\frac{(x-${h})^2}{${a*a}} + \\frac{(y-${k})^2}{${b*b}} = 1\\).`,
    a: `Center: \\((${h}, ${k})\\), Major axis: ${2*a}, Minor axis: ${2*b}`,
    steps: [
      `Standard form: \\(\\frac{(x-h)^2}{a^2} + \\frac{(y-k)^2}{b^2} = 1\\).`,
      `Center: \\((h, k) = (${h}, ${k})\\).`,
      `Major axis length: \\(2a = ${2*a}\\), Minor axis length: \\(2b = ${2*b}\\).`
    ],
    vec: [unitIndex('PC_Conics'), 3, h, k, a, b],
    key: 'pc_ellipse_center'
  };
});
registerGen('PC_Conics', (rng)=> {
  const a = pick(rng, [3, 4, 5]);
  const b = pick(rng, [2, 3, 4]);
  const type = pick(rng, ['horizontal', 'vertical']);
  
  if (type === 'horizontal') {
    return {
      q: `Identify the type and orientation of \\(\\frac{x^2}{${a*a}} - \\frac{y^2}{${b*b}} = 1\\).`,
      a: `Hyperbola opening horizontally`,
      steps: [
        `Standard form: \\(\\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1\\) is a horizontal hyperbola.`,
        `Opens left and right along x-axis.`
      ],
      vec: [unitIndex('PC_Conics'), 4, a, b, 1],
      key: 'pc_hyperbola_horiz'
    };
  } else {
    return {
      q: `Identify the type and orientation of \\(\\frac{y^2}{${a*a}} - \\frac{x^2}{${b*b}} = 1\\).`,
      a: `Hyperbola opening vertically`,
      steps: [
        `Standard form: \\(\\frac{y^2}{a^2} - \\frac{x^2}{b^2} = 1\\) is a vertical hyperbola.`,
        `Opens up and down along y-axis.`
      ],
      vec: [unitIndex('PC_Conics'), 4, a, b, 2],
      key: 'pc_hyperbola_vert'
    };
  }
});
registerGen('PC_Sequences', (rng)=> {
  const a1 = randInt(rng, -10, 10);
  const d = pick(rng, [-3, -2, 2, 3, 4, 5]);
  const n = pick(rng, [10, 15, 20]);
  const an = a1 + (n - 1) * d;
  
  return {
    q: `Find the ${n}th term of the arithmetic sequence with \\(a_1 = ${a1}\\) and \\(d = ${d}\\).`,
    a: `\\(a_{${n}} = ${an}\\)`,
    steps: [
      `Formula: \\(a_n = a_1 + (n-1)d\\).`,
      `\\(a_{${n}} = ${a1} + (${n}-1)(${d})\\).`,
      `\\(a_{${n}} = ${an}\\).`
    ],
    vec: [unitIndex('PC_Sequences'), 1, a1, d, n],
    key: 'pc_arith_seq_term'
  };
});
registerGen('PC_Sequences', (rng)=> {
  const a1 = pick(rng, [2, 3, 4, 5]);
  const r = pick(rng, [2, 3, 0.5]);
  const n = pick(rng, [5, 6, 7]);
  const an = a1 * Math.pow(r, n - 1);
  
  return {
    q: `Find the ${n}th term of the geometric sequence with \\(a_1 = ${a1}\\) and \\(r = ${r}\\).`,
    a: `\\(a_{${n}} = ${an}\\)`,
    steps: [
      `Formula: \\(a_n = a_1 \\cdot r^{n-1}\\).`,
      `\\(a_{${n}} = ${a1} \\cdot ${r}^{${n}-1}\\).`,
      `\\(a_{${n}} = ${an}\\).`
    ],
    vec: [unitIndex('PC_Sequences'), 2, a1, Math.round(r*10), n],
    key: 'pc_geom_seq_term'
  };
});
registerGen('PC_Sequences', (rng)=> {
  const a1 = randInt(rng, 1, 10);
  const d = pick(rng, [2, 3, 4, 5]);
  const n = pick(rng, [10, 15, 20]);
  const an = a1 + (n - 1) * d;
  const sum = n * (a1 + an) / 2;
  
  return {
    q: `Find the sum of the first ${n} terms of the arithmetic sequence \\(a_1 = ${a1}\\), \\(d = ${d}\\).`,
    a: `\\(S_{${n}} = ${sum}\\)`,
    steps: [
      `Formula: \\(S_n = \\frac{n(a_1 + a_n)}{2}\\).`,
      `First find \\(a_{${n}} = ${a1} + ${(n-1)*d} = ${an}\\).`,
      `\\(S_{${n}} = \\frac{${n}(${a1} + ${an})}{2} = ${sum}\\).`
    ],
    vec: [unitIndex('PC_Sequences'), 3, a1, d, n],
    key: 'pc_arith_series_sum'
  };
});
registerGen('PC_Sequences', (rng)=> {
  const a = pick(rng, [2, 3, 4, 6, 8]);
  const r = pick(rng, [0.5, 0.25, 0.4, 0.6]);
  const sum = a / (1 - r);
  
  return {
    q: `Find the sum of the infinite geometric series with \\(a = ${a}\\) and \\(r = ${r}\\).`,
    a: `\\(S = ${sum}\\)`,
    steps: [
      `For \\(|r| < 1\\), sum formula: \\(S = \\frac{a}{1-r}\\).`,
      `\\(S = \\frac{${a}}{1-${r}} = ${sum}\\).`
    ],
    vec: [unitIndex('PC_Sequences'), 4, a, Math.round(r*100)],
    key: 'pc_geom_series_infinite'
  };
});
registerGen('PC_Vectors', (rng)=> {
  const x = randInt(rng, -5, 5);
  const y = randInt(rng, -5, 5);
  const magSq = x*x + y*y;
  const mag = Math.sqrt(magSq);
  const diagram = svgVector(x, y, 120, 'v');

  const xStr = x < 0 ? `(${x})` : `${x}`;
  const yStr = y < 0 ? `(${y})` : `${y}`;
  
  // Use exact answer if possible
  let answer;
  if (isPerfectSquare(magSq)) {
    answer = `\\(|\\vec{v}| = ${Math.sqrt(magSq)}\\)`;
  } else {
    const simplified = simplifyRadical(magSq);
    answer = `\\(|\\vec{v}| = ${simplified}\\)${mag > 10 ? ` \\(\\approx ${mag.toFixed(3)}\\)` : ''}`;
  }
  
  return {
    q: `Find the magnitude of vector \\(\\vec{v} = \\langle ${x}, ${y} \\rangle\\).<br><br>${diagram}`,
    a: answer,
    steps: [
      `Magnitude formula: \\(|\\vec{v}| = \\sqrt{x^2 + y^2}\\).`,
      `\\(|\\vec{v}| = \\sqrt{${xStr}^2 + ${yStr}^2} = \\sqrt{${magSq}}${isPerfectSquare(magSq) ? ' = '+Math.sqrt(magSq) : ' = '+simplifyRadical(magSq)}\\).`
    ],
    vec: [unitIndex('PC_Vectors'), 1, x, y],
    key: 'pc_vector_magnitude'
  };
});
registerGen('PC_Vectors', (rng)=> {
  const u = [randInt(rng, -4, 4), randInt(rng, -4, 4)];
  const v = [randInt(rng, -4, 4), randInt(rng, -4, 4)];
  const sum = [u[0] + v[0], u[1] + v[1]];
  const diagram = svgVectorAddition(u, v);
  
  return {
    q: `Find \\(\\vec{u} + \\vec{v}\\) where \\(\\vec{u} = \\langle ${u[0]}, ${u[1]} \\rangle\\) and \\(\\vec{v} = \\langle ${v[0]}, ${v[1]} \\rangle\\).<br><br>${diagram}`,
    a: `\\(\\langle ${sum[0]}, ${sum[1]} \\rangle\\)`,
    steps: [
      `Add corresponding components.`,
      `\\(\\vec{u} + \\vec{v} = \\langle ${u[0]} + ${v[0]}, ${u[1]} + ${v[1]} \\rangle = \\langle ${sum[0]}, ${sum[1]} \\rangle\\).`
    ],
    vec: [unitIndex('PC_Vectors'), 2, u[0], u[1], v[0], v[1]],
    key: 'pc_vector_addition'
  };
});
registerGen('PC_Vectors', (rng)=> {
  const k = pick(rng, [-3, -2, 2, 3, 4]);
  const v = [randInt(rng, -3, 3), randInt(rng, -3, 3)];
  const result = [k * v[0], k * v[1]];
  
  return {
    q: `Find \\(${k}\\vec{v}\\) where \\(\\vec{v} = \\langle ${v[0]}, ${v[1]} \\rangle\\).`,
    a: `\\(\\langle ${result[0]}, ${result[1]} \\rangle\\)`,
    steps: [
      `Multiply each component by the scalar.`,
      `\\(${k}\\vec{v} = \\langle ${k}(${v[0]}), ${k}(${v[1]}) \\rangle = \\langle ${result[0]}, ${result[1]} \\rangle\\).`
    ],
    vec: [unitIndex('PC_Vectors'), 3, k, v[0], v[1]],
    key: 'pc_vector_scalar'
  };
});
registerGen('PC_Vectors', (rng)=> {
  const x = pick(rng, [3, 4, 6, 8]);
  const y = pick(rng, [3, 4, 6, 8]);
  const mag = Math.sqrt(x*x + y*y);
  const ux = x / mag;
  const uy = y / mag;
  
  return {
    q: `Find the unit vector in the direction of \\(\\vec{v} = \\langle ${x}, ${y} \\rangle\\).`,
    a: `\\(\\langle ${ux.toFixed(3)}, ${uy.toFixed(3)} \\rangle\\)`,
    steps: [
      `Unit vector formula: \\(\\hat{v} = \\frac{\\vec{v}}{|\\vec{v}|}\\).`,
      `\\(|\\vec{v}| = \\sqrt{${x}^2 + ${y}^2} = ${mag.toFixed(3)}\\).`,
      `\\(\\hat{v} = \\langle \\frac{${x}}{${mag.toFixed(3)}}, \\frac{${y}}{${mag.toFixed(3)}} \\rangle = \\langle ${ux.toFixed(3)}, ${uy.toFixed(3)} \\rangle\\).`
    ],
    vec: [unitIndex('PC_Vectors'), 4, x, y],
    key: 'pc_vector_unit'
  };
});
