// C3 generator registrations — order frozen by the published registry.
registerGen('C3_Vectors', (rng)=> {
  const a = [randInt(rng,-4,4), randInt(rng,-4,4), randInt(rng,-4,4)];
  const b = [randInt(rng,-4,4), randInt(rng,-4,4), randInt(rng,-4,4)];
  const ans = dot3(a,b);
  const p = (n) => (n < 0 ? `(${n})` : `${n}`);

  return {
    q: `Compute ${vecTeX(a)}\\(\\cdot\\)${vecTeX(b)}.`,
    a: `\\(${ans}\\)`,
    steps: [
      `Dot product: \\(a\\cdot b=a_1b_1+a_2b_2+a_3b_3\\).`,
      `Compute: \\(${p(a[0])}\\cdot${p(b[0])} + ${p(a[1])}\\cdot${p(b[1])} + ${p(a[2])}\\cdot${p(b[2])} = ${ans}\\).`
    ],
    vec: [unitIndex('C3_Vectors'), 1, ...a, ...b],
    key:'c3_dot'
  };
});
registerGen('C3_Vectors', (rng)=> {
  const P = [randInt(rng,-2,4), randInt(rng,-2,4), randInt(rng,-2,4)];
  const n = [pick(rng,[1,2,3]), pick(rng,[1,2,3]), pick(rng,[1,2,3])];
  const d = n[0]*P[0]+n[1]*P[1]+n[2]*P[2];
  return {
    q: `Find an equation of the plane through \\(P(${P[0]},${P[1]},${P[2]})\\) with normal ${vecTeX(n)}.`,
    a: `\\(${n[0]}x+${n[1]}y+${n[2]}z=${d}\\)`,
    steps: [
      `Plane: \\(a(x-x_0)+b(y-y_0)+c(z-z_0)=0\\).`,
      `Expand to get \\(${n[0]}x+${n[1]}y+${n[2]}z=${d}\\).`
    ],
    vec: [unitIndex('C3_Vectors'), 2, ...P, ...n],
    key:'c3_plane'
  };
});
registerGen('C3_Vectors', (rng)=> {
  const a = pick(rng,[1,2,3]);
  const b = pick(rng,[1,2,3]);
  const c = pick(rng,[1,2,3]);
  const d = randInt(rng,-6,6);
  const P = [randInt(rng,-2,3), randInt(rng,-2,3), randInt(rng,-2,3)];
  const num = Math.abs(a*P[0]+b*P[1]+c*P[2]-d);
  const denSq = a*a+b*b+c*c;
  const denSimp = simplifyRadical(denSq);
  const dist = num / Math.sqrt(denSq);
  
  return {
    q: `Find the distance from \\(P(${P[0]},${P[1]},${P[2]})\\) to the plane \\(${a}x+${b}y+${c}z=${d}\\).`,
    a: `\\(\\frac{${num}}{${denSimp}}\\)${dist > 2 ? ` \\(\\approx ${smartRound(dist, 3)}\\)` : ''}`,
    steps: [
      `Distance point-to-plane: \\(\\frac{|ax_0+by_0+cz_0-d|}{\\sqrt{a^2+b^2+c^2}}\\).`,
      `Substitute: \\(\\frac{|${a}(${P[0]})+${b}(${P[1]})+${c}(${P[2]})-${d}|}{${denSimp}} = \\frac{${num}}{${denSimp}}\\).`
    ],
    vec: [unitIndex('C3_Vectors'), 3, a,b,c,d, ...P],
    key:'c3_dist_point_plane'
  };
});
registerGen('C3_Partials', (rng)=> {
  const A = randInt(rng,1,5);
  const B = randInt(rng,-4,4);
  const C = randInt(rng,1,5);
  const x0 = randInt(rng,-2,3);
  const y0 = randInt(rng,-2,3);
  const fx = 2*A*x0 + B*y0;
  const fy = B*x0 + 2*C*y0;
  const fTeX = `f(x,y)=${A}x^2 ${B>=0?'+':''}${B}xy ${C>=0?'+':''}${C}y^2`;
  return {
    q: `Given \\(${fTeX}\\), find \\(f_x(${x0},${y0})\\) and \\(f_y(${x0},${y0})\\).`,
    a: `\\(f_x=${fx},\\; f_y=${fy}\\)`,
    steps: [
      `\\(f_x=2${A}x+${B}y\\), \\(f_y=${B}x+2${C}y\\).`,
      `Evaluate at \\(${x0},${y0}\\).`
    ],
    vec: [unitIndex('C3_Partials'), 1, A,B,C,x0,y0],
    key:'c3_partials_quad'
  };
});
registerGen('C3_Partials', (rng)=> {
  const a = randInt(rng,1,4);
  const b = randInt(rng,1,4);
  const x0 = randInt(rng,0,2);
  const y0 = randInt(rng,0,2);
  // f(x,y)=ax^2+by^2, fx=2ax, fy=2by
  const z0 = a*x0*x0 + b*y0*y0;
  const fx = 2*a*x0;
  const fy = 2*b*y0;
  return {
    q: `Find the tangent plane to \\(z=${a}x^2+${b}y^2\\) at \\((${x0},${y0},${z0})\\).`,
    a: `\\(z=${z0}+(${fx})(x-${x0})+(${fy})(y-${y0})\\)`,
    steps: [
      `Tangent plane: \\(z=f(x_0,y_0)+f_x(x_0,y_0)(x-x_0)+f_y(x_0,y_0)(y-y_0)\\).`,
      `Here \\(f_x=2${a}x\\), \\(f_y=2${b}y\\).`,
      `Evaluate at \\(${x0},${y0}\\): \\(f_x=${fx}\\), \\(f_y=${fy}\\), \\(f=${z0}\\).`
    ],
    vec: [unitIndex('C3_Partials'), 2, a,b,x0,y0],
    key:'c3_tangent_plane'
  };
});
registerGen('C3_Partials', (rng)=> {
  // Max/min of f(x,y)=x^2+y^2 subject to x+y=1
  return {
    q: `Use Lagrange multipliers to find the minimum of \\(f(x,y)=x^2+y^2\\) subject to \\(x+y=1\\).`,
    a: `Minimum at \\((\\tfrac12,\\tfrac12)\\) with value \\(\\tfrac12\\).`,
    steps: [
      `Constraint: \\(g(x,y)=x+y-1=0\\).`,
      `\\(\\nabla f=\\langle 2x,2y\\rangle\\), \\(\\nabla g=\\langle 1,1\\rangle\\).`,
      `Set \\(\\nabla f=\\lambda\\nabla g\\Rightarrow 2x=\\lambda,\\;2y=\\lambda\\Rightarrow x=y\\).`,
      `With \\(x+y=1\\Rightarrow x=y=1/2\\).`,
      `Value: \\(f=1/4+1/4=1/2\\).`
    ],
    vec: [unitIndex('C3_Partials'), 3, 0,0,0],
    key:'c3_lagrange_simple'
  };
});
registerGen('C3_MultInt', (rng)=> {
  const R = pick(rng, [1,2,3,4]);
  const integrand = pick(rng, ['1','x2y2']);
  if(integrand === '1'){
    // ∫∫_disk 1 dA = πR^2
    return {
      q: `Evaluate \\(\\iint_D 1\\,dA\\) where \\(D=\\{(x,y):x^2+y^2\\le ${R*R}\\}\\) using polar coordinates.`,
      a: `\\(\\pi(${R})^2 = ${R*R}\\pi\\).`,
      steps: [
        `Convert to polar: \\(x=r\\cos\\theta,\\;y=r\\sin\\theta\\), and \\(dA=r\\,dr\\,d\\theta\\).`,
        `Region: \\(0\\le r\\le ${R},\\;0\\le \\theta\\le 2\\pi\\).`,
        `\\(\\iint_D 1\\,dA = \\int_0^{2\\pi}\\int_0^{${R}} 1\\cdot r\\,dr\\,d\\theta\\).`,
        `Inner integral: \\(\\int_0^{${R}} r\\,dr=\\frac{${R}^2}{2}\\). Outer: \\(\\int_0^{2\\pi} \\frac{${R}^2}{2}\\,d\\theta=${R*R}\\pi\\).`
      ],
      vec: [unitIndex('C3_MultInt'), 81, R, 1,0,0],
      key:'c3_polar_jacobian_area_disk'
    };
  }
  // integrand x^2+y^2 = r^2
  const coef = exactFrac(R**4, 2); // (π/2)R^4
  return {
    q: `Evaluate \\(\\iint_D (x^2+y^2)\\,dA\\) where \\(D=\\{(x,y):x^2+y^2\\le ${R*R}\\}\\) using polar coordinates.`,
    a: `\\(\\frac{\\pi}{2}${R**4} = ${coef}\\pi\\).`,
    steps: [
      `In polar, \\(x^2+y^2=r^2\\) and \\(dA=r\\,dr\\,d\\theta\\).`,
      `So the integrand becomes \\(r^2\\cdot r=r^3\\).`,
      `\\(\\iint_D (x^2+y^2)\\,dA = \\int_0^{2\\pi}\\int_0^{${R}} r^3\\,dr\\,d\\theta\\).`,
      `\\(\\int_0^{${R}} r^3\\,dr=\\frac{${R}^4}{4}\\). Multiply by \\(2\\pi\\): \\(2\\pi\\cdot\\frac{${R}^4}{4} = \\frac{\\pi}{2}${R**4}\\).`
    ],
    vec: [unitIndex('C3_MultInt'), 82, R, 2,0,0],
    key:'c3_polar_jacobian_r2_disk'
  };
});
registerGen('C3_MultInt', (rng)=> {
  const A = randInt(rng,1,4);
  const B = randInt(rng,1,5);
  const a = randInt(rng,1,4);
  const b = randInt(rng,1,4);
  const val = A*b*(a*a)/2 + B*(b*b)*a/2;
  return {
    q: `Evaluate \\(\\int_0^{${a}}\\int_0^{${b}}(${A}x+${B}y)\\,dy\\,dx\\).`,
    a: `\\(${val}\\)`,
    steps: [
      `Integrate inner w.r.t. \\(y\\), then outer w.r.t. \\(x\\).`
    ],
    vec: [unitIndex('C3_MultInt'), 1, A,B,a,b],
    key:'c3_dbl_rect'
  };
});
registerGen('C3_MultInt', (rng)=> {
  const R = pick(rng,[1,2,3,4]);
  // ∫∫_disk 1 dA = area = pi R^2
  return {
    q: `Use polar coordinates to evaluate \\(\\iint_D 1\\,dA\\) where \\(D\\) is the disk \\(x^2+y^2\\le ${R*R}\\).`,
    a: `\\(\\pi\\cdot ${R*R} = ${ (Math.PI*R*R).toFixed(4) }\\)`,
    steps: [
      `In polar, \\(dA=r\\,dr\\,d\\theta\\).`,
      `\\(0\\le r\\le ${R}\\), \\(0\\le \\theta\\le 2\\pi\\).`,
      `\\(\\int_0^{2\\pi}\\int_0^{${R}} r\\,dr\\,d\\theta = \\int_0^{2\\pi}\\frac{${R}^2}{2}\\,d\\theta=${R*R}\\pi\\).`
    ],
    vec: [unitIndex('C3_MultInt'), 2, R,0,0],
    key:'c3_polar_area_disk'
  };
});
registerGen('C3_MultInt', (rng)=> {
  const R = pick(rng,[1,2,3]);
  const H = pick(rng,[2,3,4]);
  // volume cylinder: pi R^2 H
  const V = Math.PI*R*R*H;
  return {
    q: `Evaluate \\(\\iiint_E 1\\,dV\\) where \\(E\\) is the solid cylinder \\(x^2+y^2\\le ${R*R}\\), \\(0\\le z\\le ${H}\\).`,
    a: `\\(${R*R}\\pi \\cdot ${H} \\approx ${V.toFixed(4)}\\)`,
    steps: [
      `Use cylindrical coords: \\(dV=r\\,dr\\,d\\theta\\,dz\\).`,
      `Bounds: \\(0\\le r\\le ${R}\\), \\(0\\le \\theta\\le 2\\pi\\), \\(0\\le z\\le ${H}\\).`,
      `Integral gives volume \\(=\\pi R^2 H\\).`
    ],
    vec: [unitIndex('C3_MultInt'), 3, R,H,0],
    key:'c3_cyl_volume'
  };
});
registerGen('C3_VecCalc', (rng)=> {
  const a = randInt(rng,1,4);
  const b = randInt(rng,1,4);
  const A = [randInt(rng,-2,2), randInt(rng,-2,2)];
  const B = [randInt(rng,1,4), randInt(rng,1,4)];
  const phiA = a*A[0]*A[0] + b*A[1]*A[1];
  const phiB = a*B[0]*B[0] + b*B[1]*B[1];
  const val = phiB - phiA;
  return {
    q: `Let \\(\\phi(x,y)=${a}x^2+${b}y^2\\) and \\(\\mathbf{F}=\\nabla\\phi\\). Compute \\(\\int_C \\mathbf{F}\\cdot d\\mathbf{r}\\) from \\(A(${A[0]},${A[1]})\\) to \\(B(${B[0]},${B[1]})\\) (any path).`,
    a: `\\(${val}\\)`,
    steps: [
      `Conservative field: integral equals \\(\\phi(B)-\\phi(A)\\).`,
      `Compute \\(\\phi\\) at endpoints.`
    ],
    vec: [unitIndex('C3_VecCalc'), 1, a,b, ...A, ...B],
    key:'c3_lineint_conservative'
  };
});
registerGen('C3_VecCalc', (rng)=> {
  // F = <0, x>, curl = dQ/dx - dP/dy = 1
  const R = pick(rng,[1,2,3,4]);
  const area = Math.PI*R*R;
  return {
    q: `Use Green's Theorem to compute \\(\\oint_C \\langle 0, x\\rangle\\cdot d\\mathbf{r}\\) where \\(C\\) is the circle \\(x^2+y^2=${R*R}\\) oriented counterclockwise.`,
    a: `\\(\\iint_D 1\\,dA = \\pi ${R*R} \\approx ${area.toFixed(4)}\\)`,
    steps: [
      `Green: \\(\\oint_C P\\,dx+Q\\,dy=\\iint_D (\\partial Q/\\partial x-\\partial P/\\partial y)\\,dA\\).`,
      `Here \\(P=0\\), \\(Q=x\\) so curl = 1.`,
      `Integral equals area of disk of radius ${R}: \\(\\pi R^2\\).`
    ],
    vec: [unitIndex('C3_VecCalc'), 2, R,0,0],
    key:'c3_green_circle'
  };
});
registerGen('C3_Vectors', (rng)=>{
  const a = randInt(rng,-3,3), b = randInt(rng,-3,3), cc = randInt(rng,-3,3);
  const r = pick(rng,[2,3,4,5]);
  const A = -2*a, B = -2*b, C = -2*cc;
  const D = r*r - (a*a+b*b+cc*cc);
  return {
    q: `Find the center and radius of the sphere \\(x^2+y^2+z^2${fmtSigned(A)}x${fmtSigned(B)}y${fmtSigned(C)}z=${D}\\).`,
    a: `Center \\((${a}, ${b}, ${cc})\\), radius \\(${r}\\)`,
    steps: [
      `Complete the square in each variable: \\((x${fmtSigned(-a)})^2+(y${fmtSigned(-b)})^2+(z${fmtSigned(-cc)})^2=${D}+${a*a+b*b+cc*cc}=${r*r}\\).`,
      `Center \\((${a}, ${b}, ${cc})\\), radius \\(\\sqrt{${r*r}}=${r}\\).`
    ],
    traps: [
      {ans:`Center \\((${-a}, ${-b}, ${-cc})\\), radius \\(${r}\\)`, why:'The center coordinates are the values that make each square zero: (x−a)² centers at +a.'},
      {ans:`Center \\((${a}, ${b}, ${cc})\\), radius \\(${r*r}\\)`, why:'The right side is r SQUARED — take the square root.'},
      {ans:`Center \\((${a}, ${b}, ${cc})\\), radius \\(${Math.max(1,r-1)}\\)`, why:'Add the completing-the-square constants to BOTH sides before reading off r².'}
    ],
    vec: [unitIndex('C3_Vectors'), 23, a, b, cc, r],
    key: 'c3_sphere_equation'
  };
});
registerGen('C3_Vectors', (rng)=>{
  const Q = pick(rng,[
    ['\\frac{x^2}{4}+\\frac{y^2}{9}+z^2=1','Ellipsoid'],
    ['x^2+y^2-z^2=1','Hyperboloid of one sheet'],
    ['-x^2-y^2+z^2=1','Hyperboloid of two sheets'],
    ['z=x^2+y^2','Elliptic paraboloid'],
    ['z=x^2-y^2','Hyperbolic paraboloid (saddle)'],
    ['z^2=x^2+y^2','Cone']
  ]);
  const all = ['Ellipsoid','Hyperboloid of one sheet','Hyperboloid of two sheets','Elliptic paraboloid','Hyperbolic paraboloid (saddle)','Cone'];
  const others = all.filter(n=>n!==Q[1]);
  const t1 = pick(rng, others);
  let t2 = pick(rng, others); while(t2===t1) t2 = pick(rng, others);
  let t3 = pick(rng, others); while(t3===t1||t3===t2) t3 = pick(rng, others);
  return {
    q: `Identify the quadric surface \\(${Q[0]}\\).`,
    a: Q[1],
    steps: [
      `Count signs and check for a linear variable: three positive squares summing to 1 → ellipsoid; one negative sign → one sheet; two negatives → two sheets; a lone linear \\(z\\) → paraboloid (same signs elliptic, mixed signs saddle); \\(z^2\\) equal to the sum → cone.`,
      `Here: ${Q[1].toLowerCase()}.`
    ],
    traps: [
      {ans:t1, why:'Count the negative squared terms: one negative → one sheet; two negatives → two sheets.'},
      {ans:t2, why:'Check whether any variable appears LINEARLY (paraboloids) versus all squared.'},
      {ans:t3, why:'A cone has =0 form (z² = x² + y²); the =1 forms are hyperboloids or ellipsoids.'}
    ],
    vec: [unitIndex('C3_Vectors'), 24, all.indexOf(Q[1])],
    key: 'c3_quadric_identify'
  };
});
registerGen('C3_Vectors', (rng)=>{
  const a = pick(rng,[2,3,4,5,6]);
  return {
    q: `Find the curvature of the circle \\(\\mathbf{r}(t)=\\langle ${a}\\cos t,\\; ${a}\\sin t\\rangle\\).`,
    a: `\\(\\kappa=${mwFracTex(1,a)}\\)`,
    steps: [
      `A circle of radius \\(R\\) has constant curvature \\(\\kappa=\\frac{1}{R}\\).`,
      `Here \\(R=${a}\\), so \\(\\kappa=${mwFracTex(1,a)}\\).`
    ],
    traps: [
      {ans:`\\(\\kappa=${a}\\)`, why:'Curvature is the RECIPROCAL of the radius: tighter circles curve more.'},
      {ans:`\\(\\kappa=${mwFracTex(1,a*a)}\\)`, why:'κ = 1/R, not 1/R².'},
      {ans:`\\(\\kappa=${mwFracTex(2,a)}\\pi\\)`, why:'2π/R is related to the circumference, not the curvature.'}
    ],
    vec: [unitIndex('C3_Vectors'), 25, a],
    key: 'c3_vvf_curvature'
  };
});
registerGen('C3_Vectors', (rng)=>{
  const P = pick(rng,[[3,4,5],[4,3,5],[6,8,10],[5,12,13]]);
  const [a,b,c] = P;
  return {
    q: `Find the unit tangent vector \\(\\mathbf{T}(0)\\) for \\(\\mathbf{r}(t)=\\langle ${a}\\cos t,\\; ${a}\\sin t,\\; ${b}t\\rangle\\).`,
    a: `\\(\\left\\langle 0,\\; ${mwFracTex(a,c)},\\; ${mwFracTex(b,c)}\\right\\rangle\\)`,
    steps: [
      `\\(\\mathbf{r}'(t)=\\langle -${a}\\sin t,\\; ${a}\\cos t,\\; ${b}\\rangle\\); at \\(t=0\\): \\(\\langle 0, ${a}, ${b}\\rangle\\).`,
      `\\(|\\mathbf{r}'(0)|=\\sqrt{${a*a}+${b*b}}=${c}\\).`,
      `\\(\\mathbf{T}(0)=\\frac{1}{${c}}\\langle 0, ${a}, ${b}\\rangle=\\left\\langle 0, ${mwFracTex(a,c)}, ${mwFracTex(b,c)}\\right\\rangle\\).`
    ],
    traps: [
      {ans:`\\(\\langle 0,\\; ${a},\\; ${b}\\rangle\\)`, why:'The UNIT tangent divides by |r′| — normalize.'},
      {ans:`\\(\\left\\langle 0,\\; ${mwFracTex(b,c)},\\; ${mwFracTex(a,c)}\\right\\rangle\\)`, why:'Components swapped: r′(0) = ⟨0, a, b⟩ in order.'},
      {ans:`\\(\\left\\langle 0,\\; ${mwFracTex(-a,c)},\\; ${mwFracTex(b,c)}\\right\\rangle\\)`, why:'At t = 0, cos t = 1: the y-component of r′ is +a.'}
    ],
    vec: [unitIndex('C3_Vectors'), 26, a, b],
    key: 'c3_vvf_tnb'
  };
});
registerGen('C3_Vectors', (rng)=>{
  const a = mwNZ(rng,-3,3), b = mwNZ(rng,-4,4), c = mwNZ(rng,-2,2);
  const co = (u)=> u===1?'':(u===-1?'-':`${u}`);
  return {
    q: `A particle's position is \\(\\mathbf{r}(t)=\\langle ${co(a)}t^2,\\; ${co(b)}t,\\; ${co(c)}t^3\\rangle\\). Find its acceleration \\(\\mathbf{a}(1)\\).`,
    a: `\\(\\langle ${2*a},\\; 0,\\; ${6*c}\\rangle\\)`,
    steps: [
      `Velocity: \\(\\mathbf{v}(t)=\\mathbf{r}'(t)=\\langle ${2*a}t,\\; ${b},\\; ${3*c}t^2\\rangle\\).`,
      `Acceleration: \\(\\mathbf{a}(t)=\\mathbf{v}'(t)=\\langle ${2*a},\\; 0,\\; ${6*c}t\\rangle\\); at \\(t=1\\): \\(\\langle ${2*a}, 0, ${6*c}\\rangle\\).`
    ],
    traps: [
      {ans:`\\(\\langle ${2*a},\\; ${b},\\; ${3*c}\\rangle\\)`, why:'That is the VELOCITY at t = 1. Acceleration is the second derivative.'},
      {ans:`\\(\\langle ${2*a},\\; 0,\\; ${3*c}\\rangle\\)`, why:'d/dt of 3ct² is 6ct — the exponent multiplies down again.'},
      {ans:`\\(\\langle ${a},\\; 0,\\; ${6*c}\\rangle\\)`, why:'d/dt of at² is 2at, so the x-component of a(t) is 2a.'}
    ],
    vec: [unitIndex('C3_Vectors'), 27, a, b, c],
    key: 'c3_vvf_motion'
  };
});
registerGen('C3_Partials', (rng)=>{
  const a = pick(rng,[1,2,3]), b = pick(rng,[1,2,3]);
  const ans = 4*a*a*b;
  return {
    q: `Let \\(z=x^2y\\) with \\(x=${a}t\\) and \\(y=${b}t^2\\). Use the chain rule to find \\(\\dfrac{dz}{dt}\\) at \\(t=1\\).`,
    a: `\\(${ans}\\)`,
    steps: [
      `\\(\\dfrac{dz}{dt}=\\dfrac{\\partial z}{\\partial x}\\dfrac{dx}{dt}+\\dfrac{\\partial z}{\\partial y}\\dfrac{dy}{dt}=(2xy)(${a})+(x^2)(${2*b}t)\\).`,
      `At \\(t=1\\): \\(x=${a}\\), \\(y=${b}\\): \\((2\\cdot ${a}\\cdot ${b})(${a})+(${a*a})(${2*b})=${2*a*a*b}+${2*a*a*b}=${ans}\\).`
    ],
    traps: [
      {ans:`\\(${2*a*a*b}\\)`, why:'The chain rule SUMS over both intermediate variables — you kept only one path.'},
      {ans:`\\(${3*a*a*b}\\)`, why:'dy/dt = 2bt, evaluated at t = 1 gives 2b (check the second path).'},
      {ans:`\\(${2*a*b}\\)`, why:'Evaluate x and y at t = 1 (x = a, y = b) before combining.'}
    ],
    vec: [unitIndex('C3_Partials'), 22, a, b],
    key: 'c3_chain_multivar'
  };
});
registerGen('C3_Partials', (rng)=>{
  const a = pick(rng,[2,3,4,6]);
  const dne = pick(rng,[true,false]);
  const top = dne ? `${a}xy` : `${a}x^2y`;
  const ans = dne ? 'DNE (the limit does not exist)' : '\\(0\\)';
  return {
    q: `Evaluate \\(\\displaystyle\\lim_{(x,y)\\to(0,0)} \\frac{${top}}{x^2+y^2}\\) or show it does not exist.`,
    a: ans,
    steps: dne
      ? [
          `Along \\(y=0\\): the limit is \\(0\\). Along \\(y=x\\): \\(\\frac{${a}x^2}{2x^2}=${mwFracTex(a,2)}\\).`,
          `Different paths give different values \\(\\Rightarrow\\) the limit does not exist.`
        ]
      : [
          `\\(\\left|\\frac{${a}x^2y}{x^2+y^2}\\right|\\le ${a}|y|\\) since \\(\\frac{x^2}{x^2+y^2}\\le 1\\).`,
          `As \\((x,y)\\to(0,0)\\), \\(${a}|y|\\to 0\\): by the Squeeze Theorem the limit is \\(0\\).`
        ],
    traps: dne
      ? [
          {ans:'\\(0\\)', why:'The y = x path gives a NONZERO value — one path is not enough to conclude 0.'},
          {ans:`\\(${mwFracTex(a,2)}\\)`, why:'That is only the y = x path. Another path gives 0, so no single value works.'}
        ]
      : [
          {ans:'DNE (the limit does not exist)', why:'The extra power of x lets the Squeeze Theorem force the limit to 0 on ALL paths.'},
          {ans:`\\(${a}\\)`, why:'Bound the fraction: x²/(x²+y²) ≤ 1, so the whole expression is squeezed to 0.'}
        ],
    vec: [unitIndex('C3_Partials'), 23, a, dne?1:0],
    key: 'c3_limit_2var'
  };
});
registerGen('C3_MultInt', (rng)=>{
  const a = pick(rng,[1,2,3]);
  const num = 4*a*a*a;
  return {
    q: `Evaluate \\(\\displaystyle\\int_0^{2\\pi}\\!\\!\\int_0^{\\pi}\\!\\!\\int_0^{${a}} \\rho^2\\sin\\varphi\\; d\\rho\\, d\\varphi\\, d\\theta\\).`,
    a: `\\(${mwFracTex(num,3)}\\pi\\)`,
    steps: [
      `\\(\\int_0^{${a}}\\rho^2 d\\rho=\\frac{${a*a*a}}{3}\\); \\(\\int_0^{\\pi}\\sin\\varphi\\, d\\varphi=2\\); \\(\\int_0^{2\\pi}d\\theta=2\\pi\\).`,
      `Product: \\(\\frac{${a*a*a}}{3}\\cdot 2\\cdot 2\\pi=${mwFracTex(num,3)}\\pi\\) — the volume of a ball of radius ${a}.`
    ],
    traps: [
      {ans:`\\(${mwFracTex(2*a*a*a,3)}\\pi\\)`, why:'∫₀^π sin φ dφ = 2 (not 1): cos φ swings from 1 to −1.'},
      {ans:`\\(${mwFracTex(num,3)}\\pi^2\\)`, why:'Only the θ integral contributes a π; the φ integral gives the plain number 2.'},
      {ans:`\\(${4*a*a===1?'':4*a*a}\\pi\\)`, why:'That is the surface AREA 4πa². The ρ² integral gives a³/3.'}
    ],
    vec: [unitIndex('C3_MultInt'), 20, a],
    key: 'c3_triple_spherical'
  };
});
registerGen('C3_MultInt', (rng)=>{
  const a = pick(rng,[2,4]), b = pick(rng,[1,2,3]), c = pick(rng,[1,2,3]);
  const ans = a*a*b*c/2;
  return {
    q: `Evaluate \\(\\displaystyle\\iiint_B x\\; dV\\) where \\(B=[0,${a}]\\times[0,${b}]\\times[0,${c}]\\).`,
    a: `\\(${ans}\\)`,
    steps: [
      `The integrand depends only on \\(x\\): \\(\\iiint_B x\\,dV=\\left(\\int_0^{${a}} x\\,dx\\right)(${b})(${c})\\).`,
      `\\(=\\frac{${a*a}}{2}\\cdot ${b*c}=${ans}\\).`
    ],
    traps: [
      {ans:`\\(${a*b*c}\\)`, why:'That is the volume ∭1 dV. The integrand x contributes a²/2, not a.'},
      {ans:`\\(${a*a*b*c}\\)`, why:'∫₀ᵃ x dx = a²/2 — keep the half.'},
      {ans:`\\(${a*a/2}\\)`, why:'The y and z integrals still contribute their interval lengths b and c.'}
    ],
    vec: [unitIndex('C3_MultInt'), 21, a, b, c],
    key: 'c3_triple_cartesian'
  };
});
registerGen('C3_VecCalc', (rng)=>{
  const a = mwNZ(rng,-5,5), b = mwNZ(rng,-5,5);
  const ans2 = a + b;   // twice the answer: ∫(a t + b t)dt over [0,1] = (a+b)/2
  return {
    q: `Evaluate \\(\\displaystyle\\int_C \\mathbf{F}\\cdot d\\mathbf{r}\\) for \\(\\mathbf{F}=\\langle ${a===1?'':a===-1?'-':a}x,\\; ${b===1?'':b===-1?'-':b}y\\rangle\\) along the segment from \\((0,0)\\) to \\((1,1)\\).`,
    a: `\\(${mwFracTex(ans2,2)}\\)`,
    steps: [
      `Parametrize: \\(\\mathbf{r}(t)=\\langle t, t\\rangle\\), \\(0\\le t\\le 1\\); \\(d\\mathbf{r}=\\langle 1,1\\rangle dt\\).`,
      `\\(\\mathbf{F}(\\mathbf{r}(t))\\cdot\\langle 1,1\\rangle=${a}t+${b}t=${a+b===1?'':a+b===-1?'-':a+b}t\\).`,
      `\\(\\int_0^1 ${a+b===1?'':a+b===-1?'-':a+b}t\\,dt=${mwFracTex(ans2,2)}\\).`
    ],
    traps: [
      {ans:`\\(${ans2}\\)`, why:'∫₀¹ t dt = 1/2 — the half comes from integrating t.'},
      {ans:`\\(${mwFracTex(a-b,2)}\\)`, why:'Both components contribute with + signs: F·dr = (ax + by)(dt) along this path.'},
      {ans:`\\(${mwFracTex(a*b,2)}\\)`, why:'The dot product ADDS the componentwise products; it does not multiply a and b together.'}
    ],
    vec: [unitIndex('C3_VecCalc'), 21, a, b],
    key: 'c3_line_integral_direct'
  };
});
registerGen('C3_VecCalc', (rng)=>{
  const cc = mwNZ(rng,-4,4);
  const a = pick(rng,[1,2,3]);
  const ans = cc*a*a;
  return {
    q: `Find the flux \\(\\displaystyle\\iint_S \\mathbf{F}\\cdot d\\mathbf{S}\\) of \\(\\mathbf{F}=\\langle 0, 0, ${cc}\\rangle\\) through the disk \\(x^2+y^2\\le ${a*a}\\) in the plane \\(z=0\\), oriented upward.`,
    a: `\\(${ans===1?'':ans===-1?'-':ans}\\pi\\)`,
    steps: [
      `Upward normal: \\(\\mathbf{n}=\\langle 0,0,1\\rangle\\), so \\(\\mathbf{F}\\cdot\\mathbf{n}=${cc}\\) (constant).`,
      `Flux \\(=${cc}\\times\\text{Area}=${cc}\\cdot\\pi(${a})^2=${ans===1?'':ans===-1?'-':ans}\\pi\\).`
    ],
    traps: [
      {ans:`\\(${2*cc*a===1?'':2*cc*a}\\pi\\)`, why:'Multiply by the AREA πa², not the circumference 2πa.'},
      {ans:`\\(0\\)`, why:'F is perpendicular to the disk, so it fully crosses it — the flux is F·n times the area, not zero.'},
      {ans:`\\(${-ans===1?'':-ans===-1?'-':-ans}\\pi\\)`, why:'Orientation: upward normal means n = ⟨0,0,+1⟩.'}
    ],
    vec: [unitIndex('C3_VecCalc'), 22, cc, a],
    key: 'c3_surface_flux'
  };
});
registerGen('C3_VecCalc', (rng)=>{
  const k = mwNZ(rng,-4,4);
  const a = pick(rng,[1,2,3]);
  const ans = k*a*a;
  return {
    q: `Use Stokes' Theorem to evaluate \\(\\displaystyle\\oint_C \\mathbf{F}\\cdot d\\mathbf{r}\\) where \\(\\mathbf{F}=\\langle 0,\\; ${k===1?'':k===-1?'-':k}x,\\; 0\\rangle\\) and \\(C\\) is the circle \\(x^2+y^2=${a*a}\\), \\(z=0\\), counterclockwise (viewed from above).`,
    a: `\\(${ans===1?'':ans===-1?'-':ans}\\pi\\)`,
    steps: [
      `\\(\\nabla\\times\\mathbf{F}=\\langle 0, 0, ${k}\\rangle\\) (constant).`,
      `Stokes: \\(\\oint_C\\mathbf{F}\\cdot d\\mathbf{r}=\\iint_S(\\nabla\\times\\mathbf{F})\\cdot\\mathbf{k}\\,dA=${k}\\cdot\\pi(${a})^2=${ans===1?'':ans===-1?'-':ans}\\pi\\).`
    ],
    traps: [
      {ans:`\\(${2*k*a===1?'':2*k*a}\\pi\\)`, why:'The surface integral uses the disk AREA πa², not the boundary length 2πa.'},
      {ans:`\\(${-ans===1?'':-ans===-1?'-':-ans}\\pi\\)`, why:'Counterclockwise from above pairs with the UPWARD normal (right-hand rule).'},
      {ans:`\\(0\\)`, why:'F is not conservative here: its curl is ⟨0,0,'+k+'⟩, so the circulation is nonzero.'}
    ],
    vec: [unitIndex('C3_VecCalc'), 23, k, a],
    key: 'c3_stokes'
  };
});
registerGen('C3_VecCalc', (rng)=>{
  const A = randInt(rng,1,3), b = randInt(rng,1,3), cc = randInt(rng,1,3);
  const R = pick(rng,[1,2,3]);
  const s = A + b + cc;
  const co = (u)=> u===1?'':`${u}`;
  return {
    q: `Use the Divergence Theorem to find the outward flux of \\(\\mathbf{F}=\\langle ${co(A)}x,\\; ${co(b)}y,\\; ${co(cc)}z\\rangle\\) through the sphere \\(x^2+y^2+z^2=${R*R}\\).`,
    a: `\\(${mwFracTex(4*s*R*R*R,3)}\\pi\\)`,
    steps: [
      `\\(\\nabla\\cdot\\mathbf{F}=${A}+${b}+${cc}=${s}\\) (constant).`,
      `Flux \\(=\\iiint_B (\\nabla\\cdot\\mathbf{F})\\,dV=${s}\\cdot\\frac{4}{3}\\pi(${R})^3=${mwFracTex(4*s*R*R*R,3)}\\pi\\).`
    ],
    traps: [
      {ans:`\\(${4*s*R*R}\\pi\\)`, why:'Multiply the (constant) divergence by the ball VOLUME 4πR³/3, not the surface area 4πR².'},
      {ans:`\\(${mwFracTex(4*A*b*cc,3)}\\pi\\)`, why:'Divergence ADDS the diagonal partials: ∂P/∂x + ∂Q/∂y + ∂R/∂z.'},
      {ans:`\\(${mwFracTex(s*R*R*R,3)}\\pi\\)`, why:'The ball volume carries the factor 4: (4/3)πR³.'}
    ],
    vec: [unitIndex('C3_VecCalc'), 24, A, b, cc, R],
    key: 'c3_divergence_theorem'
  };
});
registerGen('C3_Vectors', (rng)=>{
  const u = [randInt(rng,-3,3), randInt(rng,-3,3), randInt(rng,-3,3)];
  const v = [randInt(rng,-3,3), randInt(rng,-3,3), randInt(rng,-3,3)];
  const w = cross3(u,v);
  if(w[0]===0 && w[1]===0 && w[2]===0){ u[0] = u[0]===3 ? 2 : u[0]+1; }
  const w2 = cross3(u,v);
  const neg = w2.map(x=>-x);
  const jflip = [w2[0], -w2[1], w2[2]];
  return {
    q: `Compute \\(\\mathbf{u}\\times\\mathbf{v}\\) for \\(\\mathbf{u}=\\langle ${u.join(', ')}\\rangle\\), \\(\\mathbf{v}=\\langle ${v.join(', ')}\\rangle\\).`,
    a: `\\(\\langle ${w2.join(', ')}\\rangle\\)`,
    steps: [
      `\\(\\mathbf{u}\\times\\mathbf{v}=\\langle u_2v_3-u_3v_2,\\; u_3v_1-u_1v_3,\\; u_1v_2-u_2v_1\\rangle\\).`,
      `First: \\(${u[1]}\\cdot${v[2]}-${u[2]}\\cdot${v[1]}=${w2[0]}\\); second: \\(${u[2]}\\cdot${v[0]}-${u[0]}\\cdot${v[2]}=${w2[1]}\\); third: \\(${u[0]}\\cdot${v[1]}-${u[1]}\\cdot${v[0]}=${w2[2]}\\).`,
      `\\(\\mathbf{u}\\times\\mathbf{v}=\\langle ${w2.join(', ')}\\rangle\\).`
    ],
    traps: [
      {ans:`\\(\\langle ${neg.join(', ')}\\rangle\\)`, why:'That is v × u. The cross product is anticommutative: swapping the order negates it.'},
      {ans:`\\(\\langle ${jflip.join(', ')}\\rangle\\)`, why:'The j-component of the determinant expansion carries a MINUS sign: it is u3v1 - u1v3.'},
      {ans:`\\(${dot3(u,v)}\\)`, why:'That is the DOT product (a scalar). The cross product is a vector.'}
    ],
    vec: [unitIndex('C3_Vectors'), 20, ...u, ...v],
    key: 'c3_cross_product'
  };
});
registerGen('C3_Vectors', (rng)=>{
  const c = mwNZ(rng,-2,2);
  const t = mwNZ(rng,-2,2);
  const v = [3,4];
  const u = [3*c - 4*t, 4*c + 3*t];
  const proj = [3*c, 4*c];
  const rej  = [-4*t, 3*t];
  return {
    q: `Find the vector projection \\(\\mathrm{proj}_{\\mathbf{v}}\\mathbf{u}\\) of \\(\\mathbf{u}=\\langle ${u.join(', ')}\\rangle\\) onto \\(\\mathbf{v}=\\langle 3, 4\\rangle\\).`,
    a: `\\(\\langle ${proj.join(', ')}\\rangle\\)`,
    steps: [
      `\\(\\mathrm{proj}_{\\mathbf{v}}\\mathbf{u}=\\dfrac{\\mathbf{u}\\cdot\\mathbf{v}}{\\mathbf{v}\\cdot\\mathbf{v}}\\,\\mathbf{v}\\).`,
      `\\(\\mathbf{u}\\cdot\\mathbf{v}=${u[0]*3+u[1]*4}\\), \\(\\mathbf{v}\\cdot\\mathbf{v}=25\\), so the scalar is \\(${c}\\).`,
      `\\(\\mathrm{proj}_{\\mathbf{v}}\\mathbf{u}=${c}\\langle 3,4\\rangle=\\langle ${proj.join(', ')}\\rangle\\).`
    ],
    traps: [
      {ans:`\\(\\langle ${rej.join(', ')}\\rangle\\)`, why:'That is the component of u ORTHOGONAL to v (the rejection), not the projection.'},
      {ans:`\\(\\langle ${(-proj[0])}, ${(-proj[1])}\\rangle\\)`, why:'Sign of the scalar u·v/(v·v): a negative dot product means the projection points opposite v.'},
      {ans:`\\(${c*5}\\)`, why:'That is the SCALAR projection (comp). The vector projection is that scalar times the unit vector of v.'}
    ],
    vec: [unitIndex('C3_Vectors'), 21, c, t],
    key: 'c3_projection'
  };
});
registerGen('C3_Vectors', (rng)=>{
  const P = pick(rng,[[3,4,5],[6,8,10],[5,12,13],[8,6,10]]);
  const [a,b,c] = P;
  return {
    q: `Find the arc length of \\(\\mathbf{r}(t)=\\langle ${a}\\cos t,\\; ${a}\\sin t,\\; ${b}t\\rangle\\) for \\(0\\le t\\le 2\\pi\\).`,
    a: `\\(${2*c}\\pi\\)`,
    steps: [
      `\\(\\mathbf{r}'(t)=\\langle -${a}\\sin t,\\; ${a}\\cos t,\\; ${b}\\rangle\\).`,
      `\\(|\\mathbf{r}'(t)|=\\sqrt{${a*a}\\sin^2 t+${a*a}\\cos^2 t+${b*b}}=\\sqrt{${a*a+b*b}}=${c}\\).`,
      `\\(L=\\int_0^{2\\pi} ${c}\\,dt=${2*c}\\pi\\).`
    ],
    traps: [
      {ans:`\\(${2*a}\\pi\\)`, why:'The z-component contributes too: |r′| = sqrt(a^2 + b^2), not just a.'},
      {ans:`\\(${2*(a+b)}\\pi\\)`, why:'Magnitudes add in quadrature (under the square root), not linearly.'},
      {ans:`\\(${c}\\pi\\)`, why:'The interval has length 2π — multiply the constant speed by the full interval.'}
    ],
    vec: [unitIndex('C3_Vectors'), 22, a, b],
    key: 'c3_vvf_arc_length'
  };
});
registerGen('C3_Partials', (rng)=>{
  const A = mwNZ(rng,-3,3);
  const B = mwNZ(rng,-3,3);
  const p = randInt(rng,-2,2);
  const qq = randInt(rng,-2,2);
  const gx = 2*A*p, gy = 2*B*qq;
  const dotv = 3*gx + 4*gy;
  return {
    q: `Let \\(f(x,y)=${A===1?'':A===-1?'-':A}x^2${B>=0?'+':''}${B===1?'':B===-1?'-':B}y^2\\). Find the directional derivative of \\(f\\) at \\((${p}, ${qq})\\) in the direction of \\(\\mathbf{v}=\\langle 3, 4\\rangle\\).`,
    a: `\\(${mwFracTex(dotv,5)}\\)`,
    steps: [
      `Gradient: \\(\\nabla f=\\langle ${2*A}x,\\; ${2*B}y\\rangle\\), so \\(\\nabla f(${p},${qq})=\\langle ${gx}, ${gy}\\rangle\\).`,
      `Unit vector: \\(|\\mathbf{v}|=5\\Rightarrow \\mathbf{u}=\\langle 3/5, 4/5\\rangle\\).`,
      `\\(D_{\\mathbf{u}}f=\\nabla f\\cdot\\mathbf{u}=\\dfrac{3(${gx})+4(${gy})}{5}=${mwFracTex(dotv,5)}\\).`
    ],
    traps: [
      {ans:`\\(${dotv}\\)`, why:'v must be a UNIT vector: divide by |v| = 5 before dotting.'},
      {ans:`\\(${mwFracTex(dotv,25)}\\)`, why:'Divide by |v| once (=5), not by |v|^2.'},
      {ans:`\\(${mwFracTex(4*gx+3*gy,5)}\\)`, why:'Component mismatch: pair f_x with the x-component of u and f_y with the y-component.'}
    ],
    vec: [unitIndex('C3_Partials'), 20, A, B, p, qq],
    key: 'c3_gradient_directional'
  };
});
registerGen('C3_Partials', (rng)=>{
  const kind = pick(rng,['min','max','saddle']);
  const a = randInt(rng,-2,2)*2;   // even → integer critical point
  const b = randInt(rng,-2,2)*2;
  let f, cp, D, fxx, cls, fTex;
  if(kind==='min'){ fTex = `x^2+y^2${fmtSigned(a)}x${fmtSigned(b)}y`; cp=[-a/2,-b/2]; D=4; fxx=2; cls='local minimum'; }
  else if(kind==='max'){ fTex = `-x^2-y^2${fmtSigned(a)}x${fmtSigned(b)}y`; cp=[a/2,b/2]; D=4; fxx=-2; cls='local maximum'; }
  else { fTex = `x^2-y^2${fmtSigned(a)}x${fmtSigned(b)}y`; cp=[-a/2,b/2]; D=-4; fxx=2; cls='saddle point'; }
  const wrongCls = kind==='min' ? 'local maximum' : (kind==='max' ? 'local minimum' : 'local minimum');
  const wrongPt = [-cp[0]||0, -cp[1]||0];
  return {
    q: `Find and classify the critical point of \\(f(x,y)=${fTex}\\).`,
    a: `${cls.charAt(0).toUpperCase()+cls.slice(1)} at \\((${cp[0]}, ${cp[1]})\\)`,
    steps: [
      `Set \\(f_x=0\\) and \\(f_y=0\\): the critical point is \\((${cp[0]}, ${cp[1]})\\).`,
      `Second derivative test: \\(D=f_{xx}f_{yy}-f_{xy}^2=${D}\\)${kind==='saddle'?'\\(<0\\Rightarrow\\) saddle point':`, \\(f_{xx}=${fxx}\\)${fxx>0?'\\(>0\\Rightarrow\\) local minimum':'\\(<0\\Rightarrow\\) local maximum'}`}.`
    ],
    traps: [
      {ans:`${wrongCls.charAt(0).toUpperCase()+wrongCls.slice(1)} at \\((${cp[0]}, ${cp[1]})\\)`, why: kind==='saddle' ? 'D < 0 means SADDLE regardless of f_xx.' : 'Right point, wrong type: after D > 0, the SIGN of f_xx decides min vs max.'},
      {ans:`${cls.charAt(0).toUpperCase()+cls.slice(1)} at \\((${wrongPt[0]}, ${wrongPt[1]})\\)`, why:'Sign slip solving f_x = 0, f_y = 0 for the critical point.'}
    ],
    vec: [unitIndex('C3_Partials'), 21, a, b, kind==='min'?0:kind==='max'?1:2],
    key: 'c3_extrema_2var'
  };
});
registerGen('C3_VecCalc', (rng)=>{
  const a = mwNZ(rng,-4,4), b = mwNZ(rng,-4,4);
  const c = mwNZ(rng,-4,4), d = mwNZ(rng,-4,4);
  const which = pick(rng,['div','curl']);
  const co = (u)=> u===1?'':(u===-1?'-':`${u}`);
  const F = `\\langle ${co(a)}x${fmtSigned(b)}y,\\; ${co(c)}x${fmtSigned(d)}y,\\; 0\\rangle`;
  const div = a + d, curlK = c - b;
  const ans = which==='div' ? `\\(${div}\\)` : `\\(\\langle 0, 0, ${curlK}\\rangle\\)`;
  const traps = which==='div'
    ? [
        {ans:`\\(${curlK}\\)`, why:'That is the k-component of the CURL. Divergence is ∂P/∂x + ∂Q/∂y.'},
        {ans:`\\(${a - d}\\)`, why:'Divergence ADDS the diagonal partials: P_x + Q_y.'},
        {ans:`\\(${b + c}\\)`, why:'Use ∂P/∂x and ∂Q/∂y — the diagonal terms, not the cross terms.'}
      ]
    : [
        {ans:`\\(\\langle 0, 0, ${-curlK}\\rangle\\)`, why:'Order: the k-component is ∂Q/∂x - ∂P/∂y.'},
        {ans:`\\(\\langle 0, 0, ${div}\\rangle\\)`, why:'That is the divergence packed into a vector. Curl k-component is Q_x - P_y.'},
        {ans:`\\(${curlK}\\)`, why:'Curl of a 3D field is a VECTOR; for a planar field it points in the k direction.'}
      ];
  return {
    q: `For \\(\\mathbf{F}(x,y,z)=${F}\\), compute ${which==='div' ? 'the divergence \\(\\nabla\\cdot\\mathbf{F}\\)' : 'the curl \\(\\nabla\\times\\mathbf{F}\\)'}.`,
    a: ans,
    steps: which==='div'
      ? [
          `\\(\\nabla\\cdot\\mathbf{F}=\\dfrac{\\partial P}{\\partial x}+\\dfrac{\\partial Q}{\\partial y}+\\dfrac{\\partial R}{\\partial z}\\).`,
          `\\(=${a}+${d}+0=${div}\\).`
        ]
      : [
          `For a planar field, \\(\\nabla\\times\\mathbf{F}=\\left(\\dfrac{\\partial Q}{\\partial x}-\\dfrac{\\partial P}{\\partial y}\\right)\\mathbf{k}\\).`,
          `\\(=(${c}-(${b}))\\mathbf{k}=\\langle 0, 0, ${curlK}\\rangle\\).`
        ],
    traps,
    vec: [unitIndex('C3_VecCalc'), 20, a, b, c, d, which==='div'?0:1],
    key: 'c3_curl_divergence'
  };
});
