// AC2 generator registrations — order frozen by the published registry.
registerGen('AC2_IntApps', (rng)=>{
  const m = pick(rng,[2,4]), q0 = pick(rng,[10,20,30]);
  const p0 = pick(rng,[20,30,40]);
  const d0 = p0 + m*q0;                          // demand p = d0 - m q hits p0 at q0
  const cs = m*q0*q0/2;
  return {
    q: `The demand curve is \\(p = ${d0} - ${m}q\\) and the market price is \\(p_0 = ${p0}\\) (so \\(q_0 = ${q0}\\)). Find the consumer surplus.`,
    a: `\\(CS = ${cs}\\)`,
    steps: [
      `\\(CS = \\int_0^{${q0}} (${d0} - ${m}q)\\,dq - p_0 q_0\\).`,
      `\\(= \\left[${d0}q - ${m===2?'':m/2 + ''}q^2${m===2?'':''}\\right]_0^{${q0}} - ${p0}\\cdot${q0} = ${d0*q0 - m*q0*q0/2} - ${p0*q0}\\).`,
      `\\(CS = ${cs}\\) — the triangle between the demand curve and the price line.`
    ],
    traps: [
      {ans: `\\(CS = ${d0*q0 - m*q0*q0/2}\\)`, why: 'That is the WHOLE area under demand — subtract what consumers actually paid (p₀q₀) to get the surplus.'},
      {ans: `\\(CS = ${m*q0*q0}\\)`, why: 'The surplus triangle has area ½·base·height = ½·q₀·(d₀−p₀); the ½ is not optional.'}
    ],
    vec: [unitIndex('AC2_IntApps'), 1, d0, m, p0, q0],
    key: 'ac2_consumer_surplus'
  };
});
registerGen('AC2_IntApps', (rng)=>{
  const n = pick(rng,[1,2,3]), q0 = pick(rng,[10,20]);
  const s0 = pick(rng,[5,10]);
  const p0 = s0 + n*q0;
  const ps = n*q0*q0/2;
  return {
    q: `The supply curve is \\(p = ${s0} + ${n}q\\) and the market price is \\(p_0 = ${p0}\\) (so \\(q_0 = ${q0}\\)). Find the producer surplus.`,
    a: `\\(PS = ${ps}\\)`,
    steps: [
      `\\(PS = p_0 q_0 - \\int_0^{${q0}} (${s0} + ${n}q)\\,dq\\).`,
      `\\(= ${p0*q0} - (${s0*q0 + n*q0*q0/2}) = ${ps}\\).`,
      `Producers receive \\(p_0\\) but were willing to sell for less — the triangle above supply, below price.`
    ],
    traps: [
      {ans: `\\(PS = ${s0*q0 + n*q0*q0/2}\\)`, why: 'That is the integral under SUPPLY (minimum acceptable revenue). Surplus is receipts p₀q₀ MINUS that.'},
      {ans: `\\(PS = ${n*q0*q0}\\)`, why: 'The surplus triangle is ½·q₀·(p₀−s₀) — half the rectangle, not all of it.'}
    ],
    vec: [unitIndex('AC2_IntApps'), 2, s0, n, p0, q0],
    key: 'ac2_producer_surplus'
  };
});
registerGen('AC2_IntApps', (rng)=>{
  const R = pick(rng,[1000,2000,3000]), d = pick(rng,[10,20]);   // r = 1/d, T = d
  return {
    q: `Income flows continuously at \\$${R} per year for ${d} years, with continuous discount rate \\(r = \\frac{1}{${d}}\\). Find the present value \\(PV = \\int_0^{${d}} ${R}e^{-t/${d}}\\,dt\\). (Exact form.)`,
    a: `\\(PV = ${R*d}(1 - e^{-1})\\)`,
    steps: [
      `\\(\\int ${R}e^{-t/${d}}dt = -${R*d}\\,e^{-t/${d}}\\).`,
      `Evaluate 0 to ${d}: \\(-${R*d}e^{-1} + ${R*d}e^{0} = ${R*d}(1 - e^{-1})\\).`,
      `\\(\\approx ${(R*d*(1-Math.exp(-1))).toFixed(0)}\\) — less than the raw \\$${R*d} because future dollars are discounted.`
    ],
    traps: [
      {ans: `\\(PV = ${R*d}\\)`, why: 'That is the undiscounted total R·T. The e^{−rt} factor shrinks future income — PV must be smaller.'},
      {ans: `\\(PV = ${R}(1 - e^{-1})\\)`, why: 'Integrating e^{−t/' + d + '} multiplies by ' + d + ' (the reciprocal of the rate): the antiderivative is −' + d + 'e^{−t/' + d + '} times R.'}
    ],
    vec: [unitIndex('AC2_IntApps'), 3, R, d],
    key: 'ac2_present_value'
  };
});
registerGen('AC2_IntApps', (rng)=>{
  const m = pick(rng,[6,12]), n = pick(rng,[1,2]), b = pick(rng,[2,4,6]);
  // average of R(x) = m x - n x^2 on [0,b]: m b/2 - n b^2/3 — pick b divisible by 6 for integers? b in {2,4,6}, ensure integer: m b /2 int; n b²/3 int requires 3 | n b². choose b=6 or n*b² divisible by 3: force b=6.
  const B = 6;
  const avg = m*B/2 - n*B*B/3;
  return {
    q: `Revenue is \\(R(x) = ${m}x - ${n}x^2\\) (thousands of dollars). Find the average revenue over \\(x \\in [0, ${B}]\\).`,
    a: `\\(${avg}\\) thousand dollars`,
    steps: [
      `Average value: \\(\\dfrac{1}{${B}-0}\\int_0^{${B}} (${m}x - ${n}x^2)\\,dx\\).`,
      `\\(\\int_0^{${B}} = \\left[${m/2===1?'':m/2}x^2 - \\frac{${n}}{3}x^3\\right]_0^{${B}} = ${m*B*B/2 - n*B*B*B/3}\\).`,
      `Divide by ${B}: average \\(= ${avg}\\).`
    ],
    traps: [
      {ans: `\\(${m*B*B/2 - n*B*B*B/3}\\) thousand dollars`, why: 'That is the integral (total) — the AVERAGE divides by the interval length ' + B + '.'},
      {ans: `\\(${m*B - n*B*B}\\) thousand dollars`, why: 'That is R(' + B + '), the endpoint value — average value integrates over the whole interval.'}
    ],
    vec: [unitIndex('AC2_IntApps'), 4, m, n, B],
    key: 'ac2_avg_revenue'
  };
});
registerGen('AC2_Multivar', (rng)=>{
  const a = mwNZ(rng,1,4), b = mwNZ(rng,2,5), c = mwNZ(rng,1,4);
  const x0 = mwNZ(rng,1,3), y0 = mwNZ(rng,1,3);
  const val = 2*a*x0 + b*y0;
  return {
    q: `Let \\(f(x,y) = ${a}x^2 + ${b}xy + ${c}y^2\\). Compute \\(f_x(${x0}, ${y0})\\).`,
    a: `\\(${val}\\)`,
    steps: [
      `Treat \\(y\\) as a constant: \\(f_x = ${2*a}x + ${b}y\\).`,
      `Evaluate: \\(f_x(${x0},${y0}) = ${2*a}(${x0}) + ${b}(${y0}) = ${val}\\).`
    ],
    traps: [
      {ans: `\\(${2*a*x0 + b*y0 + 2*c*y0}\\)`, why: 'The ' + c + 'y² term has NO x — it differentiates to 0 with respect to x. Only x-bearing terms survive.'},
      {ans: `\\(${b*x0 + 2*c*y0}\\)`, why: 'That is f_y — the partial with respect to y. Check which variable the subscript names.'}
    ],
    vec: [unitIndex('AC2_Multivar'), 1, a, b, c, x0, y0],
    key: 'ac2_partial_eval'
  };
});
registerGen('AC2_Multivar', (rng)=>{
  const xa = mwNZ(rng,1,4), yb = mwNZ(rng,1,4);
  const a = 2*xa, b = 2*yb;                       // f = x^2 + y^2 - a x - b y → crit (xa, yb)
  return {
    q: `Find the critical point of \\(f(x,y) = x^2 + y^2 - ${a}x - ${b}y + ${pick(rng,[3,5,7])}\\).`,
    a: `\\((${xa},\\ ${yb})\\)`,
    steps: [
      `Set both partials to zero: \\(f_x = 2x - ${a} = 0\\) and \\(f_y = 2y - ${b} = 0\\).`,
      `\\(x = ${xa}\\), \\(y = ${yb}\\).`,
      `(Both second partials are \\(+2\\) with \\(f_{xy}=0\\): \\(D = 4 > 0\\), a minimum.)`
    ],
    traps: [
      {ans: `\\((${a},\\ ${b})\\)`, why: 'f_x = 2x − ' + a + ' = 0 gives x = ' + a + '/2 = ' + xa + ' — do not forget the 2 from differentiating x².'},
      {ans: `\\((${-xa},\\ ${-yb})\\)`, why: 'Moving −' + a + 'x across: 2x = +' + a + '. Watch the sign.'}
    ],
    vec: [unitIndex('AC2_Multivar'), 2, a, b, xa, yb],
    key: 'ac2_critical_point'
  };
});
registerGen('AC2_Multivar', (rng)=>{
  const kind = pick(rng, ['min','max','saddle']);
  let a, c, b;
  if(kind==='min'){ a = mwNZ(rng,1,3); c = mwNZ(rng,1,3); b = 1; }
  else if(kind==='max'){ a = -mwNZ(rng,1,3); c = -mwNZ(rng,1,3); b = 1; }
  else { a = mwNZ(rng,1,3); c = -mwNZ(rng,1,3); b = 1; }
  const D = 4*a*c - b*b;
  const label = kind==='min' ? 'Local minimum' : kind==='max' ? 'Local maximum' : 'Saddle point';
  const others = ['Local minimum','Local maximum','Saddle point'].filter(s=>s!==label);
  return {
    q: `\\(f(x,y) = ${a}x^2 + ${b}xy ${c<0?'-':'+'} ${Math.abs(c)}y^2\\) has a critical point at \\((0,0)\\). Classify it using \\(D = f_{xx}f_{yy} - f_{xy}^2\\).`,
    a: label,
    steps: [
      `\\(f_{xx} = ${2*a}\\), \\(f_{yy} = ${2*c}\\), \\(f_{xy} = ${b}\\).`,
      `\\(D = (${2*a})(${2*c}) - (${b})^2 = ${D}\\).`,
      kind==='saddle' ? `\\(D < 0\\): saddle point.` :
        `\\(D > 0\\) and \\(f_{xx} ${a>0?'> 0':'< 0'}\\): local ${kind === 'min' ? 'minimum' : 'maximum'}.`
    ],
    traps: [
      {ans: others[0], why: 'D < 0 always means saddle; D > 0 means an extremum whose TYPE is read from the sign of f_xx.'},
      {ans: others[1], why: 'Compute D first — f_xx alone cannot distinguish a max/min from a saddle.'}
    ],
    vec: [unitIndex('AC2_Multivar'), 3, kind==='min'?0:kind==='max'?1:2, a, b, c],
    key: 'ac2_dtest'
  };
});
