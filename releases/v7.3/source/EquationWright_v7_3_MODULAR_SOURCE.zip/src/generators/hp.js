// HP generator registrations — order frozen by the published registry.
registerGen('HP_Conversion', (rng)=>{
  const kind = pick(rng,[0,1,2]);
  const n = pick(rng,[2,4,5,8]);
  const qs = [`Convert ${n} g to milligrams.`, `Convert ${n*500} mL to liters.`, `Convert ${n} mg to micrograms.`];
  const ans = [`${n*1000} mg`, `${n*500/1000} L`, `${n*1000} mcg`];
  const tr = [
    [{ans:`${n/1000} mg`, why:'Grams are LARGER than milligrams — converting to the smaller unit multiplies by 1000.'},
     {ans:`${n*100} mg`, why:'The metric jump g→mg is 1000, not 100.'}],
    [{ans:`${n*500*1000} L`, why:'Liters are LARGER than mL — divide by 1000 going up the ladder.'},
     {ans:`${n*500/100} L`, why:'mL→L divides by 1000, not 100.'}],
    [{ans:`${n/1000} mcg`, why:'mcg is SMALLER than mg — multiply by 1000. (1 mg = 1000 mcg.)'},
     {ans:`${n*100} mcg`, why:'Each metric step here is 1000: mg→mcg multiplies by 1000.'}]
  ][kind];
  return {
    q: qs[kind], a: ans[kind],
    steps: [
      `Metric ladder: 1 g = 1000 mg = 1{,}000{,}000 mcg; 1 L = 1000 mL.`,
      `Smaller unit → multiply; larger unit → divide.`
    ],
    traps: tr,
    vec: [unitIndex('HP_Conversion'), 1, kind, n],
    key: 'hp_metric_convert'
  };
});
registerGen('HP_Conversion', (rng)=>{
  const kg = pick(rng,[10,20,30,40,50,60]);
  const lb = Math.round(kg*2.2*10)/10;
  return {
    q: `A patient weighs ${lb} lb. Convert to kilograms (1 kg = 2.2 lb).`,
    a: `${kg} kg`,
    steps: [
      `Kilograms are larger, so DIVIDE: \\(${lb} \\div 2.2 = ${kg}\\) kg.`,
      `Sense check: the kg number should be smaller than the lb number.`
    ],
    traps: [
      {ans: `${Math.round(lb*2.2*10)/10} kg`, why: 'Multiplying converts kg→lb. Going TO kilograms divides by 2.2 — the kg value must come out smaller.'},
      {ans: `${Math.round((lb-2.2)*10)/10} kg`, why: 'Unit conversion is a ratio (divide by 2.2), never a subtraction.'}
    ],
    vec: [unitIndex('HP_Conversion'), 2, kg],
    key: 'hp_lb_kg'
  };
});
registerGen('HP_Conversion', (rng)=>{
  const tsp = pick(rng,[2,3,4]);
  return {
    q: `A liquid medication order is ${tsp} teaspoons. How many milliliters is that? (1 tsp = 5 mL)`,
    a: `${tsp*5} mL`,
    steps: [ `\\(${tsp} \\times 5 = ${tsp*5}\\) mL — household to metric multiplies by the equivalence.` ],
    traps: [
      {ans: `${tsp*15} mL`, why: '15 mL is a TABLEspoon (1 tbsp); a teaspoon is 5 mL.'},
      {ans: `${Math.round(tsp/5*100)/100} mL`, why: 'tsp→mL multiplies by 5; each teaspoon holds 5 mL.'}
    ],
    vec: [unitIndex('HP_Conversion'), 3, tsp],
    key: 'hp_tsp_ml'
  };
});
registerGen('HP_Dosage', (rng)=>{
  const H = pick(rng,[125,250,500]), Qm = pick(rng,[5,10]);
  const mult = pick(rng,[2,3]);
  const D = H*mult/ (pick(rng,[1,2]));           // D/H in {mult, mult/2}
  const give = D/H*Qm;
  return {
    q: `Order: ${D} mg. Available: ${H} mg per ${Qm} mL. How many mL should be given? (Use \\(\\frac{D}{H}\\times Q\\).)`,
    a: `${give} mL`,
    steps: [
      `\\(\\frac{D}{H}\\times Q = \\frac{${D}}{${H}}\\times ${Qm} = ${give}\\) mL.`,
      `Sense check: the order is ${D>H?'more':'not more'} than one ${Qm}-mL unit${D>H?', so the volume exceeds '+Qm+' mL':''}.`
    ],
    traps: [
      {ans: `${H/D*Qm} mL`, why: 'Desired goes on TOP: D/H, order over stock. Flipping it under-doses or over-doses.'},
      {ans: `${D/H} mL`, why: 'The ratio D/H is in DOSES of stock; multiply by Q (mL per stock unit) to get volume.'}
    ],
    vec: [unitIndex('HP_Dosage'), 1, D, H, Qm, give],
    key: 'hp_dose_formula'
  };
});
registerGen('HP_Dosage', (rng)=>{
  const tab = pick(rng,[250,500]);
  const n = pick(rng,[2,3]);
  const half = pick(rng,[0, tab/2]);
  const order = tab*n + half;
  const tabs = order/tab;
  return {
    q: `Order: ${order} mg. Tablets on hand: ${tab} mg each (scored). How many tablets?`,
    a: `${tabs} tablet${tabs===1?'':'s'}`,
    steps: [ `\\(${order} \\div ${tab} = ${tabs}\\) tablets.` ],
    traps: [
      {ans: `${order*tab} tablets`, why: 'Divide the ordered dose by the strength per tablet — multiplying gives a nonsense count.'},
      {ans: `${tabs + 1} tablets`, why: 'Scored tablets allow half-tablet doses — compute the exact quotient, do not round a dose up.'}
    ],
    vec: [unitIndex('HP_Dosage'), 2, order, tab],
    key: 'hp_dose_tablets'
  };
});
registerGen('HP_Dosage', (rng)=>{
  const rate = pick(rng,[5,10,15]), kg = pick(rng,[12,20,30]);
  return {
    q: `A pediatric order is ${rate} mg/kg. The child weighs ${kg} kg. What is the dose?`,
    a: `${rate*kg} mg`,
    steps: [ `Dose = rate × weight = \\(${rate}\\times${kg} = ${rate*kg}\\) mg.` ],
    traps: [
      {ans: `${rate + kg} mg`, why: 'mg/kg is a RATE — it multiplies the weight; the units cancel: (mg/kg)(kg) = mg.'},
      {ans: `${Math.round(kg/rate*100)/100} mg`, why: 'The weight multiplies the per-kg rate; dividing shrinks the dose as the child grows.'}
    ],
    vec: [unitIndex('HP_Dosage'), 3, rate, kg],
    key: 'hp_dose_weight'
  };
});
registerGen('HP_Dosage', (rng)=>{
  const per = pick(rng,[3,4]);                          // q8h -> 3, q6h -> 4
  const each = pick(rng,[100,150,200,250]);
  const daily = each*per;
  const hrs = per===3 ? 8 : 6;
  return {
    q: `The daily order is ${daily} mg, given every ${hrs} hours (q${hrs}h). How many mg per dose?`,
    a: `${each} mg per dose`,
    steps: [
      `Doses per day: \\(24 \\div ${hrs} = ${per}\\).`,
      `Per dose: \\(${daily} \\div ${per} = ${each}\\) mg.`
    ],
    traps: [
      {ans: `${Math.round(daily/hrs)} mg per dose`, why: 'Divide by the NUMBER of doses (24 ÷ ' + hrs + ' = ' + per + '), not by the hour interval itself.'},
      {ans: `${daily} mg per dose`, why: 'That is the whole DAY at once — q' + hrs + 'h splits it into ' + per + ' doses.'}
    ],
    vec: [unitIndex('HP_Dosage'), 4, daily, hrs, per, each],
    key: 'hp_dose_divided'
  };
});
registerGen('HP_IVRates', (rng)=>{
  const hrs = pick(rng,[4,8,10]);
  const rate = pick(rng,[75,100,125]);
  const vol = rate*hrs;
  return {
    q: `An IV of ${vol} mL is to infuse over ${hrs} hours. What is the flow rate in mL/hr?`,
    a: `${rate} mL/hr`,
    steps: [ `Rate = volume ÷ time = \\(${vol} \\div ${hrs} = ${rate}\\) mL/hr.` ],
    traps: [
      {ans: `${vol*hrs} mL/hr`, why: 'Rate divides volume by time; multiplying makes the number grow with LONGER infusions, which is backwards.'},
      {ans: `${Math.round(hrs/vol*10000)/10000} mL/hr`, why: 'Volume over time, not time over volume — mL/hr puts mL on top.'}
    ],
    vec: [unitIndex('HP_IVRates'), 1, vol, hrs, rate],
    key: 'hp_iv_mlhr'
  };
});
registerGen('HP_IVRates', (rng)=>{
  const gtt = pick(rng,[10,15,20]);                        // gtt factor per mL
  const per = 60/gtt;                                       // 6, 4, 3
  const drops = pick(rng,[20,25,30,40]);
  const rate = drops*per;                                   // mL/hr chosen so gtt/min integer
  return {
    q: `An IV runs at ${rate} mL/hr with tubing calibrated at ${gtt} gtt/mL. Find the drip rate in gtt/min.`,
    a: `${drops} gtt/min`,
    steps: [
      `\\(\\text{gtt/min} = \\dfrac{\\text{mL/hr}\\times\\text{gtt factor}}{60}\\).`,
      `\\(= \\dfrac{${rate}\\times${gtt}}{60} = ${drops}\\) gtt/min.`
    ],
    traps: [
      {ans: `${rate*gtt} gtt/min`, why: 'The ÷60 converts per-HOUR to per-MINUTE — skipping it gives a per-hour drop count.'},
      {ans: `${Math.round(rate/gtt)} gtt/min`, why: 'The gtt factor MULTIPLIES (drops per mL), then divide by 60 minutes.'}
    ],
    vec: [unitIndex('HP_IVRates'), 2, rate, gtt, drops],
    key: 'hp_iv_gtt'
  };
});
registerGen('HP_IVRates', (rng)=>{
  const pct = pick(rng,[5,9,10]);
  const vol = pick(rng,[200,500,1000]);
  const g = pct*vol/100;
  return {
    q: `How many grams of dextrose are in ${vol} mL of a ${pct}\\% solution? (\\(${pct}\\%\\) = ${pct} g per 100 mL)`,
    a: `${g} g`,
    steps: [ `\\(\\dfrac{${pct}\\text{ g}}{100\\text{ mL}}\\times ${vol}\\text{ mL} = ${g}\\) g.` ],
    traps: [
      {ans: `${pct*vol} g`, why: 'Percent solutions are g per 100 mL — divide by 100 (or use the proportion) before scaling.'},
      {ans: `${pct} g`, why: 'That is the amount in only 100 mL; this bag holds ' + vol + ' mL — scale up proportionally.'}
    ],
    vec: [unitIndex('HP_IVRates'), 3, pct, vol, g],
    key: 'hp_percent_solution'
  };
});
registerGen('HP_IVRates', (rng)=>{
  const C1 = pick(rng,[10,20]);
  const C2 = pick(rng,[2,5].filter(v=>C1%v===0));
  const V2 = pick(rng,[100,200,500]);
  const V1 = C2*V2/C1;
  return {
    q: `A ${C1}\\% stock solution must be diluted to make ${V2} mL of a ${C2}\\% solution. How much stock is needed? (Use \\(C_1V_1 = C_2V_2\\).)`,
    a: `${V1} mL of stock`,
    steps: [
      `\\(C_1V_1 = C_2V_2 \\Rightarrow V_1 = \\dfrac{C_2 V_2}{C_1} = \\dfrac{${C2}\\times${V2}}{${C1}} = ${V1}\\) mL.`,
      `Then add diluent up to ${V2} mL total.`
    ],
    traps: [
      {ans: `${C1*V2/C2} mL of stock`, why: 'Solve for V₁ = C₂V₂/C₁ — the STOCK concentration goes in the denominator. Needing more stock than the final volume is the giveaway.'},
      {ans: `${V2 - V1} mL of stock`, why: 'That is the DILUENT to add; the stock volume comes from the dilution equation.'}
    ],
    vec: [unitIndex('HP_IVRates'), 4, C1, C2, V2, V1],
    key: 'hp_dilution'
  };
});
