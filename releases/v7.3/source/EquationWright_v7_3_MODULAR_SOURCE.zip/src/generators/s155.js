// S155 generator registrations — order frozen by the published registry.
registerGen('S155_Descriptive', (rng)=>{
  const base = pick(rng,[4,6,8,10]);
  const data = [base, base+2, base+3, base+5, base+10].map(v=>v+pick(rng,[0,1]));
  const mean = mwMean(data), med = mwMedian(data);
  const meanR = Math.round(mean*10)/10;
  return {
    q: `Find the mean and median of the data set: ${data.join(', ')}.`,
    a: `Mean = ${meanR}, Median = ${med}`,
    steps: [
      `Mean: sum ÷ count = ${data.reduce((a,b)=>a+b,0)} ÷ ${data.length} = ${meanR}.`,
      `Median: sort (already sorted) and take the middle value: ${med}.`,
      mean > med ? `Mean > median — the larger values pull the mean up.` : `Values are fairly balanced here.`
    ],
    traps: [
      {ans: `Mean = ${med}, Median = ${meanR}`, why: 'Swapped — the median is the positional middle; the mean is the arithmetic average.'},
      {ans: `Mean = ${meanR}, Median = ${data[1]}`, why: 'The median of five values is the 3rd after sorting, not the 2nd.'}
    ],
    vec: [unitIndex('S155_Descriptive'), 1, ...data],
    key: 's155_mean_median'
  };
});
registerGen('S155_Descriptive', (rng)=>{
  const m = pick(rng,[10,20,30]);
  const pat = pick(rng,[[-3,-1,0,1,3],[-4,-2,0,2,4],[-2,-1,0,1,2],[-5,-1,0,1,5],[-3,-2,0,2,3],[-4,-1,0,1,4]]);
  const data = pat.map(d=>m+d);
  const ss = pat.reduce((a,d)=>a+d*d,0);
  const sd = mwSampleSD(data);
  const sdR = Math.round(sd*100)/100;
  return {
    q: `Compute the sample standard deviation of: ${data.join(', ')}. (Round to 2 decimals.)`,
    a: `s = ${sdR}`,
    steps: [
      `Mean = ${m}. Deviations: ${pat.join(', ')}; squared sum = ${ss}.`,
      `Sample variance divides by n − 1 = 4: \\(s^2 = ${ss}/4 = ${ss/4}\\).`,
      `\\(s = \\sqrt{${ss/4}} \\approx ${sdR}\\).`
    ],
    traps: [
      {ans: `s = ${Math.round(Math.sqrt(ss/5)*100)/100}`, why: 'SAMPLE standard deviation divides by n − 1, not n — the correction for estimating from a sample.'},
      {ans: `s = ${ss/4}`, why: (ss/4) + ' is the VARIANCE; the standard deviation is its square root.'}
    ],
    vec: [unitIndex('S155_Descriptive'), 2, m],
    key: 's155_sample_sd'
  };
});
registerGen('S155_Descriptive', (rng)=>{
  const data = [10,12,14,16,18].map(v=>v+pick(rng,[0,2,4]));
  const out = pick(rng,[80,100,120]);
  const oldMean = mwMean(data), oldMed = mwMedian(data);
  const newMean = Math.round(mwMean([...data,out])*10)/10;
  const newMed = mwMedian([...data,out]);
  return {
    q: `The data set ${data.join(', ')} has mean ${oldMean} and median ${oldMed}. An outlier of ${out} is added. What happens?`,
    a: `The mean jumps to ${newMean}; the median barely moves (to ${newMed})`,
    steps: [
      `New mean: \\((${data.reduce((a,b)=>a+b,0)} + ${out}) \\div 6 = ${newMean}\\) — every value feeds the mean, so the outlier drags it.`,
      `New median: middle of six values = ${newMed} — position-based, so one extreme value barely matters.`,
      `This is why the median is preferred for skewed data (incomes, home prices).`
    ],
    traps: [
      {ans: `Both jump to about ${newMean}`, why: 'The median is resistant to outliers — it depends on position, not magnitude.'},
      {ans: `Neither changes; one value cannot move a summary statistic`, why: 'The MEAN uses every value, so a single extreme value can move it substantially.'}
    ],
    vec: [unitIndex('S155_Descriptive'), 3, out, ...data],
    key: 's155_outlier_effect'
  };
});
registerGen('S155_Normal', (rng)=>{
  const mu = pick(rng,[50,70,100,500]), sd = pick(rng,[4,5,10,20]);
  const zInt = pick(rng,[-3,-2,-1,1,2,3]) * pick(rng,[1,1,1]) + pick(rng,[0,0,0]);
  const x = mu + zInt*sd;
  return {
    q: `Scores are normal with \\(\\mu = ${mu}\\), \\(\\sigma = ${sd}\\). Find the z-score of \\(x = ${x}\\).`,
    a: `\\(z = ${zInt}\\)`,
    steps: [ `\\(z = \\dfrac{x - \\mu}{\\sigma} = \\dfrac{${x} - ${mu}}{${sd}} = ${zInt}\\).` ],
    traps: [
      {ans: `\\(z = ${-zInt}\\)`, why: 'z = (x − μ)/σ — x minus the mean. Reversing the subtraction flips the sign and the above/below-average meaning.'},
      {ans: `\\(z = ${x - mu}\\)`, why: 'Divide the deviation by σ — the z-score counts standard deviations, not raw points.'}
    ],
    vec: [unitIndex('S155_Normal'), 1, mu, sd, x, zInt],
    key: 's155_z_score'
  };
});
registerGen('S155_Normal', (rng)=>{
  // wide z grid per review: ~24 distinct answers, collision-safe for Quiz Mode
  const z100 = pick(rng,[-250,-200,-175,-150,-125,-110,-90,-80,-65,-50,-40,-30,-20,-15,15,20,30,40,50,65,80,90,110,125,150,175,200,250]);
  const z = z100/100;
  const mu = pick(rng,[100,200,60]), sd = pick(rng,[10,20,5]);
  const x = Math.round((mu + z*sd)*100)/100;
  const p = mwNormCdf(z);
  const pR = p.toFixed(4);
  return {
    q: `Heights are normal with \\(\\mu = ${mu}\\), \\(\\sigma = ${sd}\\). Find \\(P(X < ${x})\\). (4 decimals.)`,
    a: `\\(${pR}\\)`,
    steps: [
      `Standardize: \\(z = (${x} - ${mu})/${sd} = ${z}\\).`,
      `Left-tail probability from the normal table/calculator: \\(\\Phi(${z}) = ${pR}\\).`
    ],
    traps: [
      {ans: `\\(${(1-p).toFixed(4)}\\)`, why: 'That is the RIGHT tail P(X > x). "Less than" is the left tail — check which side of the curve the question shades.'},
      {ans: `\\(${Math.abs(z).toFixed(4)}\\)`, why: 'The z-score is the input, not the probability — convert it with the normal table.'}
    ],
    vec: [unitIndex('S155_Normal'), 2, mu, sd, z100],
    key: 's155_norm_left'
  };
});
registerGen('S155_Normal', (rng)=>{
  const pairs = [[-2,-1],[-2,1],[-1.5,1.5],[-1,2],[-1,1],[0.5,2],[-2.5,0],[1,2.5],[0,1.5],[-1.25,1.25]];
  const [za, zb] = pick(rng, pairs);
  const mu = pick(rng,[80,120,500]), sd = pick(rng,[8,10,25]);
  const a = mu + za*sd, b = mu + zb*sd;
  const p = mwNormInterval(za, zb);
  const pR = p.toFixed(4);
  return {
    q: `Weights are normal with \\(\\mu = ${mu}\\), \\(\\sigma = ${sd}\\). Find \\(P(${a} < X < ${b})\\). (4 decimals.)`,
    a: `\\(${pR}\\)`,
    steps: [
      `Standardize both: \\(z_1 = ${za}\\), \\(z_2 = ${zb}\\).`,
      `\\(P = \\Phi(${zb}) - \\Phi(${za}) = ${mwNormCdf(zb).toFixed(4)} - ${mwNormCdf(za).toFixed(4)} = ${pR}\\).`
    ],
    traps: [
      {ans: `\\(${(mwNormCdf(zb)+mwNormCdf(za)).toFixed(4)}\\)`, why: 'Between-probabilities SUBTRACT the two left tails — adding double-counts everything below the lower bound.'},
      {ans: `\\(${mwNormCdf(zb).toFixed(4)}\\)`, why: 'That is everything below the upper bound; the region below the LOWER bound must still be removed.'}
    ],
    vec: [unitIndex('S155_Normal'), 3, mu, sd, Math.round(za*100), Math.round(zb*100)],
    key: 's155_norm_between'
  };
});
registerGen('S155_Normal', (rng)=>{
  const kind = pick(rng,[0,1,2,3,4]);
  const mu = pick(rng,[100,60,500]), sd = pick(rng,[10,5,50]);
  const facts = [
    {q:`between \\(${mu-sd}\\) and \\(${mu+sd}\\)`, a:'About 68\\%', why1:'within 1 SD'},
    {q:`between \\(${mu-2*sd}\\) and \\(${mu+2*sd}\\)`, a:'About 95\\%', why1:'within 2 SD'},
    {q:`between \\(${mu-3*sd}\\) and \\(${mu+3*sd}\\)`, a:'About 99.7\\%', why1:'within 3 SD'},
    {q:`above \\(${mu+sd}\\)`, a:'About 16\\%', why1:'half of the 32% outside 1 SD'},
    {q:`below \\(${mu-2*sd}\\)`, a:'About 2.5\\%', why1:'half of the 5% outside 2 SD'}
  ];
  const f = facts[kind];
  const others = ['About 68\\%','About 95\\%','About 99.7\\%','About 16\\%','About 2.5\\%'].filter(s=>s!==f.a);
  return {
    q: `Scores are normal with \\(\\mu = ${mu}\\), \\(\\sigma = ${sd}\\). By the empirical rule, what percent of scores fall ${f.q}?`,
    a: f.a,
    steps: [
      `Empirical rule: 68\\% within 1 SD, 95\\% within 2, 99.7\\% within 3.`,
      `This region is ${f.why1}: ${f.a.toLowerCase()}.`
    ],
    traps: [
      {ans: others[0], why: 'Match the bounds to SD counts first: how many σ from μ is each endpoint?'},
      {ans: others[1], why: 'One-sided tails take HALF the outside percentage — symmetry splits it evenly.'}
    ],
    vec: [unitIndex('S155_Normal'), 4, kind, mu, sd],
    key: 's155_empirical'
  };
});
registerGen('S155_Correlation', (rng)=>{
  const rv = pick(rng,[-95,-85,-60,-30,-10,10,30,60,85,95]);
  const r = rv/100;
  const strength = Math.abs(rv) >= 80 ? 'strong' : Math.abs(rv) >= 50 ? 'moderate' : 'weak';
  const dir = rv > 0 ? 'positive' : 'negative';
  const label = `${strength.charAt(0).toUpperCase()+strength.slice(1)} ${dir} linear relationship`;
  const wrongDir = `${strength.charAt(0).toUpperCase()+strength.slice(1)} ${rv>0?'negative':'positive'} linear relationship`;
  const wrongStr = `${strength==='strong'?'Weak':'Strong'} ${dir} linear relationship`;
  return {
    q: `A study reports a correlation of \\(r = ${r}\\). Interpret it.`,
    a: label,
    steps: [
      `Sign gives direction: ${rv>0?'positive (rise together)':'negative (one rises as the other falls)'}.`,
      `Magnitude gives strength: \\(|r| = ${Math.abs(r)}\\) is ${strength} (near 1 = strong, near 0 = weak).`
    ],
    traps: [
      {ans: wrongDir, why: 'The SIGN of r carries the direction — negative r means the variables move oppositely.'},
      {ans: wrongStr, why: 'Strength comes from |r|: ' + Math.abs(r) + ' is ' + strength + '. The sign says nothing about strength.'}
    ],
    vec: [unitIndex('S155_Correlation'), 1, rv],
    key: 's155_r_interpret'
  };
});
registerGen('S155_Correlation', (rng)=>{
  const i = pick(rng,[0,1]);
  const scen = [
    {s:'Shoe size and reading level are strongly correlated among children.', conf:'Age drives both — older children have bigger feet AND read better'},
    {s:'Sunscreen sales and drowning deaths are strongly correlated.', conf:'Hot weather drives both — more swimming and more sunscreen'}
  ][i];
  return {
    q: `${scen.s} What is the best conclusion?`,
    a: `Correlation does not imply causation: ${scen.conf.toLowerCase()}`,
    steps: [
      `A strong r shows association, not cause.`,
      `A lurking variable (${scen.conf.split(' ')[0].toLowerCase()}) plausibly drives both measured variables.`,
      `Only a controlled, randomized experiment can establish causation.`
    ],
    traps: [
      {ans: i===0 ? 'Bigger feet cause better reading' : 'Sunscreen causes drowning', why: 'Association is not causation — check for a third variable driving both before drawing causal arrows.'},
      {ans: 'The correlation must be a calculation error', why: 'The correlation is real; the CAUSAL interpretation is what fails. Real associations often come from lurking variables.'}
    ],
    vec: [unitIndex('S155_Correlation'), 2, i],
    key: 's155_causation'
  };
});
registerGen('S155_Inference', (rng)=>{
  const xbar = pick(rng,[50,72,120]), sigma = pick(rng,[10,15,20]);
  const n = pick(rng,[25,100]);
  const se = sigma/Math.sqrt(n);
  const moe = Math.round(1.96*se*100)/100;
  const lo = Math.round((xbar-moe)*100)/100, hi = Math.round((xbar+moe)*100)/100;
  return {
    q: `A sample of \\(n = ${n}\\) gives \\(\\bar{x} = ${xbar}\\) with known \\(\\sigma = ${sigma}\\). Build a 95\\% confidence interval for \\(\\mu\\) (use \\(z^* = 1.96\\)).`,
    a: `\\((${lo},\\ ${hi})\\)`,
    steps: [
      `Standard error: \\(\\sigma/\\sqrt{n} = ${sigma}/${Math.sqrt(n)} = ${se}\\).`,
      `Margin of error: \\(1.96 \\times ${se} = ${moe}\\).`,
      `Interval: \\(${xbar} \\pm ${moe} = (${lo},\\ ${hi})\\).`
    ],
    traps: [
      {ans: `\\((${Math.round((xbar-1.96*sigma)*100)/100},\\ ${Math.round((xbar+1.96*sigma)*100)/100})\\)`, why: 'The margin uses the standard error σ/√n, not σ itself — larger samples give tighter intervals.'},
      {ans: `\\((${xbar - Math.round(se*100)/100},\\ ${xbar + Math.round(se*100)/100})\\)`, why: 'Multiply the SE by the critical value 1.96 — one SE alone is only a ~68% interval.'}
    ],
    vec: [unitIndex('S155_Inference'), 1, xbar, sigma, n],
    key: 's155_ci_compute'
  };
});
registerGen('S155_Inference', (rng)=>{
  const lvl = pick(rng,[90,95,99]);
  const lo = pick(rng,[48,62]), hi = lo + pick(rng,[4,6]);
  return {
    q: `A ${lvl}\\% confidence interval for the mean is \\((${lo}, ${hi})\\). What does "${lvl}\\% confident" mean?`,
    a: `The method captures the true mean in ${lvl}\\% of samples; we are confident this interval is one of those`,
    steps: [
      `Confidence describes the METHOD long-run success rate, not this one interval.`,
      `The true \\(\\mu\\) is fixed — it is either in \\((${lo}, ${hi})\\) or not; the 95\\% is about how often intervals built this way succeed.`
    ],
    traps: [
      {ans: `${lvl}\\% of the data values fall between ${lo} and ${hi}`, why: 'The CI estimates the MEAN, not the spread of individual data — most data can lie outside a tight interval for μ.'},
      {ans: `There is a ${lvl}\\% probability that \\(\\mu\\) moves into this interval`, why: 'μ is a fixed number, not a random one — the randomness is in the sampling, hence in the interval, not in μ.'}
    ],
    vec: [unitIndex('S155_Inference'), 2, lo, hi],
    key: 's155_ci_meaning'
  };
});
registerGen('S155_Inference', (rng)=>{
  const pv = pick(rng,[3,12,45])/1000 * pick(rng,[1,10]);
  const pR = pv.toFixed(3);
  const small = pv < 0.05;
  return {
    q: `A hypothesis test gives \\(p = ${pR}\\). What does this p-value mean?`,
    a: `If \\(H_0\\) were true, data this extreme would occur about ${(pv*100).toFixed(1)}\\% of the time${small ? ' — strong evidence against H₀ at α = 0.05' : ' — not unusual, so H₀ is not rejected at α = 0.05'}`,
    steps: [
      `The p-value is a conditional probability: P(data this extreme | H₀ true).`,
      `${small ? 'Small p → the data are surprising under H₀ → evidence against it.' : 'Large p → the data are unsurprising under H₀ → no evidence against it.'}`
    ],
    traps: [
      {ans: `There is a ${(pv*100).toFixed(1)}\\% chance that \\(H_0\\) is true`, why: 'The p-value conditions ON H₀ being true — it is not the probability OF H₀. That reversal is the most common p-value error.'},
      {ans: `The result is ${small ? '' : 'not '}practically important`, why: 'Statistical significance measures surprise, not size — a tiny, unimportant effect can produce a small p with a big sample.'}
    ],
    vec: [unitIndex('S155_Inference'), 3, Math.round(pv*1000)],
    key: 's155_pvalue_meaning'
  };
});
