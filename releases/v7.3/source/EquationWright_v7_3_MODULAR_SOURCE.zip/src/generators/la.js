// LA generator registrations — order frozen by the published registry.
registerGen('LA_MatrixAlg', (rng)=>{
  const A = [[mwNZ(rng,-3,3),mwNZ(rng,-3,3)],[mwNZ(rng,-3,3),mwNZ(rng,-3,3)]];
  const B = [[mwNZ(rng,-3,3),mwNZ(rng,-3,3)],[mwNZ(rng,-3,3),mwNZ(rng,-3,3)]];
  const kf = pick(rng,[2,3]);
  const R = A.map((r,i)=> r.map((v,j)=> v + kf*B[i][j]));
  const wrong = A.map((r,i)=> r.map((v,j)=> kf*(v + B[i][j])));
  return {
    q: `Compute \\(A + ${kf}B\\) where \\(A = ${laMtx(A)}\\) and \\(B = ${laMtx(B)}\\).`,
    a: `\\(${laMtx(R)}\\)`,
    steps: [
      `Scale B first: \\(${kf}B = ${laMtx(B.map(r=>r.map(v=>kf*v)))}\\).`,
      `Add entrywise: \\(${laMtx(R)}\\).`
    ],
    traps: [
      {ans: `\\(${laMtx(wrong)}\\)`, why: 'The scalar multiplies ONLY B — that answer computed k(A+B).'},
      {ans: `\\(${laMtx(A.map((r,i)=>r.map((v,j)=>v+B[i][j])))}\\)`, why: 'B must be scaled by ' + kf + ' before adding.'}
    ],
    vec: [unitIndex('LA_MatrixAlg'), 1, kf, ...A.flat(), ...B.flat()],
    key: 'la_mat_addscale'
  };
});
registerGen('LA_MatrixAlg', (rng)=>{
  const A = [[mwNZ(rng,1,3),mwNZ(rng,-2,2)],[mwNZ(rng,-2,2),mwNZ(rng,1,3)]];
  const B = [[mwNZ(rng,1,3),mwNZ(rng,-2,2)],[mwNZ(rng,-2,2),mwNZ(rng,1,3)]];
  const P = [[A[0][0]*B[0][0]+A[0][1]*B[1][0], A[0][0]*B[0][1]+A[0][1]*B[1][1]],
             [A[1][0]*B[0][0]+A[1][1]*B[1][0], A[1][0]*B[0][1]+A[1][1]*B[1][1]]];
  const wrongEntry = A.map((r,i)=> r.map((v,j)=> v*B[i][j]));
  return {
    q: `Compute the product \\(AB\\) where \\(A = ${laMtx(A)}\\) and \\(B = ${laMtx(B)}\\).`,
    a: `\\(${laMtx(P)}\\)`,
    steps: [
      `Entry \\((i,j)\\) = (row \\(i\\) of A) · (column \\(j\\) of B).`,
      `Top-left: \\((${A[0][0]})(${B[0][0]}) + (${A[0][1]})(${B[1][0]}) = ${P[0][0]}\\); repeat for all four entries.`
    ],
    traps: [
      {ans: `\\(${laMtx(wrongEntry)}\\)`, why: 'Matrix multiplication is row·column dot products, NOT entrywise multiplication.'},
      {ans: `\\(${laMtx([[P[0][0],P[1][0]],[P[0][1],P[1][1]]])}\\)`, why: 'Rows of A pair with COLUMNS of B — that answer transposed the pairing (computed BA-style).'}
    ],
    vec: [unitIndex('LA_MatrixAlg'), 2, ...A.flat(), ...B.flat()],
    key: 'la_mat_multiply'
  };
});
registerGen('LA_MatrixAlg', (rng)=>{
  const A = [[mwNZ(rng,-4,4),mwNZ(rng,-4,4),mwNZ(rng,-4,4)],[mwNZ(rng,-4,4),mwNZ(rng,-4,4),mwNZ(rng,-4,4)]];
  const T = [[A[0][0],A[1][0]],[A[0][1],A[1][1]],[A[0][2],A[1][2]]];
  return {
    q: `Find \\(A^T\\) for \\(A = ${laMtx(A)}\\).`,
    a: `\\(${laMtx(T)}\\)`,
    steps: [
      `Transpose swaps rows and columns: a 2×3 becomes 3×2.`,
      `Row 1 of A becomes column 1 of \\(A^T\\).`
    ],
    traps: [
      {ans: `\\(${laMtx([[A[0][2],A[0][1],A[0][0]],[A[1][2],A[1][1],A[1][0]]])}\\)`, why: 'Transposing is not reversing each row — entry (i,j) moves to (j,i), changing the SHAPE from 2×3 to 3×2.'},
      {ans: `\\(${laMtx(A)}\\)`, why: 'Only symmetric matrices equal their transpose — this one is not even square.'}
    ],
    vec: [unitIndex('LA_MatrixAlg'), 3, ...A.flat()],
    key: 'la_mat_transpose'
  };
});
registerGen('LA_MatrixAlg', (rng)=>{
  const b = mwNZ(rng,1,3), c = mwNZ(rng,1,3);
  const A = [[1,b],[c,1+b*c]];                              // det = 1
  const Inv = [[1+b*c,-b],[-c,1]];
  return {
    q: `Find \\(A^{-1}\\) for \\(A = ${laMtx(A)}\\).`,
    a: `\\(${laMtx(Inv)}\\)`,
    steps: [
      `\\(\\det A = (1)(${1+b*c}) - (${b})(${c}) = 1\\).`,
      `For 2×2: \\(A^{-1} = \\frac{1}{\\det A}${laMtx([['d','-b'],['-c','a']])}\\) — swap the diagonal, negate the off-diagonal.`,
      `With \\(\\det = 1\\): \\(A^{-1} = ${laMtx(Inv)}\\). Check: \\(AA^{-1} = I\\). ✓`
    ],
    traps: [
      {ans: `\\(${laMtx([[1,-b],[-c,1+b*c]])}\\)`, why: 'The DIAGONAL entries swap places; only the off-diagonal entries get negated.'},
      {ans: `\\(${laMtx([[1+b*c,b],[c,1]])}\\)`, why: 'Swapping the diagonal is half the formula — the off-diagonal entries must also change sign.'}
    ],
    vec: [unitIndex('LA_MatrixAlg'), 4, b, c],
    key: 'la_mat_inverse2'
  };
});
registerGen('LA_MatrixAlg', (rng)=>{
  const a = mwNZ(rng,-4,4), b = mwNZ(rng,-4,4), c = mwNZ(rng,-4,4), d = mwNZ(rng,-4,4);
  const det = a*d - b*c;
  return {
    q: `Compute \\(\\det${laMtx([[a,b],[c,d]])}\\).`,
    a: `\\(${det}\\)`,
    steps: [ `\\(\\det = ad - bc = (${a})(${d}) - (${b})(${c}) = ${a*d} - ${b*c >= 0 ? b*c : '('+(b*c)+')'} = ${det}\\).` ],
    traps: [
      {ans: `\\(${a*d + b*c}\\)`, why: 'The formula SUBTRACTS bc: ad − bc. The minus sign is the whole point.'},
      {ans: `\\(${a*b - c*d}\\)`, why: 'Multiply along the DIAGONALS (a·d and b·c), not along the rows.'}
    ],
    vec: [unitIndex('LA_MatrixAlg'), 5, a, b, c, d, det],
    key: 'la_det2'
  };
});
registerGen('LA_MatrixAlg', (rng)=>{
  const a = mwNZ(rng,1,3), cc = mwNZ(rng,-3,3), e = mwNZ(rng,-3,3), g = mwNZ(rng,1,3), d = mwNZ(rng,2,4);
  const M = [[a, mwNZ(rng,-3,3), cc],[0, d, 0],[e, mwNZ(rng,-3,3), g]];
  const det = d*(a*g - cc*e);
  return {
    q: `Compute \\(\\det${laMtx(M)}\\) by cofactor expansion along the second row.`,
    a: `\\(${det}\\)`,
    steps: [
      `Row 2 has only one nonzero entry (\\(${d}\\)), so one cofactor survives.`,
      `Position (2,2) has sign \\((+)\\): \\(\\det = ${d}\\cdot\\det${laMtx([[a,cc],[e,g]])}\\).`,
      `\\(= ${d}\\,(${a}\\cdot${g} - ${cc}\\cdot${e}) = ${det}\\).`
    ],
    traps: [
      {ans: `\\(${-det}\\)`, why: 'The (2,2) cofactor sign is (−1)^{2+2} = +. The checkerboard starts with + at (1,1).'},
      {ans: `\\(${d*(a*g + cc*e)}\\)`, why: 'The 2×2 minor still uses ad − bc, with the subtraction.'}
    ],
    vec: [unitIndex('LA_MatrixAlg'), 6, a, cc, e, g, d, det],
    key: 'la_det3_cofactor'
  };
});
registerGen('LA_MatrixAlg', (rng)=>{
  const d0 = mwNZ(rng,-5,5), kf = pick(rng,[2,3]);
  const ans = kf*kf*d0;
  return {
    q: `A is a \\(2\\times 2\\) matrix with \\(\\det A = ${d0}\\). Find \\(\\det(${kf}A)\\).`,
    a: `\\(${ans}\\)`,
    steps: [
      `Scaling an \\(n\\times n\\) matrix scales the determinant by \\(k^n\\): every ROW gets multiplied.`,
      `Here \\(n = 2\\): \\(\\det(${kf}A) = ${kf}^2\\det A = ${kf*kf}\\cdot${d0} = ${ans}\\).`
    ],
    traps: [
      {ans: `\\(${kf*d0}\\)`, why: 'kA multiplies BOTH rows by k, and each row multiplication scales det by k — so k² total for 2×2.'},
      {ans: `\\(${d0}\\)`, why: 'Determinants are not scale-invariant — only row REPLACEMENT operations leave det unchanged.'}
    ],
    vec: [unitIndex('LA_MatrixAlg'), 7, d0, kf, ans],
    key: 'la_det_scale'
  };
});
registerGen('LA_Eigen', (rng)=>{
  const l1 = mwNZ(rng,1,3), gap = pick(rng,[2,3]);
  const l2 = l1 + gap;
  const c = gap - 1;                                        // construction: det = l1*l2, trace = l1+l2
  const A = [[l1+1, 1],[c, l2-1]];
  return {
    q: `Find the eigenvalues of \\(A = ${laMtx(A)}\\).`,
    a: `\\(\\lambda = ${l1}\\) and \\(\\lambda = ${l2}\\)`,
    steps: [
      `Characteristic equation: \\(\\lambda^2 - (\\text{tr}A)\\lambda + \\det A = 0\\).`,
      `\\(\\text{tr}A = ${l1+l2}\\), \\(\\det A = ${(l1+1)*(l2-1) - c} \\Rightarrow \\lambda^2 - ${l1+l2}\\lambda + ${l1*l2} = 0\\).`,
      `Factor: \\((\\lambda - ${l1})(\\lambda - ${l2}) = 0\\).`
    ],
    traps: [
      {ans: `\\(\\lambda = ${l1+1}\\) and \\(\\lambda = ${l2-1}\\)`, why: 'The diagonal entries are only the eigenvalues for TRIANGULAR matrices — this one has a nonzero below the diagonal.'},
      {ans: `\\(\\lambda = ${-l1}\\) and \\(\\lambda = ${-l2}\\)`, why: 'The characteristic polynomial is λ² − (trace)λ + det; sign slips flip the roots.'}
    ],
    vec: [unitIndex('LA_Eigen'), 1, l1, l2, c],
    key: 'la_eigen_values'
  };
});
registerGen('LA_Eigen', (rng)=>{
  const l1 = mwNZ(rng,1,3), gap = pick(rng,[2,3,4]);
  const l2 = l1 + gap, kk = mwNZ(rng,1,3);
  const A = [[l1, kk],[0, l2]];
  const v = [kk, gap];                                      // eigenvector for l2: (k, l2-l1)
  return {
    q: `For \\(A = ${laMtx(A)}\\), find an eigenvector for \\(\\lambda = ${l2}\\).`,
    a: `\\(${laMtx([[v[0]],[v[1]]])}\\) (or any nonzero multiple)`,
    steps: [
      `Solve \\((A - ${l2}I)\\mathbf{v} = 0\\): \\(A - ${l2}I = ${laMtx([[l1-l2,kk],[0,0]])}\\).`,
      `Row 1: \\(${l1-l2}x + ${kk}y = 0 \\Rightarrow \\mathbf{v} = (${v[0]},\\ ${v[1]})\\) works.`,
      `Check: \\(A\\mathbf{v} = ${l2}\\mathbf{v}\\). ✓`
    ],
    traps: [
      {ans: `\\(${laMtx([[1],[0]])}\\)`, why: 'That is the eigenvector for λ = ' + l1 + ' (the other eigenvalue) — each eigenvalue has its own eigenvector direction.'},
      {ans: `\\(${laMtx([[0],[0]])}\\)`, why: 'The zero vector is excluded by definition — eigenvectors must be nonzero.'}
    ],
    vec: [unitIndex('LA_Eigen'), 2, l1, l2, kk],
    key: 'la_eigen_vector'
  };
});
registerGen('LA_Eigen', (rng)=>{
  const a = mwNZ(rng,1,4), b = mwNZ(rng,-3,3), c = mwNZ(rng,-3,3), d = mwNZ(rng,1,4);
  const T = a+d, D = a*d-b*c;
  return {
    q: `Write the characteristic polynomial of \\(A = ${laMtx([[a,b],[c,d]])}\\).`,
    a: `\\(\\lambda^2 - ${T}\\lambda ${D<0?'-':'+'} ${Math.abs(D)}\\)`,
    steps: [
      `\\(p(\\lambda) = \\det(A - \\lambda I) = \\lambda^2 - (\\text{tr}A)\\lambda + \\det A\\).`,
      `Trace \\(= ${a}+${d} = ${T}\\); determinant \\(= ${a}\\cdot${d} - (${b})(${c}) = ${D}\\).`
    ],
    traps: [
      {ans: `\\(\\lambda^2 + ${T}\\lambda ${D<0?'-':'+'} ${Math.abs(D)}\\)`, why: 'The trace term carries a MINUS sign: λ² − (tr)λ + det.'},
      {ans: `\\(\\lambda^2 - ${T}\\lambda ${D<0?'+':'-'} ${Math.abs(D)}\\)`, why: 'The constant term is det A = ad − bc, sign included.'}
    ],
    vec: [unitIndex('LA_Eigen'), 3, a, b, c, d],
    key: 'la_eigen_charpoly'
  };
});
registerGen('LA_Eigen', (rng)=>{
  const dep = pick(rng,[true,false]);
  const v1 = [mwNZ(rng,1,3), mwNZ(rng,-3,3)];
  const kf = pick(rng,[2,3,-2]);
  const v2 = dep ? [kf*v1[0], kf*v1[1]] : [v1[0]+1, v1[1] + (v1[1]>=0? 2 : -2) + 1];
  const det = v1[0]*v2[1] - v1[1]*v2[0];
  const label = dep ? 'Linearly dependent' : 'Linearly independent';
  return {
    q: `Are \\(\\mathbf{v}_1 = (${v1.join(',\\ ')})\\) and \\(\\mathbf{v}_2 = (${v2.join(',\\ ')})\\) linearly independent?`,
    a: label,
    steps: [
      `Two vectors in \\(\\mathbb{R}^2\\) are dependent exactly when one is a multiple of the other — equivalently \\(\\det${laMtx([[v1[0],v2[0]],[v1[1],v2[1]]])} = 0\\).`,
      `Determinant \\(= ${det}\\) — ${dep ? 'zero: dependent (\\(\\mathbf{v}_2 = '+kf+'\\mathbf{v}_1\\)).' : 'nonzero: independent.'}`
    ],
    traps: [
      {ans: dep ? 'Linearly independent' : 'Linearly dependent', why: 'Test with the determinant (or look for a scalar multiple): zero ⇒ dependent, nonzero ⇒ independent.'},
      {ans: 'Cannot be determined without a third vector', why: 'Independence of TWO vectors is decidable on its own — a multiple relationship either exists or it does not.'}
    ],
    vec: [unitIndex('LA_Eigen'), 4, dep?1:0, v1[0], v1[1], v2[0], v2[1]],
    key: 'la_indep_check'
  };
});
registerGen('LA_Eigen', (rng)=>{
  const kind = pick(rng,[1,2,3]);
  const a = mwNZ(rng,1,3), b = mwNZ(rng,1,3);
  let vecs, dim, why;
  if(kind===1){ vecs = [[1,0,a],[2,0,2*a],[3,0,3*a]]; dim = 1; why = 'all three are multiples of the first — one direction'; }
  else if(kind===2){ vecs = [[1,0,a],[0,1,b],[1,1,a+b]]; dim = 2; why = 'the third is v₁ + v₂, so only two are independent'; }
  else { vecs = [[1,0,0],[0,1,b],[0,0,1]]; dim = 3; why = 'no vector is a combination of the others (triangular pattern — three pivots)'; }
  return {
    q: `Find the dimension of \\(\\text{span}\\{(${vecs[0].join(',')}),\\ (${vecs[1].join(',')}),\\ (${vecs[2].join(',')})\\}\\) in \\(\\mathbb{R}^3\\).`,
    a: `\\(${dim}\\)`,
    steps: [
      `Dimension of the span = number of linearly independent vectors (the rank).`,
      `Here ${why}.`,
      `Dimension \\(= ${dim}\\).`
    ],
    traps: [
      {ans: `\\(3\\)` === `\\(${dim}\\)` ? `\\(2\\)` : `\\(3\\)`, why: 'Three vectors do not guarantee dimension 3 — dependent vectors add no new directions. Row reduce and count pivots.'},
      {ans: `\\(${dim===1?2:dim-1}\\)` === `\\(${dim}\\)` ? `\\(1\\)` : `\\(${dim===1?2:dim-1}\\)`, why: 'Count ALL independent vectors — check each against combinations of the previous ones.'}
    ],
    vec: [unitIndex('LA_Eigen'), 5, kind, a, b],
    key: 'la_span_dim'
  };
});
registerGen('LA_Eigen', (rng)=>{
  const l1 = mwNZ(rng,-3,4) || 2, l2 = mwNZ(rng,1,5);
  return {
    q: `A \\(2\\times 2\\) matrix has eigenvalues \\(\\lambda_1 = ${l1}\\) and \\(\\lambda_2 = ${l2}\\). Find \\(\\det A\\) and \\(\\text{tr}\\,A\\).`,
    a: `\\(\\det A = ${l1*l2}\\), \\(\\text{tr}\\,A = ${l1+l2}\\)`,
    steps: [
      `The determinant is the PRODUCT of the eigenvalues: \\(${l1}\\cdot${l2} = ${l1*l2}\\).`,
      `The trace is their SUM: \\(${l1}+${l2} = ${l1+l2}\\).`
    ],
    traps: [
      {ans: `\\(\\det A = ${l1+l2}\\), \\(\\text{tr}\\,A = ${l1*l2}\\)`, why: 'Swapped: det = product, trace = sum — they are the constant and (negated) linear coefficients of the characteristic polynomial.'},
      {ans: `Cannot be found without the matrix itself`, why: 'det and trace are determined BY the eigenvalues — that is exactly what the characteristic polynomial encodes.'}
    ],
    vec: [unitIndex('LA_Eigen'), 6, l1, l2],
    key: 'la_eigen_tracedet'
  };
});
registerGen('LA_Systems', (rng)=>{
  const x0 = mwNZ(rng,-4,4), y0 = mwNZ(rng,-4,4);
  let a1 = mwNZ(rng,1,3), b1 = mwNZ(rng,-3,3), a2 = mwNZ(rng,-3,3), b2 = mwNZ(rng,1,3);
  if(a1*b2 - a2*b1 === 0) a1 += 1;
  const c1 = a1*x0 + b1*y0, c2 = a2*x0 + b2*y0;
  return {
    q: `Solve the system: \\(\\begin{cases}${laEqTex(a1,b1,c1)}\\\\ ${laEqTex(a2,b2,c2)}\\end{cases}\\)`,
    a: `\\((x,\\,y) = (${x0},\\ ${y0})\\)`,
    steps: [
      `Eliminate one variable: multiply the equations so the \\(x\\) (or \\(y\\)) coefficients match, then subtract.`,
      `Solving gives \\(y = ${y0}\\); substitute back to get \\(x = ${x0}\\).`,
      `Check in BOTH original equations: \\(${a1}(${x0}) ${b1<0?'-':'+'} ${Math.abs(b1)}(${y0}) = ${c1}\\) ✓`
    ],
    traps: [
      {ans: `\\((x,\\,y) = (${y0},\\ ${x0})\\)`, why: 'Variables swapped — state the answer in the same (x, y) order as the system.'},
      {ans: `\\((x,\\,y) = (${-x0},\\ ${-y0})\\)`, why: 'Sign error during elimination — subtracting equations flips every sign of the second equation, not just one term.'}
    ],
    vec: [unitIndex('LA_Systems'), 1, x0, y0, a1, b1, a2, b2],
    key: 'la_sys_solve2'
  };
});
registerGen('LA_Systems', (rng)=>{
  const x0 = mwNZ(rng,-3,3), y0 = mwNZ(rng,-3,3), z0 = mwNZ(rng,-3,3);
  const b1 = pick(rng,[1,2]), c1 = pick(rng,[1,2]), c2 = pick(rng,[1,2]);
  // Upper-triangular construction (all-positive helpers -> no zero coefficients after disguise).
  const r1 = [1, b1, c1,  x0 + b1*y0 + c1*z0];
  const r2 = [0, 1,  c2,  y0 + c2*z0];
  const r3 = [0, 0,  1,   z0];
  // Disguise: add r2 to r1 and r3 to r2 so it isn't already triangular.
  const R1 = r1.map((v,i)=> v + r2[i]);
  const R2 = r2.map((v,i)=> v + r3[i]);
  const eq = (r)=>{
    const names = ['x','y','z'];
    let s = '';
    for(let i=0; i<3; i++){
      const v = r[i];
      if(v === 0) continue;
      const mag = Math.abs(v) === 1 ? '' : String(Math.abs(v));
      s += s === '' ? (v < 0 ? '-' : '') + mag + names[i]
                    : ' ' + (v < 0 ? '-' : '+') + ' ' + mag + names[i];
    }
    return s + ' = ' + r[3];
  };
  return {
    q: `Solve the system: \\(\\begin{cases}${eq(R1)}\\\\ ${eq(R2)}\\\\ ${eq(r3)}\\end{cases}\\)`,
    a: `\\((x,\\,y,\\,z) = (${x0},\\ ${y0},\\ ${z0})\\)`,
    steps: [
      `Use row reduction: subtract rows to reach triangular form.`,
      `The last equation gives \\(z=${z0}\\); back-substitute upward.`,
      `Then \\(y=${y0}\\) and finally \\(x=${x0}\\).`
    ],
    traps: [
      {ans: `\\((x,\\,y,\\,z) = (${x0},\\ ${z0},\\ ${y0})\\)`, why: 'y and z swapped during back-substitution — label each value as you find it.'},
      {ans: `\\((x,\\,y,\\,z) = (${-x0},\\ ${y0},\\ ${z0})\\)`, why: 'Sign slip in the final back-substitution for x — move every known term across with its sign flipped.'}
    ],
    vec: [unitIndex('LA_Systems'), 2, x0, y0, z0, b1, c1, c2],
    key: 'la_sys_solve3'
  };
});
registerGen('LA_SolutionSets', (rng)=>{
  const kind = pick(rng, ['unique','none','infinite']);
  const a = mwNZ(rng,1,3), b = mwNZ(rng,-3,3) || 2, c = mwNZ(rng,-5,5), k = pick(rng,[2,3]);
  let r2, whyCore;
  if(kind==='unique'){ r2 = [a+1, b - (b===1?2:1), mwNZ(rng,-5,5)]; whyCore = 'the left sides are NOT proportional, so the lines cross exactly once'; }
  else if(kind==='none'){ r2 = [k*a, k*b, k*c + mwNZ(rng,1,3)]; whyCore = `the left side of row 2 is \\(${k}\\times\\) row 1 but the right side is not — parallel lines, no intersection`; }
  else { r2 = [k*a, k*b, k*c]; whyCore = `row 2 is exactly \\(${k}\\times\\) row 1 — the same line twice`; }
  const label = kind==='unique' ? 'Exactly one solution' : kind==='none' ? 'No solution' : 'Infinitely many solutions';
  const others = ['Exactly one solution','No solution','Infinitely many solutions'].filter(s=>s!==label);
  return {
    q: `How many solutions does this system have? \\(\\begin{cases}${laEqTex(a,b,c)}\\\\ ${laEqTex(r2[0],r2[1],r2[2])}\\end{cases}\\)`,
    a: label,
    steps: [
      `Compare the rows: is one left side a multiple of the other?`,
      `Here ${whyCore}.`,
      `Conclusion: ${label.toLowerCase()}.`
    ],
    traps: [
      {ans: others[0], why: 'Test proportionality of the FULL rows: left sides AND right side. Proportional left + matching right = infinite; proportional left + mismatched right = none; non-proportional left = unique.'},
      {ans: others[1], why: 'Check whether the constant column follows the same multiple as the coefficients.'}
    ],
    vec: [unitIndex('LA_SolutionSets'), 3, kind==='unique'?0:kind==='none'?1:2, a, b, c, k],
    key: 'la_sys_classify'
  };
});
registerGen('LA_SolutionSets', (rng)=>{
  const a = mwNZ(rng,1,3), b = mwNZ(rng,-3,3) || 2, c = mwNZ(rng,-4,4), k = pick(rng,[2,3,-2]);
  const h = k*c;
  return {
    q: `For what value of \\(h\\) does the system have infinitely many solutions? \\(\\begin{cases}${laEqTex(a,b,c)}\\\\ ${laEqTex(k*a,k*b,0)}\\end{cases}\\) — where the second right-hand side is \\(h\\) instead of \\(0\\).`,
    a: `\\(h = ${h}\\)`,
    steps: [
      `The second row's left side is \\(${k}\\times\\) the first row's.`,
      `For the rows to be the same equation (infinitely many solutions), the right side must scale the same way: \\(h = ${k}\\cdot${c} = ${h}\\).`,
      `Any other \\(h\\) makes the system inconsistent (no solution).`
    ],
    traps: [
      {ans: `\\(h = ${c}\\)`, why: 'h must be k times the first right-hand side, not equal to it — the whole row scales.'},
      {ans: `\\(h = ${-h}\\)`, why: 'Watch the sign of the multiplier k when scaling the constant.'}
    ],
    vec: [unitIndex('LA_SolutionSets'), 4, a, b, c, k],
    key: 'la_sys_hvalue'
  };
});
registerGen('LA_RowRed', (rng)=>{
  const c = mwNZ(rng,-4,4), d = mwNZ(rng,-4,4);
  const good = laMtx([[1,0,c],[0,1,d],[0,0,0]]);
  const refNotRref = laMtx([[1, mwNZ(rng,1,3), c],[0,1,d],[0,0,0]]);        // nonzero above pivot
  const badPivot  = laMtx([[1,0,c],[0,pick(rng,[2,3]),d],[0,0,0]]);          // pivot not 1
  const badRow    = laMtx([[1,0,c],[0,0,0],[0,1,d]]);                        // zero row not at bottom
  return {
    q: `Which matrix is in reduced row echelon form (RREF)? \\(${good}\\)`,
    a: `\\(${good}\\)`,
    steps: [
      `RREF needs all four: leading entry of each nonzero row is 1; each leading 1 is the ONLY nonzero entry in its column; leading 1s move right as you go down; zero rows are at the bottom.`,
      `The correct matrix satisfies all four conditions.`
    ],
    traps: [
      {ans: `\\(${refNotRref}\\)`, why: 'That is REF but not RREF — there is a nonzero entry ABOVE a leading 1. RREF requires zeros above and below each pivot.'},
      {ans: `\\(${badPivot}\\)`, why: 'A leading entry other than 1 disqualifies RREF — pivots must be scaled to 1.'},
      {ans: `\\(${badRow}\\)`, why: 'A zero row sitting above a nonzero row violates echelon form — zero rows go last.'}
    ],
    vec: [unitIndex('LA_RowRed'), 5, c, d],
    key: 'la_rref_identify'
  };
});
registerGen('LA_RowRed', (rng)=>{
  const M = [[mwNZ(rng,1,3), mwNZ(rng,-3,3), mwNZ(rng,-5,5)],
             [mwNZ(rng,-3,3), mwNZ(rng,1,3), mwNZ(rng,-5,5)]];
  const k = pick(rng,[2,3,-2]);
  const newR2 = M[1].map((v,i)=> v + k*M[0][i]);
  const kTex = k<0 ? `- ${Math.abs(k)}` : `+ ${k}`;
  const wrongLast = [...newR2]; wrongLast[2] = M[1][2] + M[0][2];      // forgot k on constant
  const wrongSign = M[1].map((v,i)=> v - k*M[0][i]);
  return {
    q: `Given the augmented matrix \\(${laAug(M)}\\), perform \\(R_2 \\to R_2 ${kTex} R_1\\). What is the new second row?`,
    a: `\\(${laAug([newR2]).replace('\\left[','[').replace('\\right]',']')}\\)`,
    steps: [
      `Multiply row 1 by \\(${k}\\): \\((${M[0].map(v=>k*v).join(',\\ ')})\\).`,
      `Add it entry-by-entry to row 2 — INCLUDING the constant column.`,
      `New row 2: \\((${newR2.join(',\\ ')})\\).`
    ],
    traps: [
      {ans: `\\(${laAug([wrongLast]).replace('\\left[','[').replace('\\right]',']')}\\)`, why: 'The constant column gets multiplied by k too — the row operation applies to the ENTIRE row.'},
      {ans: `\\(${laAug([wrongSign]).replace('\\left[','[').replace('\\right]',']')}\\)`, why: 'Sign of k reversed — R2 + kR1 adds k copies; check whether the operation says + or −.'}
    ],
    vec: [unitIndex('LA_RowRed'), 6, k, M[0][0], M[0][1], M[0][2], M[1][0], M[1][1], M[1][2]],
    key: 'la_rowop_apply'
  };
});
registerGen('LA_RowRed', (rng)=>{
  const A = [[1, mwNZ(rng,-3,3), mwNZ(rng,-4,4)],
             [mwNZ(rng,2,3), mwNZ(rng,-3,3), mwNZ(rng,-4,4)]];
  const k = A[1][0]; // eliminate the leading entry of row 2
  const B = [A[0], A[1].map((v,i)=> v - k*A[0][i])];
  return {
    q: `What single row operation transforms \\(${laAug(A)}\\) into \\(${laAug(B)}\\)?`,
    a: `\\(R_2 \\to R_2 - ${k}R_1\\)`,
    steps: [
      `Row 1 is unchanged, so the operation acted on row 2.`,
      `The leading entry went from \\(${k}\\) to \\(0\\): we subtracted \\(${k}\\) copies of row 1.`,
      `Check another column to confirm the same multiple was used throughout.`
    ],
    traps: [
      {ans: `\\(R_2 \\to R_2 + ${k}R_1\\)`, why: 'Adding would make the leading entry grow, not vanish — check the sign by what happened to column 1.'},
      {ans: `\\(R_1 \\leftrightarrow R_2\\)`, why: 'A swap changes BOTH rows — row 1 is identical in both matrices, so no swap occurred.'}
    ],
    vec: [unitIndex('LA_RowRed'), 7, k, A[0][1], A[0][2], A[1][1], A[1][2]],
    key: 'la_rowop_identify'
  };
});
registerGen('LA_Systems', (rng)=>{
  const z0 = mwNZ(rng,-3,3), y0 = mwNZ(rng,-3,3), x0 = mwNZ(rng,-3,3);
  const b1 = mwNZ(rng,-2,2), c1 = mwNZ(rng,-2,2), c2 = mwNZ(rng,-2,2), d3 = pick(rng,[2,3]);
  const e1 = x0 + b1*y0 + c1*z0, e2 = y0 + c2*z0, e3 = d3*z0;
  return {
    q: `The row-reduced system is \\(\\begin{cases}x ${b1<0?'-':'+'} ${Math.abs(b1)}y ${c1<0?'-':'+'} ${Math.abs(c1)}z = ${e1}\\\\ y ${c2<0?'-':'+'} ${Math.abs(c2)}z = ${e2}\\\\ ${d3}z = ${e3}\\end{cases}\\). Solve by back-substitution.`,
    a: `\\((x,\\,y,\\,z) = (${x0},\\ ${y0},\\ ${z0})\\)`,
    steps: [
      `Bottom up: \\(z = ${e3}/${d3} = ${z0}\\).`,
      `Middle: \\(y = ${e2} ${c2<0?'+':'-'} ${Math.abs(c2)}(${z0}) = ${y0}\\).`,
      `Top: \\(x = ${e1} ${b1<0?'+':'-'} ${Math.abs(b1)}(${y0}) ${c1<0?'+':'-'} ${Math.abs(c1)}(${z0}) = ${x0}\\).`
    ],
    traps: [
      {ans: `\\((x,\\,y,\\,z) = (${e1},\\ ${e2},\\ ${z0})\\)`, why: 'The right-hand sides are not the answers — each variable still needs the known values substituted and moved across.'},
      {ans: `\\((x,\\,y,\\,z) = (${x0},\\ ${-y0},\\ ${z0})\\)`, why: 'Sign slip when moving a term across the equals sign during the middle substitution.'}
    ],
    vec: [unitIndex('LA_Systems'), 8, x0, y0, z0, b1, c1, c2, d3],
    key: 'la_backsub'
  };
});
registerGen('LA_SolutionSets', (rng)=>{
  const b = mwNZ(rng,1,3), c = mwNZ(rng,-4,4), k = pick(rng,[2,3]);
  return {
    q: `Solve, expressing the solution set with a free parameter: \\(\\begin{cases}x + ${b}y = ${c}\\\\ ${k}x + ${k*b}y = ${k*c}\\end{cases}\\)`,
    a: `\\((x,\\,y) = (${c} - ${b}t,\\ t),\\ t \\in \\mathbb{R}\\)`,
    steps: [
      `Row 2 is \\(${k}\\times\\) row 1 — only ONE independent equation, so one variable is free.`,
      `Let \\(y = t\\) (the free variable).`,
      `Then \\(x = ${c} - ${b}t\\): every choice of \\(t\\) gives a solution.`
    ],
    traps: [
      {ans: 'No solution', why: 'Proportional rows with MATCHING constants mean the same line twice — infinitely many solutions, not none. "No solution" needs mismatched constants.'},
      {ans: `\\((x,\\,y) = (${c},\\ 0)\\)`, why: 'That is one point on the solution line (t = 0), but the solution SET is the whole line — express it with the parameter.'}
    ],
    vec: [unitIndex('LA_SolutionSets'), 9, b, c, k],
    key: 'la_sys_param'
  };
});
registerGen('LA_SolutionSets', (rng)=>{
  const r = pick(rng,[1,2,3]);
  const a = mwNZ(rng,1,3), b = mwNZ(rng,-3,3), c = mwNZ(rng,-3,3), k = pick(rng,[2,3]);
  let M;
  if(r===1){ M = [[a,b,c],[k*a,k*b,k*c],[-a,-b,-c]]; }
  else if(r===2){ M = [[a,b,c],[0, mwNZ(rng,1,3), mwNZ(rng,-3,3)], [k*a, k*b, k*c]]; }
  else { M = [[1,b,c],[0,1,mwNZ(rng,-3,3)],[0,0,mwNZ(rng,1,3)]]; }
  return {
    q: `Find the rank of \\(${laMtx(M)}\\).`,
    a: `\\(${r}\\)`,
    steps: [
      `Row reduce and count the nonzero rows (equivalently, the pivots).`,
      r===1 ? `Every row is a multiple of the first — one independent row.` :
      r===2 ? `Row 3 is a multiple of row 1, so only two rows are independent.` :
              `Already triangular with three nonzero diagonal entries — three pivots.`,
      `Rank \\(= ${r}\\).`
    ],
    traps: [
      {ans: `\\(3\\)` === `\\(${r}\\)` ? `\\(2\\)` : `\\(3\\)`, why: 'Count pivots AFTER reducing — rows that look different can still be multiples of each other.'},
      {ans: `\\(${r===1?2:r-1}\\)` === `\\(${r}\\)` ? `\\(1\\)` : `\\(${r===1?2:r-1}\\)`, why: 'Do not stop reducing early; a row of zeros only appears once elimination is complete.'}
    ],
    vec: [unitIndex('LA_SolutionSets'), 10, r, a, b, c, k],
    key: 'la_rank_small'
  };
});
registerGen('LA_RowRed', (rng)=>{
  const kind = pick(rng, ['upper triangular','lower triangular','diagonal','symmetric','identity']);
  const a = mwNZ(rng,1,4), b = mwNZ(rng,1,4), c = mwNZ(rng,-3,3), d = mwNZ(rng,-3,3);
  let M;
  if(kind==='upper triangular') M = [[a,c,d],[0,b,c],[0,0,a]];
  else if(kind==='lower triangular') M = [[a,0,0],[c,b,0],[d,c,a]];
  else if(kind==='diagonal') M = [[a,0,0],[0,b,0],[0,0,-a]];
  else if(kind==='symmetric') M = [[a,c,d],[c,b,0],[d,0,a]];
  else M = [[1,0,0],[0,1,0],[0,0,1]];
  const label = kind.charAt(0).toUpperCase()+kind.slice(1);
  const others = ['Upper triangular','Lower triangular','Diagonal','Symmetric','Identity'].filter(s=>s!==label);
  return {
    q: `Classify the matrix \\(${laMtx(M)}\\) using the most specific term.`,
    a: label,
    steps: [
      `Check the zero pattern (above/below the diagonal) and whether \\(A = A^T\\).`,
      kind==='identity' ? `Ones on the diagonal, zeros elsewhere — the identity (which is also diagonal, but identity is more specific).` :
      kind==='diagonal' ? `Only diagonal entries are nonzero.` :
      kind==='symmetric' ? `Entry \\((i,j)\\) equals entry \\((j,i)\\) everywhere: \\(A = A^T\\).` :
      `All zeros ${kind==='upper triangular'?'below':'above'} the main diagonal.`
    ],
    traps: [
      {ans: others[0], why: 'Check WHICH side of the main diagonal holds the zeros, and test A = Aᵀ before choosing.'},
      {ans: others[1], why: 'Use the most specific correct term — e.g., the identity is diagonal, but "identity" says more.'}
    ],
    vec: [unitIndex('LA_RowRed'), 11, ['upper triangular','lower triangular','diagonal','symmetric','identity'].indexOf(kind), a, b, c, d],
    key: 'la_matrix_terms'
  };
});
registerGen('LA_Systems', (rng)=>{
  const adult = pick(rng,[8,10,12,15]), child = pick(rng,[4,5,6]);
  const a0 = mwNZ(rng,20,60), c0 = mwNZ(rng,30,90);
  const total = a0 + c0, revenue = adult*a0 + child*c0;
  return {
    q: `A theater sells adult tickets for \\$${adult} and child tickets for \\$${child}. It sold ${total} tickets for \\$${revenue} total. How many of each were sold?`,
    a: `${a0} adult and ${c0} child tickets`,
    steps: [
      `Let \\(a\\) = adult tickets, \\(c\\) = child tickets: \\(a + c = ${total}\\) and \\(${adult}a + ${child}c = ${revenue}\\).`,
      `From the first equation \\(c = ${total} - a\\); substitute into the second.`,
      `\\(${adult}a + ${child}(${total}-a) = ${revenue} \\Rightarrow a = ${a0}\\), so \\(c = ${c0}\\).`
    ],
    traps: [
      {ans: `${c0} adult and ${a0} child tickets`, why: 'Answer swapped — after solving, match each number back to its variable and its meaning.'},
      {ans: `${a0 + c0} adult and ${revenue - adult*(a0+c0) >= 0 ? revenue - adult*(a0+c0) : 0} child tickets`, why: 'The ticket-count equation and the money equation are different constraints — both must hold at once.'}
    ],
    vec: [unitIndex('LA_Systems'), 12, adult, child, a0, c0],
    key: 'la_sys_word'
  };
});
