// TRIG generator registrations — order frozen by the published registry.
registerGen('TRIG_Identities', (rng)=>{
  const R = pick(rng,[10,15,20,25]);
  const H = R + pick(rng,[2,5,10]);
  const T = pick(rng,[4,6,8,10]);
  const correct = `\\(h(t)=${H}-${R}\\cos\\left(\\frac{2\\pi}{${T}}t\\right)\\)`;
  return {
    q: `A Ferris wheel of radius \\(${R}\\) m has its center \\(${H}\\) m above the ground and makes one revolution every \\(${T}\\) minutes. A rider boards at the lowest point at \\(t=0\\). Which function models the rider's height?`,
    a: correct,
    steps: [
      `Midline = center height ${H}; amplitude = radius ${R}; period ${T} gives \\(B=\\frac{2\\pi}{${T}}\\).`,
      `Starting at the LOWEST point means the minimum at \\(t=0\\): use \\(-\\cos\\).`,
      `${correct}.`
    ],
    traps: [
      {ans:`\\(h(t)=${H}+${R}\\cos\\left(\\frac{2\\pi}{${T}}t\\right)\\)`, why:'+cos starts at the TOP. Boarding at the bottom needs −cos.'},
      {ans:`\\(h(t)=${H}+${R}\\sin\\left(\\frac{2\\pi}{${T}}t\\right)\\)`, why:'sin starts at the MIDLINE, not the lowest point.'},
      {ans:`\\(h(t)=${H}-${R}\\cos\\left(${T}t\\right)\\)`, why:'Period T means B = 2π/T inside the cosine.'}
    ],
    vec: [unitIndex('TRIG_Identities'), 20, R, H, T],
    key: 'trig_sinusoid_model'
  };
});
registerGen('TRIG_Identities', (rng)=>{
  const A = pick(rng,[1,2,3]);
  const B = pick(rng,[1,2]);
  const useSin = pick(rng,[true,false]);
  const fn = x => A * (useSin ? Math.sin(B*x) : Math.cos(B*x));
  const name = useSin ? '\\sin' : '\\cos';
  const other = useSin ? '\\cos' : '\\sin';
  const bT = B===1?'x':`${B}x`;
  const correct = `\\(y=${A===1?'':A}${name}(${bT})\\)`;
  return {
    q: `Which function matches this graph? (gridlines every 1 unit; one period fits in about \\(${B===1?'6.3':'3.1'}\\) units)<br><br>${svgFnPlot(fn)}`,
    a: correct,
    steps: [
      `At \\(x=0\\) the curve is ${useSin?'at the midline heading up: sine':'at its maximum: cosine'}.`,
      `Amplitude (peak height) is ${A}; period \\(\\frac{2\\pi}{${B}}\\) gives \\(B=${B}\\).`,
      `${correct}.`
    ],
    traps: [
      {ans:`\\(y=${A===1?'':A}${other}(${bT})\\)`, why: useSin?'Cosine starts at its MAXIMUM at x = 0; this curve starts at the midline.':'Sine starts at the MIDLINE at x = 0; this curve starts at a peak.'},
      {ans:`\\(y=${2*A}${name}(${bT})\\)`, why:'Amplitude is the distance from the midline to a peak, not peak-to-trough.'},
      {ans:`\\(y=${A===1?'':A}${name}(${B===1?'2x':'x'})\\)`, why:'Larger B compresses the graph: period = 2π/B.'}
    ],
    vec: [unitIndex('TRIG_Identities'), 21, A, B, useSin?1:0],
    key: 'trig_graph_identify'
  };
});
registerGen('TRIG_Triangle', (rng)=>{
  const A = pick(rng,[25,30,35,40,45,50,55,60,65]);
  const adj = randInt(rng,5,30);
  const rad = A*Math.PI/180;
  const opp = adj*Math.tan(rad);
  return {
    q: `In a right triangle, the angle at \\(A\\) is \\(${A}^\\circ\\) and the side adjacent to \\(A\\) is \\(${adj}\\). Find the length of the side opposite \\(A\\) (round to 2 decimal places).`,
    a: `\\(${fmtDec(opp,2)}\\)`,
    steps: [
      `Opposite and adjacent \\(\\Rightarrow\\) use tangent: \\(\\tan(${A}^\\circ)=\\dfrac{\\text{opp}}{${adj}}\\).`,
      `\\(\\text{opp}=${adj}\\tan(${A}^\\circ)\\approx ${fmtDec(opp,2)}\\).`
    ],
    traps: [
      {ans:`\\(${fmtDec(adj/Math.tan(rad),2)}\\)`, why:'That is adj/tan — the ratio was inverted. tan = opposite over adjacent.'},
      {ans:`\\(${fmtDec(adj*Math.sin(rad),2)}\\)`, why:'Sine uses the hypotenuse, not the adjacent side. With opp and adj, use tangent.'},
      {ans:`\\(${fmtDec(adj/Math.cos(rad),2)}\\)`, why:'adj/cos gives the hypotenuse, not the opposite side.'}
    ],
    vec: [unitIndex('TRIG_Triangle'), 20, A, adj],
    key: 'trig_right_triangle_solve'
  };
});
registerGen('TRIG_Triangle', (rng)=>{
  const theta = pick(rng,[20,25,30,35,40,50,55,60]);
  const d = randInt(rng,20,120);
  const rad = theta*Math.PI/180;
  const h = d*Math.tan(rad);
  return {
    q: `From a point \\(${d}\\) ft from the base of a building, the angle of elevation to the top is \\(${theta}^\\circ\\). Find the height of the building (round to 1 decimal place).`,
    a: `\\(${fmtDec(h,1)}\\) ft`,
    steps: [
      `Height is opposite the angle; distance to the base is adjacent: \\(\\tan(${theta}^\\circ)=\\dfrac{h}{${d}}\\).`,
      `\\(h=${d}\\tan(${theta}^\\circ)\\approx ${fmtDec(h,1)}\\) ft.`
    ],
    traps: [
      {ans:`\\(${fmtDec(d/Math.tan(rad),1)}\\) ft`, why:'That is d/tan — the tangent ratio was inverted.'},
      {ans:`\\(${fmtDec(d*Math.sin(rad),1)}\\) ft`, why:'Sine would need the line-of-sight (hypotenuse) distance; here the ground distance is the adjacent side.'}
    ],
    vec: [unitIndex('TRIG_Triangle'), 21, theta, d],
    key: 'trig_elevation_depression'
  };
});
registerGen('TRIG_Angles', (rng)=> {
  const deg = pick(rng, [30, 45, 60, 90, 120, 135, 150, 180, 210, 225, 240, 270, 300, 315, 330, 360]);
  const rad = deg * Math.PI / 180;
  const radFrac = {
    30: '\\frac{\\pi}{6}', 45: '\\frac{\\pi}{4}', 60: '\\frac{\\pi}{3}', 90: '\\frac{\\pi}{2}',
    120: '\\frac{2\\pi}{3}', 135: '\\frac{3\\pi}{4}', 150: '\\frac{5\\pi}{6}', 180: '\\pi',
    210: '\\frac{7\\pi}{6}', 225: '\\frac{5\\pi}{4}', 240: '\\frac{4\\pi}{3}', 270: '\\frac{3\\pi}{2}',
    300: '\\frac{5\\pi}{3}', 315: '\\frac{7\\pi}{4}', 330: '\\frac{11\\pi}{6}', 360: '2\\pi'
  }[deg];
  
  return {
    q: `Convert ${deg}° to radians (exact value).`,
    a: `\\(${radFrac}\\)`,
    steps: [
      `Use formula: radians = degrees \\(\\times \\frac{\\pi}{180}\\).`,
      `\\(${deg} \\times \\frac{\\pi}{180} = ${radFrac}\\).`
    ],
    vec: [unitIndex('TRIG_Angles'), 1, deg],
    key: 'trig_deg_to_rad'
  };
});
registerGen('TRIG_Angles', (rng)=> {
  const choices = [
    { rad: '\\frac{\\pi}{6}', deg: 30 }, { rad: '\\frac{\\pi}{4}', deg: 45 },
    { rad: '\\frac{\\pi}{3}', deg: 60 }, { rad: '\\frac{2\\pi}{3}', deg: 120 },
    { rad: '\\frac{3\\pi}{4}', deg: 135 }, { rad: '\\frac{5\\pi}{6}', deg: 150 }
  ];
  const choice = pick(rng, choices);
  
  return {
    q: `Convert \\(${choice.rad}\\) radians to degrees.`,
    a: `\\(${choice.deg}°\\)`,
    steps: [
      `Use formula: degrees = radians \\(\\times \\frac{180}{\\pi}\\).`,
      `\\(${choice.rad} \\times \\frac{180}{\\pi} = ${choice.deg}°\\).`
    ],
    vec: [unitIndex('TRIG_Angles'), 2, choice.deg],
    key: 'trig_rad_to_deg'
  };
});
registerGen('TRIG_Angles', (rng)=> {
  const r = pick(rng, [3, 4, 5, 6, 8, 10]);
  const theta = pick(rng, [Math.PI/6, Math.PI/4, Math.PI/3, Math.PI/2]);
  const thetaFrac = {
    [Math.PI/6]: '\\frac{\\pi}{6}',
    [Math.PI/4]: '\\frac{\\pi}{4}',
    [Math.PI/3]: '\\frac{\\pi}{3}',
    [Math.PI/2]: '\\frac{\\pi}{2}'
  }[theta];
  const s = r * theta;
  
  return {
    q: `Find the arc length of a circle with radius ${r} and central angle \\(${thetaFrac}\\) radians.`,
    a: `\\(s = ${s.toFixed(3)}\\) or \\(\\frac{${r}\\pi}{${Math.round(Math.PI/theta)}}\\)`,
    steps: [
      `Arc length formula: \\(s = r\\theta\\).`,
      `\\(s = ${r} \\times ${thetaFrac} = ${s.toFixed(3)}\\).`
    ],
    vec: [unitIndex('TRIG_Angles'), 3, r, Math.round(theta*100)],
    key: 'trig_arc_length'
  };
});
registerGen('TRIG_UnitCircle', (rng)=> {
  const angles = [
    { deg: 0, rad: '0', radNum: 0, sin: '0', cos: '1', tan: '0' },
    { deg: 30, rad: '\\frac{\\pi}{6}', radNum: Math.PI/6, sin: '\\frac{1}{2}', cos: '\\frac{\\sqrt{3}}{2}', tan: '\\frac{\\sqrt{3}}{3}' },
    { deg: 45, rad: '\\frac{\\pi}{4}', radNum: Math.PI/4, sin: '\\frac{\\sqrt{2}}{2}', cos: '\\frac{\\sqrt{2}}{2}', tan: '1' },
    { deg: 60, rad: '\\frac{\\pi}{3}', radNum: Math.PI/3, sin: '\\frac{\\sqrt{3}}{2}', cos: '\\frac{1}{2}', tan: '\\sqrt{3}' },
    { deg: 90, rad: '\\frac{\\pi}{2}', radNum: Math.PI/2, sin: '1', cos: '0', tan: '\\text{DNE}' },
    { deg: 120, rad: '\\frac{2\\pi}{3}', radNum: 2*Math.PI/3, sin: '\\frac{\\sqrt{3}}{2}', cos: '-\\frac{1}{2}', tan: '-\\sqrt{3}' },
    { deg: 135, rad: '\\frac{3\\pi}{4}', radNum: 3*Math.PI/4, sin: '\\frac{\\sqrt{2}}{2}', cos: '-\\frac{\\sqrt{2}}{2}', tan: '-1' },
    { deg: 150, rad: '\\frac{5\\pi}{6}', radNum: 5*Math.PI/6, sin: '\\frac{1}{2}', cos: '-\\frac{\\sqrt{3}}{2}', tan: '-\\frac{\\sqrt{3}}{3}' },
    { deg: 180, rad: '\\pi', radNum: Math.PI, sin: '0', cos: '-1', tan: '0' }
  ];
  const angle = pick(rng, angles);
  const func = pick(rng, ['sin', 'cos', 'tan']);
  const diagram = svgUnitCircle(angle.radNum);
  
  return {
    q: `Evaluate \\(\\${func}\\left(${angle.rad}\\right)\\).<br><br>${diagram}`,
    a: `\\(${angle[func]}\\)`,
    steps: [
      `\\(${angle.rad}\\) radians = ${angle.deg}°.`,
      `From unit circle, \\(\\${func}(${angle.rad}) = ${angle[func]}\\).`
    ],
    vec: [unitIndex('TRIG_UnitCircle'), 1, angle.deg, func.charCodeAt(0)],
    key: 'trig_unit_circle_eval'
  };
});
registerGen('TRIG_UnitCircle', (rng)=> {
  const angles = [
    { angle: 150, ref: 30, quad: 'II' }, { angle: 210, ref: 30, quad: 'III' },
    { angle: 225, ref: 45, quad: 'III' }, { angle: 300, ref: 60, quad: 'IV' },
    { angle: 315, ref: 45, quad: 'IV' }, { angle: 330, ref: 30, quad: 'IV' }
  ];
  const choice = pick(rng, angles);
  
  return {
    q: `Find the reference angle for ${choice.angle}°.`,
    a: `${choice.ref}°`,
    steps: [
      `${choice.angle}° is in quadrant ${choice.quad}.`,
      choice.quad === 'II' ? `Reference angle = 180° - ${choice.angle}° = ${choice.ref}°.` :
      choice.quad === 'III' ? `Reference angle = ${choice.angle}° - 180° = ${choice.ref}°.` :
      `Reference angle = 360° - ${choice.angle}° = ${choice.ref}°.`
    ],
    vec: [unitIndex('TRIG_UnitCircle'), 2, choice.angle],
    key: 'trig_ref_angle'
  };
});
registerGen('TRIG_UnitCircle', (rng)=> {
  const quads = [
    { name: 'I', sin: '+', cos: '+', tan: '+' },
    { name: 'II', sin: '+', cos: '-', tan: '-' },
    { name: 'III', sin: '-', cos: '-', tan: '+' },
    { name: 'IV', sin: '-', cos: '+', tan: '-' }
  ];
  const quad = pick(rng, quads);
  const func = pick(rng, ['sin', 'cos', 'tan']);
  
  return {
    q: `What is the sign of \\(\\${func}(\\theta)\\) when \\(\\theta\\) is in quadrant ${quad.name}?`,
    a: `${quad[func]}`,
    steps: [
      `Use "All Students Take Calculus" mnemonic.`,
      `Quadrant ${quad.name}: ${quad.name === 'I' ? 'All positive' : quad.name === 'II' ? 'Sin positive' : quad.name === 'III' ? 'Tan positive' : 'Cos positive'}.`,
      `Therefore \\(\\${func}\\) is ${quad[func] === '+' ? 'positive' : 'negative'}.`
    ],
    vec: [unitIndex('TRIG_UnitCircle'), 3, quad.name.charCodeAt(0), func.charCodeAt(0)],
    key: 'trig_sign_quad'
  };
});
registerGen('TRIG_UnitCircle', (rng)=> {
  const angle = pick(rng, [30, 45, 60, 120, 135, 150, 210, 225, 240, 300, 315, 330]);
  const coterm = angle + 360;
  
  return {
    q: `Find a positive coterminal angle for ${angle}°.`,
    a: `${coterm}° (also accept ${angle - 360}° as negative coterminal)`,
    steps: [
      `Coterminal angles differ by multiples of 360°.`,
      `${angle}° + 360° = ${coterm}°.`
    ],
    vec: [unitIndex('TRIG_UnitCircle'), 4, angle],
    key: 'trig_coterminal'
  };
});
registerGen('TRIG_Identities', (rng)=> {
  const base = pick(rng, ['\\sin','\\cos']);
  const A = pick(rng, [-4,-3,-2,-1,1,2,3,4]);
  const B = pick(rng, [1,2,3,4]);
  const D = randInt(rng, -3, 3);

  // Phase shift C as a nice multiple of pi
  const cChoice = pick(rng, [
    {n:0,d:1},
    {n:1,d:6},
    {n:1,d:4},
    {n:1,d:3},
    {n:1,d:2},
    {n:-1,d:6},
    {n:-1,d:4},
    {n:-1,d:3},
    {n:-1,d:2},
  ]);
  const Ctex = mwPiTex(cChoice.n, cChoice.d);

  // Build inside: x - C  (or x + ...)
  let inside;
  if(cChoice.n === 0){
    inside = 'x';
  } else if(cChoice.n > 0){
    inside = `x-${Ctex}`;
  } else {
    inside = `x+${mwPiTex(-cChoice.n, cChoice.d)}`;
  }

  const fTex = `y=${A===1?'':(A===-1?'-':A)}${base}\\left(${B===1?inside:`${B}(${inside})`}\\right)${D===0?'':(D>0?`+${D}`:`${D}`)}`;

  const amp = Math.abs(A);
  const periodTex = `\\frac{2\\pi}{${B}}`;
  const phase = (cChoice.n === 0) ? `0` : Ctex;
  const phaseDir = (cChoice.n === 0) ? '' : (cChoice.n > 0 ? `\\text{right}` : `\\text{left}`);
  const vertShift = D;

  return {
    q: `For the function \\(${fTex}\\), identify the amplitude, period, phase shift, and vertical shift.`,
    a: `\\(\\text{Amplitude }=${amp},\\;\\text{Period }=${periodTex},\\;\\text{Phase shift }=${phase}~(${phaseDir}),\\;\\text{Vertical shift }=${vertShift}.\\)`,
    steps: [
      `Amplitude is \\(|A|\\): \\(|${A}|=${amp}\\).`,
      `For \\(y=A\\${base}(B(\\cdot)) + D\\), period is \\(\\frac{2\\pi}{|B|}\\): here \\(\\frac{2\\pi}{${B}}\\).`,
      `Phase shift comes from \\((x-C)\\) (right by \\(C\\)) or \\((x+C)\\) (left by \\(C\\)).`,
      `Vertical shift is \\(D\\): here \\(D=${D}\\).`
    ],
    vec: [unitIndex('TRIG_Identities'), 81, A,B,cChoice.n,cChoice.d,D],
    key:'trig_graph_features_abcd'
  };
});
registerGen('TRIG_Identities', (rng)=> {
  const type = pick(rng, ['sin', 'cos']);
  const val = pick(rng, [3/5, 4/5, 5/13, 12/13]);
  const valFrac = val === 3/5 ? '\\frac{3}{5}' : val === 4/5 ? '\\frac{4}{5}' : val === 5/13 ? '\\frac{5}{13}' : '\\frac{12}{13}';
  const other = Math.sqrt(1 - val*val);
  
  if (type === 'sin') {
    return {
      q: `If \\(\\sin(\\theta) = ${valFrac}\\) and \\(\\theta\\) is in quadrant I, find \\(\\cos(\\theta)\\).`,
      a: `\\(${other.toFixed(4)}\\)`,
      steps: [
        `Use \\(\\sin^2(\\theta) + \\cos^2(\\theta) = 1\\).`,
        `\\(\\cos^2(\\theta) = 1 - \\sin^2(\\theta) = 1 - (${valFrac})^2\\).`,
        `\\(\\cos(\\theta) = ${other.toFixed(4)}\\) (positive in quadrant I).`
      ],
      vec: [unitIndex('TRIG_Identities'), 1, Math.round(val*1000), 1],
      key: 'trig_pythag_sin_to_cos'
    };
  } else {
    return {
      q: `If \\(\\cos(\\theta) = ${valFrac}\\) and \\(\\theta\\) is in quadrant I, find \\(\\sin(\\theta)\\).`,
      a: `\\(${other.toFixed(4)}\\)`,
      steps: [
        `Use \\(\\sin^2(\\theta) + \\cos^2(\\theta) = 1\\).`,
        `\\(\\sin^2(\\theta) = 1 - \\cos^2(\\theta) = 1 - (${valFrac})^2\\).`,
        `\\(\\sin(\\theta) = ${other.toFixed(4)}\\) (positive in quadrant I).`
      ],
      vec: [unitIndex('TRIG_Identities'), 1, Math.round(val*1000), 2],
      key: 'trig_pythag_cos_to_sin'
    };
  }
});
registerGen('TRIG_Identities', (rng)=> {
  const identities = [
    { expr: '\\tan(x)\\cos(x)', ans: '\\sin(x)', reason: 'tan = sin/cos' },
    { expr: '\\frac{\\sin(x)}{\\cos(x)}', ans: '\\tan(x)', reason: 'definition of tan' },
    { expr: '1 - \\cos^2(x)', ans: '\\sin^2(x)', reason: 'Pythagorean identity' },
    { expr: '\\sec^2(x) - 1', ans: '\\tan^2(x)', reason: '1 + tan² = sec²' }
  ];
  const id = pick(rng, identities);
  
  return {
    q: `Simplify: \\(${id.expr}\\).`,
    a: `\\(${id.ans}\\)`,
    steps: [
      `Use ${id.reason}.`,
      `Result: \\(${id.ans}\\).`
    ],
    vec: [unitIndex('TRIG_Identities'), 2, identities.indexOf(id)],
    key: 'trig_identity_simplify'
  };
});
registerGen('TRIG_Identities', (rng)=> {
  const angle = pick(rng, [30, 45, 60]);
  const radMap = { 30: '\\frac{\\pi}{6}', 45: '\\frac{\\pi}{4}', 60: '\\frac{\\pi}{3}' };
  const sinExact = { 30: '\\frac{1}{2}', 45: '\\frac{\\sqrt{2}}{2}', 60: '\\frac{\\sqrt{3}}{2}' };
  const cosExact = { 30: '\\frac{\\sqrt{3}}{2}', 45: '\\frac{\\sqrt{2}}{2}', 60: '\\frac{1}{2}' };
  const sin2Exact = { 30: '\\frac{\\sqrt{3}}{2}', 45: '1', 60: '\\frac{\\sqrt{3}}{2}' };
  
  return {
    q: `Use the double angle formula to find \\(\\sin(2\\theta)\\) when \\(\\theta = ${radMap[angle]}\\).`,
    a: `\\(${sin2Exact[angle]}\\)`,
    steps: [
      `Double angle formula: \\(\\sin(2\\theta) = 2\\sin(\\theta)\\cos(\\theta)\\).`,
      `\\(\\sin(${radMap[angle]}) = ${sinExact[angle]}\\), \\(\\cos(${radMap[angle]}) = ${cosExact[angle]}\\).`,
      `\\(\\sin(2 \\cdot ${radMap[angle]}) = 2 \\cdot ${sinExact[angle]} \\cdot ${cosExact[angle]} = ${sin2Exact[angle]}\\).`
    ],
    vec: [unitIndex('TRIG_Identities'), 3, angle],
    key: 'trig_double_angle'
  };
});
registerGen('TRIG_Identities', (rng)=> {
  const identities = [
    '\\tan^2(x) + 1 = \\sec^2(x)',
    '\\frac{1}{\\cos^2(x)} = 1 + \\tan^2(x)',
    '\\sin(x)\\cot(x) = \\cos(x)'
  ];
  const id = pick(rng, identities);
  
  return {
    q: `Verify the identity: \\(${id}\\).`,
    a: `Identity verified (see steps)`,
    steps: [
      `Start with one side of the equation.`,
      `Use fundamental identities to transform it.`,
      `Show that it equals the other side.`,
      `(Detailed algebraic verification left to student practice.)`
    ],
    vec: [unitIndex('TRIG_Identities'), 4, identities.indexOf(id)],
    key: 'trig_verify_identity'
  };
});
registerGen('TRIG_Identities', (rng)=> {
  const a = randInt(rng, 1, 7);
  const b = randInt(rng, 1, 7);
  const hyp = Math.sqrt(a*a + b*b);

  const q = `Evaluate \\(\\sin(\\arctan(\\frac{${a}}{${b}}))\\). Give an exact value.`;
  const aStr = `\\(\\dfrac{${a}}{\\sqrt{${a*a + b*b}}}\\)`;

  const steps = [
    `Let \\(\\theta=\\arctan(\\frac{${a}}{${b}})\\). Then \\(\\tan\\theta=\\frac{${a}}{${b}}\\).`,
    `Draw a right triangle: opposite=${a}, adjacent=${b}, so hypotenuse \\(=\\sqrt{${a}^2+${b}^2}=\\sqrt{${a*a + b*b}}\\).`,
    `Then \\(\\sin\\theta=\\frac{\\text{opp}}{\\text{hyp}}=\\frac{${a}}{\\sqrt{${a*a + b*b}}}\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 201, a, b], key:'trig_inv_sin_arctan' };
});
registerGen('TRIG_Identities', (rng)=> {
  const a = randInt(rng, 1, 7);
  const b = randInt(rng, 1, 7);

  const q = `Evaluate \\(\\cos(\\arctan(\\frac{${a}}{${b}}))\\). Give an exact value.`;
  const aStr = `\\(\\dfrac{${b}}{\\sqrt{${a*a + b*b}}}\\)`;

  const steps = [
    `Let \\(\\theta=\\arctan(\\frac{${a}}{${b}})\\Rightarrow \\tan\\theta=\\frac{${a}}{${b}}\\).`,
    `Triangle: opp=${a}, adj=${b}, hyp \\(=\\sqrt{${a}^2+${b}^2}=\\sqrt{${a*a + b*b}}\\).`,
    `So \\(\\cos\\theta=\\frac{\\text{adj}}{\\text{hyp}}=\\frac{${b}}{\\sqrt{${a*a + b*b}}}\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 202, a, b], key:'trig_inv_cos_arctan' };
});
registerGen('TRIG_Identities', (rng)=> {
  const triples = [
    {p:3, q:5, adj:4},
    {p:5, q:13, adj:12},
    {p:8, q:17, adj:15},
    {p:7, q:25, adj:24}
  ];
  const T = pick(rng, triples);

  const q = `Evaluate \\(\\tan(\\arcsin(\\frac{${T.p}}{${T.q}}))\\). Give an exact value.`;
  const aStr = `\\(\\dfrac{${T.p}}{${T.adj}}\\)`;

  const steps = [
    `Let \\(\\theta=\\arcsin(\\frac{${T.p}}{${T.q}})\\Rightarrow \\sin\\theta=\\frac{${T.p}}{${T.q}}\\).`,
    `Use a right triangle: opposite=${T.p}, hypotenuse=${T.q}, adjacent=\\(\\sqrt{${T.q}^2-${T.p}^2}=${T.adj}\\).`,
    `Then \\(\\tan\\theta=\\frac{\\text{opp}}{\\text{adj}}=\\frac{${T.p}}{${T.adj}}\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 203, T.p, T.q], key:'trig_inv_tan_arcsin' };
});
registerGen('TRIG_Identities', (rng)=> {
  const triples = [
    {adj:4, q:5, opp:3},
    {adj:12, q:13, opp:5},
    {adj:15, q:17, opp:8},
    {adj:24, q:25, opp:7}
  ];
  const T = pick(rng, triples);

  const q = `Evaluate \\(\\sin(\\arccos(\\frac{${T.adj}}{${T.q}}))\\). Give an exact value.`;
  const aStr = `\\(\\dfrac{${T.opp}}{${T.q}}\\)`;

  const steps = [
    `Let \\(\\theta=\\arccos(\\frac{${T.adj}}{${T.q}})\\Rightarrow \\cos\\theta=\\frac{${T.adj}}{${T.q}}\\).`,
    `Triangle: adjacent=${T.adj}, hypotenuse=${T.q}, opposite=\\(\\sqrt{${T.q}^2-${T.adj}^2}=${T.opp}\\).`,
    `So \\(\\sin\\theta=\\frac{\\text{opp}}{\\text{hyp}}=\\frac{${T.opp}}{${T.q}}\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 204, T.adj, T.q], key:'trig_inv_sin_arccos' };
});
registerGen('TRIG_Identities', (rng)=> {
  const which = pick(rng, ['75','15']);
  const q = `Evaluate \\(\\sin(${which}^\\circ)\\) exactly using a sum/difference identity.`;
  const aStr = (which === '75') ? `\\(\\dfrac{\\sqrt{6}+\\sqrt{2}}{4}\\)` : `\\(\\dfrac{\\sqrt{6}-\\sqrt{2}}{4}\\)`;

  const steps = (which === '75') ? [
    `Write \\(75^\\circ=45^\\circ+30^\\circ\\). Use \\(\\sin(\\alpha+\\beta)=\\sin\\alpha\\cos\\beta+\\cos\\alpha\\sin\\beta\\).`,
    `\\(\\sin45^\\circ=\\frac{\\sqrt2}{2},\\ \\cos30^\\circ=\\frac{\\sqrt3}{2},\\ \\cos45^\\circ=\\frac{\\sqrt2}{2},\\ \\sin30^\\circ=\\frac12\\).`,
    `So \\(\\sin75^\\circ=\\frac{\\sqrt2}{2}\\cdot\\frac{\\sqrt3}{2}+\\frac{\\sqrt2}{2}\\cdot\\frac12=\\frac{\\sqrt6}{4}+\\frac{\\sqrt2}{4}=\\frac{\\sqrt6+\\sqrt2}{4}\\).`
  ] : [
    `Write \\(15^\\circ=45^\\circ-30^\\circ\\). Use \\(\\sin(\\alpha-\\beta)=\\sin\\alpha\\cos\\beta-\\cos\\alpha\\sin\\beta\\).`,
    `Plug in values: \\(\\sin45^\\circ=\\frac{\\sqrt2}{2},\\ \\cos30^\\circ=\\frac{\\sqrt3}{2},\\ \\cos45^\\circ=\\frac{\\sqrt2}{2},\\ \\sin30^\\circ=\\frac12\\).`,
    `So \\(\\sin15^\\circ=\\frac{\\sqrt2}{2}\\cdot\\frac{\\sqrt3}{2}-\\frac{\\sqrt2}{2}\\cdot\\frac12=\\frac{\\sqrt6-\\sqrt2}{4}\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 205, (which==='75'?75:15)], key:'trig_sumdiff_sin_exact' };
});
registerGen('TRIG_Identities', (rng)=> {
  const which = pick(rng, ['15','75']);
  const q = `Evaluate \\(\\cos(${which}^\\circ)\\) exactly using a sum/difference identity.`;
  const aStr = (which === '15') ? `\\(\\dfrac{\\sqrt{6}+\\sqrt{2}}{4}\\)` : `\\(\\dfrac{\\sqrt{6}-\\sqrt{2}}{4}\\)`;

  const steps = (which === '15') ? [
    `Write \\(15^\\circ=45^\\circ-30^\\circ\\). Use \\(\\cos(\\alpha-\\beta)=\\cos\\alpha\\cos\\beta+\\sin\\alpha\\sin\\beta\\).`,
    `\\(\\cos45^\\circ=\\frac{\\sqrt2}{2},\\ \\cos30^\\circ=\\frac{\\sqrt3}{2},\\ \\sin45^\\circ=\\frac{\\sqrt2}{2},\\ \\sin30^\\circ=\\frac12\\).`,
    `So \\(\\cos15^\\circ=\\frac{\\sqrt2}{2}\\cdot\\frac{\\sqrt3}{2}+\\frac{\\sqrt2}{2}\\cdot\\frac12=\\frac{\\sqrt6+\\sqrt2}{4}\\).`
  ] : [
    `Write \\(75^\\circ=45^\\circ+30^\\circ\\). Use \\(\\cos(\\alpha+\\beta)=\\cos\\alpha\\cos\\beta-\\sin\\alpha\\sin\\beta\\).`,
    `Plug in values: \\(\\cos45^\\circ=\\frac{\\sqrt2}{2},\\ \\cos30^\\circ=\\frac{\\sqrt3}{2},\\ \\sin45^\\circ=\\frac{\\sqrt2}{2},\\ \\sin30^\\circ=\\frac12\\).`,
    `So \\(\\cos75^\\circ=\\frac{\\sqrt2}{2}\\cdot\\frac{\\sqrt3}{2}-\\frac{\\sqrt2}{2}\\cdot\\frac12=\\frac{\\sqrt6-\\sqrt2}{4}\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 206, (which==='15'?15:75)], key:'trig_sumdiff_cos_exact' };
});
registerGen('TRIG_Identities', (rng)=> {
  const q = `Evaluate \\(\\tan(75^\\circ)\\) exactly using a sum identity.`;
  const aStr = `\\(2+\\sqrt{3}\\)`;

  const steps = [
    `Write \\(75^\\circ=45^\\circ+30^\\circ\\). Use \\(\\tan(\\alpha+\\beta)=\\frac{\\tan\\alpha+\\tan\\beta}{1-\\tan\\alpha\\tan\\beta}\\).`,
    `\\(\\tan45^\\circ=1\\) and \\(\\tan30^\\circ=\\frac{1}{\\sqrt3}\\).`,
    `So \\(\\tan75^\\circ=\\frac{1+\\frac{1}{\\sqrt3}}{1-\\frac{1}{\\sqrt3}}\\). Multiply top/bottom by \\(\\sqrt3\\):`,
    `\\(\\tan75^\\circ=\\frac{\\sqrt3+1}{\\sqrt3-1}=\\frac{(\\sqrt3+1)^2}{(\\sqrt3-1)(\\sqrt3+1)}=\\frac{3+2\\sqrt3+1}{2}=2+\\sqrt3\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 207, 75], key:'trig_sumdiff_tan_exact' };
});
registerGen('TRIG_Identities', (rng)=> {
  const q = `Evaluate \\(\\cos(22.5^\\circ)\\) exactly using a half-angle identity.`;
  const aStr = `\\(\\dfrac{\\sqrt{2+\\sqrt2}}{2}\\)`;

  const steps = [
    `Note \\(22.5^\\circ=\\frac{45^\\circ}{2}\\). Use \\(\\cos\\frac{\\theta}{2}=\\pm\\sqrt{\\frac{1+\\cos\\theta}{2}}\\).`,
    `Since \\(22.5^\\circ\\) is in Quadrant I, the cosine is positive.`,
    `\\(\\cos45^\\circ=\\frac{\\sqrt2}{2}\\), so`,
    `\\(\\cos22.5^\\circ=\\sqrt{\\frac{1+\\frac{\\sqrt2}{2}}{2}}=\\sqrt{\\frac{2+\\sqrt2}{4}}=\\frac{\\sqrt{2+\\sqrt2}}{2}\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 208, 225], key:'trig_halfangle_cos_exact' };
});
registerGen('TRIG_Identities', (rng)=> {
  const q = `Evaluate \\(\\sin(22.5^\\circ)\\) exactly using a half-angle identity.`;
  const aStr = `\\(\\dfrac{\\sqrt{2-\\sqrt2}}{2}\\)`;

  const steps = [
    `Note \\(22.5^\\circ=\\frac{45^\\circ}{2}\\). Use \\(\\sin\\frac{\\theta}{2}=\\pm\\sqrt{\\frac{1-\\cos\\theta}{2}}\\).`,
    `Since \\(22.5^\\circ\\) is in Quadrant I, the sine is positive.`,
    `\\(\\cos45^\\circ=\\frac{\\sqrt2}{2}\\), so`,
    `\\(\\sin22.5^\\circ=\\sqrt{\\frac{1-\\frac{\\sqrt2}{2}}{2}}=\\sqrt{\\frac{2-\\sqrt2}{4}}=\\frac{\\sqrt{2-\\sqrt2}}{2}\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 209, 225], key:'trig_halfangle_sin_exact' };
});
registerGen('TRIG_Identities', (rng)=> {
  const aDeg = pick(rng, [30,45,60]);
  const q = `Rewrite as a single trig function: \\(\\sin x\\cos(${aDeg}^\\circ)+\\cos x\\sin(${aDeg}^\\circ)\\).`;
  const aStr = `\\(\\sin(x+${aDeg}^\\circ)\\)`;

  const steps = [
    `Use the sine addition identity: \\(\\sin(x+\\alpha)=\\sin x\\cos\\alpha+\\cos x\\sin\\alpha\\).`,
    `Match \\(\\alpha=${aDeg}^\\circ\\). Therefore the expression equals \\(\\sin(x+${aDeg}^\\circ)\\).`
  ];

  return { q, a: aStr, steps, vec:[unitIndex('TRIG_Identities'), 210, aDeg], key:'trig_identity_sin_add_pattern' };
});
registerGen('TRIG_Equations', (rng)=> {
  const vals = [
    { func: 'sin', val: '\\frac{1}{2}', angles: '30°, 150°' },
    { func: 'cos', val: '\\frac{\\sqrt{2}}{2}', angles: '45°, 315°' },
    { func: 'tan', val: '1', angles: '45°, 225°' },
    { func: 'sin', val: '\\frac{\\sqrt{3}}{2}', angles: '60°, 120°' }
  ];
  const choice = pick(rng, vals);
  
  return {
    q: `Solve for \\(\\theta\\) in \\([0°, 360°)\\): \\(\\${choice.func}(\\theta) = ${choice.val}\\).`,
    a: `\\(\\theta = ${choice.angles}\\)`,
    steps: [
      `Find reference angle where \\(\\${choice.func} = ${choice.val}\\).`,
      `Determine which quadrants give this value.`,
      `Solutions: \\(${choice.angles}\\).`
    ],
    vec: [unitIndex('TRIG_Equations'), 1, vals.indexOf(choice)],
    key: 'trig_solve_basic'
  };
});
registerGen('TRIG_Equations', (rng)=> {
  const a = pick(rng, [2, 3, 4]);
  
  return {
    q: `Solve for \\(x\\) in \\([0, 2\\pi)\\): \\(${a}\\sin^2(x) - \\sin(x) = 0\\).`,
    a: `\\(x = 0, \\arcsin\\left(\\frac{1}{${a}}\\right), \\pi\\)`,
    steps: [
      `Factor: \\(\\sin(x)(${a}\\sin(x) - 1) = 0\\).`,
      `Set each factor to zero: \\(\\sin(x) = 0\\) or \\(\\sin(x) = \\frac{1}{${a}}\\).`,
      `Solve each equation in the given interval.`
    ],
    vec: [unitIndex('TRIG_Equations'), 2, a],
    key: 'trig_solve_quadratic'
  };
});
registerGen('TRIG_Equations', (rng)=> {
  return {
    q: `Solve for \\(x\\) in \\([0, 2\\pi)\\): \\(2\\cos^2(x) + \\cos(x) - 1 = 0\\).`,
    a: `\\(x = \\frac{\\pi}{3}, \\pi, \\frac{5\\pi}{3}\\)`,
    steps: [
      `This is a quadratic in \\(\\cos(x)\\). Let \\(u = \\cos(x)\\).`,
      `\\(2u^2 + u - 1 = 0\\) factors to \\((2u - 1)(u + 1) = 0\\).`,
      `\\(u = \\frac{1}{2}\\) or \\(u = -1\\).`,
      `\\(\\cos(x) = \\frac{1}{2}\\Rightarrow x = \\frac{\\pi}{3}, \\frac{5\\pi}{3}\\).`,
      `\\(\\cos(x) = -1\\Rightarrow x = \\pi\\).`
    ],
    vec: [unitIndex('TRIG_Equations'), 3, 0],
    key: 'trig_solve_identity'
  };
});
registerGen('TRIG_Triangle', (rng)=> {
  // Law of Sines (SSA): choose values that always produce a valid acute angle B
  // and avoid impossible triangles (sin(B) > 1) / NaN.
  const A = pick(rng, [40, 50, 60]); // keep acute
  let a = pick(rng, [10, 12, 15]);
  // ensure b <= a to avoid impossible case and reduce ambiguity
  let bChoices = [8, 10, 13].filter(v => v <= a);
  if (bChoices.length === 0) bChoices = [8]; // safety
  let b = pick(rng, bChoices);

  // compute B from sin(B) = b*sin(A)/a (acute solution)
  const sinB = (b * Math.sin(A * Math.PI / 180)) / a;
  const B = Math.asin(sinB) * 180 / Math.PI;

    return {
    q: `In triangle ABC, \\(a = ${a}\\), \\(b = ${b}\\), and \\(A = ${A}^\\circ\\). Find angle \\(B\\) using the Law of Sines.`,
    a: `\\(B \\approx ${B.toFixed(1)}^\\circ\\)`,
    steps: [
      `Law of Sines: \\(\\frac{\\sin(A)}{a} = \\frac{\\sin(B)}{b}\\).`,
      `\\(\\sin(B) = \\frac{b \\cdot \\sin(A)}{a} = \\frac{${b} \\cdot \\sin(${A}^\\circ)}{${a}}\\).`,
      `\\(\\sin(B) \\approx ${sinB.toFixed(4)}\\) so \\(B = \\arcsin(\\sin(B)) \\approx ${B.toFixed(1)}^\\circ\\).`
    ],
    vec: [unitIndex('TRIG_Triangle'), 2, a, b, A],
    key: 'trig_law_sines_angle'
  };
});
registerGen('TRIG_Triangle', (rng)=> {
  const a = pick(rng, [8, 10, 12]);
  const b = pick(rng, [10, 12, 15]);
  const C = pick(rng, [60, 90, 120]);

  // Exact cos values to prevent 0.4999999999... issues
  const cosVal = (C === 90) ? 0 : (C === 60 ? 0.5 : -0.5);
  const cSq = Math.round(a*a + b*b - 2*a*b*cosVal); // exact integer
  const c = Math.sqrt(cSq);
  const cExact = simplifyRadical(cSq);

  return {
    q: `In triangle ABC, \\(a = ${a}\\), \\(b = ${b}\\), and \\(C = ${C}°\\). Find side \\(c\\) using the Law of Cosines.`,
    a: `\\(c \\approx ${c.toFixed(2)}\\)`,
    steps: [
      `Law of Cosines: \\(c^2 = a^2 + b^2 - 2ab\\cos(C)\\).`,
      `\\(c^2 = ${a}^2 + ${b}^2 - 2(${a})(${b})\\cos(${C}°) = ${cSq}\\).`,  // ✅ SHOW EXACT c²
      `\\(c = \\sqrt{${cSq}} = ${cExact} \\approx ${c.toFixed(2)}\\).`  // ✅ SHOW RADICAL FORM
    ],
    vec: [unitIndex('TRIG_Triangle'), 3, a, b, C],
    key: 'trig_law_cosines_side'
  };
});
registerGen('TRIG_Triangle', (rng)=> {
  const a = pick(rng, [6, 8, 10, 12]);
  const b = pick(rng, [8, 10, 12, 15]);
  const C = pick(rng, [30, 45, 60, 90]);
  const area = 0.5 * a * b * Math.sin(C * Math.PI / 180);
  
  return {
    q: `Find the area of triangle ABC with \\(a = ${a}\\), \\(b = ${b}\\), and \\(C = ${C}°\\).`,
    a: `\\(${area.toFixed(2)}\\) square units`,
    steps: [
      `Area formula (SAS): \\(A = \\frac{1}{2}ab\\sin(C)\\).`,
      `\\(A = \\frac{1}{2}(${a})(${b})\\sin(${C}°)\\).`,
      `\\(A \\approx ${area.toFixed(2)}\\).`
    ],
    vec: [unitIndex('TRIG_Triangle'), 4, a, b, C],
    key: 'trig_area_sas'
  };
});
registerGen('TRIG_Polar', (rng)=> {
  const r = pick(rng, [2, 3, 4, 5]);
  const theta = pick(rng, [0, 30, 45, 60, 90, 120, 135, 150, 180]);
  const x = r * Math.cos(theta * Math.PI / 180);
  const y = r * Math.sin(theta * Math.PI / 180);
  const diagram = svgPolarGrid(r, theta * Math.PI / 180);
  
  // Use exact values for special angles
  const exactMap = {
    0: ['{R}', '0'],
    30: ['\\frac{{R}\\sqrt{3}}{2}', '\\frac{{R}}{2}'],
    45: ['\\frac{{R}\\sqrt{2}}{2}', '\\frac{{R}\\sqrt{2}}{2}'],
    60: ['\\frac{{R}}{2}', '\\frac{{R}\\sqrt{3}}{2}'],
    90: ['0', '{R}'],
    120: ['-\\frac{{R}}{2}', '\\frac{{R}\\sqrt{3}}{2}'],
    135: ['-\\frac{{R}\\sqrt{2}}{2}', '\\frac{{R}\\sqrt{2}}{2}'],
    150: ['-\\frac{{R}\\sqrt{3}}{2}', '\\frac{{R}}{2}'],
    180: ['-{R}', '0']
  };
  const [xExact, yExact] = exactMap[theta] || [`${smartRound(x, 2)}`, `${smartRound(y, 2)}`];
  
  return {
    q: `Convert polar coordinates \\((${r}, ${theta}°)\\) to rectangular coordinates.<br><br>${diagram}`,
    a: `\\((${xExact.split('{R}').join(r)}, ${yExact.split('{R}').join(r)})\\)`,
    steps: [
      `Use \\(x = r\\cos(\\theta)\\) and \\(y = r\\sin(\\theta)\\).`,
      `\\(x = ${r}\\cos(${theta}°)\\), \\(y = ${r}\\sin(${theta}°)\\).`
    ],
    vec: [unitIndex('TRIG_Polar'), 1, r, theta],
    key: 'trig_polar_to_rect'
  };
});
registerGen('TRIG_Polar', (rng)=> {
  const x = pick(rng, [-3, -2, -1, 1, 2, 3, 4]);
  const y = pick(rng, [-3, -2, -1, 1, 2, 3, 4]);
  const r = Math.sqrt(x*x + y*y);
  const theta = Math.atan2(y, x) * 180 / Math.PI;
  
  return {
    q: `Convert rectangular coordinates \\((${x}, ${y})\\) to polar coordinates.`,
    a: `\\((${r.toFixed(2)}, ${theta.toFixed(1)}°)\\)`,
    steps: [
      `Use \\(r = \\sqrt{x^2 + y^2}\\) and \\(\\theta = \\arctan(y/x)\\).`,
      `\\(r = \\sqrt{${x}^2 + ${y}^2} = ${r.toFixed(2)}\\).`,
      `\\(\\theta = \\arctan(${y}/${x}) \\approx ${theta.toFixed(1)}°\\).`
    ],
    vec: [unitIndex('TRIG_Polar'), 2, x, y],
    key: 'trig_rect_to_polar'
  };
});
registerGen('TRIG_Polar', (rng)=> {
  const curves = [
    { eq: 'r = 3', type: 'Circle centered at origin with radius 3' },
    { eq: 'r = 2\\cos(\\theta)', type: 'Circle passing through origin' },
    { eq: 'r = 1 + \\cos(\\theta)', type: 'Cardioid' },
    { eq: 'r = 2\\sin(3\\theta)', type: 'Rose curve with 3 petals' }
  ];
  const curve = pick(rng, curves);
  
  return {
    q: `Identify the type of curve: \\(${curve.eq}\\).`,
    a: `${curve.type}`,
    steps: [
      `Recognize the standard form.`,
      `This is a ${curve.type}.`
    ],
    vec: [unitIndex('TRIG_Polar'), 3, curves.indexOf(curve)],
    key: 'trig_polar_curve'
  };
});
