// CA generator registrations — order frozen by the published registry.
registerGen('CA_Functions', (rng)=>{
  const kind = pick(rng,['even','odd','neither']);
  const a = mwNZ(rng,1,4), b = mwNZ(rng,1,5);
  let fTex, why;
  if(kind==='even'){ fTex = `${a===1?'':a}x^4${fmtSigned(-b)}x^2`; why = `all exponents are even, so \\(f(-x)=f(x)\\)`; }
  else if(kind==='odd'){ fTex = `${a===1?'':a}x^3${fmtSigned(-b)}x`; why = `all exponents are odd, so \\(f(-x)=-f(x)\\)`; }
  else { fTex = `${a===1?'':a}x^3${fmtSigned(b)}x^2`; why = `mixed parity of exponents: \\(f(-x)\\) is neither \\(f(x)\\) nor \\(-f(x)\\)`; }
  const label = kind.charAt(0).toUpperCase()+kind.slice(1);
  const others = ['Even','Odd','Neither'].filter(x=>x!==label);
  return {
    q: `Is \\(f(x)=${fTex}\\) even, odd, or neither?`,
    a: label,
    steps: [
      `Test \\(f(-x)\\): replace every \\(x\\) with \\(-x\\).`,
      `Here ${why}.`,
      `Conclusion: ${label.toLowerCase()}.`
    ],
    traps: [
      {ans: others[0], why:'Check every exponent: even powers keep their sign under x → −x, odd powers flip.'},
      {ans: others[1], why:'Compare f(−x) to BOTH f(x) and −f(x) before concluding.'}
    ],
    vec: [unitIndex('CA_Functions'), 20, kind==='even'?0:kind==='odd'?1:2, a, b],
    key: 'ca_func_even_odd'
  };
});
registerGen('CA_Polynomials', (rng)=>{
  const n = pick(rng,[2,3,4,5]);
  const a = pick(rng,[1,-1,2,-2,3,-3]);
  const up = '\\infty', dn = '-\\infty';
  const rightUp = a > 0;
  const leftUp = (n % 2 === 0) ? rightUp : !rightUp;
  const eb = (L,R)=> `As \\(x\\to-\\infty\\), \\(f\\to ${L}\\); as \\(x\\to\\infty\\), \\(f\\to ${R}\\)`;
  const ans = eb(leftUp?up:dn, rightUp?up:dn);
  const co = a===1?'':(a===-1?'-':`${a}`);
  const tail = n>=3 ? ` ${fmtSigned(mwNZ(rng,-4,4))}x${fmtSigned(randInt(rng,-5,5))}` : ` ${fmtSigned(randInt(rng,-5,5))}`;
  return {
    q: `Describe the end behavior of \\(f(x)=${co}x^{${n}}${tail}\\).`,
    a: ans,
    steps: [
      `Only the leading term \\(${co}x^{${n}}\\) controls end behavior.`,
      `Degree ${n} is ${n%2===0?'even: both ends point the same way':'odd: the ends point opposite ways'}; leading coefficient is ${a>0?'positive':'negative'}.`,
      `${ans}.`
    ],
    traps: [
      {ans: eb(leftUp?dn:up, rightUp?dn:up), why:'The sign of the leading coefficient sets the RIGHT end; you have both ends flipped.'},
      {ans: eb(leftUp?dn:up, rightUp?up:dn), why: n%2===0 ? 'Even degree: both ends go the SAME direction.' : 'Odd degree: the two ends go OPPOSITE directions.'}
    ],
    vec: [unitIndex('CA_Polynomials'), 22, n, a],
    key: 'ca_poly_end_behavior'
  };
});
registerGen('CA_ExpLog', (rng)=>{
  const kind = pick(rng,['exp','expdecay','log']);
  const k = randInt(rng,-2,2);
  let fn, correct, refl, shiftFlip, swap;
  const kT = (kk)=> kk===0?'':fmtSigned(kk);
  if(kind==='exp'){
    fn = x => Math.exp(x)+k;
    correct = `\\(y=e^{x}${kT(k)}\\)`;
    refl = `\\(y=e^{-x}${kT(k)}\\)`;
    shiftFlip = `\\(y=e^{x}${kT(k===0?1:-k)}\\)`;
    swap = `\\(y=\\ln x${kT(k)}\\)`;
  } else if(kind==='expdecay'){
    fn = x => Math.exp(-x)+k;
    correct = `\\(y=e^{-x}${kT(k)}\\)`;
    refl = `\\(y=e^{x}${kT(k)}\\)`;
    shiftFlip = `\\(y=e^{-x}${kT(k===0?1:-k)}\\)`;
    swap = `\\(y=\\ln(-x)${kT(k)}\\)`;
  } else {
    fn = x => Math.log(x)+k;
    correct = `\\(y=\\ln x${kT(k)}\\)`;
    refl = `\\(y=\\ln(-x)${kT(k)}\\)`;
    shiftFlip = `\\(y=\\ln x${kT(k===0?1:-k)}\\)`;
    swap = `\\(y=e^{x}${kT(k)}\\)`;
  }
  return {
    q: `Which function matches this graph?<br><br>${svgFnPlot(fn)}`,
    a: correct,
    steps: [
      kind==='log' ? `The curve exists only for \\(x>0\\) and grows slowly: a logarithm.` :
        `The curve is defined for all \\(x\\) with a horizontal asymptote: an exponential, ${kind==='exp'?'increasing (growth)':'decreasing (decay)'}.`,
      `The horizontal ${kind==='log'?'shift/level':'asymptote'} sits at \\(y=${k}\\), giving the vertical shift ${k}.`,
      `So ${correct}.`
    ],
    traps: [
      {ans: refl,      why:'Check whether the curve increases or decreases left to right (reflection in x).'},
      {ans: shiftFlip, why:'Read the vertical shift from the asymptote/level: it moves WITH the sign of k.'},
      {ans: swap,      why: kind==='log' ? 'Logs are only defined for positive inputs; exponentials for all x.' : 'Exponentials are defined for all x; a log would stop at a vertical asymptote.'}
    ],
    vec: [unitIndex('CA_ExpLog'), 20, kind==='exp'?0:kind==='expdecay'?1:2, k],
    key: 'ca_explog_graph_identify'
  };
});
registerGen('CA_ExpLog', (rng)=>{
  const bse = pick(rng,[2,3,4,5]);
  const e = pick(rng,[2,3,4]);
  const val = Math.pow(bse,e);
  const toLog = pick(rng,[true,false]);
  if(toLog){
    return {
      q: `Write \\(${bse}^{${e}}=${val}\\) in logarithmic form.`,
      a: `\\(\\log_{${bse}} ${val}=${e}\\)`,
      steps: [`\\(b^x=y\\) means \\(\\log_b y=x\\): the base stays the base, the exponent is the log's value.`],
      traps: [
        {ans:`\\(\\log_{${e}} ${val}=${bse}\\)`, why:'The BASE of the power is the base of the log; the exponent is the answer.'},
        {ans:`\\(\\log_{${bse}} ${e}=${val}\\)`, why:'The log of the RESULT equals the exponent: log_b(y) = x.'},
        {ans:`\\(\\log_{${val}} ${bse}=${e}\\)`, why:'Base and result are swapped.'}
      ],
      vec: [unitIndex('CA_ExpLog'), 21, bse, e, 1],
      key: 'ca_log_convert_form'
    };
  }
  return {
    q: `Write \\(\\log_{${bse}} ${val}=${e}\\) in exponential form.`,
    a: `\\(${bse}^{${e}}=${val}\\)`,
    steps: [`\\(\\log_b y=x\\) means \\(b^x=y\\).`],
    traps: [
      {ans:`\\(${e}^{${bse}}=${val}\\)`, why:'The base of the log is the base of the power.'},
      {ans:`\\(${bse}^{${val}}=${e}\\)`, why:'The log VALUE is the exponent, not the result.'},
      {ans:`\\(${val}^{${e}}=${bse}\\)`, why:'Base and result are swapped.'}
    ],
    vec: [unitIndex('CA_ExpLog'), 21, bse, e, 0],
    key: 'ca_log_convert_form'
  };
});
registerGen('CA_Functions', (rng)=>{
  const a = pick(rng,[1,-1,2,-2]);
  const h = randInt(rng,-3,3);
  const k = randInt(rng,-4,4);
  const up = a > 0;
  const co = a===1?'':(a===-1?'-':`${a}`);
  const fTex = `${co}\\sqrt{${parenXMinus(h).slice(1,-1)}}${fmtSigned(k)}`;
  const ans = up ? `[${k}, \\infty)` : `(-\\infty, ${k}]`;
  const dom = `[${h}, \\infty)`;
  return {
    q: `Find the range of \\(f(x)=${fTex}\\).`,
    a: `\\(${ans}\\)`,
    steps: [
      `\\(\\sqrt{\\cdot}\\ge 0\\), so \\(${co||'1'}\\sqrt{x-${h}}\\) is ${up?'\\(\\ge 0\\)':'\\(\\le 0\\)'}.`,
      `Adding ${k}: outputs are ${up?'at least':'at most'} ${k}.`,
      `Range: \\(${ans}\\).`
    ],
    traps: [
      {ans:`\\(${dom}\\)`, why:'That is the DOMAIN (the allowed x-values). Range asks for the outputs.'},
      {ans:`\\(${up ? `(-\\infty, ${k}]` : `[${k}, \\infty)`}\\)`, why:`The coefficient ${a} is ${up?'positive: outputs go UP from':'negative: outputs go DOWN from'} ${k}.`},
      {ans:`\\((${k}, \\infty)\\)`, why:'The endpoint IS attained (at x = '+h+'), so the interval is closed at '+k+'.'}
    ],
    vec: [unitIndex('CA_Functions'), 21, a, h, k],
    key: 'ca_func_range'
  };
});
registerGen('CA_Polynomials', (rng)=>{
  const p = randInt(rng,-3,3);
  const q = randInt(rng,1,4);
  const B = -2*p, C = p*p + q*q;
  const zTex = (pp,qq)=> pp===0 ? `\\pm ${qq}i` : `${pp}\\pm ${qq}i`;
  return {
    q: `Find all zeros of \\(f(x)=x^2${fmtSigned(B)}x${fmtSigned(C)}\\).`,
    a: `\\(x=${zTex(p,q)}\\)`,
    steps: [
      `Quadratic formula: \\(x=\\frac{${-B}\\pm\\sqrt{${B*B}-${4*C}}}{2}\\).`,
      `Discriminant: \\(${B*B-4*C}<0\\), so the zeros are complex conjugates.`,
      `\\(x=\\frac{${-B}\\pm\\sqrt{${4*C-B*B}}\\,i}{2}=${zTex(p,q)}\\).`
    ],
    traps: [
      {ans:`\\(x=${zTex(p===0?1:-p,q)}\\)`, why:'Sign of the real part: it is -b/(2a), watch the sign of b.'},
      {ans:`\\(x=${p===0?`\\pm ${q}`:`${p}\\pm ${q}`}\\)`, why:'The discriminant is negative, so the roots are complex — do not drop the i.'},
      {ans:`\\(x=${zTex(p,q+1)}\\)`, why:'Check the arithmetic under the radical: sqrt(4c-b^2)/2 gives the imaginary part.'}
    ],
    vec: [unitIndex('CA_Polynomials'), 20, p, q],
    key: 'ca_poly_complex_zeros'
  };
});
registerGen('CA_Polynomials', (rng)=>{
  let r1 = randInt(rng,-5,3);
  let r2 = r1 + randInt(rng,1,5);
  const strict = pick(rng,[true,false]);
  const gt = pick(rng,[true,false]);
  const B = -(r1+r2), C = r1*r2;
  const op = gt ? (strict?'>':'\\ge') : (strict?'<':'\\le');
  const br = strict ? ['(',')'] : ['[',']'];
  const inside  = `${br[0]}${r1}, ${r2}${br[1]}`;
  const outside = `(-\\infty, ${r1}${br[1]}\\cup${br[0]}${r2}, \\infty)`;
  const insideO  = `(${r1}, ${r2})`;
  const outsideO = `(-\\infty, ${r1})\\cup(${r2}, \\infty)`;
  const insideC  = `[${r1}, ${r2}]`;
  const outsideC = `(-\\infty, ${r1}]\\cup[${r2}, \\infty)`;
  const ans = gt ? (strict?outsideO:outsideC) : (strict?insideO:insideC);
  const wrongRegion = gt ? (strict?insideO:insideC) : (strict?outsideO:outsideC);
  const wrongClosure = gt ? (strict?outsideC:outsideO) : (strict?insideC:insideO);
  return {
    q: `Solve the inequality \\(x^2${fmtSigned(B)}x${fmtSigned(C)} ${op} 0\\). Give your answer in interval notation.`,
    a: `\\(${ans}\\)`,
    steps: [
      `Factor: \\(${parenXMinus(r1)}${parenXMinus(r2)} ${op} 0\\), zeros at \\(x=${r1}\\) and \\(x=${r2}\\).`,
      `Sign chart: the parabola opens upward, so it is negative between the zeros and positive outside them.`,
      `The inequality is ${strict?'strict, so the endpoints are excluded':'not strict, so the endpoints are included'}: \\(${ans}\\).`
    ],
    traps: [
      {ans:`\\(${wrongRegion}\\)`, why:'Check the sign chart: an upward parabola is positive OUTSIDE its zeros and negative BETWEEN them.'},
      {ans:`\\(${wrongClosure}\\)`, why: strict?'Strict inequality: the zeros themselves are not solutions — use open endpoints.':'Non-strict inequality: the zeros ARE solutions — use closed endpoints.'}
    ],
    vec: [unitIndex('CA_Polynomials'), 21, r1, r2, strict?1:0, gt?1:0],
    key: 'ca_poly_inequality'
  };
});
registerGen('CA_Rational', (rng)=>{
  let a = randInt(rng,-4,4);
  let b = a; while(b===a) b = randInt(rng,-4,4);
  const gt = pick(rng,[true,false]);
  const lo = Math.min(a,b), hi = Math.max(a,b);
  const numIsLo = (a === lo);
  let ans, trapClosedDen, trapRegion;
  if(gt){
    ans = `(-\\infty, ${lo})\\cup(${hi}, \\infty)`;
    trapRegion = `(${lo}, ${hi})`;
    trapClosedDen = `(-\\infty, ${lo}]\\cup[${hi}, \\infty)`;
  } else {
    ans = numIsLo ? `[${lo}, ${hi})` : `(${lo}, ${hi}]`;
    trapRegion = `(-\\infty, ${lo})\\cup(${hi}, \\infty)`;
    trapClosedDen = `[${lo}, ${hi}]`;
  }
  return {
    q: `Solve \\(\\dfrac{${parenXMinus(a).slice(1,-1)}}{${parenXMinus(b).slice(1,-1)}} ${gt?'>':'\\le'} 0\\). Give interval notation.`,
    a: `\\(${ans}\\)`,
    steps: [
      `Critical values: numerator zero at \\(x=${a}\\); denominator zero (excluded!) at \\(x=${b}\\).`,
      `Sign chart on the intervals split by \\(${lo}\\) and \\(${hi}\\): the quotient is ${gt?'positive outside the critical values':'negative (or zero) between them'}.`,
      `\\(x=${b}\\) makes the denominator zero and is never included; \\(x=${a}\\) ${gt?'is excluded (strict inequality)':'is included (the quotient equals 0 there)'}.`,
      `Answer: \\(${ans}\\).`
    ],
    traps: [
      {ans:`\\(${trapClosedDen}\\)`, why:`x=${b} makes the denominator zero — it can never be included, even with ≤.`},
      {ans:`\\(${trapRegion}\\)`, why:'Re-check the sign chart: test one point from each interval.'}
    ],
    vec: [unitIndex('CA_Rational'), 20, a, b, gt?1:0],
    key: 'ca_rational_inequality'
  };
});
registerGen('CA_Quadratics', (rng)=>{
  // ANSWER FIRST: choose the clean function, then render it as the question.
  const aCoef = pick(rng, [1, -1, 2, -2]);
  const h = randInt(rng, -3, 3);
  const k = randInt(rng, -3, 3);

  const term = (hh)=> hh===0 ? 'x' : (hh>0 ? `(x-${hh})` : `(x+${-hh})`);
  const kTail = (kk)=> kk===0 ? '' : (kk>0 ? `+${kk}` : `${kk}`);
  const aHead = (aa)=> aa===1 ? '' : (aa===-1 ? '-' : `${aa}`);
  const vf = (aa,hh,kk)=> `\\(y=${aHead(aa)}${term(hh)}^2${kTail(kk)}\\)`;

  const correct = vf(aCoef,h,k);
  return {
    q: `Which function matches this graph? (vertex marked, gridlines every 1 unit)<br><br>${svgParabola(aCoef,h,k)}`,
    a: correct,
    steps: [
      `The vertex is at \\((${h}, ${k})\\), so the form is \\(y=a(x-${h})^2${kTail(k)}\\).`,
      `The parabola opens ${aCoef>0?'upward':'downward'} and is ${Math.abs(aCoef)===2?'narrower than':'as wide as'} \\(y=x^2\\), so \\(a=${aCoef}\\).`,
      `Therefore ${correct}.`
    ],
    traps: [
      (h!==0) ? {ans: vf(aCoef,-h,k), why:'Sign of h: in y=a(x-h)^2+k, the graph shifts toward the SAME sign as the vertex x-coordinate.'} : null,
      {ans: vf(-aCoef,h,k), why:'Check which way the parabola opens: a>0 opens up, a<0 opens down.'},
      (h!==k) ? {ans: vf(aCoef,k,h), why:'h and k swapped: the vertex is (h, k) — horizontal shift first, vertical second.'} : {ans: vf(aCoef,h,(k===0?1:-k)), why:'Sign of k: the vertical shift matches the vertex y-coordinate.'}
    ].filter(Boolean),
    vec: [unitIndex('CA_Quadratics'), 9, aCoef, h, k],
    key: 'ca_quad_graph_identify'
  };
});
registerGen('CA_Linear', (rng)=> {
  const a = randInt(rng, 2, 8);
  const b = randInt(rng, -10, 10);
  const c = randInt(rng, 1, a-1);
  const d = randInt(rng, -10, 10);
  const x = (d - b) / (a - c);
  
  return {
    q: `Solve for \\(x\\): \\(${a}x + ${b} = ${c}x + ${d}\\).`,
    a: `\\(x = ${x}\\)`,
    steps: [
      `Subtract \\(${c}x\\) from both sides: \\(${a-c}x + ${b} = ${d}\\).`,
      `Subtract \\(${b}\\) from both sides: \\(${a-c}x = ${d-b}\\).`,
      `Divide by \\(${a-c}\\): \\(x = ${x}\\).`
    ],
    vec: [unitIndex('CA_Linear'), 1, a, b, c, d],
    key: 'ca_linear_solve'
  };
});
registerGen('CA_Linear', (rng)=> {
  const a = randInt(rng, 2, 5);
  const b = randInt(rng, -6, 6);
  const c = randInt(rng, 5, 15);
  const x1 = (c - b) / a;
  const x2 = (-c - b) / a;
  
  return {
    q: `Solve for \\(x\\): \\(|${a}x + ${b}| = ${c}\\).`,
    a: `\\(x = ${x1}\\) or \\(x = ${x2}\\)`,
    steps: [
      `Split into two cases: \\(${a}x + ${b} = ${c}\\) or \\(${a}x + ${b} = -${c}\\).`,
      `Case 1: \\(${a}x = ${c-b}\\Rightarrow x = ${x1}\\).`,
      `Case 2: \\(${a}x = ${-c-b}\\Rightarrow x = ${x2}\\).`
    ],
    vec: [unitIndex('CA_Linear'), 2, a, b, c],
    key: 'ca_abs_value'
  };
});
registerGen('CA_Linear', (rng)=> {
  const a = randInt(rng, 2, 6);
  const b = randInt(rng, -8, 8);
  const c = randInt(rng, 1, a-1);
  const d = randInt(rng, -8, 8);
  const bound = (d - b) / (a - c);
  
  return {
    q: `Solve the inequality: \\(${a}x + ${b} < ${c}x + ${d}\\).`,
    a: `\\(x < ${bound}\\)` + ` or \\((-\\infty, ${bound})\\)`,
    steps: [
      `Subtract \\(${c}x\\) and \\(${b}\\) from both sides: \\(${a-c}x < ${d-b}\\).`,
      `Divide by \\(${a-c}\\): \\(x < ${bound}\\).`,
      `Interval notation: \\((-\\infty, ${bound})\\).`
    ],
    vec: [unitIndex('CA_Linear'), 3, a, b, c, d],
    key: 'ca_linear_ineq'
  };
});
registerGen('CA_Linear', (rng)=> {
  const h = randInt(rng, 3, 9);
  const k = randInt(rng, 3, 9);

  const q = [
    `Graph the system and list the vertices of the feasible region:`,
    `\\[`,
    `\\begin{cases}`,
    `x \\ge 0\\\\`,
    `y \\ge 0\\\\`,
    `${k}x + ${h}y \\le ${h*k}`,
    `\\end{cases}`,
    `\\]`
  ].join('<br>');

  const a = `Vertices: \\((0,0)\\), \\((${h},0)\\), \\((0,${k})\\).`;

  const steps = [
    `Boundary lines are \\(x=0\\), \\(y=0\\), and \\(${k}x+${h}y=${h*k}\\). Shade the side that satisfies each inequality.`,
    `Find intercepts of \\(${k}x+${h}y=${h*k}\\): set \\(y=0\\Rightarrow x=${h}\\); set \\(x=0\\Rightarrow y=${k}\\).`,
    `The feasible region is the triangle in the first quadrant bounded by those lines.`,
    `Vertices come from intersections: \\((0,0)\\), \\((${h},0)\\), and \\((0,${k})\\).`
  ];

  return {
    q, a, steps,
    vec: [unitIndex('CA_Linear'), 91, h, k],
    key: 'ca_linear_feasible_triangle'
  };
});
registerGen('CA_Linear', (rng)=> {
  const h = randInt(rng, 4, 10);
  const k = randInt(rng, 3, 9);
  const p = randInt(rng, 1, 6);
  const qcoef = randInt(rng, 1, 6);

  const verts = [
    {x:0, y:0},
    {x:h, y:0},
    {x:0, y:k},
  ];
  const vals = verts.map(v => ({...v, z: p*v.x + qcoef*v.y}));
  vals.sort((a,b)=> b.z - a.z);
  const best = vals[0];

  const q = [
    `For the feasible region below, find the maximum value of \\(P=${p}x+${qcoef}y\\) and where it occurs:`,
    `\\[`,
    `\\begin{cases}`,
    `x \\ge 0\\\\`,
    `y \\ge 0\\\\`,
    `${k}x + ${h}y \\le ${h*k}`,
    `\\end{cases}`,
    `\\]`
  ].join('<br>');

  const a = `Maximum \\(P=${best.z}\\) at \\((${best.x},${best.y})\\).`;

  const steps = [
    `First find the feasible-region vertices (same as the intercepts/axes intersections): \\((0,0)\\), \\((${h},0)\\), \\((0,${k})\\).`,
    `Evaluate \\(P=${p}x+${qcoef}y\\) at each vertex:`,
    `\\(P(0,0)=0\\), \\(P(${h},0)=${p*h}\\), \\(P(0,${k})=${qcoef*k}\\).`,
    `Compare the values. The largest is \\(P=${best.z}\\) at \\((${best.x},${best.y})\\).`
  ];

  return {
    q, a, steps,
    vec: [unitIndex('CA_Linear'), 92, h, k, p, qcoef, best.x, best.y],
    key: 'ca_linear_optimize_triangle'
  };
});
registerGen('CA_Linear', (rng)=> {
  const h = randInt(rng, 4, 9);
  const k = randInt(rng, 4, 9);
  const m = randInt(rng, Math.max(h,k)+1, h+k-1); // ensures both intersections exist

  const xTop = m - k;   // intersection with y = k
  const yRight = m - h; // intersection with x = h

  const q = [
    `Graph the system and list the vertices of the feasible region:`,
    `\\[`,
    `\\begin{cases}`,
    `0 \\le x \\le ${h}\\\\`,
    `0 \\le y \\le ${k}\\\\`,
    `x+y \\le ${m}`,
    `\\end{cases}`,
    `\\]`
  ].join('<br>');

  const a = `Vertices: \\((0,0)\\), \\((${h},0)\\), \\((${h},${yRight})\\), \\((${xTop},${k})\\), \\((0,${k})\\).`;

  const steps = [
    `Start with the rectangle from \\(0\\le x\\le ${h}\\) and \\(0\\le y\\le ${k}\\).`,
    `Add the diagonal boundary \\(x+y=${m}\\). Keep the half-plane \\(x+y\\le ${m}\\) (the side containing the origin).`,
    `Find where \\(x+y=${m}\\) hits the rectangle:`,
    `• with \\(x=${h}\\): \\(y=${m}-${h}=${yRight}\\).`,
    `• with \\(y=${k}\\): \\(x=${m}-${k}=${xTop}\\).`,
    `So the clipped polygon has vertices \\((0,0)\\), \\((${h},0)\\), \\((${h},${yRight})\\), \\((${xTop},${k})\\), \\((0,${k})\\).`
  ];

  return {
    q, a, steps,
    vec: [unitIndex('CA_Linear'), 93, h, k, m],
    key: 'ca_linear_feasible_rectdiag'
  };
});
registerGen('CA_Linear', (rng)=> {
  const d = 2 * randInt(rng, 1, 5); // even so d/2 is integer
  let b = randInt(rng, 7, 15);
  // enforce (b + d) divisible by 3 so intersection is nice
  for(let tries=0; tries<20 && ((b + d) % 3 !== 0); tries++){
    b = randInt(rng, 7, 15);
  }
  const xi = (b + d) / 3;
  const yi = (2*b - d) / 3;

  const q = [
    `Graph the system and list the vertices of the feasible region:`,
    `\\[`,
    `\\begin{cases}`,
    `x \\ge 0\\\\`,
    `y \\ge 0\\\\`,
    `y \\le -x + ${b}\\\\`,
    `y \\ge 2x - ${d}`,
    `\\end{cases}`,
    `\\]`
  ].join('<br>');

  const a = `Vertices: \\((0,0)\\), \\((${d/2},0)\\), \\((${xi},${yi})\\), \\((0,${b})\\).`;

  const steps = [
    `Draw boundary lines \\(y=-x+${b}\\) and \\(y=2x-${d}\\) along with the axes \\(x=0\\) and \\(y=0\\).`,
    `The region must be in the first quadrant, below \\(y=-x+${b}\\), and above \\(y=2x-${d}\\).`,
    `Find key intersections:`,
    `• \\(y=2x-${d}\\) with \\(y=0\\): \\(0=2x-${d}\\Rightarrow x=${d/2}\\), so \\((${d/2},0)\\).`,
    `• \\(y=-x+${b}\\) with \\(x=0\\): \\((0,${b})\\).`,
    `• Intersection of the two lines: solve \\(2x-${d}=-x+${b}\\Rightarrow 3x=${b+d}\\Rightarrow x=${xi}\\).`,
    `  Then \\(y=2x-${d}=2(${xi})-${d}=${yi}\\), so \\((${xi},${yi})\\).`,
    `Together with the origin, these are the vertices: \\((0,0)\\), \\((${d/2},0)\\), \\((${xi},${yi})\\), \\((0,${b})\\).`
  ];

  return {
    q, a, steps,
    vec: [unitIndex('CA_Linear'), 94, b, d, xi, yi],
    key: 'ca_linear_feasible_quad'
  };
});
registerGen('CA_Linear', (rng)=> {
  const a = pick(rng, [-3,-2,-1,2,3,4]);
  const h = randInt(rng, -5, 6);
  const k = randInt(rng, -5, 6);

  const inner = (h===0 ? 'x' : `x${fmtSigned(-h)}`);
  const q = `For \\(f(x)=${a}|${inner}|${fmtSigned(k)}\\), state the vertex and describe the transformations from \\(y=|x|\\).`;
  const vertex = `(${h},${k})`;

  const steps = [
    `Write \\(f(x)=a|x-h|+k\\). Here \\(a=${a}\\), \\(h=${h}\\), \\(k=${k}\\).`,
    `Vertex occurs at \\(x=h\\). So the vertex is \\((${h},${k})\\).`,
    `Transformations from \\(y=|x|\\):`,
    `• shift right/left by ${h} (right if \\(h>0\\), left if \\(h<0\\));`,
    `• vertical stretch/compression by factor \\(|a|=${Math.abs(a)}\\);`,
    (a < 0 ? `• reflect across the \\(x\\)-axis (since \\(a<0\\));` : `• no reflection (since \\(a>0\\));`),
    `• shift up/down by ${k} (up if \\(k>0\\), down if \\(k<0\\)).`
  ];

  return {
    q,
    a: `Vertex: \\(${vertex}\\).`,
    steps,
    vec: [unitIndex('CA_Linear'), 95, a, h, k],
    key: 'ca_abs_transform'
  };
});
registerGen('CA_Linear', (rng)=> {
  const a = pick(rng, [-3,-2,-1,2,3,4]);
  const h = randInt(rng, -4, 5);
  const k = randInt(rng, -4, 5);

  const inner = (h===0 ? 'x' : `x${fmtSigned(-h)}`);
  const q = `Write \\(f(x)=${a}|${inner}|${fmtSigned(k)}\\) as a piecewise function.`;

  // Build linear expressions without relying on cleanCoefficientsAndSpacing (keep generators self-contained)
  const lin = (m, b)=> {
    const mPart = (m === 0) ? '' : (m === 1 ? 'x' : (m === -1 ? '-x' : `${m}x`));
    const bPart = (b === 0) ? '' : (b > 0 ? `+${b}` : `${b}`);
    const out = (mPart || bPart) ? (mPart + bPart) : '0';
    return out;
  };

  // For x < h: f(x) = a|x-h| + k = a(-(x-h)) + k = -a x + (a h + k)
  const leftExpr  = lin(-a, a*h + k);
  // For x >= h: f(x) = a(x-h) + k = a x + (-a h + k)
  const rightExpr = lin(a, -a*h + k);

  const aStr = [
    `\\(f(x)=\\begin{cases}`,
    `${leftExpr}, & x < ${h}\\\\`,
    `${rightExpr}, & x \\ge ${h}`,
    `\\end{cases}\\)`
  ].join('');

  const steps = [
    `Use \\(|x-h|=\\begin{cases}-(x-h), & x < h\\\\ (x-h), & x\\ge h\\end{cases}\\).`,
    `For \\(x<${h}\\): \\(f(x)=${a}(-(x-${h}))+${k}=-${a}(x-${h})+${k}\\Rightarrow ${leftExpr}\\).`,
    `For \\(x\\ge ${h}\\): \\(f(x)=${a}(x-${h})+${k}\\Rightarrow ${rightExpr}\\).`
  ];

  return {
    q,
    a: aStr,
    steps,
    vec: [unitIndex('CA_Linear'), 96, a, h, k],
    key: 'ca_abs_piecewise'
  };
});
registerGen('CA_Linear', (rng)=> {
  const a = pick(rng, [2,3,4]);
  const r = randInt(rng, 1, 5);
  const k = -a * r;
  const h = randInt(rng, -5, 6);

  const inner = (h===0 ? 'x' : `x${fmtSigned(-h)}`);
  const q = `Find the \\(x\\)-intercepts and \\(y\\)-intercept of \\(f(x)=${a}|${inner}|${fmtSigned(k)}\\).`;

  const yInt = a*Math.abs(h) + k;
  const x1 = h - r;
  const x2 = h + r;

  const aStr = `\\(x\\)-intercepts: \\(x=${x1}\\) and \\(x=${x2}\\).  \\(y\\)-intercept: \\(f(0)=${yInt}\\).`;

  const steps = [
    `\\(y\\)-intercept: evaluate \\(f(0)=${a}|0-${h}|${fmtSigned(k)}=${a}|${h}|${fmtSigned(k)}=${a*Math.abs(h)}${fmtSigned(k)}=${yInt}\\).`,
    `\\(x\\)-intercepts: set \\(f(x)=0\\):`,
    `\\(${a}|x-${h}|${fmtSigned(k)}=0\\Rightarrow ${a}|x-${h}|=${-k}\\Rightarrow |x-${h}|=${-k}/${a}=${r}\\).`,
    `So \\(x-${h}=\\pm ${r}\\Rightarrow x=${h}\\pm ${r}\\Rightarrow x=${x1}, ${x2}\\).`,
    `Graph checklist: vertex at \\((${h},${k})\\), opens up (since \\(a>0\\)), and crosses the \\(x\\)-axis at the intercepts above.`
  ];

  return {
    q, a: aStr, steps,
    vec: [unitIndex('CA_Linear'), 97, a, h, k, r],
    key: 'ca_abs_intercepts'
  };
});
registerGen('CA_Quadratics', (rng)=> {
  const a = pick(rng, [-3, -2, -1, 1, 2, 3]);
  const h = randInt(rng, -5, 5);
  const k = randInt(rng, -8, 8);
  
  return {
    q: `Find the vertex of \\(f(x) = ${a}(x - ${h})^2 + ${k}\\).`,
    a: `Vertex: \\((${h}, ${k})\\)`,
    steps: [
      `The function is in vertex form: \\(f(x) = a(x-h)^2 + k\\).`,
      `Vertex is at \\((h, k) = (${h}, ${k})\\).`,
      `Opens ${a > 0 ? 'upward' : 'downward'} since \\(a = ${a}\\).`
    ],
    vec: [unitIndex('CA_Quadratics'), 1, a, h, k],
    key: 'ca_quad_vertex_form'
  };
});
registerGen('CA_Quadratics', (rng)=> {
  const h = randInt(rng, -4, 4);
  const k = randInt(rng, -6, 6);
  const b = -2 * h;
  const c = h * h + k;
  
  return {
    q: `Complete the square: \\(x^2 + ${b}x + ${c}\\).`,
    a: `\\((x - ${h})^2 + ${k}\\)`,
    steps: [
      `Take half of \\(${b}\\): \\(\\frac{${b}}{2} = ${b/2}\\).`,
      `Square it: \\((${b/2})^2 = ${(b/2)**2}\\).`,
      `Rewrite: \\(x^2 + ${b}x + ${(b/2)**2} - ${(b/2)**2} + ${c} = (x - ${h})^2 + ${k}\\).`
    ],
    vec: [unitIndex('CA_Quadratics'), 2, h, k],
    key: 'ca_complete_square'
  };
});
registerGen('CA_Quadratics', (rng)=> {
  const a = randInt(rng, 1, 3);
  const b = randInt(rng, -8, 8);
  const c = randInt(rng, -10, 10);
  const disc = b*b - 4*a*c;
  
  let answer;
  if (disc < 0) {
    answer = `No real solutions (discriminant = \\(${disc}\\) < 0)`;
  } else if (disc === 0) {
    // One solution (exact)
    answer = `\\(x = ${exactFrac(-b, 2*a)}\\)`;
  } else if (isPerfectSquare(disc)) {
    // Two exact solutions
    const sqrtDisc = Math.sqrt(disc);
    const x1 = exactFrac(-b + sqrtDisc, 2*a);
    const x2 = exactFrac(-b - sqrtDisc, 2*a);
    answer = `\\(x = ${x1}\\) or \\(x = ${x2}\\)`;
  } else {
    // Radical form
    const rad = simplifyRadical(disc);
    answer = `\\(x = \\frac{${-b} \\pm ${rad}}{${2*a}}\\)`;
  }
  
  return {
    q: `Solve using the quadratic formula: \\(${a === 1 ? '' : a}x^2 ${b >= 0 ? '+' : ''}${b}x ${c >= 0 ? '+' : ''}${c} = 0\\).`,
    a: answer,
    steps: [
      `Quadratic formula: \\(x = \\frac{-b \\pm \\sqrt{b^2-4ac}}{2a}\\).`,
      `Here \\(a=${a}, b=${b}, c=${c}\\).`,
      `Discriminant: \\(b^2-4ac = ${b}^2 - 4(${a})(${c}) = ${disc}\\).`,
      disc < 0 ? `Since discriminant < 0, no real solutions.` : 
      disc === 0 ? `Since discriminant = 0, one solution: \\(x = \\frac{-b}{2a}\\).` :
      `\\(x = \\frac{${-b} \\pm \\sqrt{${disc}}}{${2*a}}${isPerfectSquare(disc) ? '' : ' = \\frac{'+(-b)+' \\pm '+simplifyRadical(disc)+'}{'+2*a+'}'}\\).`
    ],
    vec: [unitIndex('CA_Quadratics'), 3, a, b, c],
    key: 'ca_quad_formula'
  };
});
registerGen('CA_Quadratics', (rng)=> {
  const P = pick(rng, [40, 50, 60, 80, 100]);
  const optW = P / 4;
  const optA = optW * optW;
  
  return {
    q: `A rectangle has perimeter ${P} ft. Express the area \\(A\\) as a function of width \\(w\\), then find the maximum area.`,
    a: `\\(A(w) = w\\left(${P/2} - w\\right)\\); Maximum area = \\(${optA}\\) ft² at \\(w = ${optW}\\) ft`,
    steps: [
      `Perimeter: \\(2w + 2l = ${P}\\Rightarrow l = ${P/2} - w\\).`,
      `Area: \\(A = wl = w(${P/2} - w) = ${P/2}w - w^2\\).`,
      `This is a downward parabola with vertex at \\(w = ${optW}\\).`,
      `Maximum area: \\(A(${optW}) = ${optW}(${P/2 - optW}) = ${optA}\\) ft².`
    ],
    vec: [unitIndex('CA_Quadratics'), 4, P],
    key: 'ca_quad_app_area'
  };
});
registerGen('CA_Polynomials', (rng)=> {
  const a = pick(rng, [2, 3, 4, 5]);
  const b = pick(rng, [2, 3, 4, 5]);
  
  return {
    q: `Factor completely: \\(${a*a}x^2 - ${b*b}\\).`,
    a: `\\((${a}x - ${b})(${a}x + ${b})\\)`,
    steps: [
      `Recognize difference of squares: \\(a^2 - b^2 = (a-b)(a+b)\\).`,
      `Here \\(a = ${a}x\\) and \\(b = ${b}\\).`,
      `Result: \\((${a}x - ${b})(${a}x + ${b})\\).`
    ],
    vec: [unitIndex('CA_Polynomials'), 1, a, b],
    key: 'ca_poly_diff_squares'
  };
});
registerGen('CA_Polynomials', (rng)=> {
  const r = randInt(rng, -3, 3);
  const a = randInt(rng, 1, 4);
  const b = randInt(rng, -6, 6);
  // Construct polynomial that has (x - r) as factor
  // P(x) = (x - r)(ax + b) = ax^2 + bx - arx - br = ax^2 + (b-ar)x - br
  const c2 = a;
  const c1 = b - a*r;
  const c0 = -b*r;
  
  return {
    q: `Use synthetic division to divide \\(${c2}x^2 + ${c1}x + ${c0}\\) by \\(x - ${r}\\).`,
    a: `Quotient: \\(${a}x + ${b}\\), Remainder: 0`,
    steps: [
      `Set up synthetic division with \\(r = ${r}\\) and coefficients [${c2}, ${c1}, ${c0}].`,
      `Bring down ${c2}, multiply by ${r}, add to next coefficient.`,
      `Result: quotient is \\(${a}x + ${b}\\) with remainder 0.`
    ],
    vec: [unitIndex('CA_Polynomials'), 2, r, a, b],
    key: 'ca_poly_synth_div'
  };
});
registerGen('CA_Polynomials', (rng)=> {
  const r1 = randInt(rng, -3, 3);
  const r2 = randInt(rng, -3, 3);
  const r3 = randInt(rng, -3, 3);
  // P(x) = (x-r1)(x-r2)(x-r3)
  
  return {
    q: `Find all zeros of \\(P(x) = (x - ${r1})(x - ${r2})(x - ${r3})\\).`,
    a: `\\(x = ${r1}, ${r2}, ${r3}\\)`,
    steps: [
      `Set each factor equal to zero.`,
      `\\(x - ${r1} = 0\\Rightarrow x = ${r1}\\).`,
      `\\(x - ${r2} = 0\\Rightarrow x = ${r2}\\).`,
      `\\(x - ${r3} = 0\\Rightarrow x = ${r3}\\).`
    ],
    vec: [unitIndex('CA_Polynomials'), 3, r1, r2, r3],
    key: 'ca_poly_zeros'
  };
});
registerGen('CA_Polynomials', (rng)=> {
  const p = pick(rng, [1, 2, 3, 4, 6]);
  const q = pick(rng, [1, 2, 3]);
  
  return {
    q: `List all possible rational zeros of \\(P(x) = ${q}x^3 - 5x^2 + ${p}\\) using the Rational Root Theorem.`,
    a: `\\(\\pm 1, \\pm ${p}${q > 1 ? `, \\pm \\frac{1}{${q}}, \\pm \\frac{${p}}{${q}}` : ''}\\)`,
    steps: [
      `Rational Root Theorem: possible zeros are \\(\\pm\\frac{p}{q}\\).`,
      `Factors of constant term (${p}): \\(\\pm 1, \\pm ${p}\\).`,
      `Factors of leading coefficient (${q}): \\(\\pm 1${q > 1 ? `, \\pm ${q}` : ''}\\).`,
      `All combinations give the list above.`
    ],
    vec: [unitIndex('CA_Polynomials'), 4, p, q],
    key: 'ca_poly_rational_root'
  };
});
registerGen('CA_Polynomials', (rng)=> {
  const a = pick(rng, [1,2]);
  const x0 = randInt(rng, 1, 7);
  let c = randInt(rng, -2, 3);
  if(x0 + c <= 0) c = 1; // ensure RHS positive for intended solution
  const b = (x0 + c)**2 - a*x0;

  const x1 = (a - 2*c) - x0; // other quadratic root
  const candidates = [x0, x1].filter(x => Number.isFinite(x));
  const good = candidates.filter(x => x + c >= 0 && a*x + b >= 0 && Math.abs(Math.sqrt(a*x + b) - (x + c)) < 1e-9);

  const sol = (good.length === 0) ? '\\(\\varnothing\\)' :
    (good.length === 1 ? `\\(x=${good[0]}\\)` : `\\(x=${good[0]}\\) or \\(x=${good[1]}\\)`);

  const q = `Solve the radical equation: \\(\\sqrt{${a}x${fmtSigned(b)}} = x${fmtSigned(c)}\\).`;
  const aStr = `Solution: ${sol}.`;

  const steps = [
    `Domain: require \\(${a}x${fmtSigned(b)}\\ge 0\\) and \\(x${fmtSigned(c)}\\ge 0\\) (since the square root is nonnegative).`,
    `Square both sides: \\(${a}x${fmtSigned(b)} = (x${fmtSigned(c)})^2\\).`,
    `Expand: \\(${a}x${fmtSigned(b)} = x^2 ${fmtSigned(2*c)}x ${fmtSigned(c*c)}\\).`,
    `Move all terms to one side: \\(0=x^2 ${fmtSigned(2*c - a)}x ${fmtSigned(c*c - b)}\\).`,
    `Solve the quadratic (factor or quadratic formula) to get candidate solutions, then **check** in the original equation.`,
    (good.length ? `After checking, the valid solution(s): ${sol}.` : `After checking, no candidates work (all extraneous).`)
  ];

  return {
    q, a: aStr, steps,
    vec: [unitIndex('CA_Polynomials'), 161, a, b, c, x0, x1],
    key: 'ca_poly_radical_solve'
  };
});
registerGen('CA_Polynomials', (rng)=> {
  const a = pick(rng, [1,2]);
  const d = randInt(rng, 1, 6);
  const x0 = randInt(rng, d, d+6); // ensure x-d >=0 for intended solution
  const b = (x0 - d)**2 - a*x0;

  const q = `Solve the radical equation: \\(\\sqrt{${a}x${fmtSigned(b)}} = x-${d}\\).`;

  // candidates from quadratic: ax+b = (x-d)^2
  // x^2 + (-2d-a)x + (d^2 - b)=0
  const x1 = (a + 2*d) - x0;
  const candidates = [x0, x1];
  const good = candidates.filter(x => x - d >= 0 && a*x + b >= 0 && Math.abs(Math.sqrt(a*x + b) - (x - d)) < 1e-9);

  const sol = (good.length === 0) ? '\\(\\varnothing\\)' :
    (good.length === 1 ? `\\(x=${good[0]}\\)` : `\\(x=${good[0]}\\) or \\(x=${good[1]}\\)`);

  const steps = [
    `Require \\(x-${d}\\ge 0\\Rightarrow x\\ge ${d}\\) and \\(${a}x${fmtSigned(b)}\\ge 0\\).`,
    `Square both sides: \\(${a}x${fmtSigned(b)}=(x-${d})^2\\).`,
    `Expand: \\(${a}x${fmtSigned(b)}=x^2-${2*d}x+${d*d}\\).`,
    `Rearrange to a quadratic and solve for candidate \\(x\\)-values.`,
    `Check each candidate in the original equation to eliminate extraneous solutions.`,
    `Valid solution(s): ${sol}.`
  ];

  return {
    q,
    a: `Solution: ${sol}.`,
    steps,
    vec: [unitIndex('CA_Polynomials'), 162, a, b, d, x0, x1],
    key: 'ca_poly_radical_extraneous'
  };
});
registerGen('CA_Polynomials', (rng)=> {
  const a = pick(rng, [1,2,3]);
  const c = pick(rng, [1,2,3]);
  let x0 = randInt(rng, -2, 7);
  // choose b,d so that ax0+b = cx0+d = t^2
  const t = randInt(rng, 1, 6);
  const b = t*t - a*x0;
  const d = t*t - c*x0;

  const q = `Solve: \\(\\sqrt{${a}x${fmtSigned(b)}}=\\sqrt{${c}x${fmtSigned(d)}}\\).`;

  // after squaring: ax+b = cx+d => (a-c)x = d-b
  let sol;
  if(a === c){
    sol = (b === d) ? 'All real \\(x\\) that keep both radicands \\(\\ge 0\\).' : '\\(\\varnothing\\).';
  }else{
    const x = (d - b) / (a - c);
    // check domain and equality
    const ok = Number.isFinite(x) && (a*x + b >= 0) && (c*x + d >= 0) &&
      (Math.abs(Math.sqrt(a*x + b) - Math.sqrt(c*x + d)) < 1e-9);
    sol = ok ? `\\(x=${fmtDec(x)}\\)` : '\\(\\varnothing\\).';
  }

  const steps = [
    `Both sides are square roots, so require each radicand \\(\\ge 0\\).`,
    `Square both sides: \\(${a}x${fmtSigned(b)}=${c}x${fmtSigned(d)}\\).`,
    `Solve the resulting linear equation for \\(x\\) (if \\(a\\ne c\\)).`,
    `Check the solution in the original equation (domain + equality).`,
    `Answer: ${sol}`
  ];

  return {
    q,
    a: `Solution: ${sol}`,
    steps,
    vec: [unitIndex('CA_Polynomials'), 163, a, b, c, d],
    key: 'ca_poly_radical_bothsides'
  };
});
registerGen('CA_Rational', (rng)=> {
  const a = randInt(rng, -5, 5);
  let b = randInt(rng, -5, 5);
  if (a === b) b = a + 1;
  
  return {
    q: `Find the domain of \\(f(x) = \\frac{x+1}{(x-${a})(x-${b})}\\).`,
    a: `All real numbers except \\(x = ${a}\\) and \\(x = ${b}\\)`,
    steps: [
      `Set denominator ≠ 0: \\((x-${a})(x-${b}) \\neq 0\\).`,
      `This means \\(x \\neq ${a}\\) and \\(x \\neq ${b}\\).`,
      `Domain: \\((-\\infty, ${a}) \\cup (${a}, ${b}) \\cup (${b}, \\infty)\\).`
    ],
    vec: [unitIndex('CA_Rational'), 1, a, b],
    key: 'ca_rational_domain'
  };
});
registerGen('CA_Rational', (rng)=> {
  const a = randInt(rng, -4, 4);
  let b = randInt(rng, -4, 4);
  if (a === b) b = a + 1;
  
  return {
    q: `Find all vertical asymptotes of \\(f(x) = \\frac{2x+3}{(x-${a})(x-${b})}\\).`,
    a: `\\(x = ${a}\\) and \\(x = ${b}\\)`,
    steps: [
      `Vertical asymptotes occur where denominator = 0 and numerator ≠ 0.`,
      `Set \\((x-${a})(x-${b}) = 0\\).`,
      `Vertical asymptotes at \\(x = ${a}\\) and \\(x = ${b}\\).`
    ],
    vec: [unitIndex('CA_Rational'), 2, a, b],
    key: 'ca_rational_vert_asymp'
  };
});
registerGen('CA_Rational', (rng)=> {
  const type = pick(rng, ['same_degree', 'num_lower', 'num_higher']);
  
  if (type === 'same_degree') {
    const a = randInt(rng, 2, 6);
    const b = randInt(rng, 2, 6);
    return {
      q: `Find the horizontal asymptote of \\(f(x) = \\frac{${a}x^2 + 3x + 1}{${b}x^2 - 2x + 5}\\).`,
      a: `\\(y = \\frac{${a}}{${b}}\\)`,
      steps: [
        `Degrees of numerator and denominator are equal (both 2).`,
        `Horizontal asymptote is ratio of leading coefficients: \\(y = \\frac{${a}}{${b}}\\).`
      ],
      vec: [unitIndex('CA_Rational'), 3, a, b, 1],
      key: 'ca_rational_horiz_same'
    };
  } else if (type === 'num_lower') {
    return {
      q: `Find the horizontal asymptote of \\(f(x) = \\frac{3x + 2}{2x^2 + 5x - 1}\\).`,
      a: `\\(y = 0\\)`,
      steps: [
        `Degree of numerator (1) < degree of denominator (2).`,
        `Horizontal asymptote is \\(y = 0\\).`
      ],
      vec: [unitIndex('CA_Rational'), 3, 0, 0, 2],
      key: 'ca_rational_horiz_lower'
    };
  } else {
    return {
      q: `Find the horizontal asymptote of \\(f(x) = \\frac{4x^3 + 2x}{2x^2 + 1}\\).`,
      a: `No horizontal asymptote (oblique asymptote exists)`,
      steps: [
        `Degree of numerator (3) > degree of denominator (2).`,
        `No horizontal asymptote. There is an oblique asymptote instead.`
      ],
      vec: [unitIndex('CA_Rational'), 3, 0, 0, 3],
      key: 'ca_rational_horiz_higher'
    };
  }
});
registerGen('CA_Rational', (rng)=> {
  const a = randInt(rng, -4, 4);
  const b = randInt(rng, 1, 5);
  const yHole = (a + b) / (2 * a + 1);
  
  return {
    q: `Identify any holes in \\(f(x) = \\frac{(x-${a})(x+${b})}{(x-${a})(2x+1)}\\).`,
    a: `Hole at \\(x = ${a}\\) with \\(y = \\frac{${a}+${b}}{${2*a}+1} = ${yHole.toFixed(3)}\\)`,
    steps: [
      `Factor and cancel common factors: \\(\\frac{x+${b}}{2x+1}\\).`,
      `Canceled factor \\((x-${a})\\) creates a hole at \\(x = ${a}\\).`,
      `Substitute \\(x=${a}\\) into simplified form: \\(y = \\frac{${a}+${b}}{2(${a})+1} = \\frac{${a+b}}{${2*a+1}}\\).`
    ],
    vec: [unitIndex('CA_Rational'), 4, a, b],
    key: 'ca_rational_holes'
  };
});
registerGen('CA_ExpLog', (rng)=> {
  const base = pick(rng, [2, 3, 4, 5]);
  const pow = randInt(rng, 2, 5);
  const val = Math.pow(base, pow);
  
  return {
    q: `Solve for \\(x\\): \\(${base}^x = ${val}\\).`,
    a: `\\(x = ${pow}\\)`,
    steps: [
      `Recognize that \\(${val} = ${base}^${pow}\\).`,
      `Therefore \\(${base}^x = ${base}^${pow}\\).`,
      `Since bases are equal: \\(x = ${pow}\\).`
    ],
    vec: [unitIndex('CA_ExpLog'), 1, base, pow],
    key: 'ca_exp_solve_simple'
  };
});
registerGen('CA_ExpLog', (rng)=> {
  const a = randInt(rng, 2, 5);
  const b = randInt(rng, 2, 5);
  const c = randInt(rng, 2, 4);
  
  return {
    q: `Expand using logarithm properties: \\(\\log\\left(\\frac{x^${a}y^${b}}{z^${c}}\\right)\\).`,
    a: `\\(${a}\\log(x) + ${b}\\log(y) - ${c}\\log(z)\\)`,
    steps: [
      `Use quotient rule: \\(\\log\\left(\\frac{A}{B}\\right) = \\log(A) - \\log(B)\\).`,
      `Use product rule: \\(\\log(xy) = \\log(x) + \\log(y)\\).`,
      `Use power rule: \\(\\log(x^n) = n\\log(x)\\).`,
      `Result: \\(${a}\\log(x) + ${b}\\log(y) - ${c}\\log(z)\\).`
    ],
    vec: [unitIndex('CA_ExpLog'), 2, a, b, c],
    key: 'ca_log_expand'
  };
});
registerGen('CA_ExpLog', (rng)=> {
  const a = randInt(rng, 2, 4);
  const b = randInt(rng, 2, 4);
  
  return {
    q: `Condense into a single logarithm: \\(${a}\\log(x) - ${b}\\log(y)\\).`,
    a: `\\(\\log\\left(\\frac{x^${a}}{y^${b}}\\right)\\)`,
    steps: [
      `Use power rule in reverse: \\(n\\log(x) = \\log(x^n)\\).`,
      `This gives: \\(\\log(x^${a}) - \\log(y^${b})\\).`,
      `Use quotient rule in reverse: \\(\\log(A) - \\log(B) = \\log(A/B)\\).`,
      `Result: \\(\\log\\left(\\frac{x^${a}}{y^${b}}\\right)\\).`
    ],
    vec: [unitIndex('CA_ExpLog'), 3, a, b],
    key: 'ca_log_condense'
  };
});
registerGen('CA_ExpLog', (rng)=> {
  const base = pick(rng, [2, 3, 5, 10]);
  const a = randInt(rng, 1, 4);
  const val = randInt(rng, 2, 5);
  const ans = Math.pow(base, val) - a;
  
  return {
    q: `Solve for \\(x\\): \\(\\log_{${base}}(x + ${a}) = ${val}\\).`,
    a: `\\(x = ${ans}\\)`,
    steps: [
      `Convert to exponential form: \\(x + ${a} = ${base}^${val}\\).`,
      `Calculate: \\(${base}^${val} = ${Math.pow(base, val)}\\).`,
      `Solve: \\(x = ${Math.pow(base, val)} - ${a} = ${ans}\\).`
    ],
    vec: [unitIndex('CA_ExpLog'), 4, base, a, val],
    key: 'ca_log_solve'
  };
});
registerGen('CA_ExpLog', (rng)=> {
  const P0 = pick(rng, [100, 200, 500, 1000]);
  const r = pick(rng, [0.03, 0.05, 0.08, 0.10]);
  const t = pick(rng, [5, 10, 15, 20]);
  const Pt = P0 * Math.exp(r * t);
  
  return {
    q: `A population of ${P0} grows continuously at rate ${(r*100).toFixed(1)}% per year. Find the population after ${t} years.`,
    a: `Approximately ${Pt.toFixed(0)}`,
    steps: [
      `Use formula: \\(P(t) = P_0 e^{rt}\\).`,
      `Here \\(P_0 = ${P0}\\), \\(r = ${r}\\), \\(t = ${t}\\).`,
      `\\(P(${t}) = ${P0} \\cdot e^{${r} \\cdot ${t}} \\approx ${Pt.toFixed(0)}\\).`
    ],
    vec: [unitIndex('CA_ExpLog'), 5, P0, Math.round(r*100), t],
    key: 'ca_exp_growth'
  };
});
registerGen('CA_ExpLog', (rng)=> {
  const base = pick(rng, [3, 5, 7]);
  const val = pick(rng, [10, 15, 20, 25]);
  
  return {
    q: `Evaluate \\(\\log_{${base}}(${val})\\) using the change of base formula (round to 3 decimals).`,
    a: `\\(${(Math.log(val) / Math.log(base)).toFixed(3)}\\)`,
    steps: [
      `Change of base formula: \\(\\log_b(a) = \\frac{\\ln(a)}{\\ln(b)}\\).`,
      `\\(\\log_{${base}}(${val}) = \\frac{\\ln(${val})}{\\ln(${base})}\\).`,
      `Calculate: \\(\\frac{${Math.log(val).toFixed(4)}}{${Math.log(base).toFixed(4)}} \\approx ${(Math.log(val) / Math.log(base)).toFixed(3)}\\).`
    ],
    vec: [unitIndex('CA_ExpLog'), 6, base, val],
    key: 'ca_change_base'
  };
});
registerGen('CA_Systems', genCASystemClassification);
registerGen('CA_Systems', (rng)=> {
  const x = randInt(rng, -3, 5);
  const y = randInt(rng, -3, 5);
  const a = randInt(rng, 2, 4);
  const b = randInt(rng, 1, 3);
  const c = a * x + b * y;
  const d = x + y;
  
  return {
    q: `Solve the system using substitution: \\(\\begin{cases} ${a}x + ${b}y = ${c} \\\\ x + y = ${d} \\end{cases}\\)`,
    a: `\\(x = ${x}, y = ${y}\\)`,
    steps: [
      `From equation 2: \\(x = ${d} - y\\).`,
      `Substitute into equation 1: \\(${a}(${d} - y) + ${b}y = ${c}\\).`,
      `Solve for \\(y\\): \\(y = ${y}\\).`,
      `Back-substitute: \\(x = ${d} - ${y} = ${x}\\).`
    ],
    vec: [unitIndex('CA_Systems'), 1, a, b, c, d],
    key: 'ca_system_sub'
  };
});
registerGen('CA_Systems', (rng)=> {
  const x = randInt(rng, -4, 4);
  const y = randInt(rng, -4, 4);
  const a1 = randInt(rng, 2, 4);
  const b1 = randInt(rng, 1, 3);
  const a2 = randInt(rng, 1, 3);
  const b2 = randInt(rng, 2, 4);
  const c1 = a1 * x + b1 * y;
  const c2 = a2 * x + b2 * y;
  
  return {
    q: `Solve using elimination: \\(\\begin{cases} ${a1}x + ${b1}y = ${c1} \\\\ ${a2}x + ${b2}y = ${c2} \\end{cases}\\)`,
    a: `\\(x = ${x}, y = ${y}\\)`,
    steps: [
      `Multiply equations to align coefficients, then add/subtract.`,
      `After elimination, solve for one variable.`,
      `Back-substitute to find the other variable.`,
      `Solution: \\(x = ${x}, y = ${y}\\).`
    ],
    vec: [unitIndex('CA_Systems'), 2, a1, b1, a2, b2],
    key: 'ca_system_elim'
  };
});
registerGen('CA_Systems', (rng)=> {
  const x = randInt(rng, 1, 3);
  const y = randInt(rng, 1, 3);
  const z = randInt(rng, 1, 3);
  const sum = x + y + z;
  
  return {
    q: `Solve: \\(\\begin{cases} x + y + z = ${sum} \\\\ x = ${x} \\\\ y = ${y} \\end{cases}\\)`,
    a: `\\(x = ${x}, y = ${y}, z = ${z}\\)`,
    steps: [
      `From equation 2: \\(x = ${x}\\).`,
      `From equation 3: \\(y = ${y}\\).`,
      `Substitute into equation 1: \\(${x} + ${y} + z = ${sum}\\).`,
      `Solve: \\(z = ${z}\\).`
    ],
    vec: [unitIndex('CA_Systems'), 3, x, y, z],
    key: 'ca_system_3var_simple'
  };
});
registerGen('CA_Systems', (rng)=> {
  const total = pick(rng, [100, 120, 150]);
  const x = randInt(rng, 30, 70);
  const y = total - x;
  const price1 = pick(rng, [3, 4, 5]);
  const price2 = pick(rng, [6, 7, 8]);
  const revenue = x * price1 + y * price2;
  
  return {
    q: `A store sells Type A items at $${price1} and Type B at $${price2}. If ${total} items are sold for $${revenue}, how many of each type were sold?`,
    a: `Type A: ${x}, Type B: ${y}`,
    steps: [
      `Let \\(x\\) = Type A items, \\(y\\) = Type B items.`,
      `Equation 1: \\(x + y = ${total}\\).`,
      `Equation 2: \\(${price1}x + ${price2}y = ${revenue}\\).`,
      `Solve the system to get \\(x = ${x}, y = ${y}\\).`
    ],
    vec: [unitIndex('CA_Systems'), 4, total, price1, price2],
    key: 'ca_system_app_mixture'
  };
});
registerGen('CA_Functions', (rng)=> {
  const a = pick(rng, [-3,-2,-1,1,2,3]);
  const b = randInt(rng, -6, 6);
  const c = randInt(rng, -8, 8);

  // For f(x)=ax^2+bx+c, difference quotient simplifies to 2ax + ah + b
  const dqX = 2*a;
  const dqH = a;
  const dqConst = b;

  const fTex = mwPoly2Tex(a,b,c);
  const dqTex = `${dqX===0?'':(dqX===1?'x':(dqX===-1?'-x':`${dqX}x`))}` +
                `${dqH===0?'':(dqX===0? (dqH===1?'h':(dqH===-1?'-h':`${dqH}h`)) : ` ${dqH<0?'-':'+'} ${Math.abs(dqH)===1?'':Math.abs(dqH)}h`)}` +
                `${dqConst===0?'':((dqX===0&&dqH===0)?`${dqConst}`:` ${dqConst<0?'-':'+'} ${Math.abs(dqConst)}`)}`;

  return {
    q: `Evaluate and simplify the difference quotient \\(\\dfrac{f(x+h)-f(x)}{h}\\) (assume \\(h\\neq 0\\)) for \\(f(x)=${fTex}\\).`,
    a: `\\(\\dfrac{f(x+h)-f(x)}{h} = ${dqTex}\\).`,
    steps: [
      `Compute \\(f(x+h) = ${a}(x+h)^2 ${fmtSigned(b)}(x+h) ${fmtSigned(c)}\\).`,
      `Expand: \\(f(x+h)= ${a}(x^2+2xh+h^2) ${fmtSigned(b)}x ${fmtSigned(b)}h ${fmtSigned(c)}\\).`,
      `Subtract \\(f(x)=${fTex}\\): \\(f(x+h)-f(x)= ${2*a}xh ${fmtSigned(a)}h^2 ${fmtSigned(b)}h\\).`,
      `Divide by \\(h\\): \\(\\dfrac{f(x+h)-f(x)}{h} = ${2*a}x ${fmtSigned(a)}h ${fmtSigned(b)}\\).`
    ],
    vec: [unitIndex('CA_Functions'), 81, a,b,c,0,0],
    key:'ca_difference_quotient_quad'
  };
});
registerGen('CA_Functions', (rng)=> {
  const A = pick(rng, [-3,-2,-1,2,3]);
  const B = pick(rng, [1,2,3]);
  const h = randInt(rng, -4, 4);
  const k = randInt(rng, -4, 4);

  const inside = (h === 0) ? `${B}x` : (h > 0 ? `${B}(x-${h})` : `${B}(x+${Math.abs(h)})`);
  const expr = `y=${A===1?'':(A===-1?'-':A)}f\\!\\left(${inside}\\right)${k===0?'':(k>0?`+${k}`:`${k}`)}`;

  const horizScale = (B === 1) ? null : `\\text{Horizontal compression by factor }\\frac{1}{${B}}`;
  const horizShift = (h === 0) ? null : (h > 0 ? `\\text{Shift right }${h}\\text{ units}` : `\\text{Shift left }${Math.abs(h)}\\text{ units}`);
  const vertScale = (Math.abs(A) === 1) ? null : `\\text{Vertical stretch by factor }${Math.abs(A)}`;
  const reflect = (A < 0) ? `\\text{Reflect across the }x\\text{-axis}` : null;
  const vertShift = (k === 0) ? null : (k > 0 ? `\\text{Shift up }${k}\\text{ units}` : `\\text{Shift down }${Math.abs(k)}\\text{ units}`);

  const items = [horizScale, horizShift, reflect, vertScale, vertShift].filter(Boolean);

  return {
    q: `Let \\(y=f(x)\\). Describe the transformations that produce \\(${expr}\\) from \\(y=f(x)\\).`,
    a: `\\(\\begin{aligned}${items.map(s=>s+`\\\\`).join('')}\\end{aligned}\\)`,
    steps: [
      `Start with \\(y=f(x)\\).`,
      ...(B===1?[]:[`Inside factor \\(${B}\\) gives a horizontal scale by \\(\\frac{1}{${B}}\\).`]),
      ...(h===0?[]:[`Inside \\((x${h>0?'-':'+'}${Math.abs(h)})\\) gives a horizontal shift (opposite direction).`]),
      ...(A<0?[`A negative outside flips the graph across the \\(x\\)-axis.`]:[]),
      ...(Math.abs(A)===1?[]:[`Outside factor \\(${Math.abs(A)}\\) scales vertically by ${Math.abs(A)}.`]),
      ...(k===0?[]:[`Adding \\(${k}\\) shifts the graph vertically.`])
    ],
    vec: [unitIndex('CA_Functions'), 82, A,B,h,k,0],
    key:'ca_transformations_generic'
  };
});
registerGen('CA_Functions', (rng)=> {
  const a = randInt(rng, 2, 5);
  const b = randInt(rng, 1, 4);
  const c = randInt(rng, 1, 3);
  
  return {
    q: `Given \\(f(x) = ${a}x + ${b}\\) and \\(g(x) = x^2 - ${c}\\), find \\((f \\circ g)(x)\\).`,
    a: `\\(${a}x^2 - ${a*c} + ${b}\\)`,
    steps: [
      `\\((f \\circ g)(x) = f(g(x))\\).`,
      `Substitute \\(g(x)\\) into \\(f\\): \\(f(x^2 - ${c}) = ${a}(x^2 - ${c}) + ${b}\\).`,
      `Simplify: \\(${a}x^2 - ${a*c} + ${b}\\).`
    ],
    vec: [unitIndex('CA_Functions'), 1, a, b, c],
    key: 'ca_func_compose'
  };
});
registerGen('CA_Functions', (rng)=> {
  const a = pick(rng, [2, 3, 4, 5]);
  const b = randInt(rng, -5, 5);
  
  return {
    q: `Find the inverse of \\(f(x) = ${a}x + ${b}\\).`,
    a: `\\(f^{-1}(x) = \\frac{x - ${b}}{${a}}\\)`,
    steps: [
      `Replace \\(f(x)\\) with \\(y\\): \\(y = ${a}x + ${b}\\).`,
      `Swap \\(x\\) and \\(y\\): \\(x = ${a}y + ${b}\\).`,
      `Solve for \\(y\\): \\(y = \\frac{x - ${b}}{${a}}\\).`,
      `Therefore \\(f^{-1}(x) = \\frac{x - ${b}}{${a}}\\).`
    ],
    vec: [unitIndex('CA_Functions'), 2, a, b],
    key: 'ca_func_inverse'
  };
});
registerGen('CA_Functions', (rng)=> {
  const a = randInt(rng, 1, 5);
  
  return {
    q: `Given \\(f(x) = \\sqrt{x}\\) and \\(g(x) = x - ${a}\\), find the domain of \\((f \\circ g)(x)\\).`,
    a: `\\([${a}, \\infty)\\)`,
    steps: [
      `\\((f \\circ g)(x) = f(g(x)) = \\sqrt{x - ${a}}\\).`,
      `For square root to be defined: \\(x - ${a} \\geq 0\\).`,
      `Therefore \\(x \\geq ${a}\\).`,
      `Domain: \\([${a}, \\infty)\\).`
    ],
    vec: [unitIndex('CA_Functions'), 3, a],
    key: 'ca_func_domain_comp'
  };
});
registerGen('CA_Functions', (rng)=> {
  const a = randInt(rng, -3, 3);
  const b = randInt(rng, 1, 5);
  const c = randInt(rng, 1, 4);
  const testVal = a + randInt(rng, -1, 1);
  
  return {
    q: `Given \\(f(x) = \\begin{cases} x^2 & \\text{if } x < ${a} \\\\ ${b}x + ${c} & \\text{if } x \\geq ${a} \\end{cases}\\), find \\(f(${testVal})\\).`,
    a: testVal < a ? `\\(${testVal * testVal}\\)` : `\\(${b * testVal + c}\\)`,
    steps: [
      testVal < a 
        ? `Since \\(${testVal} < ${a}\\), use first piece: \\(f(${testVal}) = ${testVal}^2 = ${testVal * testVal}\\).`
        : `Since \\(${testVal} \\geq ${a}\\), use second piece: \\(f(${testVal}) = ${b}(${testVal}) + ${c} = ${b * testVal + c}\\).`
    ],
    vec: [unitIndex('CA_Functions'), 4, a, testVal],
    key: 'ca_func_piecewise'
  };
});
