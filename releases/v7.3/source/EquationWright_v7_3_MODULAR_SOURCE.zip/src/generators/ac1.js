// AC1 generator registrations — order frozen by the published registry.
registerGen('AC1_Marginal', (rng)=>{
  const a = mwNZ(rng,1,3), b = pick(rng,[20,30,40,50]), c = pick(rng,[100,200,500]), x0 = pick(rng,[5,10,20]);
  const mc = 2*a*x0 + b;
  return {
    q: `A firm's cost function is \\(C(x) = ${a}x^2 + ${b}x + ${c}\\) dollars. Find the marginal cost at \\(x = ${x0}\\).`,
    a: `\\(C'(${x0}) = ${mc}\\) dollars per unit`,
    steps: [
      `Marginal cost is the derivative: \\(C'(x) = ${2*a}x + ${b}\\).`,
      `Evaluate: \\(C'(${x0}) = ${2*a}(${x0}) + ${b} = ${mc}\\).`,
      `Interpretation: producing the next unit after the ${x0}th costs about \\$${mc}.`
    ],
    traps: [
      {ans: `\\(C'(${x0}) = ${a*x0*x0 + b*x0 + c}\\) dollars per unit`, why: 'That is C(' + x0 + ') — the TOTAL cost. Marginal cost is the derivative C′, the rate per additional unit.'},
      {ans: `\\(C'(${x0}) = ${2*a*x0}\\) dollars per unit`, why: 'The linear term ' + b + 'x differentiates to ' + b + ' — do not drop it; only the constant ' + c + ' vanishes.'}
    ],
    vec: [unitIndex('AC1_Marginal'), 1, a, b, c, x0],
    key: 'ac1_marg_cost'
  };
});
registerGen('AC1_Marginal', (rng)=>{
  const m = pick(rng,[60,80,100,120]), n = mwNZ(rng,1,3), x0 = pick(rng,[5,10,15]);
  const mr = m - 2*n*x0;
  return {
    q: `The demand price is \\(p = ${m} - ${n}x\\). Revenue is \\(R(x) = xp\\). Find the marginal revenue at \\(x = ${x0}\\).`,
    a: `\\(R'(${x0}) = ${mr}\\)`,
    steps: [
      `Revenue: \\(R(x) = x(${m} - ${n}x) = ${m}x - ${n}x^2\\).`,
      `Marginal revenue: \\(R'(x) = ${m} - ${2*n}x\\).`,
      `Evaluate: \\(R'(${x0}) = ${m} - ${2*n}(${x0}) = ${mr}\\).`
    ],
    traps: [
      {ans: `\\(R'(${x0}) = ${m - n*x0}\\)`, why: 'R(x) = ' + m + 'x − ' + n + 'x² — the squared term differentiates to ' + (2*n) + 'x, doubling the coefficient. You differentiated the PRICE, not the revenue.'},
      {ans: `\\(R'(${x0}) = ${m*x0 - n*x0*x0}\\)`, why: 'That is total revenue R(' + x0 + '), not the marginal (derivative) value.'}
    ],
    vec: [unitIndex('AC1_Marginal'), 2, m, n, x0],
    key: 'ac1_marg_revenue'
  };
});
registerGen('AC1_Marginal', (rng)=>{
  const n = mwNZ(rng,1,3), b = pick(rng,[10,20,30]);
  const xstar = pick(rng,[5,10,15,20]);
  const m = b + 2*n*xstar;                       // makes R'=C' solve to xstar exactly
  return {
    q: `Revenue is \\(R(x) = ${m}x - ${n}x^2\\) and cost is \\(C(x) = ${b}x + ${pick(rng,[50,100,200])}\\). What production level \\(x\\) maximizes profit?`,
    a: `\\(x = ${xstar}\\)`,
    steps: [
      `Profit is maximized where marginal revenue equals marginal cost: \\(R'(x) = C'(x)\\).`,
      `\\(R'(x) = ${m} - ${2*n}x\\) and \\(C'(x) = ${b}\\).`,
      `Set equal: \\(${m} - ${2*n}x = ${b} \\Rightarrow x = ${xstar}\\). (\\(R'' = ${-2*n} < 0\\): a maximum.)`
    ],
    traps: [
      {ans: `\\(x = ${2*xstar}\\)`, why: 'R′ has coefficient 2n = ' + (2*n) + ' on x — dividing by n instead of 2n doubles the answer.'},
      {ans: `\\(x = ${m}\\)`, why: 'Set R′ = C′ and SOLVE for x; the answer is not a coefficient from the problem.'}
    ],
    vec: [unitIndex('AC1_Marginal'), 3, m, n, b, xstar],
    key: 'ac1_profit_max'
  };
});
registerGen('AC1_Marginal', (rng)=>{
  const x0 = pick(rng,[20,50,100]), mc = pick(rng,[8,12,15,25]);
  return {
    q: `A cost function satisfies \\(C'(${x0}) = ${mc}\\). What is the best interpretation?`,
    a: `Producing the ${x0+1}th unit costs approximately \\$${mc}`,
    steps: [
      `\\(C'(x)\\) is the RATE of change of cost — dollars per additional unit.`,
      `So \\(C'(${x0}) = ${mc}\\) estimates the cost of one more unit beyond ${x0}.`
    ],
    traps: [
      {ans: `The total cost of ${x0} units is \\$${mc}`, why: 'C′ is a rate, not a total. Total cost is C(' + x0 + '), a different (usually much larger) number.'},
      {ans: `The average cost per unit is \\$${mc}`, why: 'Average cost is C(x)/x. Marginal cost is the derivative — the cost of the NEXT unit, not the average so far.'}
    ],
    vec: [unitIndex('AC1_Marginal'), 4, x0, mc],
    key: 'ac1_marg_interpret'
  };
});
registerGen('AC1_Elasticity', (rng)=>{
  const b = mwNZ(rng,1,3), halfP = pick(rng,[10,15,20,25]);
  const a = 2*b*halfP;                           // rev-max price = a/(2b) = halfP
  const p0 = pick(rng,[halfP-5, halfP+5].filter(v=>v>0 && a-b*v>0)) || halfP - 5;
  const q0 = a - b*p0;
  const En = b*p0, Ed = q0;                      // E = bp/(a-bp)
  const g = (x,y)=>{ while(y){ [x,y]=[y,x%y]; } return x; };
  const gg = g(En,Ed);
  const eTex = (Ed/gg===1) ? `${En/gg}` : `\\frac{${En/gg}}{${Ed/gg}}`;
  return {
    q: `Demand is \\(q = ${a} - ${b}p\\). Find the elasticity of demand \\(E = \\dfrac{-p}{q}\\cdot\\dfrac{dq}{dp}\\) at \\(p = ${p0}\\).`,
    a: `\\(E = ${eTex}\\)`,
    steps: [
      `\\(\\frac{dq}{dp} = -${b}\\), and at \\(p = ${p0}\\): \\(q = ${a} - ${b}(${p0}) = ${q0}\\).`,
      `\\(E = \\dfrac{-${p0}}{${q0}}(-${b}) = \\dfrac{${En}}{${Ed}}${gg>1 ? ' = ' + ((Ed/gg===1)? (En/gg) : '\\\\frac{'+(En/gg)+'}{'+(Ed/gg)+'}') : ''}\\).`,
      `\\(E ${En>Ed?'>':'<'} 1\\): demand is ${En>Ed?'elastic':'inelastic'} at this price.`
    ],
    traps: [
      {ans: `\\(E = \\frac{${Ed}}{${En}}\\)`, why: 'E = (p/q)·|dq/dp| — the price goes on TOP. Flipping the ratio flips the elastic/inelastic conclusion.'},
      {ans: `\\(E = ${b}\\)`, why: 'The slope dq/dp alone is not elasticity — E rescales it by p/q, so it changes along the demand curve.'}
    ],
    vec: [unitIndex('AC1_Elasticity'), 1, a, b, p0],
    key: 'ac1_elast_value'
  };
});
registerGen('AC1_Elasticity', (rng)=>{
  const b = mwNZ(rng,1,3), halfP = pick(rng,[10,20,30]);
  const a = 2*b*halfP;
  const side = pick(rng,['above','below']);
  const p0 = side==='above' ? halfP + pick(rng,[4,6,8]) : halfP - pick(rng,[4,6,8]);
  const label = side==='above' ? 'Elastic' : 'Inelastic';
  return {
    q: `For demand \\(q = ${a} - ${b}p\\), is demand elastic or inelastic at \\(p = ${p0}\\)?`,
    a: label,
    steps: [
      `For linear demand \\(q = a - bp\\), \\(E = 1\\) exactly at \\(p = \\frac{a}{2b} = ${halfP}\\).`,
      `Above that price demand is elastic (\\(E > 1\\)); below it, inelastic.`,
      `\\(${p0} ${side==='above'?'>':'<'} ${halfP}\\), so demand is ${label.toLowerCase()}.`
    ],
    traps: [
      {ans: side==='above' ? 'Inelastic' : 'Elastic', why: 'HIGH prices are the elastic region: at high p, q is small and E = bp/q is large. The intuition "expensive = customers react strongly" points the right way.'},
      {ans: 'Unit elastic', why: 'E = 1 only at exactly p = a/(2b) = ' + halfP + '; the given price is not that value.'}
    ],
    vec: [unitIndex('AC1_Elasticity'), 2, a, b, p0, side==='above'?1:0],
    key: 'ac1_elast_classify'
  };
});
registerGen('AC1_Elasticity', (rng)=>{
  const b = mwNZ(rng,1,4), halfP = pick(rng,[10,15,20,25,30]);
  const a = 2*b*halfP;
  return {
    q: `Demand is \\(q = ${a} - ${b}p\\). What price maximizes revenue?`,
    a: `\\(p = ${halfP}\\)`,
    steps: [
      `Revenue: \\(R(p) = pq = ${a}p - ${b}p^2\\).`,
      `\\(R'(p) = ${a} - ${2*b}p = 0 \\Rightarrow p = \\frac{${a}}{${2*b}} = ${halfP}\\).`,
      `(Equivalently: revenue peaks where elasticity \\(E = 1\\).)`
    ],
    traps: [
      {ans: `\\(p = ${2*halfP}\\)`, why: 'That is a/b — the price where demand hits ZERO (and revenue too). Revenue peaks at half that: a/(2b).'},
      {ans: `\\(p = ${a}\\)`, why: 'Differentiate R(p) = ap − bp² and solve R′ = 0; the intercept a is a quantity, not the optimal price.'}
    ],
    vec: [unitIndex('AC1_Elasticity'), 3, a, b, halfP],
    key: 'ac1_elast_revmax'
  };
});
registerGen('AC1_Finance', (rng)=>{
  const P = pick(rng,[1000,2000,5000]), rPct = pick(rng,[4,5,8,10]), t = pick(rng,[5,10]);
  const rt = rPct*t;                             // exponent numerator in %, e.g. e^{0.5}
  const expTex = (rt % 100 === 0) ? String(rt/100) : `0.${String(rt).padStart(2,'0')}`;
  return {
    q: `\\$${P} is invested at ${rPct}\\% annual interest, compounded continuously. What is the balance after ${t} years? (Exact form.)`,
    a: `\\(A = ${P}e^{${expTex}}\\)`,
    steps: [
      `Continuous compounding: \\(A = Pe^{rt}\\).`,
      `\\(r = ${rPct}\\% = ${(rPct/100)}\\), so \\(rt = ${(rPct/100)}\\times${t} = ${expTex}\\).`,
      `\\(A = ${P}e^{${expTex}}\\).`
    ],
    traps: [
      {ans: `\\(A = ${P}e^{${rPct*t}}\\)`, why: 'Convert the percent: r = ' + rPct + '% = ' + (rPct/100) + '. Using ' + rPct + ' raw makes the exponent 100× too large.'},
      {ans: `\\(A = ${P}(1 + ${(rPct/100)})^{${t}}\\)`, why: 'That is ANNUAL compounding. Continuous compounding uses Pe^{rt}.'}
    ],
    vec: [unitIndex('AC1_Finance'), 1, P, rPct, t],
    key: 'ac1_fin_amount'
  };
});
registerGen('AC1_Finance', (rng)=>{
  const d = pick(rng,[20,25,50]);                // r = 1/d
  const mult = pick(rng,[2,3]);
  return {
    q: `Money grows continuously at rate \\(r = \\frac{1}{${d}}\\) per year. How long until an investment ${mult===2?'doubles':'triples'}?`,
    a: `\\(t = ${d}\\ln ${mult}\\)`,
    steps: [
      `\\(A = Pe^{t/${d}}\\); we need \\(A = ${mult}P\\).`,
      `\\(e^{t/${d}} = ${mult} \\Rightarrow t/${d} = \\ln ${mult}\\).`,
      `\\(t = ${d}\\ln ${mult} \\approx ${(d*Math.log(mult)).toFixed(1)}\\) years.`
    ],
    traps: [
      {ans: `\\(t = \\dfrac{\\ln ${mult}}{${d}}\\)`, why: 't = ln(' + mult + ')/r, and dividing by r = 1/' + d + ' means multiplying by ' + d + '.'},
      {ans: `\\(t = ${d*mult}\\)`, why: 'Exponential growth is not linear — the answer involves ln ' + mult + ' ≈ ' + Math.log(mult).toFixed(2) + ', not the factor itself.'}
    ],
    vec: [unitIndex('AC1_Finance'), 2, d, mult],
    key: 'ac1_fin_time'
  };
});
registerGen('AC1_Finance', (rng)=>{
  const t = pick(rng,[10,20,25]), mult = pick(rng,[2,3,4]);
  return {
    q: `An investment ${mult===2?'doubled':mult===3?'tripled':'quadrupled'} in ${t} years under continuous compounding. Find the rate \\(r\\). (Exact form.)`,
    a: `\\(r = \\dfrac{\\ln ${mult}}{${t}}\\)`,
    steps: [
      `\\(${mult}P = Pe^{r(${t})} \\Rightarrow e^{${t}r} = ${mult}\\).`,
      `\\(${t}r = \\ln ${mult} \\Rightarrow r = \\dfrac{\\ln ${mult}}{${t}} \\approx ${(Math.log(mult)/t*100).toFixed(1)}\\%\\).`
    ],
    traps: [
      {ans: `\\(r = ${t}\\ln ${mult}\\)`, why: 'Divide by the time: r = ln(' + mult + ')/t. Multiplying gives a rate over ' + (t*t) + '× too large.'},
      {ans: `\\(r = \\dfrac{${mult}}{${t}}\\)`, why: 'Undo the exponential with a logarithm first — the growth factor ' + mult + ' enters as ln ' + mult + '.'}
    ],
    vec: [unitIndex('AC1_Finance'), 3, t, mult],
    key: 'ac1_fin_rate'
  };
});
