// C2 generator registrations — order frozen by the published registry.
registerGen('C2_Tech', (rng) => {
  const a = pick(rng, [2,3,4,5]);
  return {
    q: `Compute \\(\\int x e^{${a}x}\\,dx\\).`,
    a: `\\(e^{${a}x}\\left(\\frac{x}{${a}}-\\frac{1}{${a*a}}\\right)+C\\)`,
    steps: [
      `Integration by parts: let \\(u=x\\), \\(dv=e^{${a}x}dx\\).`,
      `Then \\(du=dx\\), \\(v=\\frac{1}{${a}}e^{${a}x}\\).`,
      `\\(\\int x e^{${a}x}dx=\\frac{x}{${a}}e^{${a}x}-\\frac{1}{${a}}\\int e^{${a}x}dx\\).`,
      `Finish: \\(e^{${a}x}(\\frac{x}{${a}}-\\frac{1}{${a*a}})+C\\).`
    ],
    vec: [unitIndex('C2_Tech'), 1, a, 0,0],
    key: 'c2_ibp_x_exp'
  };
});
registerGen('C2_Tech', (rng) => ({
  q: `Compute \\(\\int \\sin^2(x)\\,dx\\).`,
  a: `\\(\\frac{x}{2}-\\frac{\\sin(2x)}{4}+C\\)`,
  steps: [
    `Use \\(\\sin^2x=\\frac{1-\\cos(2x)}{2}\\).`,
    `Integrate term-by-term.`
  ],
  vec: [unitIndex('C2_Tech'), 2, 0,0,0],
  key: 'c2_trig_sin2'
}));
registerGen('C2_Tech', (rng)=> {
  const a = randInt(rng,1,4);
  const b = randInt(rng,2,6);
  // ∫ (ax+b)/(x(x+1)) dx = ∫ [A/x + B/(x+1)] dx
  // Solve: ax+b = A(x+1)+Bx = (A+B)x + A => A=b, A+B=a => B=a-b
  const A = b;
  const B = a-b;
  return {
    q: `Compute \\(\\int \\frac{${a}x+${b}}{x(x+1)}\\,dx\\).`,
    a: `\\(${A}\\ln|x|+${B}\\ln|x+1|+C\\)`,
    steps: [
      `Decompose: \\(\\frac{${a}x+${b}}{x(x+1)}=\\frac{A}{x}+\\frac{B}{x+1}\\).`,
      `Match: \\(${a}x+${b}=(A+B)x+A\\Rightarrow A=${A},\\;B=${B}\\).`,
      `Integrate: \\(\\int A/x dx=A\\ln|x|\\), \\(\\int B/(x+1) dx=B\\ln|x+1|\\).`
    ],
    vec: [unitIndex('C2_Tech'), 3, a, b, 0],
    key:'c2_partial_frac'
  };
});
registerGen('C2_Tech', (rng)=> {
  const a = pick(rng, [2,3,4,5]);
  // ∫ dx/sqrt(a^2-x^2) = arcsin(x/a)+C
  return {
    q: `Compute \\(\\int \\frac{1}{\\sqrt{${a*a}-x^2}}\\,dx\\).`,
    a: `\\(\\arcsin\\left(\\frac{x}{${a}}\\right)+C\\)`,
    steps: [
      `Recognize standard form: \\(\\int \\frac{dx}{\\sqrt{a^2-x^2}}=\\arcsin(x/a)+C\\).`,
      `Here \\(a=${a}\\).`
    ],
    vec: [unitIndex('C2_Tech'), 4, a, 0,0],
    key:'c2_trigsub_arcsin'
  };
});
registerGen('C2_Tech', (rng)=> {
  const a = pick(rng, [-3,-2,-1,1,2,3]);
  const y0 = randInt(rng, 1, 6);
  const xEval = pick(rng, [1,2]);
  const q = `Solve the differential equation \\(\\frac{dy}{dx}=${a}xy\\) with \\(y(0)=${y0}\\). Then find \\(y(${xEval})\\).`;

  const expo = (a * xEval * xEval) / 2;
  const aStr = `\\(y(x)=${y0}e^{${a}x^2/2}\\), so \\(y(${xEval})=${y0}e^{${a}(${xEval}^2)/2}=${y0}e^{${expo}}\\).`;

  const steps = [
    `Separate variables: \\(\\frac{1}{y}dy=${a}x\\,dx\\).`,
    `Integrate both sides: \\(\\int \\frac{1}{y}dy=\\int ${a}x\\,dx\\Rightarrow \\ln|y|=\\frac{${a}}{2}x^2+C\\).`,
    `Exponentiate: \\(|y|=e^{C}e^{${a}x^2/2}\\). Let \\(K=e^{C}>0\\), so \\(y=\\pm K e^{${a}x^2/2}\\).`,
    `Use the initial condition \\(y(0)=${y0}\\): \\(y0=\\pm K\\Rightarrow K=${y0}\\) (since ${y0}>0), so \\(y(x)=${y0}e^{${a}x^2/2}\\).`,
    `Evaluate: \\(y(${xEval})=${y0}e^{${expo}}\\).`
  ];

  return {
    q, a:aStr, steps,
    vec:[unitIndex('C2_Tech'), 201, a, y0, xEval],
    key:'c2_de_separable_xyy'
  };
});
registerGen('C2_Tech', (rng)=> {
  const n = pick(rng, [-3,-2,-1,1,2,3,4]);
  const y1 = randInt(rng, 1, 8);
  const xEval = pick(rng, [2,3,4]);
  const yEval = y1 * (xEval**n);

  const q = `Solve the differential equation \\(\\frac{dy}{dx}=\\frac{${n}y}{x}\\) with \\(y(1)=${y1}\\). Then find \\(y(${xEval})\\).`;
  const aStr = `\\(y(x)=${y1}x^{${n}}\\), so \\(y(${xEval})=${yEval}\\).`;

  const steps = [
    `Separate variables: \\(\\frac{1}{y}dy=${n}\\frac{1}{x}dx\\).`,
    `Integrate: \\(\\ln|y|=${n}\\ln|x|+C\\).`,
    `Exponentiate: \\(|y|=e^C|x|^{${n}}\\). For \\(x>0\\), write \\(y=Cx^{${n}}\\).`,
    `Apply \\(y(1)=${y1}\\): \\(${y1}=C\\cdot 1^{${n}}\\Rightarrow C=${y1}\\).`,
    `So \\(y(x)=${y1}x^{${n}}\\). Evaluate: \\(y(${xEval})=${y1}(${xEval})^{${n}}=${yEval}\\).`
  ];

  return {
    q, a:aStr, steps,
    vec:[unitIndex('C2_Tech'), 202, n, y1, xEval],
    key:'c2_de_separable_y_over_x'
  };
});
registerGen('C2_Improper', (rng) => {
  const p = pick(rng, [0.5, 1, 2, 3, 4]);
  const pTag = Math.round(p*10);
  if(p <= 1){
    return {
      q: `Determine whether \\(\\int_1^{\\infty}\\frac{1}{x^{${p}}}\\,dx\\) converges or diverges.`,
      a: `Diverges (because \\(p\\le 1\\)).`,
      steps: [
        `This is a p-integral; it converges iff \\(p>1\\).`,
        `Here \\(p=${p}\\le 1\\), so it diverges.`
      ],
      vec: [unitIndex('C2_Improper'), 1, pTag, 0,0],
      key:'c2_p_integral'
    };
  }
  const val = 1/(p-1);
  return {
    q: `Evaluate \\(\\int_1^{\\infty}\\frac{1}{x^{${p}}}\\,dx\\).`,
    a: `Converges to \\(${exactFrac(1, p-1)} \\approx ${smartRound(val, 3)}\\).`,
    steps: [
      `p-integral with \\(p=${p}>1\\) converges.`,
      `\\(\\int x^{-p}dx=\\frac{x^{1-p}}{1-p}\\).`,
      `Limit gives \\(\\frac{1}{p-1} = ${exactFrac(1,p-1)} \\approx ${smartRound(val, 3)}\\).`
    ],
    vec: [unitIndex('C2_Improper'), 2, pTag, 0,0],
    key:'c2_p_integral_val'
  };
});
registerGen('C2_Improper', (rng)=> {
  const p = pick(rng, [1,2,3]);
  // ∫_0^1 x^{-p} dx diverges for p>=1
  return {
    q: `Determine whether \\(\\int_0^{1}\\frac{1}{x^{${p}}}\\,dx\\) converges or diverges.`,
    a: `Diverges (because exponent \\(\\ge 1\\)).`,
    steps: [
      `\\(\\int_0^1 x^{-p}dx\\) converges only if \\(-p>-1\\Rightarrow p<1\\).`,
      `Here \\(p=${p}\\ge 1\\), so it diverges.`
    ],
    vec: [unitIndex('C2_Improper'), 3, p, 0,0],
    key:'c2_improper_0_1'
  };
});
registerGen('C2_Series', genC2SeriesConvergenceTests);
registerGen('C2_Series', (rng) => {
  const a = randInt(rng, 1, 8);
  let num, den, r;
  // Ensure |r| < 1 from the start
  do {
    num = pick(rng, [-3,-2,-1,1,2,3]);
    den = pick(rng, [2,3,4,5,6,7,8]);
    r = num/den;
  } while (Math.abs(r) >= 1);
  
  // Calculate exact sum: a/(1-r) = a / ((den-num)/den) = a*den/(den-num)
  const sumNum = a * den;
  const sumDen = den - num;
  const exactSum = exactFrac(sumNum, sumDen);
  const decimalSum = sumNum / sumDen;
  
  return {
    q: `Find the sum of \\(\\sum_{n=0}^{\\infty} ${a}\\left(\\frac{${num}}{${den}}\\right)^n\\).`,
    a: `\\(${exactSum}\\)${Math.abs(decimalSum) > 10 ? ` \\(\\approx ${smartRound(decimalSum, 2)}\\)` : ''}`,
    steps: [
      `Geometric series with first term \\(a=${a}\\) and ratio \\(r=\\frac{${num}}{${den}}\\).`,
      `Converges if \\(|r|<1\\).`,
      `Sum \\(=\\frac{a}{1-r} = \\frac{${a}}{1-\\frac{${num}}{${den}}} = \\frac{${a} \\cdot ${den}}{${den-num}} = ${exactSum}\\).`
    ],
    vec: [unitIndex('C2_Series'), 1, a, num, den],
    key:'c2_geom_sum'
  };
});
registerGen('C2_Series', (rng)=> {
  const a = randInt(rng,1,4);
  const b = randInt(rng,2,6);
  // sum (a^n)/(n!) always converges
  return {
    q: `Determine whether \\(\\sum_{n=1}^{\\infty}\\frac{${a}^n}{n!}\\) converges or diverges.`,
    a: `Converges (by Ratio Test).`,
    steps: [
      `Let \\(a_n=\\frac{${a}^n}{n!}\\).`,
      `\\(\\left|\\frac{a_{n+1}}{a_n}\\right|=\\frac{${a}}{n+1}\\to 0\\).`,
      `Since limit < 1, the series converges absolutely.`
    ],
    vec: [unitIndex('C2_Series'), 2, a, 0,0],
    key:'c2_ratio_fact'
  };
});
registerGen('C2_Series', (rng)=> {
  const p = pick(rng, [1,2,3]);
  return {
    q: `Determine whether \\(\\sum_{n=1}^{\\infty}\\frac{(-1)^{n}}{n^{${p}}}\\) converges absolutely, conditionally, or diverges.`,
    a: (p>1) ? `Converges absolutely.` : `Converges conditionally (alternating test; not absolutely).`,
    steps: [
      `Absolute series is \\(\\sum 1/n^{${p}}\\) which ${(p>1)?'converges (p>1)':'diverges (p\\le 1)'} .`,
      `Alternating test applies because \\(1/n^{${p}}\\to 0\\) and is decreasing.`,
      `So it converges ${(p>1)?'absolutely':'conditionally'}.`
    ],
    vec: [unitIndex('C2_Series'), 3, p, 0,0],
    key:'c2_alt_p'
  };
});
registerGen('C2_Series', (rng)=> {
  const a = pick(rng, [0,1]);
  const center = a===0 ? 0 : 1;
  // Taylor for e^x at 0: sum x^n/n!
  // at 1: e^1 sum (x-1)^n/n!
  const expr = (center===0) ? `\\(e^x=\\sum_{n=0}^{\\infty}\\frac{x^n}{n!}\\)` : `\\(e^x=e\\sum_{n=0}^{\\infty}\\frac{(x-1)^n}{n!}\\)`;
  return {
    q: `Write the Taylor series for \\(e^x\\) centered at \\(x=${center}\\).`,
    a: expr,
    steps: [
      `Recall \\(e^x=\\sum_{n=0}^{\\infty}\\frac{x^n}{n!}\\) (Maclaurin).`,
      `Shift center: \\(e^x=e^{${center}}e^{x-${center}}=e^{${center}}\\sum_{n=0}^{\\infty}\\frac{(x-${center})^n}{n!}\\).`
    ],
    vec: [unitIndex('C2_Series'), 4, center, 0,0],
    key:'c2_taylor_exp'
  };
});
registerGen('C2_Series', (rng)=> {
  const q = `Find the radius and interval of convergence of the power series \\(\\sum_{n=1}^{\\infty} \\frac{x^n}{n}\\).`;

  const aStr = `Radius \\(R=1\\). Interval of convergence: \\([-1,1)\\).`;

  const steps = [
    `Use the Ratio Test with \\(a_n=\\frac{x^n}{n}\\).`,
    `\\(\\left|\\frac{a_{n+1}}{a_n}\\right|=\\left|\\frac{x^{n+1}}{n+1}\\cdot\\frac{n}{x^n}\\right|=|x|\\cdot\\frac{n}{n+1}\\to |x|\\).`,
    `Converges when \\(|x|<1\\) and diverges when \\(|x|>1\\). So \\(R=1\\).`,
    `Check endpoints:`,
    `At \\(x=1\\): \\(\\sum \\frac{1}{n}\\) diverges (harmonic).`,
    `At \\(x=-1\\): \\(\\sum \\frac{(-1)^n}{n}\\) converges (alternating harmonic).`,
    `So the interval is \\([-1,1)\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C2_Series'), 301, 1], key:'c2_roc_xn_over_n' };
});
registerGen('C2_Series', (rng)=> {
  const q = `Find the radius and interval of convergence of \\(\\sum_{n=1}^{\\infty} \\frac{(x-1)^n}{n\\,5^n}\\).`;

  const aStr = `Radius \\(R=5\\). Interval of convergence: \\([-4,6)\\).`;

  const steps = [
    `Let \\(a_n=\\frac{(x-1)^n}{n5^n}\\). Ratio Test:`,
    `\\(\\left|\\frac{a_{n+1}}{a_n}\\right|=\\left|\\frac{(x-1)^{n+1}}{(n+1)5^{n+1}}\\cdot\\frac{n5^n}{(x-1)^n}\\right|=\\left|\\frac{x-1}{5}\\right|\\cdot\\frac{n}{n+1}\\to \\left|\\frac{x-1}{5}\\right|\\).`,
    `So it converges when \\(|x-1| < 5\\Rightarrow -4 < x < 6\\). Thus \\(R=5\\).`,
    `Endpoint checks:`,
    `At \\(x=6\\): \\(\\sum \\frac{1}{n}\\) diverges.`,
    `At \\(x=-4\\): \\(\\sum \\frac{(-1)^n}{n}\\) converges (alternating harmonic).`,
    `So the interval is \\([-4,6)\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C2_Series'), 302, 5, 1], key:'c2_ioc_shifted_harmonic' };
});
registerGen('C2_Series', (rng)=> {
  const q = `Find the radius and interval of convergence of \\(\\sum_{n=1}^{\\infty} n\\left(\\frac{x+2}{4}\\right)^n\\).`;

  const aStr = `Radius \\(R=4\\). Interval of convergence: \\((-6,2)\\).`;

  const steps = [
    `This is like \\(\\sum n r^n\\) with \\(r=\\frac{x+2}{4}\\).`,
    `We know \\(\\sum n r^n\\) converges when \\(|r|<1\\) and diverges when \\(|r|\\ge 1\\).`,
    `So require \\(\\left|\\frac{x+2}{4}\\right| < 1\\Rightarrow |x+2| < 4\\Rightarrow -6 < x < 2\\). Thus \\(R=4\\).`,
    `Check endpoints quickly:`,
    `At \\(x=2\\): terms are \\(n\\), diverges.`,
    `At \\(x=-6\\): terms are \\(n(-1)^n\\), does not go to 0, diverges.`,
    `So the interval is \\((-6,2)\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C2_Series'), 303, 4, -2], key:'c2_ioc_nrn' };
});
registerGen('C2_Series', (rng)=> {
  const eps = pick(rng, [0.01, 0.005, 0.001]);
  const N = Math.ceil(Math.sqrt(1/eps) - 1);

  const q = `For the alternating series \\(\\sum_{n=1}^{\\infty} (-1)^{n+1}\\frac{1}{n^2}\\), how many terms are needed so that the remainder \\(|R_N|<${eps}\\)?`;
  const aStr = `It suffices to take \\(N\\ge ${N}\\) terms.`;

  const steps = [
    `The series is alternating with terms \\(b_n=\\frac{1}{n^2}\\) decreasing to 0.`,
    `Alternating Series Estimation Theorem: \\(|R_N|\\le b_{N+1}=\\frac{1}{(N+1)^2}\\).`,
    `Require \\(\\frac{1}{(N+1)^2}<${eps}\\Rightarrow (N+1)^2>\\frac{1}{${eps}}\\Rightarrow N+1>\\sqrt{\\frac{1}{${eps}}}\\).`,
    `So \\(N>\\sqrt{\\frac{1}{${eps}}}-1\\). Smallest integer: \\(N=${N}\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C2_Series'), 304, Math.round(eps*1000)], key:'c2_alt_error_bound' };
});
registerGen('C2_Series', (rng)=> {
  const which = pick(rng, ['sin','cos']);
  const fTex = (which === 'sin') ? '\\\\sin' : '\\\\cos';

  const q = `Write the Maclaurin series for \\(${fTex} x\\) through the first four nonzero terms.`;
  const aStr = (which === 'sin')
    ? `\\(\\sin x = x-\\frac{x^3}{3!}+\\frac{x^5}{5!}-\\frac{x^7}{7!}+\\cdots\\)`
    : `\\(\\cos x = 1-\\frac{x^2}{2!}+\\frac{x^4}{4!}-\\frac{x^6}{6!}+\\cdots\\)`;

  const steps = (which === 'sin')
    ? [
        `Maclaurin series form: \\(\\sin x=\\sum_{n=0}^{\\infty}(-1)^n\\frac{x^{2n+1}}{(2n+1)!}\\).`,
        `First four nonzero terms (n=0,1,2,3): \\(x-\\frac{x^3}{3!}+\\frac{x^5}{5!}-\\frac{x^7}{7!}+\\cdots\\).`
      ]
    : [
        `Maclaurin series form: \\(\\cos x=\\sum_{n=0}^{\\infty}(-1)^n\\frac{x^{2n}}{(2n)!}\\).`,
        `First four nonzero terms (n=0,1,2,3): \\(1-\\frac{x^2}{2!}+\\frac{x^4}{4!}-\\frac{x^6}{6!}+\\cdots\\).`
      ];

  return { q, a:aStr, steps, vec:[unitIndex('C2_Series'), 305, which==='sin'?1:2], key:`c2_maclaurin_${which}_4terms` };
});
registerGen('C2_Series', (rng)=> {
  const a = pick(rng, [2,3,4,5]);
  const q = `Find a power series for \\(\\frac{1}{1-${a}x}\\) and state its interval of convergence.`;

  const aStr = `\\(\\frac{1}{1-${a}x}=\\sum_{n=0}^{\\infty} (${a}x)^n=\\sum_{n=0}^{\\infty} ${a}^n x^n\\), for \\(|x|<\\frac{1}{${a}}\\).`;

  const steps = [
    `Recall the geometric series: \\(\\frac{1}{1-r}=\\sum_{n=0}^{\\infty} r^n\\) for \\(|r|<1\\).`,
    `Here \\(r=${a}x\\). Therefore \\(\\frac{1}{1-${a}x}=\\sum_{n=0}^{\\infty} (${a}x)^n\\).`,
    `Convergence requires \\(|${a}x|<1\\Rightarrow |x|<\\frac{1}{${a}}\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C2_Series'), 306, a], key:'c2_geom_power_series' };
});
registerGen('C2_ParamPolar', (rng) => {
  const c = pick(rng, [1,2,-1]);
  const val = (3*c*c - 1) / (2*c);
  return {
    q: `For \\(x=t^2+1\\), \\(y=t^3-t\\), find \\(\\frac{dy}{dx}\\) at \\(t=${c}\\).`,
    a: `\\(${val}\\)`,
    steps: [
      `\\(dx/dt=2t\\), \\(dy/dt=3t^2-1\\).`,
      `\\(dy/dx=(dy/dt)/(dx/dt)=\\frac{3t^2-1}{2t}\\).`,
      `Plug in \\(t=${c}\\).`
    ],
    vec: [unitIndex('C2_ParamPolar'), 1, c, 0,0],
    key:'c2_param_dydx'
  };
});
registerGen('C2_ParamPolar', (rng) => ({
  q: `Find the area for \\(r=\\theta\\) from \\(\\theta=0\\) to \\(\\theta=\\frac{\\pi}{2}\\).`,
  a: `\\(\\frac{\\pi^3}{48}\\)`,
  steps: [
    `Area: \\(A=\\frac12\\int_a^b r^2\\,d\\theta\\).`,
    `\\(A=\\frac12\\int_0^{\\pi/2}\\theta^2 d\\theta=\\frac12\\cdot\\frac{(\\pi/2)^3}{3}=\\frac{\\pi^3}{48}\\).`
  ],
  vec: [unitIndex('C2_ParamPolar'), 2, 0,0,0],
  key:'c2_polar_area'
}));
registerGen('C2_AppsInt', (rng)=> {
  const method = pick(rng, ['disk','washer','shell']);
  const axis = (method === 'shell') ? 'y' : 'x'; // keep it simple/standard

  // build a positive polynomial f(x)=c0 + c1 x + c2 x^2 on [a,b]
  let a=0, b=0, f=[0,0,0];
  let tries=0;
  while(tries++ < 200){
    a = pick(rng, [0,1]);
    b = pick(rng, [2,3,4,5]);
    const c2 = pick(rng, [0,0,0,1,1,2]); // mostly linear/constant
    const c1 = randInt(rng, -2, 3);
    const c0 = randInt(rng, 1, 6);
    f = [c0, c1, c2];
    // sample positivity
    const vals = [a,(a+b)/2,b].map(x=> f[0] + f[1]*x + f[2]*x*x);
    if(vals.every(v=> v > 0)) break;
  }

  const fTex = mwPolyToTex(f,'x');

  if(method === 'disk'){
    const sq = mwPolyPow2(f);
    const I = mwPolyDefInt(sq, a, b);
    return {
      q: `Find the volume of the solid obtained by rotating the region under \\(y=${fTex}\\) from \\(x=${a}\\) to \\(x=${b}\\) about the \\(${axis}\\)-axis (Disk Method).`,
      a: `\\(V=\\pi\\int_{${a}}^{${b}}(${fTex})^2\\,dx = \\left(${mwFracToTex(I)}\\right)\\pi\\).`,
      steps: [
        `Disk method about the \\(x\\)-axis: \\(V=\\pi\\int_a^b [f(x)]^2\\,dx\\).`,
        `Here \\(f(x)=${fTex}\\), so integrate \\((${fTex})^2\\) from \\(${a}\\) to \\(${b}\\).`,
        `The definite integral evaluates to \\(${mwFracToTex(I)}\\).`,
        `Multiply by \\(\\pi\\) to get the volume.`
      ],
      vec: [unitIndex('C2_AppsInt'), 81, a,b,f[0],f[1],f[2]],
      key:'c2_volume_disk_poly'
    };
  }

  if(method === 'washer'){
    const t = pick(rng, [1,2]); // thickness between outer and inner
    // inner radius r(x)=f(x)-t (ensure positive on interval)
    const g = [f[0]-t, f[1], f[2]];
    // if inner not positive, fall back to disk
    const vals = [a,(a+b)/2,b].map(x=> g[0] + g[1]*x + g[2]*x*x);
    if(!vals.every(v=> v > 0)){
      const sq = mwPolyPow2(f);
      const I = mwPolyDefInt(sq, a, b);
      return {
        q: `Find the volume of the solid obtained by rotating the region under \\(y=${fTex}\\) from \\(x=${a}\\) to \\(x=${b}\\) about the \\(${axis}\\)-axis (Disk Method).`,
        a: `\\(V=\\left(${mwFracToTex(I)}\\right)\\pi\\).`,
        steps: [
          `Inner radius would be nonpositive for a washer; use disk method instead.`,
          `Compute \\(\\pi\\int_a^b [f(x)]^2\\,dx\\).`
        ],
        vec: [unitIndex('C2_AppsInt'), 82, a,b,f[0],f[1],f[2]],
        key:'c2_volume_disk_fallback_from_washer'
      };
    }
    const gTex = mwPolyToTex(g,'x');
    const I = mwSubF(mwPolyDefInt(mwPolyPow2(f), a, b), mwPolyDefInt(mwPolyPow2(g), a, b));
    return {
      q: `Find the volume of the solid obtained by rotating the region between \\(y=${fTex}\\) and \\(y=${gTex}\\) from \\(x=${a}\\) to \\(x=${b}\\) about the \\(${axis}\\)-axis (Washer Method).`,
      a: `\\(V=\\pi\\int_{${a}}^{${b}}\\big[(${fTex})^2-(${gTex})^2\\big]dx = \\left(${mwFracToTex(I)}\\right)\\pi\\).`,
      steps: [
        `Washer method about the \\(x\\)-axis: \\(V=\\pi\\int_a^b (R^2-r^2)\\,dx\\).`,
        `Here \\(R(x)=${fTex}\\) and \\(r(x)=${gTex}\\).`,
        `Compute \\(\\int_a^b\\big(R^2-r^2\\big)dx = ${mwFracToTex(I)}\\).`,
        `Multiply by \\(\\pi\\).`
      ],
      vec: [unitIndex('C2_AppsInt'), 83, a,b,t,f[0],f[1]],
      key:'c2_volume_washer_poly'
    };
  }

  // shell method about y-axis: V = 2π ∫_a^b x f(x) dx
  const xf = [0, f[0], f[1], f[2]]; // x*f(x)
  const I = mwPolyDefInt(xf, a, b);
  const coef = mwMulF(mwFrac(2,1), I);
  return {
    q: `Find the volume of the solid obtained by rotating the region under \\(y=${fTex}\\) from \\(x=${a}\\) to \\(x=${b}\\) about the \\(y\\)-axis (Shell Method).`,
    a: `\\(V=2\\pi\\int_{${a}}^{${b}} x\\,(${fTex})\\,dx = \\left(${mwFracToTex(coef)}\\right)\\pi\\).`,
    steps: [
      `Shell method about the \\(y\\)-axis: \\(V=2\\pi\\int_a^b x\\,f(x)\\,dx\\).`,
      `Here \\(f(x)=${fTex}\\), so integrate \\(x f(x)\\) from \\(${a}\\) to \\(${b}\\).`,
      `The integral is \\(${mwFracToTex(I)}\\), then multiply by \\(2\\pi\\).`
    ],
    vec: [unitIndex('C2_AppsInt'), 84, a,b,f[0],f[1],f[2]],
    key:'c2_volume_shell_poly'
  };
});
registerGen('C2_AppsInt', (rng)=> {
  // Build a positive polynomial f(x)=c0 + c1 x + c2 x^2 on [a,b]
  let a=0, b=0, f=[0,0,0];
  let tries=0;
  while(tries++ < 200){
    a = pick(rng, [0,1]);
    b = pick(rng, [2,3,4,5]);
    const c2 = pick(rng, [0,0,0,1,1,2]); // mostly linear/constant
    const c1 = randInt(rng, -2, 3);
    const c0 = randInt(rng, 1, 6);
    f = [c0, c1, c2];
    // sample positivity
    const vals = [a,(a+b)/2,b].map(x=> f[0] + f[1]*x + f[2]*x*x);
    if(vals.every(v=> v > 0)) break;
  }

  const fTex = mwPolyToTex(f,'x');
  const sq = mwPolyPow2(f);
  const I = mwPolyDefInt(sq, a, b); // returns fraction-like {n,d} in your helper system

  return {
    q: `Find the volume of the solid obtained by rotating the region under \\(y=${fTex}\\) from \\(x=${a}\\) to \\(x=${b}\\) about the \\(x\\)-axis (Disk Method).`,
    a: `\\(V=\\pi\\int_{${a}}^{${b}}(${fTex})^2\\,dx = \\left(${mwFracToTex(I)}\\right)\\pi\\).`,
    steps: [
      `Disk method about the \\(x\\)-axis: \\(V=\\pi\\int_a^b [f(x)]^2\\,dx\\).`,
      `Here \\(f(x)=${fTex}\\), so integrate \\((${fTex})^2\\) from \\(${a}\\) to \\(${b}\\).`,
      `The definite integral evaluates to \\(${mwFracToTex(I)}\\).`,
      `Multiply by \\(\\pi\\) to get the volume.`
    ],
    vec: [unitIndex('C2_AppsInt'), 82, a, b, f[0], f[1], f[2]],
    key:'mth264_volrev_poly',
    meta: { topicId:'volume', topicLabel:'Volume' }
  };
});
registerGen('C2_AppsInt', (rng)=> {
  const R = randInt(rng, 3, 10);
  const h = randInt(rng, 1, R); // fill depth from bottom, 0<h<=R (hemisphere)

  // V = π ∫_0^h (2Ry - y^2) dy = π (R h^2 - h^3/3)
  const Rh2 = R * h * h;
  const h3_over3 = exactFrac(h*h*h, 3);

  // Build a clean LaTeX expression: π( Rh^2 - h^3/3 )
  const expr = `\\pi\\left(${Rh2} - ${h3_over3}\\right)`;

  return {
    q: `A hemispherical tank has radius \\(R=${R}\\). Find the volume of water when it is filled to depth \\(h=${h}\\) (measured from the bottom).`,
    a: `\\(${expr}\\)`,
    steps: [
      `Model the hemisphere by \\(x^2+(y-${R})^2=${R}^2\\) with \\(0\\le y\\le ${R}\\).`,
      `At height \\(y\\), cross-section radius satisfies \\(x^2=2${R}y-y^2\\).`,
      `Disk area: \\(A(y)=\\pi(2${R}y-y^2)\\).`,
      `Volume: \\(V=\\int_0^{${h}} A(y)\\,dy = \\pi\\int_0^{${h}}(2${R}y-y^2)\\,dy\\).`,
      `Compute: \\(\\pi\\left[${R}y^2-\\frac{y^3}{3}\\right]_0^{${h}}=\\pi\\left(${Rh2}-${h3_over3}\\right)\\).`
    ],
    vec: [unitIndex('C2_AppsInt'), 83, R, h],
    key:'mth264_vol_tank',
    meta: { topicId:'volume', topicLabel:'Volume' }
  };
});
registerGen('C2_AppsInt', (rng)=> {
  const p = randInt(rng, -4, 4) || 3;
  const q = randInt(rng, -4, 4) || -2;
  const t0 = pick(rng, [0,1]);
  const t1 = pick(rng, [2,3,4]);
  const dt = t1 - t0;

  const speed2 = p*p + q*q;
  const parts = mwSqrtParts(speed2);
  const a = parts.a, b = parts.b;

  let Ltex;
  if(b === 1){
    Ltex = `${dt*a}`;
  } else {
    const coef = dt*a;
    Ltex = (coef === 1) ? `\\sqrt{${b}}` : `${coef}\\sqrt{${b}}`;
  }

  return {
    q: `Find the arc length of the parametric curve \\(x=${p}t,\\; y=${q}t\\) for \\(${t0}\\le t\\le ${t1}\\).`,
    a: `\\(L=\\int_{${t0}}^{${t1}}\\sqrt{\\left(\\frac{dx}{dt}\\right)^2+\\left(\\frac{dy}{dt}\\right)^2}\\,dt = ${Ltex}\\).`,
    steps: [
      `Compute derivatives: \\(\\frac{dx}{dt}=${p}\\), \\(\\frac{dy}{dt}=${q}\\).`,
      `Speed: \\(\\sqrt{${p*p}+${q*q}}=${mwSqrtTex(speed2)}\\).`,
      `Since speed is constant, \\(L=(${t1}-${t0})\\cdot ${mwSqrtTex(speed2)} = ${Ltex}\\).`
    ],
    vec: [unitIndex('C2_AppsInt'), 85, p,q,t0,t1,0],
    key:'c2_arc_param_line'
  };
});
registerGen('C2_AppsInt', (rng)=> {
  const R = pick(rng, [1,2,3,4,5]);
  const interval = pick(rng, [
    {m:1,n:2, label:'0\\le \\theta \\le \\frac{\\pi}{2}'},
    {m:1,n:1, label:'0\\le \\theta \\le \\pi'},
    {m:2,n:1, label:'0\\le \\theta \\le 2\\pi'}
  ]);
  // For r=R constant, L = ∫ sqrt(r^2 + (dr/dθ)^2) dθ = ∫ R dθ = R Δθ
  const dThetaTex = mwPiTex(interval.m, interval.n);
  const L = mwPiTex(R*interval.m, interval.n);
  return {
    q: `Find the arc length of the polar curve \\(r=${R}\\) on the interval \\(${interval.label}\\).`,
    a: `\\(L=\\int \\sqrt{r^2+\\left(\\frac{dr}{d\\theta}\\right)^2}\\,d\\theta = \\int R\\,d\\theta = R\\,\\Delta\\theta = ${L}\\).`,
    steps: [
      `For \\(r=${R}\\), \\(\\frac{dr}{d\\theta}=0\\).`,
      `Arc length: \\(L=\\int_{\\theta_0}^{\\theta_1}\\sqrt{r^2+(r')^2}\\,d\\theta = \\int_{\\theta_0}^{\\theta_1}${R}\\,d\\theta\\).`,
      `Here \\(\\Delta\\theta=${dThetaTex}\\), so \\(L=${R}\\cdot ${dThetaTex}=${L}\\).`
    ],
    vec: [unitIndex('C2_AppsInt'), 86, R, interval.m, interval.n, 0,0],
    key:'c2_arc_polar_circle'
  };
});
registerGen('C2_AppsInt', (rng)=> {
  // arc length of y = x^2 on [0,1] requires integral sqrt(1+(2x)^2) dx; too heavy.
  // Use easy: y=0 on [0,1] => length 1 (but trivial). Better: y = ax, arc length on [0,1] = sqrt(1+a^2).
  const a = randInt(rng,1,5);
  const radicand = 1 + a*a;
  const exactLen = simplifyRadical(radicand);
  const decimalLen = Math.sqrt(radicand);
  
  return {
    q: `Find the arc length of \\(y=${a}x\\) on \\([0,1]\\).`,
    a: `\\(${exactLen}\\)${decimalLen > 3 ? ` \\(\\approx ${smartRound(decimalLen, 3)}\\)` : ''}`,
    steps: [
      `Arc length: \\(L=\\int_0^1\\sqrt{1+(y')^2}\\,dx\\).`,
      `Here \\(y'=${a}\\), so \\(L=\\int_0^1\\sqrt{1+${a*a}}\\,dx=${exactLen}\\).`
    ],
    vec: [unitIndex('C2_AppsInt'), 1, a,0,0],
    key:'c2_arc_length_line'
  };
});
registerGen('C2_AppsInt', (rng)=> {
  const k = randInt(rng,2,8);
  const a = randInt(rng,1,4);
  // work to stretch spring from 0 to a: ∫ kx dx = (k a^2)/2
  const W = k*a*a/2;
  return {
    q: `A spring has constant \\(k=${k}\\) (in appropriate units). Find the work to stretch it from \\(x=0\\) to \\(x=${a}\\).`,
    a: `\\(${W}\\)`,
    steps: [
      `Hooke's law: \\(F(x)=kx\\). Work: \\(W=\\int_0^{${a}} kx\\,dx\\).`,
      `\\(W=k\\left[\\frac{x^2}{2}\\right]_0^{${a}}=\\frac{k${a*a}}{2}=${W}\\).`
    ],
    vec: [unitIndex('C2_AppsInt'), 2, k, a,0],
    key:'c2_work_spring'
  };
});
registerGen('C2_AppsInt', (rng)=> {
  const a = randInt(rng, 0, 2);
  const b = randInt(rng, a+1, a+3);
  const area = (Math.pow(b, 3) - Math.pow(a, 3)) / 3;
  const diagram = svgIntegrationRegion(a, b);
  
  return {
    q: `Find the area under \\(y = x^2\\) from \\(x = ${a}\\) to \\(x = ${b}\\).<br><br>${diagram}`,
    a: `\\(\\frac{${b}^3 - ${a}^3}{3} = ${exactFrac(Math.pow(b,3) - Math.pow(a,3), 3)}\\)`,
    steps: [
      `Area: \\(A = \\int_{${a}}^{${b}} x^2\\,dx\\).`,
      `\\(A = \\left[\\frac{x^3}{3}\\right]_{${a}}^{${b}} = \\frac{${b}^3}{3} - \\frac{${a}^3}{3} = \\frac{${Math.pow(b,3)} - ${Math.pow(a,3)}}{3}\\).`
    ],
    vec: [unitIndex('C2_AppsInt'), 3, a, b],
    key: 'c2_area_under_curve'
  };
});
registerGen('C2_AppsInt', (rng)=> {
  const r = pick(rng, [2,3,4,5,6]);
  const q = `Find the surface area generated by revolving the curve \\(y=\\sqrt{${r*r}-x^2}\\) about the x-axis for \\(-${r}\\le x\\le ${r}\\).`;

  const aStr = `\\(S=4\\pi(${r}^2)=4\\pi\\cdot ${r*r}\\).`;

  const steps = [
    `Surface area about the x-axis: \\(S=2\\pi\\int_{a}^{b} y\\sqrt{1+(y')^2}\\,dx\\).`,
    `Here \\(y=\\sqrt{${r*r}-x^2}\\). Differentiate: \\(y'=\\frac{-x}{\\sqrt{${r*r}-x^2}}\\).`,
    `Compute \\(1+(y')^2=1+\\frac{x^2}{${r*r}-x^2}=\\frac{${r*r}}{${r*r}-x^2}\\), so \\(\\sqrt{1+(y')^2}=\\frac{${r}}{\\sqrt{${r*r}-x^2}}\\).`,
    `Then \\(y\\sqrt{1+(y')^2}=\\sqrt{${r*r}-x^2}\\cdot\\frac{${r}}{\\sqrt{${r*r}-x^2}}=${r}\\) (constant).`,
    `So \\(S=2\\pi\\int_{-${r}}^{${r}} ${r}\\,dx=2\\pi\\cdot ${r}\\cdot(2${r})=4\\pi ${r*r}\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C2_AppsInt'), 401, r], key:'c2_surface_area_sphere' };
});
registerGen('C2_AppsInt', (rng)=> {
  const q = `Find the arc length of \\(y=\\frac{1}{2}x^2\\) from \\(x=0\\) to \\(x=2\\). Give an exact answer.`;

  const aStr = `\\(L=\\int_0^2 \\sqrt{1+x^2}\\,dx=\\sqrt{5}+\\frac{1}{2}\\ln(2+\\sqrt{5})\\).`;

  const steps = [
    `Arc length for \\(y=f(x)\\) on \\([a,b]\\): \\(L=\\int_a^b \\sqrt{1+(f'(x))^2}\\,dx\\).`,
    `Here \\(y=\\frac{1}{2}x^2\\Rightarrow y'=x\\). So \\(L=\\int_0^2 \\sqrt{1+x^2}\\,dx\\).`,
    `Use the standard antiderivative: \\(\\int \\sqrt{1+x^2}\\,dx=\\frac{1}{2}\\left(x\\sqrt{1+x^2}+\\ln\\left|x+\\sqrt{1+x^2}\\right|\\right)+C\\).`,
    `Evaluate from 0 to 2:`,
    `\\(L=\\frac{1}{2}\\left(2\\sqrt{5}+\\ln(2+\\sqrt{5})\\right)-\\frac{1}{2}(0+\\ln 1)=\\sqrt{5}+\\frac{1}{2}\\ln(2+\\sqrt{5})\\).`
  ];

  return { q, a:aStr, steps, vec:[unitIndex('C2_AppsInt'), 402, 2], key:'c2_arc_length_sqrt1x2' };
});
registerGen('C2_AppsInt', (rng)=>{
  const a = pick(rng,[2,3,4,6]);
  const square = pick(rng,[true,false]);
  const num = a*a*a;
  const ans = square ? mwFracTex(num,3) : `\\frac{\\pi}{24}\\cdot ${num}` ;
  const ansT = square ? `\\(${mwFracTex(num,3)}\\)` : `\\(${mwFracTex(num,24)}\\pi\\)`;
  return {
    q: `The base of a solid is the triangle bounded by \\(y=0\\), \\(x=0\\), and \\(y=${a}-x\\). Cross-sections perpendicular to the \\(x\\)-axis are ${square?'squares':'semicircles (diameter on the base)'}. Find the volume.`,
    a: ansT,
    steps: [
      `Side length at position \\(x\\): \\(s=${a}-x\\).`,
      square
        ? `\\(V=\\int_0^{${a}} (${a}-x)^2\\,dx=\\left[-\\frac{(${a}-x)^3}{3}\\right]_0^{${a}}=${mwFracTex(num,3)}\\).`
        : `Semicircle of diameter \\(s\\): area \\(=\\frac{\\pi}{8}s^2\\). \\(V=\\frac{\\pi}{8}\\int_0^{${a}}(${a}-x)^2dx=\\frac{\\pi}{8}\\cdot\\frac{${num}}{3}=${mwFracTex(num,24)}\\pi\\).`
    ],
    traps: square
      ? [
          {ans:`\\(${num}\\)`, why:'Integrate the cross-sectional area along x — do not just cube the side.'},
          {ans:`\\(${mwFracTex(num,2)}\\)`, why:'∫(a−x)² dx over [0,a] equals a³/3.'},
          {ans:`\\(${mwFracTex(num,24)}\\pi\\)`, why:'π/8 belongs to SEMICIRCULAR cross-sections; squares have area s².'}
        ]
      : [
          {ans:`\\(${mwFracTex(num,12)}\\pi\\)`, why:'A SEMIcircle has half the area: π/8·s², not π/4·s².'},
          {ans:`\\(${mwFracTex(num,3)}\\)`, why:'That is the square-cross-section volume; semicircles carry the factor π/8.'},
          {ans:`\\(${mwFracTex(num,8)}\\pi\\)`, why:'Do not forget the ∫(a−x)²dx = a³/3 part.'}
        ],
    vec: [unitIndex('C2_AppsInt'), 20, a, square?1:0],
    key: 'c2_volume_cross_section'
  };
});
registerGen('C2_AppsInt', (rng)=>{
  const r = pick(rng,[1,2,3]);
  const H = pick(rng,[2,4,6]);
  const coef = r*r*H*H/2;
  return {
    q: `A cylindrical tank of radius \\(${r}\\) m and height \\(${H}\\) m is full of a liquid of weight density \\(\\rho\\) N/m\\(^3\\). Find the work required to pump all the liquid over the top. (Answer in terms of \\(\\rho\\).)`,
    a: `\\(${coef===1?'':coef}\\pi\\rho\\) J`,
    steps: [
      `A slice at height \\(y\\) (thickness \\(dy\\)) has weight \\(\\rho\\pi(${r})^2 dy\\) and rises \\(${H}-y\\).`,
      `\\(W=\\rho\\pi ${r*r===1?'':r*r}\\int_0^{${H}} (${H}-y)\\,dy=\\rho\\pi ${r*r===1?'':r*r}\\cdot\\frac{${H*H}}{2}=${coef===1?'':coef}\\pi\\rho\\) J.`
    ],
    traps: [
      {ans:`\\(${r*r*H*H===1?'':r*r*H*H}\\pi\\rho\\) J`, why:'∫(H−y)dy from 0 to H is H²/2 — the ½ matters.'},
      {ans:`\\(${r*r*H===1?'':r*r*H}\\pi\\rho\\) J`, why:'Each slice travels a DIFFERENT distance (H − y): work needs the integral, not weight × H alone.'},
      {ans:`\\(${r*H*H/2===1?'':r*H*H/2}\\pi\\rho\\) J`, why:'The slice cross-section is a disk: area πr² uses radius SQUARED.'}
    ],
    vec: [unitIndex('C2_AppsInt'), 21, r, H],
    key: 'c2_work_pumping'
  };
});
registerGen('C2_AppsInt', (rng)=>{
  const a = pick(rng,[3,6,9,12]);
  const xb = mwFracTex(2*a,3), yb = mwFracTex(a,3);
  return {
    q: `Find the centroid of the triangular region bounded by \\(y=x\\), \\(y=0\\), and \\(x=${a}\\).`,
    a: `\\(\\left(${xb}, ${yb}\\right)\\)`,
    steps: [
      `Area \\(=\\frac{${a}^2}{2}=${a*a/2}\\).`,
      `\\(\\bar{x}=\\frac{1}{A}\\int_0^{${a}} x\\cdot x\\,dx=\\frac{2}{${a*a}}\\cdot\\frac{${a}^3}{3}=${xb}\\).`,
      `\\(\\bar{y}=\\frac{1}{A}\\int_0^{${a}} \\frac{x^2}{2}\\,dx=\\frac{2}{${a*a}}\\cdot\\frac{${a}^3}{6}=${yb}\\).`
    ],
    traps: [
      {ans:`\\(\\left(${yb}, ${xb}\\right)\\)`, why:'x̄ and ȳ are swapped — the centroid of this triangle sits closer to the tall side in x.'},
      {ans:`\\(\\left(${mwFracTex(a,2)}, ${mwFracTex(a,2)}\\right)\\)`, why:'(a/2, a/2) is the centroid of a SQUARE; a triangle balances at thirds.'},
      {ans:`\\(\\left(${xb}, ${xb}\\right)\\)`, why:'ȳ uses ∫y·(strip) = ∫x²/2 dx here — it comes out a/3, not 2a/3.'}
    ],
    vec: [unitIndex('C2_AppsInt'), 22, a],
    key: 'c2_center_of_mass'
  };
});
registerGen('C2_Tech', (rng)=>{
  const a = pick(rng,[2,4]);
  const Tval = 3*a*a*a/8;
  const exact = mwFracTex(a*a*a,3);
  return {
    q: `Use the Trapezoidal Rule with \\(n=2\\) to estimate \\(\\displaystyle\\int_0^{${a}} x^2\\,dx\\).`,
    a: `\\(${Tval}\\)`,
    steps: [
      `\\(\\Delta x=${a/2}\\); nodes \\(x_0=0\\), \\(x_1=${a/2}\\), \\(x_2=${a}\\).`,
      `\\(T_2=\\frac{\\Delta x}{2}\\left[f(0)+2f(${a/2})+f(${a})\\right]=\\frac{${a/2}}{2}\\left[0+2\\cdot ${a*a/4}+${a*a}\\right]=${Tval}\\).`
    ],
    traps: [
      {ans:`\\(${exact}\\)`, why:'That is the EXACT value — the question asks for the trapezoidal ESTIMATE (which overshoots for concave-up f).'},
      {ans:`\\(${2*Tval}\\)`, why:'The rule carries a factor Δx/2 out front.'},
      {ans:`\\(${(a/2/2)*(a*a/4*1 + a*a)}\\)`, why:'Interior nodes are weighted by 2: f(0) + 2f(x1) + f(x2).'}
    ],
    vec: [unitIndex('C2_Tech'), 21, a],
    key: 'c2_numeric_trap_simpson'
  };
});
registerGen('C2_Series', (rng)=>{
  const a = mwNZ(rng,-6,6);
  const c = pick(rng,[1,2,3,4]);
  const b = randInt(rng,-9,9);
  const d = randInt(rng,-9,9);
  const co = (u)=> u===1?'':(u===-1?'-':`${u}`);
  return {
    q: `Find \\(\\displaystyle\\lim_{n\\to\\infty} a_n\\) for \\(a_n=\\dfrac{${co(a)}n${fmtSigned(b)}}{${co(c)}n${fmtSigned(d)}}\\).`,
    a: `\\(${mwFracTex(a,c)}\\)`,
    steps: [
      `Divide top and bottom by \\(n\\): \\(\\dfrac{${a}+${b}/n}{${c}+${d}/n}\\).`,
      `As \\(n\\to\\infty\\) the \\(1/n\\) terms vanish: limit \\(=${mwFracTex(a,c)}\\).`
    ],
    traps: [
      {ans:`\\(${d===0? (b===0?'1':`${b}`) : mwFracTex(b,d)}\\)`, why:'For n → ∞ the LEADING coefficients dominate, not the constants.'},
      {ans:`\\(0\\)`, why:'Same-degree top and bottom: the limit is the ratio of leading coefficients, not 0.'},
      {ans:`DNE`, why:'The sequence converges — same-degree rational sequences settle at the leading ratio.'}
    ],
    vec: [unitIndex('C2_Series'), 20, a, b, c, d],
    key: 'c2_sequence_limit'
  };
});
registerGen('C2_Series', (rng)=>{
  const a = pick(rng,[1,2,3]);
  const t1 = a===1?'x':`${a}x`;
  const c3 = mwFracTex(a*a*a,6);
  const c5 = mwFracTex(Math.pow(a,5),120);
  const correct = `\\(${t1}-${c3}x^3+${c5}x^5\\)`;
  return {
    q: `Find the first three nonzero terms of the Maclaurin series for \\(\\sin(${a===1?'':a}x)\\).`,
    a: correct,
    steps: [
      `\\(\\sin u=u-\\frac{u^3}{3!}+\\frac{u^5}{5!}-\\cdots\\) with \\(u=${a===1?'':a}x\\).`,
      `\\(u^3=${a*a*a}x^3\\), \\(u^5=${Math.pow(a,5)}x^5\\): \\(${t1}-\\frac{${a*a*a}}{6}x^3+\\frac{${Math.pow(a,5)}}{120}x^5\\).`
    ],
    traps: [
      {ans:`\\(${t1}+${c3}x^3+${c5}x^5\\)`, why:'The sine series ALTERNATES: minus on x³, plus on x⁵.'},
      {ans:`\\(${t1}-${mwFracTex(a,6)}x^3+${mwFracTex(a,120)}x^5\\)`, why:`Substitute u = ${a}x fully: u³ brings ${a}³, u⁵ brings ${a}⁵.`},
      {ans:`\\(1-${mwFracTex(a*a,2)}x^2+${mwFracTex(Math.pow(a,4),24)}x^4\\)`, why:'That is the COSINE series (even powers). Sine uses odd powers starting at x.'}
    ],
    vec: [unitIndex('C2_Series'), 21, a],
    key: 'c2_taylor_sincos'
  };
});
registerGen('C2_ParamPolar', (rng)=>{
  const eChoice = pick(rng,[['\\frac{1}{2}','Ellipse',0.5],['1','Parabola',1],['2','Hyperbola',2],['\\frac{1}{3}','Ellipse',1/3],['3','Hyperbola',3]]);
  const [eT, name, eV] = eChoice;
  const k = pick(rng,[2,3,4,6]);
  const others = ['Ellipse','Parabola','Hyperbola'].filter(n=>n!==name);
  return {
    q: `Identify the conic \\(r=\\dfrac{${k}}{1+${eT}\\cos\\theta}\\).`,
    a: `${name} (eccentricity \\(e=${eT}\\))`,
    steps: [
      `The form \\(r=\\frac{ed}{1+e\\cos\\theta}\\) has eccentricity equal to the coefficient of \\(\\cos\\theta\\): \\(e=${eT}\\).`,
      `\\(e<1\\): ellipse; \\(e=1\\): parabola; \\(e>1\\): hyperbola. Here: ${name.toLowerCase()}.`
    ],
    traps: [
      {ans:`${others[0]} (eccentricity \\(e=${eT}\\))`, why:'Classify by e: less than 1 → ellipse, equal to 1 → parabola, greater than 1 → hyperbola.'},
      {ans:`${others[1]} (eccentricity \\(e=${eT}\\))`, why:'Read e as the coefficient of cos θ in the standard polar form.'},
      {ans:`${name} (eccentricity \\(e=${k}\\))`, why:`The numerator is e·d, not e. Eccentricity is the cos θ coefficient.`}
    ],
    vec: [unitIndex('C2_ParamPolar'), 20, eV*6, k],
    key: 'c2_polar_conic'
  };
});
registerGen('C2_Tech', (rng)=>{
  const a = randInt(rng,2,9);
  let b = randInt(rng,2,9);
  const variant = pick(rng,['sin','exp']);
  const top = variant==='sin' ? `\\sin(${a}x)` : `e^{${a}x}-1`;
  const dtop = variant==='sin' ? `${a}\\cos(${a}x)` : `${a}e^{${a}x}`;
  return {
    q: `Use L'Hôpital's Rule to evaluate \\(\\displaystyle\\lim_{x\\to 0}\\frac{${top}}{${b}x}\\).`,
    a: `\\(${mwFracTex(a,b)}\\)`,
    steps: [
      `As \\(x\\to 0\\) both numerator and denominator \\(\\to 0\\): the form is \\(\\frac{0}{0}\\), so L'Hôpital applies.`,
      `Differentiate top and bottom: \\(\\displaystyle\\lim_{x\\to 0}\\frac{${dtop}}{${b}}\\).`,
      `Substitute \\(x=0\\): \\(${mwFracTex(a,b)}\\).`
    ],
    traps: [
      {ans:`\\(${mwFracTex(b,a)}\\)`, why:'Differentiate numerator over denominator — do not flip the fraction.'},
      {ans:`\\(0\\)`, why:'0/0 is INDETERMINATE, not 0 — that is exactly when L’Hôpital applies.'},
      {ans:`\\(1\\)`, why:`The inner coefficient matters: the chain rule brings down a factor of ${a}.`}
    ],
    vec: [unitIndex('C2_Tech'), 20, a, b, variant==='sin'?0:1],
    key: 'c2_lhopital'
  };
});
