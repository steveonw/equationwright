// QR generator registrations — order frozen by the published registry.
registerGen('QR_Proportion', (rng)=>{
  const b = pick(rng,[4,5,8,10]), d = pick(rng,[12,16,20,25]);
  const unit = mwNZ(rng,2,6);
  const a = unit*b, want = unit*d;
  return {
    q: `Solve the proportion \\(\\dfrac{${a}}{${b}} = \\dfrac{x}{${d}}\\).`,
    a: `\\(x = ${want}\\)`,
    steps: [
      `Cross-multiply: \\(${b}x = ${a}\\cdot${d} = ${a*d}\\).`,
      `Divide: \\(x = ${a*d}/${b} = ${want}\\).`,
      `Sense check: \\(${a}/${b} = ${unit}\\) per unit, and \\(${want}/${d} = ${unit}\\) too. ✓`
    ],
    traps: [
      {ans: `\\(x = ${a*b === want ? a*b+1 : Math.round(a*d/ d)}\\)`, why: 'Cross-multiply means multiplying the DIAGONAL pair, then dividing by the remaining number.'},
      {ans: `\\(x = ${a + (d - b)}\\)`, why: 'Proportions scale by multiplication, not by adding the same difference to both parts.'}
    ],
    vec: [unitIndex('QR_Proportion'), 1, a, b, d, want],
    key: 'qr_prop_solve'
  };
});
registerGen('QR_Proportion', (rng)=>{
  const ozA = pick(rng,[8,10,16]), perOz = pick(rng,[25,30,40]);        // cents per oz
  const ozB = ozA*2;
  const cheaper = pick(rng,['A','B']);
  const priceA = ozA*perOz, priceB = cheaper==='B' ? ozB*(perOz-5) : ozB*(perOz+5);
  const upA = perOz, upB = priceB/ozB;
  return {
    q: `Brand A: ${ozA} oz for ${priceA}¢. Brand B: ${ozB} oz for ${priceB}¢. Which is the better buy (lower unit price)?`,
    a: `Brand ${cheaper} (${cheaper==='A'?upA:upB}¢ per oz vs ${cheaper==='A'?upB:upA}¢ per oz)`,
    steps: [
      `Unit prices: A = ${priceA}/${ozA} = ${upA}¢ per oz; B = ${priceB}/${ozB} = ${upB}¢ per oz.`,
      `Lower unit price wins: Brand ${cheaper}.`
    ],
    traps: [
      {ans: `Brand ${cheaper==='A'?'B':'A'} (${cheaper==='A'?upB:upA}¢ per oz vs ${cheaper==='A'?upA:upB}¢ per oz)`, why: 'Compare PER-UNIT prices, and pick the LOWER one — the bigger package is not automatically the better buy.'},
      {ans: `They cost the same per ounce`, why: 'Divide each price by its own size before comparing — the unit prices differ here.'}
    ],
    vec: [unitIndex('QR_Proportion'), 2, ozA, priceA, ozB, priceB, cheaper==='A'?0:1],
    key: 'qr_prop_unitprice'
  };
});
registerGen('QR_Proportion', (rng)=>{
  const A = pick(rng,[40,50,80,200]);
  const pct = pick(rng,[10,20,25,50]);
  const up = pick(rng,[true,false]);
  const B = up ? A + A*pct/100 : A - A*pct/100;
  return {
    q: `A price changes from \\$${A} to \\$${B}. What is the percent change?`,
    a: `${up?'+':'-'}${pct}\\%`,
    steps: [
      `Percent change \\(= \\dfrac{\\text{new} - \\text{old}}{\\text{old}}\\times 100\\).`,
      `\\(= \\dfrac{${B} - ${A}}{${A}}\\times 100 = ${up?'+':'-'}${pct}\\%\\).`
    ],
    traps: [
      {ans: `${up?'+':'-'}${Math.round(Math.abs(B-A)/B*100)}\\%`, why: 'Divide by the ORIGINAL value (old), not the new one — the base of a percent change is where you started.'},
      {ans: `${up?'+':'-'}\\$${Math.abs(B-A)}`, why: 'That is the dollar change; percent change divides it by the original and multiplies by 100.'}
    ],
    vec: [unitIndex('QR_Proportion'), 3, A, B, up?pct:-pct],
    key: 'qr_percent_change'
  };
});
registerGen('QR_Proportion', (rng)=>{
  const k = pick(rng,[25,40,50]), inches = pick(rng,[3,4,6]);
  return {
    q: `A map's scale is 1 inch = ${k} miles. Two cities are ${inches} inches apart on the map. What is the real distance?`,
    a: `${k*inches} miles`,
    steps: [
      `Scale is a rate: ${k} miles per inch.`,
      `\\(${inches}\\times${k} = ${k*inches}\\) miles.`
    ],
    traps: [
      {ans: `${k + inches} miles`, why: 'Scales multiply — each inch stands for ' + k + ' miles, so ' + inches + ' inches is ' + inches + ' groups of ' + k + '.'},
      {ans: `${Math.round(k/inches)} miles`, why: 'Multiply by the map distance; dividing would shrink the real distance as the map distance grows.'}
    ],
    vec: [unitIndex('QR_Proportion'), 4, k, inches],
    key: 'qr_prop_scale'
  };
});
registerGen('QR_Finance', (rng)=>{
  const P = pick(rng,[500,1000,2000]), r = pick(rng,[3,4,5,6]), t = pick(rng,[2,3,5]);
  const I = P*r*t/100;
  return {
    q: `\\$${P} is deposited at ${r}\\% simple interest for ${t} years. How much interest is earned?`,
    a: `\\$${I}`,
    steps: [
      `Simple interest: \\(I = Prt\\).`,
      `\\(I = ${P}\\times${r/100 === 0.03 ? '0.03' : (r/100)}\\times${t} = ${I}\\).`
    ],
    traps: [
      {ans: `\\$${P*r*t}`, why: 'Convert the percent: ' + r + '% = ' + (r/100) + '. Skipping the conversion inflates the interest 100×.'},
      {ans: `\\$${P*r/100}`, why: 'Simple interest accrues EACH year — multiply by t = ' + t + ' years, not just one.'}
    ],
    vec: [unitIndex('QR_Finance'), 1, P, r, t, I],
    key: 'qr_fin_simple'
  };
});
registerGen('QR_Finance', (rng)=>{
  const P = pick(rng,[100,200,1000]), r = pick(rng,[10,20]);
  const g = 1 + r/100;
  const A = P*g*g;                                 // 2 years, exact
  return {
    q: `\\$${P} grows at ${r}\\% per year, compounded annually, for 2 years. What is the final amount?`,
    a: `\\$${A}`,
    steps: [
      `Compound growth: \\(A = P(1+r)^t = ${P}(${g})^2\\).`,
      `\\((${g})^2 = ${g*g}\\), so \\(A = ${A}\\).`,
      `Note: more than simple interest (\\$${P + 2*P*r/100}) — year 2 earns interest on year 1's interest.`
    ],
    traps: [
      {ans: `\\$${P + 2*P*r/100}`, why: 'That is SIMPLE interest. Compounding multiplies by (1+r) each year, earning interest on interest.'},
      {ans: `\\$${P*g*2}`, why: '(1+r)^2 means squared, not times 2 — compounding is repeated multiplication.'}
    ],
    vec: [unitIndex('QR_Finance'), 2, P, r, A],
    key: 'qr_fin_compound'
  };
});
registerGen('QR_Finance', (rng)=>{
  const price = pick(rng,[200,300,400])*100, pct = pick(rng,[5,10,20]);
  const down = price*pct/100;
  return {
    q: `A car costs \\$${price}. The buyer makes a ${pct}\\% down payment. How much is financed (borrowed)?`,
    a: `\\$${price - down}`,
    steps: [
      `Down payment: \\(${pct}\\%\\) of \\(${price}\\) = \\$${down}.`,
      `Financed = price − down payment = \\(${price} - ${down} = ${price - down}\\).`
    ],
    traps: [
      {ans: `\\$${down}`, why: 'That is the down payment itself — the amount FINANCED is what remains after it.'},
      {ans: `\\$${price + down}`, why: 'The down payment reduces the loan; it is not added to the price.'}
    ],
    vec: [unitIndex('QR_Finance'), 3, price, pct, down],
    key: 'qr_fin_downpayment'
  };
});
registerGen('QR_Finance', (rng)=>{
  const monthly = pick(rng,[250,300,400]), months = pick(rng,[24,36,48]);
  const principal = pick(rng,[6,8,10])*1000;
  const paid = monthly*months, interest = paid - principal;
  return {
    q: `A \\$${principal} loan is repaid with ${months} monthly payments of \\$${monthly}. How much total interest is paid?`,
    a: `\\$${interest}`,
    steps: [
      `Total paid: \\(${monthly}\\times${months} = ${paid}\\).`,
      `Interest = total paid − amount borrowed = \\(${paid} - ${principal} = ${interest}\\).`
    ],
    traps: [
      {ans: `\\$${paid}`, why: 'That is the TOTAL repaid — interest is the part beyond the original loan.'},
      {ans: `\\$${monthly*12}`, why: "One year's payments is neither the total nor the interest — use all " + months + " payments, then subtract the principal."}
    ],
    vec: [unitIndex('QR_Finance'), 4, principal, monthly, months, interest],
    key: 'qr_fin_loan_interest'
  };
});
registerGen('QR_Logic', (rng)=>{
  const pairs = [
    ['All students passed', 'Some students did not pass'],
    ['Some phones are cheap', 'No phones are cheap'],
    ['No cars are free', 'Some cars are free'],
    ['Some tests are not hard', 'All tests are hard']
  ];
  const i = pick(rng,[0,1,2,3]);
  const [stmt, neg] = pairs[i];
  const wrongs = {
    0: ['No students passed', 'All students did not pass'],
    1: ['All phones are cheap', 'Some phones are not cheap'],
    2: ['All cars are free', 'No cars are not free'],
    3: ['No tests are hard', 'Some tests are hard']
  }[i];
  return {
    q: `What is the negation of: “${stmt}”?`,
    a: `“${neg}”`,
    steps: [
      `Negation must be true exactly when the original is false.`,
      `“All are” negates to “Some are not”; “Some are” negates to “None are” — and vice versa.`,
      `So: “${neg}”.`
    ],
    traps: [
      {ans: `“${wrongs[0]}”`, why: 'The negation of "All are X" is "Some are not X" — NOT "None are X" (both could be false at once).'},
      {ans: `“${wrongs[1]}”`, why: 'Check: could this and the original both be true? A real negation can never share a truth value with the original.'}
    ],
    vec: [unitIndex('QR_Logic'), 1, i],
    key: 'qr_logic_negation'
  };
});
registerGen('QR_Logic', (rng)=>{
  const pv = pick(rng,[true,false]), qv = pick(rng,[true,false]);
  const which = pick(rng,[0,1,2]);
  const exprs = [
    { tex: '(p \\land q) \\lor \\neg p', f: (p,q)=> (p&&q) || !p },
    { tex: 'p \\land (\\neg q \\lor p)', f: (p,q)=> p && (!q || p) },
    { tex: '\\neg(p \\lor q)',           f: (p,q)=> !(p||q) }
  ];
  const e = exprs[which];
  const val = e.f(pv,qv);
  return {
    q: `If \\(p\\) is ${pv?'true':'false'} and \\(q\\) is ${qv?'true':'false'}, what is the truth value of \\(${e.tex}\\)?`,
    a: val ? 'True' : 'False',
    steps: [
      `Substitute: \\(p = ${pv?'T':'F'}\\), \\(q = ${qv?'T':'F'}\\).`,
      `Work inside-out: \\(\\neg\\) first, then \\(\\land\\), then \\(\\lor\\).`,
      `Result: ${val?'True':'False'}.`
    ],
    traps: [
      {ans: val ? 'False' : 'True', why: '∧ needs BOTH true; ∨ needs at least one; ¬ flips. Evaluate the innermost parentheses first.'},
      {ans: 'Cannot be determined', why: 'With both p and q assigned, every compound statement has a definite truth value.'}
    ],
    vec: [unitIndex('QR_Logic'), 2, which, pv?1:0, qv?1:0, val?1:0],
    key: 'qr_logic_truthvalue'
  };
});
registerGen('QR_Logic', (rng)=>{
  const forms = [
    { name: 'modus ponens',  lines: 'If it rains, the game is canceled. It rains. Therefore the game is canceled.', valid: true },
    { name: 'modus tollens', lines: 'If it rains, the game is canceled. The game is not canceled. Therefore it did not rain.', valid: true },
    { name: 'affirming the consequent', lines: 'If it rains, the game is canceled. The game is canceled. Therefore it rained.', valid: false },
    { name: 'denying the antecedent',   lines: 'If it rains, the game is canceled. It does not rain. Therefore the game is not canceled.', valid: false }
  ];
  const i = pick(rng,[0,1,2,3]);
  const f = forms[i];
  return {
    q: `Is this argument valid? “${f.lines}”`,
    a: f.valid ? 'Valid' : 'Invalid',
    steps: [
      `This is the form “${f.name}”.`,
      f.valid ? `It is one of the two valid conditional forms (modus ponens / modus tollens).`
              : `It is a classic fallacy — the game could be canceled (or on) for other reasons; the conditional only promises one direction.`
    ],
    traps: [
      {ans: f.valid ? 'Invalid' : 'Valid', why: 'Valid forms: affirm the IF-part (modus ponens) or deny the THEN-part (modus tollens). Affirming the then-part or denying the if-part proves nothing.'},
      {ans: 'Valid only if it actually rained', why: 'Validity is about FORM, not facts — a valid argument guarantees the conclusion whenever the premises hold, regardless of the weather.'}
    ],
    vec: [unitIndex('QR_Logic'), 3, i, f.valid?1:0],
    key: 'qr_logic_valid'
  };
});
registerGen('QR_Logic', (rng)=>{
  const nA = pick(rng,[20,25,30]), nB = pick(rng,[15,18,24]), both = pick(rng,[5,8,10]);
  const union = nA + nB - both;
  return {
    q: `In a class, ${nA} students take math, ${nB} take biology, and ${both} take both. How many take math or biology (or both)?`,
    a: `${union} students`,
    steps: [
      `Inclusion–exclusion: \\(|A \\cup B| = |A| + |B| - |A \\cap B|\\).`,
      `\\(${nA} + ${nB} - ${both} = ${union}\\) — subtracting the overlap so nobody is counted twice.`
    ],
    traps: [
      {ans: `${nA + nB} students`, why: 'The ' + both + ' students in both classes got counted twice — subtract the overlap once.'},
      {ans: `${nA + nB + both} students`, why: 'The overlap is SUBTRACTED, not added: those students already appear in both counts.'}
    ],
    vec: [unitIndex('QR_Logic'), 4, nA, nB, both, union],
    key: 'qr_set_union'
  };
});
registerGen('QR_Modeling', (rng)=>{
  const fixed = pick(rng,[30,50,100]), per = pick(rng,[2,5,10]), n = pick(rng,[8,12,20]);
  return {
    q: `A gym charges a \\$${fixed} joining fee plus \\$${per} per visit. Write the cost model and find the cost of ${n} visits.`,
    a: `\\(C(x) = ${per}x + ${fixed}\\); \\(C(${n}) = ${per*n + fixed}\\) dollars`,
    steps: [
      `Per-visit charge is the slope; the joining fee is the fixed (starting) value: \\(C(x) = ${per}x + ${fixed}\\).`,
      `\\(C(${n}) = ${per}(${n}) + ${fixed} = ${per*n + fixed}\\).`
    ],
    traps: [
      {ans: `\\(C(x) = ${fixed}x + ${per}\\); \\(C(${n}) = ${fixed*n + per}\\) dollars`, why: 'Slope and intercept swapped — the per-visit rate multiplies x; the one-time fee stands alone.'},
      {ans: `\\(C(x) = ${per}x + ${fixed}\\); \\(C(${n}) = ${per*n}\\) dollars`, why: 'The joining fee applies once but it still applies — add it to the visit charges.'}
    ],
    vec: [unitIndex('QR_Modeling'), 1, fixed, per, n],
    key: 'qr_model_build'
  };
});
registerGen('QR_Modeling', (rng)=>{
  const m = pick(rng,[15,25,40]), b = pick(rng,[60,100,200]);
  return {
    q: `A phone plan's cost is modeled by \\(C(g) = ${m}g + ${b}\\), where \\(g\\) is gigabytes used. What does the ${m} represent?`,
    a: `Each additional gigabyte costs \\$${m}`,
    steps: [
      `In \\(y = mx + b\\), the slope \\(m\\) is the rate of change — cost per unit of \\(g\\).`,
      `Here: \\$${m} per additional gigabyte. (The \\$${b} is the fixed base charge.)`
    ],
    traps: [
      {ans: `The base monthly charge is \\$${m}`, why: 'The base charge is the intercept ' + b + ' (the cost at g = 0). The coefficient on g is the per-gigabyte rate.'},
      {ans: `The total cost is \\$${m}`, why: 'The total depends on usage: C(g). The ' + m + ' is a RATE, dollars per gigabyte.'}
    ],
    vec: [unitIndex('QR_Modeling'), 2, m, b],
    key: 'qr_model_slope'
  };
});
registerGen('QR_Modeling', (rng)=>{
  const m = pick(rng,[5,10,20]), b = pick(rng,[40,50,100]);
  const n = pick(rng,[4,6,10]);
  const target = m*n + b;
  return {
    q: `Using the model \\(C(x) = ${m}x + ${b}\\), for what \\(x\\) is the cost exactly \\$${target}?`,
    a: `\\(x = ${n}\\)`,
    steps: [
      `Set the model equal to the target: \\(${m}x + ${b} = ${target}\\).`,
      `Subtract ${b}: \\(${m}x = ${target - b}\\); divide: \\(x = ${n}\\).`
    ],
    traps: [
      {ans: `\\(x = ${Math.round(target/m)}\\)`, why: 'Subtract the fixed ' + b + ' BEFORE dividing by the rate — only the variable part scales with x.'},
      {ans: `\\(x = ${target - b}\\)`, why: 'After subtracting ' + b + ', still divide by the per-unit rate ' + m + '.'}
    ],
    vec: [unitIndex('QR_Modeling'), 3, m, b, n, target],
    key: 'qr_model_solve'
  };
});
