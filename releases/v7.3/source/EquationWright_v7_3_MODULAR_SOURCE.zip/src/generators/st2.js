// ST2 generator registrations — order frozen by the published registry.
registerGen('ST2_ChiSquare', (rng)=>{
  // Observed vs expected built so each (O-E)^2/E is a clean integer
  const E = pick(rng,[10,20,25]);
  const d1 = pick(rng,[0, E/5>=2?Math.round(E/5):2]), d2 = pick(rng,[E/10>=1?Math.round(E/10):1, E/5>=2?Math.round(E/5):2]);
  const O = [E+d1, E-d1, E+d2, E-d2];
  const chi = (d1*d1 + d1*d1 + d2*d2 + d2*d2)/E;
  return {
    q: `A die-style experiment has 4 categories, each with expected count \\(E = ${E}\\). Observed counts: ${O.join(', ')}. Compute the chi-square statistic \\(\\chi^2 = \\sum \\frac{(O-E)^2}{E}\\).`,
    a: `\\(\\chi^2 = ${chi}\\)`,
    steps: [
      `Deviations: \\(${d1}, -${d1}, ${d2}, -${d2}\\) — square each: \\(${d1*d1}, ${d1*d1}, ${d2*d2}, ${d2*d2}\\).`,
      `Sum of squares: \\(${2*d1*d1 + 2*d2*d2}\\); divide each by \\(E=${E}\\) (same here): \\(\\chi^2 = ${chi}\\).`
    ],
    traps: [
      {ans: `\\(\\chi^2 = ${(2*d1 + 2*d2)/1}\\)`, why: 'Square the deviations before dividing — (O−E)²/E, not (O−E)/E. Unsquared deviations sum to zero.'},
      {ans: `\\(\\chi^2 = ${2*d1*d1 + 2*d2*d2}\\)`, why: 'Each squared deviation is divided by its expected count E — that scaling is what makes χ² comparable across studies.'}
    ],
    vec: [unitIndex('ST2_ChiSquare'), 1, E, d1, d2, chi],
    key: 'st2_chi_stat'
  };
});
registerGen('ST2_ChiSquare', (rng)=>{
  const r1 = pick(rng,[30,40,60]), r2 = pick(rng,[20,40,60]);
  const c1 = pick(rng,[25,50]), total = r1 + r2;
  const c2 = total - c1;
  const E11 = r1*c1/total;
  const ok = Number.isInteger(E11) ? 0 : 1;
  const E = Math.round(E11*100)/100;
  return {
    q: `In a two-way table, Row 1 total = ${r1}, Column 1 total = ${c1}, grand total = ${total}. What is the expected count for the Row 1–Column 1 cell (assuming independence)?`,
    a: `\\(E = \\dfrac{${r1}\\times${c1}}{${total}} = ${E}\\)`,
    steps: [
      `Expected count = (row total × column total) / grand total.`,
      `\\(E = ${r1}\\cdot${c1}/${total} = ${E}\\).`,
      `Independence predicts the cell in proportion to its row and column shares.`
    ],
    traps: [
      {ans: `\\(E = ${Math.round(r1*c1/100)/1}\\)`, why: 'Divide by the GRAND total of the table, not 100 — this is a count, not a percent.'},
      {ans: `\\(E = ${Math.round((r1+c1)/2*100)/100}\\)`, why: 'Expected counts multiply the marginal totals and divide by n — averaging the margins is not the independence model.'}
    ],
    vec: [unitIndex('ST2_ChiSquare'), 2, r1, c1, total, Math.round(E*100)],
    key: 'st2_chi_expected'
  };
});
registerGen('ST2_ChiSquare', (rng)=>{
  const r = pick(rng,[2,3,4]), c = pick(rng,[2,3]);
  const df = (r-1)*(c-1);
  const chi = df + pick(rng,[3,5,8]);        // stat above df
  const crit = pick(rng,[true,false]) ? chi - 1 : chi + 2;   // reject iff chi > crit
  const reject = chi > crit;
  return {
    q: `A chi-square test of independence on a ${r}×${c} table gives \\(\\chi^2 = ${chi}\\). The critical value at \\(\\alpha = 0.05\\) is ${crit}. State the degrees of freedom and the decision.`,
    a: `\\(df = ${df}\\); ${reject ? 'Reject' : 'Fail to reject'} \\(H_0\\)`,
    steps: [
      `\\(df = (r-1)(c-1) = (${r}-1)(${c}-1) = ${df}\\).`,
      `Decision rule: reject \\(H_0\\) (independence) when \\(\\chi^2 >\\) critical value.`,
      `\\(${chi} ${reject ? '>' : '<'} ${crit}\\): ${reject ? 'reject — evidence of association.' : 'fail to reject — no significant association shown.'}`
    ],
    traps: [
      {ans: `\\(df = ${r*c - 1}\\); ${reject ? 'Reject' : 'Fail to reject'} \\(H_0\\)`, why: 'For a TWO-WAY table, df = (r−1)(c−1). The rc−1 formula belongs to one-way goodness-of-fit.'},
      {ans: `\\(df = ${df}\\); ${reject ? 'Fail to reject' : 'Reject'} \\(H_0\\)`, why: 'Large χ² is evidence AGAINST independence — reject when the statistic EXCEEDS the critical value.'}
    ],
    vec: [unitIndex('ST2_ChiSquare'), 3, r, c, chi, crit, reject?1:0],
    key: 'st2_chi_decision'
  };
});
registerGen('ST2_ANOVA', (rng)=>{
  const k = pick(rng,[3,4,5]), n = pick(rng,[6,8,10]);
  const N = k*n;
  return {
    q: `An ANOVA compares \\(k = ${k}\\) groups with \\(${n}\\) observations each (total \\(N = ${N}\\)). Find the degrees of freedom (between, within).`,
    a: `\\(df_{between} = ${k-1}\\), \\(df_{within} = ${N-k}\\)`,
    steps: [
      `Between groups: \\(k - 1 = ${k-1}\\).`,
      `Within groups: \\(N - k = ${N} - ${k} = ${N-k}\\).`,
      `(They sum to \\(N - 1 = ${N-1}\\), the total df.)`
    ],
    traps: [
      {ans: `\\(df_{between} = ${k}\\), \\(df_{within} = ${N-k+1}\\)`, why: 'Each df loses one for an estimated mean: k−1 between, N−k within.'},
      {ans: `\\(df_{between} = ${k-1}\\), \\(df_{within} = ${N-1}\\)`, why: 'Within-groups df subtracts ALL k group means: N−k, not N−1.'}
    ],
    vec: [unitIndex('ST2_ANOVA'), 1, k, n, N],
    key: 'st2_anova_df'
  };
});
registerGen('ST2_ANOVA', (rng)=>{
  const dfb = pick(rng,[2,3,4]), dfw = pick(rng,[12,20,30]);
  const msw = pick(rng,[2,4,5]);
  const F = pick(rng,[3,4,6]);
  const msb = F*msw;
  const ssb = msb*dfb, ssw = msw*dfw;
  return {
    q: `An ANOVA gives \\(SS_{between} = ${ssb}\\) with \\(df_{between} = ${dfb}\\), and \\(SS_{within} = ${ssw}\\) with \\(df_{within} = ${dfw}\\). Compute the F statistic.`,
    a: `\\(F = ${F}\\)`,
    steps: [
      `Mean squares: \\(MS_B = ${ssb}/${dfb} = ${msb}\\); \\(MS_W = ${ssw}/${dfw} = ${msw}\\).`,
      `\\(F = MS_B / MS_W = ${msb}/${msw} = ${F}\\).`
    ],
    traps: [
      {ans: `\\(F = ${Math.round(ssb/ssw*100)/100}\\)`, why: 'F compares MEAN squares (SS ÷ df), not raw sums of squares — the df scaling is the point.'},
      {ans: `\\(F = ${Math.round(msw/msb*1000)/1000}\\)`, why: 'Between-groups variance goes on TOP: F = MS_B / MS_W. Large F = groups differ more than noise explains.'}
    ],
    vec: [unitIndex('ST2_ANOVA'), 2, ssb, dfb, ssw, dfw, F],
    key: 'st2_anova_f'
  };
});
registerGen('ST2_ANOVA', (rng)=>{
  const F = pick(rng,[2,5,7]), crit = pick(rng,[3,4]);
  const reject = F > crit;
  return {
    q: `A one-way ANOVA yields \\(F = ${F}\\); the critical value at \\(\\alpha = 0.05\\) is ${crit}. What is the correct conclusion?`,
    a: reject ? 'Reject H₀: at least one group mean differs' : 'Fail to reject H₀: no significant difference among the means',
    steps: [
      `\\(H_0\\): all group means are equal. Reject when \\(F >\\) critical value.`,
      `\\(${F} ${reject?'>':'<'} ${crit}\\): ${reject ? 'reject.' : 'fail to reject.'}`,
      reject ? `ANOVA says SOME mean differs — it does not say which (that needs follow-up comparisons).` : `The variation between groups is within what chance would produce.`
    ],
    traps: [
      {ans: reject ? 'Reject H₀: all group means differ from each other' : 'Reject H₀: at least one group mean differs', why: reject ? 'A significant F says AT LEAST ONE mean differs — not that every pair differs.' : 'Reject only when F exceeds the critical value.'},
      {ans: reject ? 'Fail to reject H₀: no significant difference among the means' : 'Accept H₀: the means are proven equal', why: reject ? 'F exceeds the critical value — that IS the rejection region.' : '“Fail to reject” is not proof of equality — absence of evidence, not evidence of absence.'}
    ],
    vec: [unitIndex('ST2_ANOVA'), 3, F, crit, reject?1:0],
    key: 'st2_anova_decision'
  };
});
registerGen('ST2_Regression', (rng)=>{
  const a = pick(rng,[10,20,50]), b = pick(rng,[2,3,5]), x0 = pick(rng,[4,6,10]);
  return {
    q: `A regression line is \\(\\hat{y} = ${a} + ${b}x\\). Predict \\(y\\) when \\(x = ${x0}\\).`,
    a: `\\(\\hat{y} = ${a + b*x0}\\)`,
    steps: [ `Substitute: \\(\\hat{y} = ${a} + ${b}(${x0}) = ${a + b*x0}\\).` ],
    traps: [
      {ans: `\\(\\hat{y} = ${(a + b)*x0}\\)`, why: 'Only the slope multiplies x; the intercept ' + a + ' is added afterward.'},
      {ans: `\\(\\hat{y} = ${a*x0 + b}\\)`, why: 'Intercept and slope swapped — the coefficient ON x is ' + b + '.'}
    ],
    vec: [unitIndex('ST2_Regression'), 1, a, b, x0],
    key: 'st2_reg_predict'
  };
});
registerGen('ST2_Regression', (rng)=>{
  const a = pick(rng,[5,10]), b = pick(rng,[2,4]), x0 = pick(rng,[3,5]);
  const yhat = a + b*x0;
  const res = pick(rng,[-4,-2,3,5]);
  const y = yhat + res;
  return {
    q: `With regression line \\(\\hat{y} = ${a} + ${b}x\\), a data point is \\((${x0}, ${y})\\). Find the residual.`,
    a: `\\(${res}\\)`,
    steps: [
      `Predicted: \\(\\hat{y} = ${a} + ${b}(${x0}) = ${yhat}\\).`,
      `Residual = observed − predicted = \\(${y} - ${yhat} = ${res}\\).`,
      res > 0 ? `Positive: the point sits ABOVE the line.` : `Negative: the point sits BELOW the line.`
    ],
    traps: [
      {ans: `\\(${-res}\\)`, why: 'Residual = observed MINUS predicted (y − ŷ). Reversing the order flips the sign and the above/below interpretation.'},
      {ans: `\\(${y}\\)`, why: 'The residual is the GAP between the point and the line, not the observed value itself.'}
    ],
    vec: [unitIndex('ST2_Regression'), 2, a, b, x0, y, res],
    key: 'st2_reg_residual'
  };
});
registerGen('ST2_Regression', (rng)=>{
  const b = pick(rng,[3,5,8]);
  return {
    q: `In the model \\(\\hat{y} = 40 + ${b}x\\) (y = exam score, x = hours studied), what does the ${b} mean?`,
    a: `Each additional hour of study is associated with about ${b} more points, on average`,
    steps: [
      `The slope is the predicted change in \\(y\\) per one-unit increase in \\(x\\).`,
      `Here: +${b} points per extra hour — an average association, not a guarantee for any single student.`
    ],
    traps: [
      {ans: `Studying ${b} hours guarantees passing`, why: 'Regression describes an average trend with scatter — it cannot guarantee an individual outcome.'},
      {ans: `A student who studies zero hours scores ${b}`, why: 'The zero-hours prediction is the INTERCEPT (40 here); the ' + b + ' is a rate of change.'}
    ],
    vec: [unitIndex('ST2_Regression'), 3, b],
    key: 'st2_reg_slope_meaning'
  };
});
registerGen('ST2_Regression', (rng)=>{
  const r2 = pick(rng,[36,49,64,81]);
  return {
    q: `A regression has \\(r^2 = 0.${r2}\\). What is the correct interpretation?`,
    a: `About ${r2}\\% of the variation in y is explained by the linear relationship with x`,
    steps: [
      `\\(r^2\\) is the coefficient of determination: the fraction of the variance in \\(y\\) accounted for by the model.`,
      `\\(0.${r2} \\Rightarrow ${r2}\\%\\) explained; the remaining ${100-r2}\\% is scatter/other factors.`
    ],
    traps: [
      {ans: `${r2}\\% of predictions are correct`, why: 'r² measures explained VARIATION, not an accuracy rate for individual predictions.'},
      {ans: `The correlation between x and y is 0.${r2}`, why: 'The correlation r is the square ROOT: |r| = ' + (Math.sqrt(r2)/10).toFixed(1) + ' here (sign from the slope).'}
    ],
    vec: [unitIndex('ST2_Regression'), 4, r2],
    key: 'st2_reg_r2'
  };
});
registerGen('ST2_Design', (rng)=>{
  const kinds = [
    { name: 'Completely randomized design', desc: 'Subjects are randomly assigned to one of the treatment groups with no other structure.' },
    { name: 'Randomized block design', desc: 'Subjects are first grouped by age bracket, then randomly assigned to treatments within each bracket.' },
    { name: 'Matched pairs design', desc: 'Each subject receives both treatments in random order, serving as their own control.' }
  ];
  const i = pick(rng,[0,1,2]);
  const others = kinds.filter((_,j)=>j!==i).map(x=>x.name);
  return {
    q: `Identify the experimental design: “${kinds[i].desc}”`,
    a: kinds[i].name,
    steps: [
      i===0 ? `Randomization with no pre-grouping = completely randomized.` :
      i===1 ? `Grouping by a known factor FIRST (blocking), then randomizing within blocks, controls that factor's noise.` :
              `Each subject compared against themselves = matched pairs — the strongest control of subject-to-subject variation.`
    ],
    traps: [
      {ans: others[0], why: 'Look for the structure BEFORE randomization: none = completely randomized; grouped first = blocked; self-paired = matched pairs.'},
      {ans: others[1], why: 'Blocking is deliberate pre-grouping by a nuisance variable; matched pairs is the special case where the "block" is one subject.'}
    ],
    vec: [unitIndex('ST2_Design'), 1, i],
    key: 'st2_design_identify'
  };
});
registerGen('ST2_Design', (rng)=>{
  const i = pick(rng,[0,1]);
  const scen = [
    { q: 'Students who eat breakfast score higher on exams. Family income affects both breakfast habits and school resources.', conf: 'Family income', wrong: 'Breakfast' },
    { q: 'Cities with more ice cream sales have more drownings. Hot weather increases both swimming and ice cream sales.', conf: 'Hot weather (temperature)', wrong: 'Ice cream sales' }
  ][i];
  return {
    q: `${scen.q} What is the likely confounding (lurking) variable?`,
    a: scen.conf,
    steps: [
      `A confounder influences BOTH the explanatory and response variables, creating an association without causation.`,
      `Here, ${scen.conf.toLowerCase()} drives both measured variables.`
    ],
    traps: [
      {ans: scen.wrong, why: 'That is the explanatory variable itself — a confounder is a THIRD variable acting on both.'},
      {ans: 'There is no confounding; the relationship is causal', why: 'Observational associations with a plausible third-variable driver cannot establish causation — that requires a randomized experiment.'}
    ],
    vec: [unitIndex('ST2_Design'), 2, i],
    key: 'st2_design_confound'
  };
});
registerGen('ST2_Design', (rng)=>{
  const plus = pick(rng,[7,8,9]), minus = pick(rng,[2,3]);
  const n = plus + minus;
  return {
    q: `In a matched-pairs study, ${plus} of ${n} pairs improved (+) and ${minus} got worse (−), with no ties. What is the sign test statistic (number of + signs), and its expected value if the treatment has no effect?`,
    a: `Statistic = ${plus}; expected under \\(H_0\\) = ${n}/2 = ${n/2 === Math.floor(n/2) ? n/2 : '\\frac{'+n+'}{2}'}`,
    steps: [
      `The sign test just counts positive differences: ${plus}.`,
      `Under "no effect," + and − are equally likely: expected \\(= n/2 = ${n}/2\\).`,
      `${plus} is well above ${(n/2).toFixed(1)} — the data lean toward improvement (a p-value would quantify how unusual).`
    ],
    traps: [
      {ans: `Statistic = ${plus - minus}; expected = 0`, why: 'The sign test statistic is the COUNT of + signs, compared to n/2 — not the difference of counts.'},
      {ans: `Statistic = ${plus}; expected = ${plus}`, why: 'The expectation comes from H₀ (no effect ⇒ 50/50), not from the observed data.'}
    ],
    vec: [unitIndex('ST2_Design'), 3, plus, minus, n],
    key: 'st2_nonparam_sign'
  };
});
registerGen('ST2_Design', (rng)=>{
  const i = pick(rng,[0,1]);
  const scen = [
    { d: 'Customer satisfaction rated on a 1–5 ordinal scale', why: 'ordinal data — differences between ranks are not meaningful distances' },
    { d: 'Reaction times with several extreme outliers and strong skew', why: 'heavy skew/outliers break the normality that t-procedures lean on' }
  ][i];
  return {
    q: `Data: ${scen.d}. Why would a non-parametric test (e.g., a rank-based test) be preferred over a t-test?`,
    a: `Because the data are ${i===0?'ordinal':'strongly non-normal'} — non-parametric tests do not require normally distributed interval data`,
    steps: [
      `t-procedures assume roughly normal, interval-scale data.`,
      `Here: ${scen.why}.`,
      `Rank-based methods trade a little power for validity under these conditions.`
    ],
    traps: [
      {ans: `Because non-parametric tests always have more power`, why: 'When normality actually holds, the t-test is MORE powerful — non-parametrics are the robust fallback, not a free upgrade.'},
      {ans: `Because the sample size is too large for a t-test`, why: 'Large samples HELP t-procedures (CLT); the issue here is the data scale/shape, not the size.'}
    ],
    vec: [unitIndex('ST2_Design'), 4, i],
    key: 'st2_nonparam_when'
  };
});
