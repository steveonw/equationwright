// D289 generator registrations — order frozen by the published registry.
registerGen('D289_FirstOrder', genD289Separable);
registerGen('D289_FirstOrder', genD289Linear);
registerGen('D289_Systems', (rng)=>{
  const l1 = mwNZ(rng,-4,-1);
  const l2 = mwNZ(rng,1,4);
  const k = mwNZ(rng,1,4);
  return d289MakeProblem({
    unitId:'D289_Systems', genNum:1,
    q:`Find the eigenvalues of the system matrix \\(A=${laMtx([[l1,k],[0,l2]])}\\).`,
    a:`\\(\\lambda_1=${l1},\\ \\lambda_2=${l2}\\)`,
    steps:[
      `The matrix is upper triangular, so its eigenvalues are its diagonal entries.`,
      `Therefore \\(\\lambda_1=${l1}\\) and \\(\\lambda_2=${l2}\\).`
    ],
    traps:[
      d289Trap(`\\(\\lambda_1=${l1+k},\\ \\lambda_2=${l2}\\)`, 'The off-diagonal entry does not change eigenvalues of a triangular matrix.'),
      d289Trap(`\\(\\lambda_1=${-l1},\\ \\lambda_2=${-l2}\\)`, 'The eigenvalues are the roots of det(A-λI), with their original signs.')
    ],
    vecTail:[l1,l2,k], key:'d289_systems_eigenvalues_triangular',
    auditSpec:{family:'systems-eigenvalues',l1,l2,k}
  });
});
registerGen('D289_Systems', (rng)=>{
  const l1 = mwNZ(rng,-4,1);
  const gap = pick(rng,[2,3,4]);
  const l2 = l1 + gap;
  const k = mwNZ(rng,1,4);
  const v = [k,gap];
  return d289MakeProblem({
    unitId:'D289_Systems', genNum:2,
    q:`For \\(A=${laMtx([[l1,k],[0,l2]])}\\), give an eigenvector for \\(\\lambda=${l2}\\).`,
    a:`\\(${laMtx([[v[0]],[v[1]]])}\\) (or any nonzero multiple)`,
    steps:[
      `Solve \\((A-${l2}I)\\mathbf v=0\\).`,
      `The first row gives \\(${l1-l2}v_1+${k}v_2=0\\); choosing \\(v_1=${k}\\), \\(v_2=${gap}\\) satisfies it.`
    ],
    traps:[
      d289Trap(`\\(${laMtx([[1],[0]])}\\)`, 'That vector belongs to the other eigenvalue for this triangular matrix.'),
      d289Trap(`\\(${laMtx([[0],[0]])}\\)`, 'The zero vector is never an eigenvector.')
    ],
    vecTail:[l1,l2,k,gap], key:'d289_systems_eigenvector',
    auditSpec:{family:'systems-eigenvector',l1,l2,k,gap,v}
  });
});
registerGen('D289_Systems', (rng)=>{
  const a = mwNZ(rng,-4,4);
  let b = mwNZ(rng,-4,4);
  if(b === a) b += (b < 4 ? 1 : -1);
  return d289MakeProblem({
    unitId:'D289_Systems', genNum:3,
    q:`Write the general solution of \\(x'=${a}x,\\ y'=${b}y\\).`,
    a:`\\(x=C_1e^{${a}t},\\quad y=C_2e^{${b}t}\\)`,
    steps:[
      `The diagonal system separates into two scalar equations.`,
      `Solve each exponential equation independently.`
    ],
    traps:[
      d289Trap(`\\(x=C_1e^{${b}t},\\quad y=C_2e^{${a}t}\\)`, 'Each exponent must stay paired with its own equation.'),
      d289Trap(`\\(x=C_1+${a}t,\\quad y=C_2+${b}t\\)`, 'Solutions of x′=ax are exponential, not linear.')
    ],
    vecTail:[a,b], key:'d289_systems_diagonal_general_solution',
    auditSpec:{family:'systems-diagonal-general',a,b}
  });
});
registerGen('D289_Systems', (rng)=>{
  const kind = pick(rng,[0,1,2]);
  const pairs = [
    [-pick(rng,[1,2,3]), -pick(rng,[4,5,6])],
    [pick(rng,[1,2,3]), pick(rng,[4,5,6])],
    [-pick(rng,[1,2,3]), pick(rng,[1,2,3])]
  ];
  const [l1,l2] = pairs[kind];
  const labels = ['Stable node','Unstable node','Saddle'];
  const answer = labels[kind];
  return d289MakeProblem({
    unitId:'D289_Systems', genNum:4,
    q:`Classify the equilibrium at the origin when the real eigenvalues are \\(\\lambda_1=${l1}\\) and \\(\\lambda_2=${l2}\\).`,
    a:answer,
    steps:[
      `Both negative gives decay, both positive gives growth, and opposite signs give a saddle.`,
      `Here the sign pattern is \\(${l1<0?'-':'+'},${l2<0?'-':'+'}\\), so the origin is a ${answer.toLowerCase()}.`
    ],
    traps:[
      d289Trap(labels[(kind+1)%3], 'Classification is determined by the signs of the eigenvalues.'),
      d289Trap(labels[(kind+2)%3], 'Recheck whether both directions decay, both grow, or one does each.')
    ],
    vecTail:[kind,l1,l2], key:'d289_systems_equilibrium_classification',
    auditSpec:{family:'systems-classification',kind,l1,l2,answer}
  });
});
registerGen('D289_Systems', (rng)=>{
  const a = mwNZ(rng,-4,4);
  let b = mwNZ(rng,-4,4);
  if(b === a) b += 1;
  const x0 = mwNZ(rng,-5,5);
  const y0 = mwNZ(rng,-5,5);
  return d289MakeProblem({
    unitId:'D289_Systems', genNum:5,
    q:`Solve the IVP \\(x'=${a}x,\\ y'=${b}y,\\ x(0)=${x0},\\ y(0)=${y0}\\).`,
    a:`\\(x=${x0}e^{${a}t},\\quad y=${y0}e^{${b}t}\\)`,
    steps:[
      `The diagonal equations solve independently.`,
      `Use \\(x(0)=${x0}\\) and \\(y(0)=${y0}\\) to determine the two constants.`
    ],
    traps:[
      d289Trap(`\\(x=${a}e^{${x0}t},\\quad y=${b}e^{${y0}t}\\)`, 'The initial values are amplitudes; the matrix entries are exponent rates.'),
      d289Trap(`\\(x=${x0}+${a}t,\\quad y=${y0}+${b}t\\)`, 'Constant-coefficient homogeneous systems produce exponentials.')
    ],
    vecTail:[a,b,x0,y0], key:'d289_systems_diagonal_ivp',
    auditSpec:{family:'systems-diagonal-ivp',a,b,x0,y0}
  });
});
registerGen('D289_Systems', (rng)=>{
  const alpha = pick(rng,[-3,-2,-1,0,1,2,3]);
  const beta = pick(rng,[1,2,3,4]);
  const A = [[alpha,-beta],[beta,alpha]];
  const answer = alpha < 0 ? 'Stable spiral' : (alpha > 0 ? 'Unstable spiral' : 'Center');
  return d289MakeProblem({
    unitId:'D289_Systems', genNum:6,
    q:`Classify the origin for \\(\\mathbf{x}'=A\\mathbf{x}\\) with \\(A=${laMtx(A)}\\).`,
    a:answer,
    steps:[
      `The eigenvalues are \\(${alpha}\\pm ${beta}i\\).`,
      alpha < 0 ? `Negative real part gives a stable spiral.` :
      alpha > 0 ? `Positive real part gives an unstable spiral.` :
                  `Zero real part with nonzero imaginary part gives a center.`
    ],
    traps:[
      d289Trap(answer==='Stable spiral'?'Unstable spiral':'Stable spiral', 'The sign of the real part controls inward versus outward motion.'),
      d289Trap(answer==='Center'?'Saddle':'Center', 'A center requires zero real part; a saddle requires real eigenvalues of opposite signs.')
    ],
    vecTail:[alpha,beta], key:'d289_systems_complex_eigen_classification',
    auditSpec:{family:'systems-complex-classification',alpha,beta,answer}
  });
});
registerGen('D289_Series', (rng)=>{
  const c = mwNZ(rng,-4,4);
  return d289MakeProblem({
    unitId:'D289_Series', genNum:1,
    q:`For a power-series solution \\(y=\\sum_{n=0}^{\\infty}a_nx^n\\) of \\(y''=${c}xy\\), give the recurrence for \\(n\\ge1\\).`,
    a:`\\(a_{n+2}=\\dfrac{${c}a_{n-1}}{(n+2)(n+1)}\\)`,
    steps:[
      `Write \\(y''=\\sum_{n=0}^{\\infty}(n+2)(n+1)a_{n+2}x^n\\).`,
      `Write \\(${c}xy=${c}\\sum_{n=1}^{\\infty}a_{n-1}x^n\\), then equate coefficients.`
    ],
    traps:[
      d289Trap(`\\(a_{n+2}=\\dfrac{${c}a_n}{(n+2)(n+1)}\\)`, 'Multiplication by x shifts the coefficient index to a_{n-1}.'),
      d289Trap(`\\(a_{n+2}=${c}(n+2)(n+1)a_{n-1}\\)`, 'The derivative factors divide when solving for a_{n+2}.')
    ],
    vecTail:[c], key:'d289_series_xy_recurrence',
    auditSpec:{family:'series-xy-recurrence',c}
  });
});
registerGen('D289_Series', (rng)=>{
  const c = mwNZ(rng,-3,3);
  const a0 = mwNZ(rng,-4,4);
  const a1 = mwNZ(rng,-4,4);
  const a3 = d289FracParts(c*a0,6);
  const a4 = d289FracParts(c*a1,12);
  const t3 = a3[0]===0 ? '' : `${a3[0]>0?'+':'-'}${d289FracTex(Math.abs(a3[0]),a3[1])}x^3`;
  const t4 = a4[0]===0 ? '' : `${a4[0]>0?'+':'-'}${d289FracTex(Math.abs(a4[0]),a4[1])}x^4`;
  const ans = `\\(y=${a0}${a1>=0?'+':''}${a1}x${t3}${t4}+\\cdots\\)`;
  return d289MakeProblem({
    unitId:'D289_Series', genNum:2,
    q:`For \\(y''=${c}xy\\), \\(y(0)=${a0}\\), \\(y'(0)=${a1}\\), write terms through \\(x^4\\).`,
    a:ans,
    steps:[
      `The constant and linear coefficients are \\(a_0=${a0}\\), \\(a_1=${a1}\\), and \\(a_2=0\\).`,
      `The recurrence gives \\(a_3=${d289FracTex(c*a0,6)}\\) and \\(a_4=${d289FracTex(c*a1,12)}\\).`
    ],
    traps:[
      d289Trap(`\\(y=${a0}${a1>=0?'+':''}${a1}x+${c*a0}x^3+${c*a1}x^4+\\cdots\\)`, 'The factorial factors from y″ must divide the coefficients.'),
      d289Trap(`\\(y=${a0}${a1>=0?'+':''}${a1}x+${d289FracTex(c*a0,2)}x^2+\\cdots\\)`, 'The x^2 coefficient is zero because the right side has no constant term.')
    ],
    vecTail:[c,a0,a1,a3[0],a3[1],a4[0],a4[1]], key:'d289_series_xy_first_terms',
    auditSpec:{family:'series-xy-terms',c,a0,a1,a3,a4}
  });
});
registerGen('D289_Series', (rng)=>{
  const k = pick(rng,[1,2,3,4,5,6]);
  return d289MakeProblem({
    unitId:'D289_Series', genNum:3,
    q:`For \\(y''+${k}y=0\\) with \\(y=\\sum a_nx^n\\), give the coefficient recurrence.`,
    a:`\\(a_{n+2}=-\\dfrac{${k}a_n}{(n+2)(n+1)}\\)`,
    steps:[
      `Shift the y″ series to powers x^n.`,
      `Equating coefficients gives \\((n+2)(n+1)a_{n+2}+${k}a_n=0\\).`
    ],
    traps:[
      d289Trap(`\\(a_{n+2}=\\dfrac{${k}a_n}{(n+2)(n+1)}\\)`, 'Moving the k a_n term across the equation introduces a minus sign.'),
      d289Trap(`\\(a_{n+2}=-${k}(n+2)(n+1)a_n\\)`, 'Solve by dividing by the derivative factors.')
    ],
    vecTail:[k], key:'d289_series_harmonic_recurrence',
    auditSpec:{family:'series-harmonic-recurrence',k}
  });
});
registerGen('D289_Series', (rng)=>{
  const k = pick(rng,[1,2,3,4,5]);
  const A = mwNZ(rng,-4,4);
  const B = mwNZ(rng,-4,4);
  const a2 = d289FracParts(-k*A,2);
  const a3 = d289FracParts(-k*B,6);
  const ans = `\\(y=${A}${B>=0?'+':''}${B}x${a2[0]>=0?'+':'-'}${d289FracTex(Math.abs(a2[0]),a2[1])}x^2${a3[0]>=0?'+':'-'}${d289FracTex(Math.abs(a3[0]),a3[1])}x^3+\\cdots\\)`;
  return d289MakeProblem({
    unitId:'D289_Series', genNum:4,
    q:`For \\(y''+${k}y=0\\), \\(y(0)=${A}\\), \\(y'(0)=${B}\\), write terms through \\(x^3\\).`,
    a:ans,
    steps:[
      `Use \\(a_0=${A}\\), \\(a_1=${B}\\), and \\(a_{n+2}=-${k}a_n/((n+2)(n+1))\\).`,
      `Thus \\(a_2=${d289FracTex(-k*A,2)}\\) and \\(a_3=${d289FracTex(-k*B,6)}\\).`
    ],
    traps:[
      d289Trap(`\\(y=${A}${B>=0?'+':''}${B}x+${d289FracTex(k*A,2)}x^2+${d289FracTex(k*B,6)}x^3+\\cdots\\)`, 'Both recurrence coefficients carry a minus sign.'),
      d289Trap(`\\(y=${A}+${d289FracTex(-k*A,2)}x^2+\\cdots\\)`, 'A nonzero y′(0) contributes the odd-power series.')
    ],
    vecTail:[k,A,B,a2[0],a2[1],a3[0],a3[1]], key:'d289_series_harmonic_first_terms',
    auditSpec:{family:'series-harmonic-terms',k,A,B,a2,a3}
  });
});
registerGen('D289_Series', (rng)=>{
  const c = pick(rng,[-3,-2,-1,0,1,2,3]);
  const x0 = pick(rng,[-3,-2,-1,0,1,2,3]);
  const ordinary = x0 !== c;
  const answer = ordinary ? 'Ordinary point' : 'Singular point';
  return d289MakeProblem({
    unitId:'D289_Series', genNum:5,
    q:`For \\((x-${c})y''+(x+1)y'+y=0\\), classify \\(x_0=${x0}\\) for a power-series expansion.`,
    a:answer,
    steps:[
      `An ordinary point requires the leading coefficient of y″ to be nonzero.`,
      `At \\(x_0=${x0}\\), the leading coefficient is \\(${x0-c}\\), so this is an ${ordinary?'ordinary':'singular'} point.`
    ],
    traps:[
      d289Trap(ordinary?'Singular point':'Ordinary point', 'Check the coefficient multiplying the highest derivative at x0.'),
      d289Trap('Regular point of every order', 'The ordinary/singular classification depends specifically on the leading coefficient.')
    ],
    vecTail:[c,x0,ordinary?1:0], key:'d289_series_ordinary_singular',
    auditSpec:{family:'series-point-classification',c,x0,answer}
  });
});
registerGen('D289_Fourier', (rng)=>{
  const odd = rng() < 0.5;
  const answer = odd
    ? '\\(a_0=a_n=0\\); only sine coefficients may remain'
    : '\\(b_n=0\\); only cosine coefficients and a_0 may remain';
  return d289MakeProblem({
    unitId:'D289_Fourier', genNum:1,
    q:`A function on \\((-L,L)\\) is ${odd?'odd':'even'}. Which Fourier coefficients vanish by symmetry?`,
    a:answer,
    steps:[
      odd ? `An odd function times cosine is odd, so its cosine integrals vanish.` :
            `An even function times sine is odd, so its sine integrals vanish.`,
      odd ? `Therefore \\(a_0=a_n=0\\).` : `Therefore \\(b_n=0\\).`
    ],
    traps:[
      d289Trap(odd?'\\(b_n=0\\)':'\\(a_0=a_n=0\\)', 'The parity of sine and cosine determines which products integrate to zero.'),
      d289Trap('No coefficients vanish automatically', 'Symmetry on a symmetric interval forces one entire coefficient family to vanish.')
    ],
    vecTail:[odd?1:0], key:'d289_fourier_parity',
    auditSpec:{family:'fourier-parity',odd,answer}
  });
});
registerGen('D289_Fourier', (rng)=>{
  const A = pick(rng,[1,2,3,4,5]);
  const n = pick(rng,[1,2,3,4,5,6,7,8]);
  const odd = n%2===1;
  const body = odd ? `\\dfrac{${4*A}}{${n}\\pi}` : '0';
  return d289MakeProblem({
    unitId:'D289_Fourier', genNum:2,
    q:`For the odd square wave \\(f(x)=A\\operatorname{sgn}(x)\\) on \\((-\\pi,\\pi)\\) with \\(A=${A}\\), find \\(b_${n}\\).`,
    a:`\\(${body}\\)`,
    steps:[
      `For this square wave, \\(b_n=4A/(n\\pi)\\) for odd n and 0 for even n.`,
      `Since \\(n=${n}\\) is ${odd?'odd':'even'}, substitute A and n.`
    ],
    traps:[
      d289Trap(`\\(\\dfrac{${2*A}}{${n}\\pi}\\)`, 'The symmetric integral doubles twice, producing 4A in the numerator for odd harmonics.'),
      d289Trap(odd?'\\(0\\)':`\\(\\dfrac{${4*A}}{${n}\\pi}\\)`, 'Only odd harmonics survive for the odd square wave.')
    ],
    vecTail:[A,n,odd?1:0], key:'d289_fourier_square_bn',
    auditSpec:{family:'fourier-square-bn',A,n}
  });
});
registerGen('D289_Fourier', (rng)=>{
  const A = pick(rng,[1,2,3,4,5,6]);
  return d289MakeProblem({
    unitId:'D289_Fourier', genNum:3,
    q:`For \\(f(x)=${A}\\operatorname{sgn}(x)\\) on \\((-\\pi,\\pi)\\), find the first sine coefficient \\(b_1\\).`,
    a:`\\(\\dfrac{${4*A}}{\\pi}\\)`,
    steps:[
      `The odd square-wave coefficients are \\(b_n=4A/(n\\pi)\\) for odd n.`,
      `Set n=1.`
    ],
    traps:[
      d289Trap(`\\(\\dfrac{${2*A}}{\\pi}\\)`, 'The full symmetric interval contributes the factor 4A.'),
      d289Trap(`\\(${4*A}\\pi\\)`, 'The coefficient divides by π; it does not multiply by π.')
    ],
    vecTail:[A], key:'d289_fourier_square_first_coefficient',
    auditSpec:{family:'fourier-square-b1',A}
  });
});
registerGen('D289_Fourier', (rng)=>{
  const n = pick(rng,[1,2,3,4,5,6,7,8]);
  const sign = n%2===1 ? 1 : -1;
  const [nn,dd] = d289FracParts(2*sign,n);
  const body = dd===1 ? `${nn}` : `\\dfrac{${nn}}{${dd}}`;
  return d289MakeProblem({
    unitId:'D289_Fourier', genNum:4,
    q:`For the sawtooth \\(f(x)=x\\) on \\((-\\pi,\\pi)\\), find \\(b_${n}\\).`,
    a:`\\(${body}\\)`,
    steps:[
      `For \\(f(x)=x\\), \\(b_n=2(-1)^{n+1}/n\\).`,
      `Substitute n=${n} and simplify.`
    ],
    traps:[
      d289Trap(`\\(${d289FracTex(-2*sign,n)}\\)`, 'The alternating sign is (-1)^{n+1}.'),
      d289Trap(`\\(${d289FracTex(sign,n)}\\)`, 'Integration by parts produces a factor of 2.')
    ],
    vecTail:[n,nn,dd], key:'d289_fourier_sawtooth_bn',
    auditSpec:{family:'fourier-sawtooth-bn',n}
  });
});
registerGen('D289_Fourier', (rng)=>{
  const c = mwNZ(rng,-6,6);
  return d289MakeProblem({
    unitId:'D289_Fourier', genNum:5,
    q:`For the constant function \\(f(x)=${c}\\) on \\((-L,L)\\), find the Fourier coefficient \\(a_0\\).`,
    a:`\\(${2*c}\\)`,
    steps:[
      `\\(a_0=(1/L)\\int_{-L}^{L}f(x)\\,dx\\).`,
      `The integral is \\(2Lc\\), so \\(a_0=2c=${2*c}\\).`
    ],
    traps:[
      d289Trap(`\\(${c}\\)`, 'The Fourier series uses a0/2 as its constant term, so a0 itself is twice the function value.'),
      d289Trap(`\\(${-2*c}\\)`, 'The symmetric integral keeps the sign of the constant function; it does not reverse it.')
    ],
    vecTail:[c], key:'d289_fourier_constant_a0',
    auditSpec:{family:'fourier-constant-a0',c}
  });
});
registerGen('D289_Fourier', (rng)=>{
  const n = pick(rng,[1,2,3,4,5,6,7,8]);
  const body = n%2===0 ? '0' : `-\\dfrac{4}{${n*n}\\pi}`;
  return d289MakeProblem({
    unitId:'D289_Fourier', genNum:6,
    q:`For \\(f(x)=|x|\\) on \\((-\\pi,\\pi)\\), find \\(a_${n}\\).`,
    a:`\\(${body}\\)`,
    steps:[
      `For \\(|x|\\), \\(a_n=2(((-1)^n)-1)/(\\pi n^2)\\).`,
      `Substitute n=${n}; even n gives 0 and odd n gives \\(-4/(\\pi n^2)\\).`
    ],
    traps:[
      d289Trap(n%2===0?`\\(-\\dfrac{4}{${n*n}\\pi}\\)`:'\\(0\\)', 'Parity of n determines whether the endpoint terms cancel.'),
      d289Trap(`\\(\\dfrac{4}{${n*n}\\pi}\\)`, 'For odd n the coefficient is negative.')
    ],
    vecTail:[n], key:'d289_fourier_absx_an',
    auditSpec:{family:'fourier-absx-an',n}
  });
});
registerGen('D289_Transforms', (rng)=>{
  const a = mwNZ(rng,-5,5);
  return d289MakeProblem({
    unitId:'D289_Transforms', genNum:1,
    q:`If \\(\\mathcal L\\{f(t)\\}=F(s)\\), find \\(\\mathcal L\\{e^{${a}t}f(t)\\}\\).`,
    a:`\\(F(s-${a})\\)`,
    steps:[
      `Use the first shifting theorem: multiplication by \\(e^{at}\\) shifts s to s-a.`,
      `Here a=${a}.`
    ],
    traps:[
      d289Trap(`\\(F(s+${a})\\)`, 'The theorem uses s-a for e^{at}.'),
      d289Trap(`\\(e^{${a}s}F(s)\\)`, 'Exponential multiplication in time shifts the transform argument; it does not multiply by e^{as}.')
    ],
    vecTail:[a], key:'d289_transforms_first_shift_forward',
    auditSpec:{family:'transform-first-shift-forward',a}
  });
});
registerGen('D289_Transforms', (rng)=>{
  const a = mwNZ(rng,-5,5);
  const b = pick(rng,[1,2,3,4,5]);
  return d289MakeProblem({
    unitId:'D289_Transforms', genNum:2,
    q:`Find \\(\\mathcal L^{-1}\\left\\{\\dfrac{${b}}{(s-${a})^2+${b*b}}\\right\\}\\).`,
    a:`\\(e^{${a}t}\\sin(${b}t)\\)`,
    steps:[
      `\\(b/(s^2+b^2)\\) is the transform of \\(\\sin(bt)\\).`,
      `Replacing s by s-${a} multiplies the time function by \\(e^{${a}t}\\).`
    ],
    traps:[
      d289Trap(`\\(e^{-${a}t}\\sin(${b}t)\\)`, 'The denominator s-a corresponds to e^{+at}.'),
      d289Trap(`\\(e^{${a}t}\\cos(${b}t)\\)`, 'A constant b in the numerator is the sine pattern; cosine has s-a in the numerator.')
    ],
    vecTail:[a,b], key:'d289_transforms_first_shift_inverse',
    auditSpec:{family:'transform-first-shift-inverse',a,b}
  });
});
registerGen('D289_Transforms', (rng)=>{
  const c = pick(rng,[1,2,3,4,5,6]);
  return d289MakeProblem({
    unitId:'D289_Transforms', genNum:3,
    q:`Find \\(\\mathcal L\\{u(t-${c})\\}\\).`,
    a:`\\(\\dfrac{e^{-${c}s}}{s}\\)`,
    steps:[
      `Write \\(u(t-${c})=u(t-${c})\\cdot1\\).`,
      `The second shifting theorem gives \\(e^{-${c}s}\\mathcal L\\{1\\}=e^{-${c}s}/s\\).`
    ],
    traps:[
      d289Trap(`\\(\\dfrac{e^{${c}s}}{s}\\)`, 'A delay produces e^{-cs}, not e^{+cs}.'),
      d289Trap(`\\(\\dfrac{1}{s-${c}}\\)`, 'That is an exponential shift, not a unit-step delay.')
    ],
    vecTail:[c], key:'d289_transforms_unit_step',
    auditSpec:{family:'transform-unit-step',c}
  });
});
registerGen('D289_Transforms', (rng)=>{
  const c = pick(rng,[1,2,3,4,5]);
  const b = pick(rng,[1,2,3,4,5]);
  return d289MakeProblem({
    unitId:'D289_Transforms', genNum:4,
    q:`Find \\(\\mathcal L\\{u(t-${c})\\sin(${b}(t-${c}))\\}\\).`,
    a:`\\(e^{-${c}s}\\dfrac{${b}}{s^2+${b*b}}\\)`,
    steps:[
      `Apply \\(\\mathcal L\\{u(t-c)f(t-c)\\}=e^{-cs}F(s)\\).`,
      `For f(t)=sin(${b}t), \\(F(s)=${b}/(s^2+${b*b})\\).`
    ],
    traps:[
      d289Trap(`\\(e^{${c}s}\\dfrac{${b}}{s^2+${b*b}}\\)`, 'A rightward time delay produces e^{-cs}.'),
      d289Trap(`\\(e^{-${c}s}\\dfrac{s}{s^2+${b*b}}\\)`, 'The numerator s belongs to cosine; sine has b.')
    ],
    vecTail:[c,b], key:'d289_transforms_delayed_sine',
    auditSpec:{family:'transform-delayed-sine',c,b}
  });
});
registerGen('D289_Transforms', (rng)=>{
  const c = pick(rng,[1,2,3,4,5]);
  const b = pick(rng,[1,2,3,4,5]);
  return d289MakeProblem({
    unitId:'D289_Transforms', genNum:5,
    q:`Find \\(\\mathcal L^{-1}\\left\\{e^{-${c}s}\\dfrac{${b}}{s^2+${b*b}}\\right\\}\\).`,
    a:`\\(u(t-${c})\\sin(${b}(t-${c}))\\)`,
    steps:[
      `First invert \\(${b}/(s^2+${b*b})\\) as \\(\\sin(${b}t)\\).`,
      `Then e^{-${c}s} delays it by c and introduces u(t-c).`
    ],
    traps:[
      d289Trap(`\\(u(t-${c})\\sin(${b}t)\\)`, 'The delayed function must use t-c inside the sine.'),
      d289Trap(`\\(e^{-${c}t}\\sin(${b}t)\\)`, 'e^{-cs} is a time delay, not exponential damping in time.')
    ],
    vecTail:[c,b], key:'d289_transforms_delayed_sine_inverse',
    auditSpec:{family:'transform-delayed-sine-inverse',c,b}
  });
});
registerGen('D289_Transforms', (rng)=>{
  const a = pick(rng,[1,2,3,4]);
  const width = pick(rng,[1,2,3,4]);
  const b = a + width;
  return d289MakeProblem({
    unitId:'D289_Transforms', genNum:6,
    q:`Find the Laplace transform of the rectangular pulse \\(f(t)=u(t-${a})-u(t-${b})\\).`,
    a:`\\(\\dfrac{e^{-${a}s}-e^{-${b}s}}{s}\\)`,
    steps:[
      `Transform each unit step separately.`,
      `\\(\\mathcal L\\{u(t-c)\\}=e^{-cs}/s\\), then subtract.`
    ],
    traps:[
      d289Trap(`\\(\\dfrac{e^{-${a}s}+e^{-${b}s}}{s}\\)`, 'The second step turns the pulse off, so it must be subtracted.'),
      d289Trap(`\\(\\dfrac{e^{${a}s}-e^{${b}s}}{s}\\)`, 'Both delays require negative exponents.')
    ],
    vecTail:[a,b], key:'d289_transforms_rectangular_pulse',
    auditSpec:{family:'transform-pulse',a,b}
  });
});
registerGen('D289_PDE', (rng)=>d289PDEClassificationProblem(rng,1));
registerGen('D289_PDE', (rng)=>d289PDEClassificationProblem(rng,2));
registerGen('D289_PDE', (rng)=>d289PDEClassificationProblem(rng,3));
registerGen('D289_PDE', (rng)=>{
  const k = pick(rng,[1,2,3,4,5,6]);
  return d289MakeProblem({
    unitId:'D289_PDE', genNum:4,
    q:`For the heat equation \\(u_t=${k}u_{xx}\\), set \\(u=X(x)T(t)\\) and choose separation constant \\(-\\lambda\\). Which ODE pair results?`,
    a:`\\(X''+\\lambda X=0,\\quad T'+${k}\\lambda T=0\\)`,
    steps:[
      `Substitute XT: \\(XT'=${k}X''T\\), then divide by ${k}XT.`,
      `Set \\(X''/X=T'/(${k}T)=-\\lambda\\) and rearrange.`
    ],
    traps:[
      d289Trap(`\\(X''-\\lambda X=0,\\quad T'-${k}\\lambda T=0\\)`, 'With separation constant -λ, both rearranged equations carry plus decay terms.'),
      d289Trap(`\\(X'+\\lambda X=0,\\quad T''+${k}\\lambda T=0\\)`, 'The derivative orders must match the original PDE.')
    ],
    vecTail:[k], key:'d289_pde_heat_separation',
    auditSpec:{family:'pde-heat-separation',k}
  });
});
registerGen('D289_PDE', (rng)=>{
  const c = pick(rng,[1,2,3,4,5,6]);
  return d289MakeProblem({
    unitId:'D289_PDE', genNum:5,
    q:`For \\(u_{tt}=${c*c}u_{xx}\\), set \\(u=X(x)T(t)\\) and use separation constant \\(-\\lambda\\). Which ODE pair results?`,
    a:`\\(X''+\\lambda X=0,\\quad T''+${c*c}\\lambda T=0\\)`,
    steps:[
      `Substitute XT and divide by \\(${c*c}XT\\).`,
      `Set \\(X''/X=T''/(${c*c}T)=-\\lambda\\), then rearrange.`
    ],
    traps:[
      d289Trap(`\\(X''+\\lambda X=0,\\quad T'+${c*c}\\lambda T=0\\)`, 'The wave equation is second order in time, so T must satisfy a second-order ODE.'),
      d289Trap(`\\(X''-${c*c}\\lambda X=0,\\quad T''-\\lambda T=0\\)`, 'Keep c² with the time equation after choosing X″/X=-λ.')
    ],
    vecTail:[c], key:'d289_pde_wave_separation',
    auditSpec:{family:'pde-wave-separation',c}
  });
});
registerGen('D289_BVP', (rng)=>{
  const L = pick(rng,[1,2,3,4,5,6]);
  return d289MakeProblem({
    unitId:'D289_BVP', genNum:1,
    q:`For \\(X''+\\lambda X=0\\), \\(X(0)=X(${L})=0\\), give the eigenvalues.`,
    a:`\\(\\lambda_n=\\left(\\dfrac{n\\pi}{${L}}\\right)^2,\\quad n=1,2,3,\\ldots\\)`,
    steps:[
      `Dirichlet conditions force \\(X(x)=\\sin(\\sqrt\\lambda x)\\).`,
      `\\(\\sin(\\sqrt\\lambda L)=0\\) gives \\(\\sqrt\\lambda L=n\\pi\\).`
    ],
    traps:[
      d289Trap(`\\(\\lambda_n=\\dfrac{n\\pi}{${L}}\\)`, 'The eigenvalue is the square of the wave number.'),
      d289Trap(`\\(\\lambda_n=\\left(\\dfrac{2n\\pi}{${L}}\\right)^2\\)`, 'Dirichlet zeros at both endpoints require nπ, not only even multiples.')
    ],
    vecTail:[L], key:'d289_bvp_dirichlet_eigenvalues',
    auditSpec:{family:'bvp-dirichlet-eigenvalues',L}
  });
});
registerGen('D289_BVP', (rng)=>{
  const L = pick(rng,[1,2,3,4,5,6]);
  const n = pick(rng,[1,2,3,4,5]);
  return d289MakeProblem({
    unitId:'D289_BVP', genNum:2,
    q:`For the Dirichlet problem on \\(0 < x < ${L}\\), give an eigenfunction for mode \\(n=${n}\\).`,
    a:`\\(X_${n}(x)=\\sin\\left(\\dfrac{${n}\\pi x}{${L}}\\right)\\)`,
    steps:[
      `Dirichlet eigenfunctions vanish at both endpoints.`,
      `The nth sine mode is \\(\\sin(n\\pi x/L)\\).`
    ],
    traps:[
      d289Trap(`\\(X_${n}(x)=\\cos\\left(\\dfrac{${n}\\pi x}{${L}}\\right)\\)`, 'Cosine does not vanish at x=0.'),
      d289Trap(`\\(X_${n}(x)=\\sin\\left(\\dfrac{\\pi x}{${n*L}}\\right)\\)`, 'The mode number multiplies π; it does not divide the interval length again.')
    ],
    vecTail:[L,n], key:'d289_bvp_dirichlet_eigenfunction',
    auditSpec:{family:'bvp-dirichlet-eigenfunction',L,n}
  });
});
registerGen('D289_BVP', (rng)=>{
  const L = pick(rng,[1,2,3,4,5,6]);
  return d289MakeProblem({
    unitId:'D289_BVP', genNum:3,
    q:`Find the smallest positive eigenvalue for \\(X''+\\lambda X=0\\), \\(X(0)=X(${L})=0\\).`,
    a:`\\(\\lambda_1=\\dfrac{\\pi^2}{${L*L}}\\)`,
    steps:[
      `Dirichlet eigenvalues are \\((n\\pi/L)^2\\).`,
      `The smallest positive one uses n=1.`
    ],
    traps:[
      d289Trap(`\\(\\lambda_1=\\dfrac{\\pi}{${L}}\\)`, 'Square the wave number to obtain λ.'),
      d289Trap(`\\(\\lambda_1=\\dfrac{4\\pi^2}{${L*L}}\\)`, 'That is the n=2 eigenvalue.')
    ],
    vecTail:[L], key:'d289_bvp_smallest_eigenvalue',
    auditSpec:{family:'bvp-smallest-eigenvalue',L}
  });
});
registerGen('D289_BVP', (rng)=>{
  const L = pick(rng,[1,2,3,4,5,6]);
  return d289MakeProblem({
    unitId:'D289_BVP', genNum:4,
    q:`For \\(X''+\\lambda X=0\\), \\(X(0)=0\\), \\(X'(${L})=0\\), give the eigenvalues.`,
    a:`\\(\\lambda_n=\\left(\\dfrac{(n+\\tfrac12)\\pi}{${L}}\\right)^2,\\quad n=0,1,2,\\ldots\\)`,
    steps:[
      `X(0)=0 leaves sine modes.`,
      `X'(L)=0 requires \\(\\cos(\\sqrt\\lambda L)=0\\), so \\(\\sqrt\\lambda L=(n+1/2)\\pi\\).`
    ],
    traps:[
      d289Trap(`\\(\\lambda_n=\\left(\\dfrac{n\\pi}{${L}}\\right)^2\\)`, 'Mixed boundary conditions produce half-integer modes.'),
      d289Trap(`\\(\\lambda_n=\\left(\\dfrac{(2n+1)\\pi}{${L}}\\right)^2\\)`, 'The odd multiples are divided by 2: (n+1/2)π/L.')
    ],
    vecTail:[L], key:'d289_bvp_mixed_eigenvalues',
    auditSpec:{family:'bvp-mixed-eigenvalues',L}
  });
});
registerGen('D289_BVP', (rng)=>{
  const L = pick(rng,[1,2,3,4,5,6]);
  const n = pick(rng,[0,1,2,3,4,5]);
  return d289MakeProblem({
    unitId:'D289_BVP', genNum:5,
    q:`For \\(X''+\\lambda X=0\\), \\(X'(0)=X'(${L})=0\\), give the eigenpair for mode \\(n=${n}\\).`,
    a:`\\(\\lambda_${n}=\\left(\\dfrac{${n}\\pi}{${L}}\\right)^2,\\quad X_${n}(x)=\\cos\\left(\\dfrac{${n}\\pi x}{${L}}\\right)\\)`,
    steps:[
      `Neumann conditions select cosine modes.`,
      `Here n may start at 0; the n=0 mode has λ=0 and a constant eigenfunction.`
    ],
    traps:[
      d289Trap(`\\(\\lambda_${n}=\\left(\\dfrac{${n+1}\\pi}{${L}}\\right)^2,\\quad X_${n}=\\sin\\left(\\dfrac{${n+1}\\pi x}{${L}}\\right)\\)`, 'Neumann conditions use cosine modes and include n=0.'),
      d289Trap(`\\(\\lambda_${n}=\\dfrac{${n}\\pi}{${L}},\\quad X_${n}=\\cos\\left(\\dfrac{${n}\\pi x}{${L}}\\right)\\)`, 'The eigenvalue is the square of the wave number.')
    ],
    vecTail:[L,n], key:'d289_bvp_neumann_eigenpair',
    auditSpec:{family:'bvp-neumann-eigenpair',L,n}
  });
});
