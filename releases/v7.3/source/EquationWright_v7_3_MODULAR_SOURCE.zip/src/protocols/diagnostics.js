function mwDiagnosticsLevel(){ return document.getElementById('ewDiagnosticsLevel')?.value||'off'; }
function mwDiagnosticDigestItems(items){
  return (items||[]).map(item=>{const x=mwPlainDeepClone(item);delete x.semanticSnapshot;return x;});
}
function mwDiagnosticAssessmentDigest(engine,items){
  const e={assessmentCompatibilityId:engine.assessmentCompatibilityId,determinismProtocol:engine.determinismProtocol,catalogDigest:engine.catalogDigest};
  return mwDigestValue({engine:e,items:mwDiagnosticDigestItems(items)});
}
function mwBuildDiagnosticProvenance(level='replay'){
  if(!['replay','full'].includes(level)||!window.LAST_BLUEPRINT||!Array.isArray(window.LAST_QUESTIONS)||!window.LAST_QUESTIONS.length) return null;
  const archiveItems=window.LAST_QUESTIONS.map(mwArchiveItemFromQuestion);
  const items=archiveItems.map((a,i)=>{
    const q=window.LAST_QUESTIONS[i]; const item={n:a.n,unitId:a.unitId,generatorId:a.generatorId,runtimeIndex:a.runtimeIndex,problemKey:a.problemKey,itemSeed:a.itemSeed,vector:a.vector,topicId:a.topicId,type:a.type,
      outputDigests:{question:mwDigestValue(a.expected.question),answer:mwDigestValue(a.expected.answer),steps:mwDigestValue(a.expected.steps)}};
    if(a.type==='mc'){item.outputDigests.choices=mwDigestValue(a.expected.choices);item.mc=mwPlainDeepClone(a.mc);item.mc.choices=item.mc.choices.map((p,pos)=>({...p,displayDigest:mwDigestValue(a.expected.choices[pos])}));}
    if(level==='full') item.semanticSnapshot=mwSemanticSnapshotOf(q)||null;
    return item;
  });
  const engine=mwEngineFingerprint();
  return {format:'equationwright-diagnostic-provenance-v1',schemaRevision:1,level,engine,assessmentDigest:mwDiagnosticAssessmentDigest(engine,items),items};
}
function mwStripDiagnosticsForTransport(obj){ const c=mwPlainDeepClone(obj); if(c&&typeof c==='object') delete c.diagnostics; return c; }
function mwDiagChoiceSchemaOk(x){
  if(!mwIsPlainObject(x)||!mwKeysAllowed(x,['position','role','origin','sourceGeneratorId','sourceRuntimeIndex','sourceProblemKey','sourceSeed','trapIndex','semanticKey','displayDigest'])||!mwHasRequired(x,['position','role','origin','displayDigest']))return false;
  if(!Number.isInteger(x.position)||x.position<0||x.position>9||!['correct','distractor'].includes(x.role)||!['correct','authored-trap','generator'].includes(x.origin)||!mwDigestOk(x.displayDigest))return false;
  if(x.sourceGeneratorId!==undefined&&x.sourceGeneratorId!==null&&!mwLowerIdOk(x.sourceGeneratorId))return false;
  if(x.sourceRuntimeIndex!==undefined&&x.sourceRuntimeIndex!==null&&(!Number.isInteger(x.sourceRuntimeIndex)||x.sourceRuntimeIndex<0))return false;
  if(x.sourceProblemKey!==undefined&&x.sourceProblemKey!==null&&(typeof x.sourceProblemKey!=='string'||x.sourceProblemKey.length>240))return false;
  if(x.sourceSeed!==undefined&&x.sourceSeed!==null&&(typeof x.sourceSeed!=='string'||x.sourceSeed.length>1024))return false;
  if(x.trapIndex!==undefined&&x.trapIndex!==null&&(!Number.isInteger(x.trapIndex)||x.trapIndex<0))return false;
  if(x.semanticKey!==undefined&&x.semanticKey!==null&&(typeof x.semanticKey!=='string'||x.semanticKey.length>2048))return false;
  return true;
}
function mwDiagMCSchemaOk(mc){
  if(!mwIsPlainObject(mc)||!mwKeysAllowed(mc,['choicePolicy','initialTargetChoiceCount','targetChoiceCount','actualChoiceCount','correctIndex','shuffleOrder','semanticValidated','choices'])||!mwHasRequired(mc,['choicePolicy','initialTargetChoiceCount','targetChoiceCount','actualChoiceCount','correctIndex','shuffleOrder','choices']))return false;
  if(typeof mc.choicePolicy!=='string'||mc.choicePolicy.length<1||mc.choicePolicy.length>160)return false;
  for(const k of ['initialTargetChoiceCount','targetChoiceCount','actualChoiceCount'])if(!Number.isInteger(mc[k])||mc[k]<2||mc[k]>4)return false;
  if(!Number.isInteger(mc.correctIndex)||mc.correctIndex<0||mc.correctIndex>3||!Array.isArray(mc.shuffleOrder)||mc.shuffleOrder.length<2||mc.shuffleOrder.length>4||new Set(mc.shuffleOrder).size!==mc.shuffleOrder.length||!mc.shuffleOrder.every(n=>Number.isInteger(n)&&n>=0&&n<=3))return false;
  if(mc.semanticValidated!==undefined&&typeof mc.semanticValidated!=='boolean')return false;
  return Array.isArray(mc.choices)&&mc.choices.length>=2&&mc.choices.length<=4&&mc.choices.every(mwDiagChoiceSchemaOk);
}
function mwDiagOutputDigestsSchemaOk(o){return mwIsPlainObject(o)&&mwKeysAllowed(o,['question','answer','steps','choices'])&&mwHasRequired(o,['question','answer','steps'])&&mwDigestOk(o.question)&&mwDigestOk(o.answer)&&mwDigestOk(o.steps)&&(o.choices===undefined||mwDigestOk(o.choices));}
function mwDiagItemSchemaOk(item){
  if(!mwIsPlainObject(item)||!mwKeysAllowed(item,['n','unitId','generatorId','runtimeIndex','problemKey','itemSeed','vector','topicId','type','outputDigests','semanticSnapshot','mc'])||!mwHasRequired(item,['n','unitId','generatorId','runtimeIndex','problemKey','itemSeed','vector','topicId','type','outputDigests']))return false;
  if(!Number.isInteger(item.n)||item.n<1||item.n>250||!mwIdOk(item.unitId)||!mwLowerIdOk(item.generatorId)||!Number.isInteger(item.runtimeIndex)||item.runtimeIndex<0||typeof item.problemKey!=='string'||item.problemKey.length<1||item.problemKey.length>240||typeof item.itemSeed!=='string'||item.itemSeed.length<1||item.itemSeed.length>1024||!mwVectorSchemaOk(item.vector)||(item.topicId!==null&&!mwIdOk(item.topicId))||!['fr','mc'].includes(item.type)||!mwDiagOutputDigestsSchemaOk(item.outputDigests))return false;
  if(item.semanticSnapshot!==undefined&&item.semanticSnapshot!==null&&!mwIsPlainObject(item.semanticSnapshot))return false;
  if(item.type==='mc')return mwDiagMCSchemaOk(item.mc)&&mwDigestOk(item.outputDigests.choices);
  return item.mc===undefined&&item.outputDigests.choices===undefined;
}
function mwValidateDiagnosticSchema(diag){
  if(!mwIsPlainObject(diag)||!mwKeysAllowed(diag,['format','schemaRevision','level','engine','assessmentDigest','items','requiresExtensions','extensions'])||!mwHasRequired(diag,['format','schemaRevision','level','engine','assessmentDigest','items']))return {ok:false,code:'invalid-diagnostics',message:'Diagnostic fields do not match v1.'};
  if(diag.format!=='equationwright-diagnostic-provenance-v1'||diag.schemaRevision!==1||!['replay','full'].includes(diag.level)||!mwEngineFingerprintSchemaOk(diag.engine)||!mwDigestOk(diag.assessmentDigest)||!Array.isArray(diag.items)||diag.items.length<1||diag.items.length>250||!diag.items.every(mwDiagItemSchemaOk)||!mwExtensionEnvelopeOk(diag))return {ok:false,code:'invalid-diagnostics',message:'Invalid diagnostic provenance.'};
  const req=mwUnsupportedRequiredExtension(diag);if(req)return {ok:false,code:'required-extension-unsupported',message:`Required extension ${req} is unsupported.`};
  return {ok:true};
}
function mwDiagMismatch(result,code,path,message,expected,actual){const m={code,path,message};if(expected!==undefined)m.expected=expected;if(actual!==undefined)m.actual=actual;result.mismatches.push(m);}
function mwReplayDiagnosticProvenance(diag){
  const result={ok:false,format:'equationwright-diagnostic-replay-result-v1',items:0,mismatches:[]};
  const valid=mwValidateDiagnosticSchema(diag);if(!valid.ok){mwDiagMismatch(result,valid.code,'$',valid.message);return result;}
  const runtime=mwEngineFingerprint();
  for(const k of ['assessmentCompatibilityId','determinismProtocol','catalogDigest'])if(diag.engine[k]!==runtime[k])mwDiagMismatch(result,'engine-'+k+'-mismatch','$.engine.'+k,'Diagnostic source engine differs from the running assessment engine.',diag.engine[k],runtime[k]);
  const digest=mwDiagnosticAssessmentDigest(diag.engine,diag.items);if(digest!==diag.assessmentDigest)mwDiagMismatch(result,'assessment-digest-mismatch','$.assessmentDigest','Diagnostic assessment digest does not recompute.',diag.assessmentDigest,digest);
  for(let i=0;i<diag.items.length;i++){
    const item=diag.items[i],path=`$.items[${i}]`;result.items++;
    if(item.n!==i+1)mwDiagMismatch(result,'item-number-mismatch',path+'.n','Diagnostic item numbers must be contiguous.',i+1,item.n);
    const found=mwGeneratorById(item.generatorId);if(!found){mwDiagMismatch(result,'generator-missing',path+'.generatorId','Stable generator is unavailable.',item.generatorId,null);continue;}
    if(found.rec.unitId!==item.unitId)mwDiagMismatch(result,'unit-mismatch',path+'.unitId','Stable generator belongs to a different unit.',item.unitId,found.rec.unitId);
    if(found.rec.runtimeIndexV72!==item.runtimeIndex)mwDiagMismatch(result,'generator-index-mismatch',path+'.runtimeIndex','Stable generator resolves at a different runtime index.',item.runtimeIndex,found.rec.runtimeIndexV72);
    const r=mwReconstructStem(item);if(!r.ok){mwDiagMismatch(result,r.code,path+'.generatorId',r.message);continue;}const p=r.p;
    if(String(p.key)!==item.problemKey)mwDiagMismatch(result,'generator-key-mismatch',path+'.problemKey','Problem key differs.',item.problemKey,p.key);
    if(String(p._seed)!==item.itemSeed)mwDiagMismatch(result,'item-seed-mismatch',path+'.itemSeed','Item seed differs.',item.itemSeed,p._seed);
    if(mwCanonicalJSON(p.vec||[])!==mwCanonicalJSON(item.vector))mwDiagMismatch(result,'vector-mismatch',path+'.vector','Vector differs.',item.vector,p.vec||[]);
    if((p.topicKey??null)!==(item.topicId??null))mwDiagMismatch(result,'topic-mismatch',path+'.topicId','Topic differs.',item.topicId??null,p.topicKey??null);
    if((item.type==='mc')!==(!!item.mc))mwDiagMismatch(result,'type-mismatch',path+'.type','Item type/provenance shape differs.',item.type,item.mc?'mc':'fr');
    const checks=[['question',mwDigestValue(String(p.q??''))],['answer',mwDigestValue(String(p.a??''))],['steps',mwDigestValue((p.steps||[]).map(String))]];
    for(const [field,actual] of checks)if(actual!==item.outputDigests[field])mwDiagMismatch(result,field+'-digest-mismatch',path+'.outputDigests.'+field,`${field} digest differs.`,item.outputDigests[field],actual);
    if(Object.prototype.hasOwnProperty.call(item,'semanticSnapshot')&&mwCanonicalJSON(mwSemanticSnapshotOf(p)||null)!==mwCanonicalJSON(item.semanticSnapshot))mwDiagMismatch(result,'semantic-snapshot-mismatch',path+'.semanticSnapshot','Semantic snapshot differs.',item.semanticSnapshot,mwSemanticSnapshotOf(p)||null);
    if(item.type==='mc'){
      const mc=buildMCFromStem(p,item.unitId);if(!mc){mwDiagMismatch(result,'mc-reconstruction-failed',path+'.mc','MC reconstruction failed.');continue;}
      const choicesDigest=mwDigestValue((mc.choices||[]).map(String));if(choicesDigest!==item.outputDigests.choices)mwDiagMismatch(result,'choices-digest-mismatch',path+'.outputDigests.choices','Choice digest differs.',item.outputDigests.choices,choicesDigest);
      const meta=mc.__mcMeta||{};for(const [field,actual] of [['choicePolicy',meta.choicePolicy],['initialTargetChoiceCount',meta.initialTargetChoiceCount],['targetChoiceCount',meta.targetChoiceCount],['actualChoiceCount',meta.actualChoiceCount],['correctIndex',mc.correctIndex]])if(item.mc[field]!==actual)mwDiagMismatch(result,'mc-'+field+'-mismatch',path+'.mc.'+field,'MC structural provenance differs.',item.mc[field],actual);
      if(mwCanonicalJSON(item.mc.shuffleOrder)!==mwCanonicalJSON(meta.shuffleOrder||[]))mwDiagMismatch(result,'shuffle-order-mismatch',path+'.mc.shuffleOrder','MC shuffle order differs.',item.mc.shuffleOrder,meta.shuffleOrder||[]);
      const cur=(meta.choiceProvenance||[]).map((x,pos)=>({position:pos,role:x.role,origin:x.origin,sourceGeneratorId:x.sourceGeneratorId??null,sourceRuntimeIndex:x.sourceRuntimeIndex??null,sourceProblemKey:x.sourceProblemKey??null,sourceSeed:x.sourceSeed??null,trapIndex:x.trapIndex??null,semanticKey:x.semanticKey??null,displayDigest:mwDigestValue(mc.choices[pos])}));if(mwCanonicalJSON(cur)!==mwCanonicalJSON(item.mc.choices))mwDiagMismatch(result,'distractor-provenance-mismatch',path+'.mc.choices','MC final-choice provenance differs.',item.mc.choices,cur);
    }
  }
  result.ok=result.mismatches.length===0;return result;
}
