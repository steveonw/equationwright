// Build-time data injection. profiles/ is the source of truth.
const EW_BUILTIN_PROFILES = /*__EW_BUILTIN_PROFILES__*/ null;
const EW_PROFILE_STORE = new Map();
let EW_ACTIVE_PROFILE = null;
function mwProfileDigest(profile){ const p=mwPlainDeepClone(profile); delete p.profileDigest; return mwDigestValue(p); }
function mwProfileKey(id,version){ return String(id)+'@'+String(version); }
function mwHasMarkup(s){ return /[<>]/.test(String(s||'')); }
function mwProfileTextSafe(v){
  if(typeof v==='string' && mwHasMarkup(v)) return false;
  if(Array.isArray(v)) return v.every(mwProfileTextSafe);
  if(v && typeof v==='object') return Object.values(v).every(mwProfileTextSafe);
  return true;
}
function mwProfileString(v,min,max){ return typeof v==='string' && v.length>=min && v.length<=max; }
function mwProfileStringMap(v,{knownKeys=null}={}){
  if(!mwIsPlainObject(v)) return false;
  for(const [k,x] of Object.entries(v)){
    if(!mwIdOk(k) || typeof x!=='string' || x.length>240) return false;
    if(knownKeys && !knownKeys.has(k)) return false;
  }
  return true;
}
function mwProfileSemverTuple(v){ if(!mwSemverOk(v)) return null; return v.split('.').map(Number); }
function mwProfileSemverCompare(a,b){
  const x=mwProfileSemverTuple(a), y=mwProfileSemverTuple(b); if(!x||!y) return 0;
  for(let i=0;i<3;i++){ if(x[i]!==y[i]) return x[i]<y[i]?-1:1; }
  return 0;
}
function mwProfileActualBump(oldV,newV){
  const a=mwProfileSemverTuple(oldV), b=mwProfileSemverTuple(newV); if(!a||!b||mwProfileSemverCompare(oldV,newV)>=0) return 'invalid';
  if(b[0]!==a[0]) return 'major';
  if(b[1]!==a[1]) return 'minor';
  return 'patch';
}
function mwValidateCurriculumProfile(profile,{allowBuiltInCollision=false}={}){
  try{
    const topAllowed=['format','schemaRevision','profileId','profileVersion','profileDigest','label','locale','catalogDigest','institution','courses','crosswalks','requiresExtensions','extensions'];
    const topRequired=['format','schemaRevision','profileId','profileVersion','profileDigest','label','locale','catalogDigest','courses','crosswalks'];
    if(!mwIsPlainObject(profile) || !mwKeysAllowed(profile,topAllowed) || !mwHasRequired(profile,topRequired)) return {ok:false,code:'profile-schema-invalid',message:'Curriculum profile does not match the v1 schema.'};
    if(profile.format!=='equationwright-curriculum-profile-v1' || profile.schemaRevision!==1) return {ok:false,code:'unsupported-profile-format',message:'Unsupported curriculum profile format.'};
    if(!mwExtensionEnvelopeOk(profile)) return {ok:false,code:'profile-schema-invalid',message:'Profile extension envelope is invalid.'};
    const reqExt=mwUnsupportedRequiredExtension(profile); if(reqExt) return {ok:false,code:'required-extension-unsupported',message:`Required extension ${reqExt} is not supported.`};
    if(!mwLowerIdOk(profile.profileId)) return {ok:false,code:'invalid-profile-id',message:'Profile ID is invalid.'};
    if(!mwSemverOk(profile.profileVersion)) return {ok:false,code:'invalid-profile-version',message:'Profile version must be semantic x.y.z.'};
    if(!mwDigestOk(profile.profileDigest) || !mwDigestOk(profile.catalogDigest)) return {ok:false,code:'profile-schema-invalid',message:'Profile digest field is invalid.'};
    if(!mwProfileString(profile.label,1,240) || !mwProfileString(profile.locale,2,35)) return {ok:false,code:'profile-schema-invalid',message:'Profile label/locale is invalid.'};
    if(profile.catalogDigest!==EW_CATALOG_DIGEST) return {ok:false,code:'catalog-digest-mismatch',message:'Profile targets a different EquationWright catalog.'};
    if(Object.prototype.hasOwnProperty.call(profile,'institution')){
      const i=profile.institution;
      if(!mwIsPlainObject(i) || !mwKeysAllowed(i,['system','institution','country'])) return {ok:false,code:'profile-schema-invalid',message:'Institution metadata is invalid.'};
      if(i.system!=null && (typeof i.system!=='string'||i.system.length>240)) return {ok:false,code:'profile-schema-invalid',message:'Institution system is invalid.'};
      if(i.institution!=null && (typeof i.institution!=='string'||i.institution.length>240)) return {ok:false,code:'profile-schema-invalid',message:'Institution name is invalid.'};
      if(i.country!=null && (typeof i.country!=='string'||!/^[A-Z]{2}$/.test(i.country))) return {ok:false,code:'profile-schema-invalid',message:'Institution country is invalid.'};
    }
    if(!mwProfileTextSafe(profile)) return {ok:false,code:'profile-markup-forbidden',message:'Profile labels and notes must be plain text.'};
    const forbidden=/(^|_)(generator|generators|rng|validator|validators|answerlogic|seedrules|javascript|script|executablecode)($|_)/i;
    const scanKeys=(x)=>{
      if(!x||typeof x!=='object') return null;
      for(const [k,v] of Object.entries(x)){ if(forbidden.test(k)) return k; const found=scanKeys(v); if(found) return found; }
      return null;
    };
    const badKey=scanKeys(profile); if(badKey) return {ok:false,code:'profile-executable-field-forbidden',message:`Profile field ${badKey} is outside the presentation/mapping boundary.`};
    if(!Array.isArray(profile.courses) || profile.courses.length<1 || profile.courses.length>200) return {ok:false,code:'invalid-profile-courses',message:'Profile course count is invalid.'};
    if(!Array.isArray(profile.crosswalks) || profile.crosswalks.length>100) return {ok:false,code:'invalid-profile-crosswalks',message:'Profile crosswalk count is invalid.'};
    const knownUnits=new Set(UNITS.map(u=>u.id)), courseIds=new Set(), aliases=new Set();
    const knownTopics=new Map(UNITS.map(u=>[u.id,new Set(ensureUnitTopics(u.id).map(t=>t.id))]));
    for(const c of profile.courses){
      const allowed=['courseId','code','title','description','legacyModeAliases','unitOrder','defaultCounts','unitLabelOverrides','topicLabelOverrides'];
      const required=['courseId','title','legacyModeAliases','unitOrder','defaultCounts'];
      if(!mwIsPlainObject(c) || !mwKeysAllowed(c,allowed) || !mwHasRequired(c,required) || !mwLowerIdOk(c.courseId)) return {ok:false,code:'invalid-course-id',message:'Course object or ID is invalid.'};
      if(courseIds.has(c.courseId)) return {ok:false,code:'duplicate-course-id',message:`Duplicate course ID ${c.courseId}.`}; courseIds.add(c.courseId);
      if(!mwProfileString(c.title,1,240) || (c.code!=null && (typeof c.code!=='string'||c.code.length>80)) || (c.description!=null && (typeof c.description!=='string'||c.description.length>2000))) return {ok:false,code:'profile-schema-invalid',message:`Course ${c.courseId} text is invalid.`};
      if(!Array.isArray(c.legacyModeAliases) || new Set(c.legacyModeAliases).size!==c.legacyModeAliases.length || !c.legacyModeAliases.every(mwIdOk)) return {ok:false,code:'invalid-course-aliases',message:`Course ${c.courseId} aliases are invalid.`};
      for(const alias of c.legacyModeAliases){ if(aliases.has(alias)) return {ok:false,code:'duplicate-course-alias',message:`Legacy mode alias ${alias} is claimed by more than one course.`}; aliases.add(alias); }
      if(!Array.isArray(c.unitOrder) || !c.unitOrder.length || c.unitOrder.length>500 || new Set(c.unitOrder).size!==c.unitOrder.length || !c.unitOrder.every(mwIdOk)) return {ok:false,code:'invalid-unit-order',message:`Course ${c.courseId} unit order is invalid.`};
      for(const uid of c.unitOrder) if(!knownUnits.has(uid)) return {ok:false,code:'unknown-unit',message:`Unknown unit ${uid}.`};
      if(!mwIsPlainObject(c.defaultCounts) || !Object.keys(c.defaultCounts).every(mwIdOk)) return {ok:false,code:'invalid-default-counts',message:`Course ${c.courseId} default counts are invalid.`};
      for(const [uid,n] of Object.entries(c.defaultCounts)) if(!c.unitOrder.includes(uid) || !Number.isInteger(n) || n<0 || n>100) return {ok:false,code:'invalid-default-count',message:`Invalid default count for ${uid}.`};
      if(c.unitLabelOverrides!=null && !mwProfileStringMap(c.unitLabelOverrides,{knownKeys:knownUnits})) return {ok:false,code:'unknown-unit-label-override',message:`Course ${c.courseId} unit-label overrides are invalid.`};
      if(c.topicLabelOverrides!=null){
        if(!mwIsPlainObject(c.topicLabelOverrides) || !Object.keys(c.topicLabelOverrides).every(mwIdOk)) return {ok:false,code:'profile-schema-invalid',message:`Course ${c.courseId} topic-label overrides are invalid.`};
        for(const [uid,m] of Object.entries(c.topicLabelOverrides)){
          if(!knownUnits.has(uid) || !mwProfileStringMap(m,{knownKeys:knownTopics.get(uid)})) return {ok:false,code:'unknown-topic',message:`Unknown or invalid topic label override in ${uid}.`};
        }
      }
    }
    for(const xw of profile.crosswalks){
      if(!mwIsPlainObject(xw) || !mwKeysAllowed(xw,['frameworkId','frameworkVersion','entries']) || !mwHasRequired(xw,['frameworkId','frameworkVersion','entries']) || !mwLowerIdOk(xw.frameworkId) || !mwProfileString(xw.frameworkVersion,1,80) || !Array.isArray(xw.entries) || xw.entries.length>2000) return {ok:false,code:'invalid-crosswalk',message:'Crosswalk is invalid.'};
      for(const e of xw.entries){
        if(!mwIsPlainObject(e) || !mwKeysAllowed(e,['sourceCourseId','targetCourseId','coverage','unitIds','unitTopics','notes']) || !mwHasRequired(e,['sourceCourseId','targetCourseId','coverage','unitIds']) || !mwLowerIdOk(e.sourceCourseId) || !mwLowerIdOk(e.targetCourseId) || !['equivalent','primary','supporting','reference'].includes(e.coverage) || !Array.isArray(e.unitIds) || new Set(e.unitIds).size!==e.unitIds.length || !e.unitIds.every(mwIdOk) || (e.notes!=null&&(typeof e.notes!=='string'||e.notes.length>2000))) return {ok:false,code:'invalid-crosswalk-entry',message:'Crosswalk entry is invalid.'};
        for(const uid of e.unitIds) if(!knownUnits.has(uid)) return {ok:false,code:'unknown-crosswalk-unit',message:`Unknown crosswalk unit ${uid}.`};
        if(e.unitTopics!=null){
          if(!mwIsPlainObject(e.unitTopics) || !Object.keys(e.unitTopics).every(mwIdOk)) return {ok:false,code:'invalid-crosswalk-entry',message:'Crosswalk unitTopics is invalid.'};
          for(const [uid,tids] of Object.entries(e.unitTopics)){
            if(!knownTopics.has(uid) || !Array.isArray(tids) || new Set(tids).size!==tids.length || !tids.every(mwIdOk)) return {ok:false,code:'unknown-crosswalk-topic-unit',message:`Unknown or invalid unitTopics entry ${uid}.`};
            for(const tid of tids) if(!knownTopics.get(uid).has(tid)) return {ok:false,code:'unknown-crosswalk-topic',message:`Unknown topic ${uid}/${tid}.`};
          }
        }
      }
    }
    const digest=mwProfileDigest(profile);
    if(profile.profileDigest!==digest) return {ok:false,code:'profile-digest-mismatch',message:'Profile digest does not match its canonical content.',actualDigest:digest};
    const builtin=EW_BUILTIN_PROFILES.find(p=>p.profileId===profile.profileId && p.profileVersion===profile.profileVersion);
    if(builtin && builtin.profileDigest!==profile.profileDigest && !allowBuiltInCollision) return {ok:false,code:'builtin-profile-collision',message:'A custom profile cannot replace a built-in profile ID/version.'};
    return {ok:true,profile:mwPlainDeepClone(profile),digest};
  }catch(e){ return {ok:false,code:'invalid-profile',message:String(e&&e.message||e)}; }
}
function mwProfileCrosswalkEntryMap(profile){
  const out=new Map();
  for(const xw of (profile.crosswalks||[])) for(const e of (xw.entries||[])) out.set(`${xw.frameworkId}\u0000${xw.frameworkVersion}\u0000${e.sourceCourseId}\u0000${e.targetCourseId}`,e);
  return out;
}
function mwClassifyProfileChange(oldP,newP){
  const keyCourse=p=>new Map((p.courses||[]).map(c=>[c.courseId,c]));
  const a=keyCourse(oldP), b=keyCourse(newP);
  let additive=false;
  for(const [id,c] of a){
    const n=b.get(id); if(!n) return 'major';
    if(mwCanonicalJSON(c.unitOrder)!==mwCanonicalJSON(n.unitOrder) || mwCanonicalJSON(c.defaultCounts)!==mwCanonicalJSON(n.defaultCounts)) return 'major';
    const oldAliases=new Set(c.legacyModeAliases||[]), newAliases=new Set(n.legacyModeAliases||[]);
    for(const x of oldAliases) if(!newAliases.has(x)) return 'major';
    for(const x of newAliases) if(!oldAliases.has(x)) additive=true;
  }
  if(b.size>a.size) additive=true;
  const oldX=mwProfileCrosswalkEntryMap(oldP), newX=mwProfileCrosswalkEntryMap(newP);
  for(const [key,e] of oldX){ const n=newX.get(key); if(!n || mwCanonicalJSON(e)!==mwCanonicalJSON(n)) return 'major'; }
  if(newX.size>oldX.size) additive=true;
  const oldFrameworks=new Set((oldP.crosswalks||[]).map(x=>`${x.frameworkId}\u0000${x.frameworkVersion}`));
  const newFrameworks=new Set((newP.crosswalks||[]).map(x=>`${x.frameworkId}\u0000${x.frameworkVersion}`));
  for(const k of oldFrameworks) if(!newFrameworks.has(k)) return 'major';
  for(const k of newFrameworks) if(!oldFrameworks.has(k)) additive=true;
  return additive?'minor':'patch';
}
function mwInstallBuiltInProfiles(){
  for(const p of EW_BUILTIN_PROFILES){
    const v=mwValidateCurriculumProfile(p,{allowBuiltInCollision:true}); if(!v.ok) throw new Error('Built-in profile invalid: '+v.message);
    EW_PROFILE_STORE.set(mwProfileKey(p.profileId,p.profileVersion),mwPlainDeepClone(p));
  }
  EW_ACTIVE_PROFILE=EW_PROFILE_STORE.get(mwProfileKey('edu.vccs.nvcc.math','1.0.0')) || EW_BUILTIN_PROFILES[0];
}
function mwRegisterCustomProfile(profile){
  const v=mwValidateCurriculumProfile(profile); if(!v.ok) return v;
  const sameId=[...EW_PROFILE_STORE.values()].filter(p=>p.profileId===v.profile.profileId && p.profileVersion!==v.profile.profileVersion).sort((a,b)=>mwProfileSemverCompare(a.profileVersion,b.profileVersion));
  const previous=[...sameId].reverse().find(p=>mwProfileSemverCompare(p.profileVersion,v.profile.profileVersion)<0) || null;
  const future=sameId.find(p=>mwProfileSemverCompare(p.profileVersion,v.profile.profileVersion)>0) || null;
  if(future) return {ok:false,code:'profile-version-not-latest',message:'Custom profile versions must be registered in increasing semantic-version order.'};
  if(previous){
    const required=mwClassifyProfileChange(previous,v.profile), actual=mwProfileActualBump(previous.profileVersion,v.profile.profileVersion);
    const sufficient=(required==='patch' && ['patch','minor','major'].includes(actual)) || (required==='minor' && ['minor','major'].includes(actual)) || (required==='major' && actual==='major');
    if(!sufficient) return {ok:false,code:'profile-version-understates-change',message:`Profile change is ${required} but version bump is ${actual}.`,requiredChange:required,actualBump:actual,previousVersion:previous.profileVersion};
    v.changeClass=required; v.previousVersion=previous.profileVersion;
  }
  EW_PROFILE_STORE.set(mwProfileKey(v.profile.profileId,v.profile.profileVersion),v.profile);
  mwRefreshProfileSelect(); return v;
}
function mwProfilesSorted(){ return [...EW_PROFILE_STORE.values()].sort((a,b)=>mwLexCompare(a.profileId,b.profileId)||mwLexCompare(a.profileVersion,b.profileVersion)||mwLexCompare(a.profileDigest,b.profileDigest)); }
function mwCourseForMode(profile,mode){
  if(!profile) return null;
  if(String(mode).startsWith('PROFILE:')) return (profile.courses||[]).find(c=>c.courseId===String(mode).slice(8))||null;
  return (profile.courses||[]).find(c=>(c.legacyModeAliases||[]).includes(mode))||null;
}
function mwModeValueForCourse(c){ return (c.legacyModeAliases&&c.legacyModeAliases[0]) || ('PROFILE:'+c.courseId); }
function mwUnitsForProfileMode(mode){
  const c=mwCourseForMode(EW_ACTIVE_PROFILE,mode); if(!c) return null;
  const byId=new Map(UNITS.map(u=>[u.id,u])); return c.unitOrder.map(id=>byId.get(id)).filter(Boolean);
}
function mwActiveCourse(){ const mode=document.getElementById('modeSelect')?.value||'MIX'; return mwCourseForMode(EW_ACTIVE_PROFILE,mode); }
function mwProfileUnitLabel(unitId){
  const c=mwActiveCourse(); return (c&&c.unitLabelOverrides&&c.unitLabelOverrides[unitId]) || (UNITS.find(u=>u.id===unitId)?.label) || unitId;
}
function mwProfileTopicLabel(unitId,topicId,fallback){
  const c=mwActiveCourse(); return (c&&c.topicLabelOverrides&&c.topicLabelOverrides[unitId]&&c.topicLabelOverrides[unitId][topicId]) || fallback || topicLabelFor(unitId,topicId,'');
}
function mwRefreshProfileSelect(){
  const sel=document.getElementById('ewProfileSelect'); if(!sel) return;
  const profiles=mwProfilesSorted(), key=EW_ACTIVE_PROFILE?mwProfileKey(EW_ACTIVE_PROFILE.profileId,EW_ACTIVE_PROFILE.profileVersion):'';
  sel.innerHTML=profiles.map(p=>`<option value="${escHtml(mwProfileKey(p.profileId,p.profileVersion))}">${escHtml(p.label)} (${escHtml(p.profileVersion)})</option>`).join('');
  if(key) sel.value=key;
}
function mwRefreshModeOptions(preferredMode){
  const sel=document.getElementById('modeSelect'); if(!sel||!EW_ACTIVE_PROFILE) return;
  const current=preferredMode||sel.value;
  sel.innerHTML=(EW_ACTIVE_PROFILE.courses||[]).map(c=>{
    const value=mwModeValueForCourse(c); const label=c.code?`${c.title} (${c.code})`:c.title;
    return `<option value="${escHtml(value)}">${escHtml(label)}</option>`;
  }).join('');
  const values=[...sel.options].map(o=>o.value); sel.value=values.includes(current)?current:(values.includes('C2')?'C2':values[0]);
}
function mwActivateProfile(profileId,version,{preserveMode=true}={}){
  const p=EW_PROFILE_STORE.get(mwProfileKey(profileId,version)); if(!p) return false;
  const oldMode=document.getElementById('modeSelect')?.value; EW_ACTIVE_PROFILE=p; mwRefreshProfileSelect(); mwRefreshModeOptions(preserveMode?oldMode:null);
  buildCoveragePills(); buildUnitControls(); return true;
}

