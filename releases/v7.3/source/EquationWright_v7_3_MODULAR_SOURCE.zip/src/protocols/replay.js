function mwReconstructStem(item){
  const found=mwGeneratorById(item.generatorId); if(!found) return {ok:false,code:'generator-missing',message:`Generator ${item.generatorId} is not present.`};
  const {rec,fn}=found; let rng=xorshift32(fnv1a(String(item.itemSeed))); rng();
  try{
    let p=fn(rng); if(!p) return {ok:false,code:'generator-threw',message:'Generator returned no item.'};
    p._seed=String(item.itemSeed);p.cat=rec.unitId;p._genIdx=rec.runtimeIndexV72;p._genName=fn.name||'anon';p.q=fixTexEscapes(p.q);p.a=fixTexEscapes(p.a);if(Array.isArray(p.steps))p.steps=p.steps.map(fixTexEscapes);
    const topicId=(fn.meta&&fn.meta.topicId)?fn.meta.topicId:((p.meta&&p.meta.topicId)?String(p.meta.topicId):deriveTopicKeyFromKey(rec.unitId,p.key));p.topicKey=topicId;const rawTopicLabel=(fn.meta&&fn.meta.topicLabel)?fn.meta.topicLabel:((p.meta&&p.meta.topicLabel)?String(p.meta.topicLabel):humanizeTopicId(topicId));p.topicLabel=topicLabelFor(rec.unitId,topicId,rawTopicLabel);
    return {ok:true,p,rec};
  }catch(e){return {ok:false,code:'generator-threw',message:String(e&&e.message||e)};}
}
function mwDirectChoiceFromProvenance(stem,prov){
  if(prov.origin==='correct') return fixTexEscapes(stem.a);
  if(prov.origin==='authored-trap'){
    const t=(stem.traps||[])[prov.trapIndex]; if(t==null) return null; return fixTexEscapes(typeof t==='string'?t:t.ans);
  }
  if(prov.origin==='generator'){
    const f=mwGeneratorById(prov.sourceGeneratorId); if(!f||!prov.sourceSeed)return null;
    try{const p=f.fn(xorshift32(fnv1a(String(prov.sourceSeed))));return p?fixTexEscapes(p.a):null;}catch(e){return null;}
  }
  return null;
}
function mwReplayMismatch(code,path,message,itemNumber,expected,actual){ const x={code,path,message}; if(itemNumber!=null)x.itemNumber=itemNumber;if(expected!==undefined)x.expected=expected;if(actual!==undefined)x.actual=actual;return x; }
function mwArchiveChoiceSchemaOk(x){
  if(!mwIsPlainObject(x)||!mwKeysAllowed(x,['position','role','origin','sourceGeneratorId','sourceRuntimeIndex','sourceProblemKey','sourceSeed','trapIndex','semanticKey'])||!mwHasRequired(x,['position','role','origin']))return false;
  if(!Number.isInteger(x.position)||x.position<0||x.position>3||!['correct','distractor'].includes(x.role)||!['correct','authored-trap','generator'].includes(x.origin))return false;
  if(x.sourceGeneratorId!==undefined&&x.sourceGeneratorId!==null&&!mwLowerIdOk(x.sourceGeneratorId))return false;
  if(x.sourceRuntimeIndex!==undefined&&x.sourceRuntimeIndex!==null&&(!Number.isInteger(x.sourceRuntimeIndex)||x.sourceRuntimeIndex<0))return false;
  if(x.sourceProblemKey!==undefined&&x.sourceProblemKey!==null&&(typeof x.sourceProblemKey!=='string'||x.sourceProblemKey.length>240))return false;
  if(x.sourceSeed!==undefined&&x.sourceSeed!==null&&(typeof x.sourceSeed!=='string'||x.sourceSeed.length>1024))return false;
  if(x.trapIndex!==undefined&&x.trapIndex!==null&&(!Number.isInteger(x.trapIndex)||x.trapIndex<0))return false;
  if(x.semanticKey!==undefined&&x.semanticKey!==null&&(typeof x.semanticKey!=='string'||x.semanticKey.length>2048))return false;
  return true;
}
function mwArchiveMCSchemaOk(mc){
  if(!mwIsPlainObject(mc)||!mwKeysAllowed(mc,['choicePolicy','initialTargetChoiceCount','targetChoiceCount','actualChoiceCount','correctIndex','shuffleOrder','semanticValidated','choices'])||!mwHasRequired(mc,['choicePolicy','initialTargetChoiceCount','targetChoiceCount','actualChoiceCount','correctIndex','shuffleOrder','choices']))return false;
  if(typeof mc.choicePolicy!=='string'||mc.choicePolicy.length<1||mc.choicePolicy.length>160)return false;
  for(const k of ['initialTargetChoiceCount','targetChoiceCount','actualChoiceCount'])if(!Number.isInteger(mc[k])||mc[k]<2||mc[k]>4)return false;
  if(!Number.isInteger(mc.correctIndex)||mc.correctIndex<0||mc.correctIndex>3)return false;
  if(!Array.isArray(mc.shuffleOrder)||mc.shuffleOrder.length<2||mc.shuffleOrder.length>4||new Set(mc.shuffleOrder).size!==mc.shuffleOrder.length||!mc.shuffleOrder.every(n=>Number.isInteger(n)&&n>=0&&n<=3))return false;
  if(mc.semanticValidated!==undefined&&typeof mc.semanticValidated!=='boolean')return false;
  if(!Array.isArray(mc.choices)||mc.choices.length<2||mc.choices.length>4||!mc.choices.every(mwArchiveChoiceSchemaOk))return false;
  return true;
}
function mwArchiveExpectedSchemaOk(exp){
  if(!mwIsPlainObject(exp)||!mwKeysAllowed(exp,['question','answer','steps','choices','correctIndex','semanticSnapshot'])||!mwHasRequired(exp,['question','answer','steps']))return false;
  if(typeof exp.question!=='string'||exp.question.length>20000||typeof exp.answer!=='string'||exp.answer.length>20000||!Array.isArray(exp.steps)||exp.steps.length>100||!exp.steps.every(x=>typeof x==='string'&&x.length<=20000))return false;
  if(exp.choices!==undefined&&(!Array.isArray(exp.choices)||exp.choices.length<2||exp.choices.length>4||!exp.choices.every(x=>typeof x==='string'&&x.length<=20000)))return false;
  if(exp.correctIndex!==undefined&&(!Number.isInteger(exp.correctIndex)||exp.correctIndex<0||exp.correctIndex>3))return false;
  if(exp.semanticSnapshot!==undefined&&exp.semanticSnapshot!==null&&!mwIsPlainObject(exp.semanticSnapshot))return false;
  return true;
}
function mwArchiveItemSchemaOk(item){
  if(!mwIsPlainObject(item)||!mwKeysAllowed(item,['n','unitId','generatorId','runtimeIndex','problemKey','itemSeed','vector','topicId','type','expected','mc'])||!mwHasRequired(item,['n','unitId','generatorId','runtimeIndex','problemKey','itemSeed','vector','topicId','type','expected']))return false;
  if(!Number.isInteger(item.n)||item.n<1||item.n>250||!mwIdOk(item.unitId)||!mwLowerIdOk(item.generatorId)||!Number.isInteger(item.runtimeIndex)||item.runtimeIndex<0)return false;
  if(typeof item.problemKey!=='string'||item.problemKey.length<1||item.problemKey.length>240||typeof item.itemSeed!=='string'||item.itemSeed.length<1||item.itemSeed.length>1024||!mwVectorSchemaOk(item.vector))return false;
  if(item.topicId!==null&&!mwIdOk(item.topicId)||!['fr','mc'].includes(item.type)||!mwArchiveExpectedSchemaOk(item.expected))return false;
  if(item.type==='mc'){
    if(!mwArchiveMCSchemaOk(item.mc)||!Array.isArray(item.expected.choices)||!Number.isInteger(item.expected.correctIndex))return false;
  }else if(item.mc!==undefined||item.expected.choices!==undefined||item.expected.correctIndex!==undefined)return false;
  return true;
}
function mwPresentationSchemaOk(p){
  if(!mwIsPlainObject(p)||!mwKeysAllowed(p,['courseLabel','unitLabels','topicLabels'])||!mwHasRequired(p,['courseLabel','unitLabels','topicLabels'])||typeof p.courseLabel!=='string'||p.courseLabel.length>240||!mwIsPlainObject(p.unitLabels)||!mwIsPlainObject(p.topicLabels))return false;
  if(!Object.keys(p.unitLabels).every(mwIdOk)||!Object.values(p.unitLabels).every(v=>typeof v==='string'&&v.length<=240)||!Object.keys(p.topicLabels).every(mwIdOk))return false;
  for(const m of Object.values(p.topicLabels)){if(!mwIsPlainObject(m)||!Object.keys(m).every(mwIdOk)||!Object.values(m).every(v=>typeof v==='string'&&v.length<=240))return false;}
  return true;
}
function mwValidateArchiveSchema(a){
  if(!mwIsPlainObject(a)||!mwKeysAllowed(a,['format','schemaRevision','blueprint','source','archive','requiresExtensions','extensions'])||!mwHasRequired(a,['format','schemaRevision','blueprint','source','archive']))return {ok:false,code:'invalid-archive',message:'Archive fields do not match archive v1.'};
  if(a.format!=='equationwright-blueprint-archive-v1'||a.schemaRevision!==1)return {ok:false,code:'unsupported-format',message:'Archive is not equationwright-blueprint-archive-v1.'};
  if(!mwExtensionEnvelopeOk(a))return {ok:false,code:'invalid-archive',message:'Archive extension fields are invalid.'};
  const reqExt=mwUnsupportedRequiredExtension(a);if(reqExt)return {ok:false,code:'required-extension-unsupported',message:`Required extension ${reqExt} is not supported.`};
  const slim=mwValidateSlimBlueprintSchema(a.blueprint);if(!slim.ok)return {ok:false,code:'invalid-archive',message:'Embedded slim blueprint is invalid: '+slim.message};
  const src=a.source;if(!mwIsPlainObject(src)||!mwKeysAllowed(src,['engine','buildVariant','artifactSha256','sourceRevision'])||!mwHasRequired(src,['engine','buildVariant'])||!mwEngineFingerprintSchemaOk(src.engine)||!['online','offline'].includes(src.buildVariant))return {ok:false,code:'invalid-archive',message:'Archive source fingerprint is invalid.'};
  if(src.artifactSha256!==undefined&&!mwDigestOk(src.artifactSha256))return {ok:false,code:'invalid-archive',message:'Archive artifact digest is invalid.'};
  if(src.sourceRevision!==undefined&&(typeof src.sourceRevision!=='string'||src.sourceRevision.length>240))return {ok:false,code:'invalid-archive',message:'Archive source revision is invalid.'};
  const ar=a.archive;if(!mwIsPlainObject(ar)||!mwKeysAllowed(ar,['createdAt','assessmentDigest','archiveDigest','items','presentation'])||!mwHasRequired(ar,['createdAt','assessmentDigest','archiveDigest','items','presentation']))return {ok:false,code:'invalid-archive',message:'Archive payload fields are invalid.'};
  if(typeof ar.createdAt!=='string'||!ar.createdAt||!mwDigestOk(ar.assessmentDigest)||!mwDigestOk(ar.archiveDigest)||!Array.isArray(ar.items)||ar.items.length<1||ar.items.length>250||!ar.items.every(mwArchiveItemSchemaOk)||!mwPresentationSchemaOk(ar.presentation))return {ok:false,code:'invalid-archive',message:'Archive payload does not match archive v1.'};
  return {ok:true};
}
function mwSafeEngineForReport(source,runtime){
  return {appVersion:(typeof source?.appVersion==='string'&&source.appVersion.length&&source.appVersion.length<=128)?source.appVersion:'unknown',assessmentCompatibilityId:mwCompatibilityIdOk(source?.assessmentCompatibilityId)?source.assessmentCompatibilityId:runtime.assessmentCompatibilityId,determinismProtocol:source?.determinismProtocol==='equationwright-determinism-v1'?source.determinismProtocol:runtime.determinismProtocol,catalogDigest:mwDigestOk(source?.catalogDigest)?source.catalogDigest:runtime.catalogDigest};
}
function mwArchiveSemanticConsistency(archive){
  const mismatches=[];const a=archive.blueprint.assessment,items=archive.archive.items;
  const expectedUnits=[];for(const uid of a.unitOrder)for(let i=0;i<a.counts[uid];i++)expectedUnits.push(uid);
  if(items.length!==expectedUnits.length)mismatches.push(mwReplayMismatch('unit-order-mismatch','$.archive.items','Archive item count does not equal the slim assessment count total.',null,expectedUnits.length,items.length));
  for(let i=0;i<items.length;i++){
    const item=items[i];
    if(item.n!==i+1)mismatches.push(mwReplayMismatch('unit-order-mismatch',`$.archive.items[${i}].n`,'Archive item numbers must be contiguous in assessment order.',i+1,i+1,item.n));
    if(expectedUnits[i]!==undefined&&item.unitId!==expectedUnits[i])mismatches.push(mwReplayMismatch('unit-order-mismatch',`$.archive.items[${i}].unitId`,'Archive item unit order does not match the authoritative slim unitOrder/counts.',item.n,expectedUnits[i],item.unitId));
    const filt=a.topicFilters[item.unitId];if(filt&&item.topicId!==null&&!filt.includes(item.topicId))mismatches.push(mwReplayMismatch('topic-mismatch',`$.archive.items[${i}].topicId`,'Archived item topic is outside the slim blueprint topic filter.',item.n,filt,item.topicId));
  }
  return mismatches;
}
function mwArchivePresentationComparison(archive){
  const cref=archive.blueprint.curriculum,pshot=archive.archive.presentation||{};
  const prof=EW_PROFILE_STORE.get(mwProfileKey(cref.profileId,cref.profileVersion));
  if(!prof||prof.profileDigest!==cref.profileDigest)return {exact:null,warning:'Archive curriculum profile is unavailable or has a different digest; presentation exactness cannot be established.'};
  const course=(prof.courses||[]).find(c=>c.courseId===cref.courseId);if(!course)return {exact:null,warning:'Archive curriculum course is unavailable; presentation exactness cannot be established.'};
  const courseLabel=course.code?`${course.title} (${course.code})`:course.title;const unitLabels={},topicLabels={};
  for(const uid of archive.blueprint.assessment.unitOrder){unitLabels[uid]=(course.unitLabelOverrides&&course.unitLabelOverrides[uid])||(UNITS.find(u=>u.id===uid)?.label)||uid;const tm={};for(const t of ensureUnitTopics(uid))tm[t.id]=(course.topicLabelOverrides&&course.topicLabelOverrides[uid]&&course.topicLabelOverrides[uid][t.id])||t.label||topicLabelFor(uid,t.id,'');topicLabels[uid]=tm;}
  const exact=pshot.courseLabel===courseLabel&&mwCanonicalJSON(pshot.unitLabels||{})===mwCanonicalJSON(unitLabels)&&mwCanonicalJSON(pshot.topicLabels||{})===mwCanonicalJSON(topicLabels);
  return {exact,warning:exact?null:'Presentation labels differ from the archive; assessed mathematics may still be exact.'};
}
function mwReplayArchive(archive,mode='strict'){
  const runtime=mwEngineFingerprint(),source=archive?.source?.engine||{};const base={format:'equationwright-replay-report-v1',schemaRevision:1,mode:['strict','verify-current'].includes(mode)?mode:'strict',status:'invalid-archive',guarantee:'none',assessmentExact:false,presentationExact:null,sourceEngine:mwSafeEngineForReport(source,runtime),runtimeEngine:runtime,replayedItemCount:0,mismatches:[],warnings:[]};
  if(!['strict','verify-current'].includes(mode)){base.mismatches.push(mwReplayMismatch('invalid-archive','$.mode','Unknown replay mode.'));return base;}
  const valid=mwValidateArchiveSchema(archive);if(!valid.ok){base.mismatches.push(mwReplayMismatch(valid.code||'invalid-archive','$',valid.message));return base;}
  // The archive has one source engine. Its embedded slim blueprint must name the
  // same engine fingerprint; otherwise the object is internally inconsistent.
  if(mwCanonicalJSON(archive.blueprint.engine)!==mwCanonicalJSON(source)){base.mismatches.push(mwReplayMismatch('invalid-archive','$.blueprint.engine','Embedded slim engine fingerprint disagrees with archive source.engine.',null,source,archive.blueprint.engine));return base;}
  if(mode==='strict'&&source.assessmentCompatibilityId!==runtime.assessmentCompatibilityId){base.status='incompatible';base.mismatches.push(mwReplayMismatch('assessment-compatibility-mismatch','$.source.engine.assessmentCompatibilityId','Assessment engine fingerprint differs.',null,source.assessmentCompatibilityId,runtime.assessmentCompatibilityId));return base;}
  if(mode==='strict'&&source.catalogDigest!==runtime.catalogDigest){base.status='incompatible';base.mismatches.push(mwReplayMismatch('catalog-digest-mismatch','$.source.engine.catalogDigest','Catalog digest differs.',null,source.catalogDigest,runtime.catalogDigest));return base;}
  const semantic=mwArchiveSemanticConsistency(archive);if(semantic.length){base.mismatches=semantic;return base;}
  const items=archive.archive.items,mismatches=[];const slotSeen={};
  for(let i=0;i<items.length;i++){
    const item=items[i],n=item.n;const slot=slotSeen[item.unitId]||0;slotSeen[item.unitId]=slot+1;const seedPrefix=`${archive.blueprint.assessment.seed}|${item.unitId}|slot${slot}|try`;
    if(!String(item.itemSeed).startsWith(seedPrefix))mismatches.push(mwReplayMismatch('item-seed-mismatch',`$.archive.items[${i}].itemSeed`,'Item seed is inconsistent with the archived assessment slot.',n,seedPrefix+'<n>',item.itemSeed));
    const r=mwReconstructStem(item);if(!r.ok){mismatches.push(mwReplayMismatch(r.code,`$.archive.items[${i}].generatorId`,r.message,n,item.generatorId,null));continue;}
    const p=r.p,rec=r.rec;if(rec.unitId!==item.unitId)mismatches.push(mwReplayMismatch('unit-missing',`$.archive.items[${i}].unitId`,'Stable generator belongs to a different unit.',n,item.unitId,rec.unitId));
    if(rec.runtimeIndexV72!==item.runtimeIndex)mismatches.push(mwReplayMismatch('generator-index-mismatch',`$.archive.items[${i}].runtimeIndex`,'Stable generator resolves at a different runtime index.',n,item.runtimeIndex,rec.runtimeIndexV72));
    if(String(p.key)!==String(item.problemKey))mismatches.push(mwReplayMismatch('generator-key-mismatch',`$.archive.items[${i}].problemKey`,'Problem key differs.',n,item.problemKey,p.key));
    if(String(p._seed)!==String(item.itemSeed))mismatches.push(mwReplayMismatch('item-seed-mismatch',`$.archive.items[${i}].itemSeed`,'Item seed differs.',n,item.itemSeed,p._seed));
    if(mwCanonicalJSON(p.vec||[])!==mwCanonicalJSON(item.vector))mismatches.push(mwReplayMismatch('vector-mismatch',`$.archive.items[${i}].vector`,'Vector differs.',n,item.vector,p.vec||[]));
    if((p.topicKey??null)!==(item.topicId??null))mismatches.push(mwReplayMismatch('topic-mismatch',`$.archive.items[${i}].topicId`,'Unit-scoped topic differs.',n,item.topicId??null,p.topicKey??null));
    const exp=item.expected;if(String(p.q??'')!==exp.question)mismatches.push(mwReplayMismatch('question-mismatch',`$.archive.items[${i}].expected.question`,'Question text differs.',n,exp.question,p.q));if(String(p.a??'')!==exp.answer)mismatches.push(mwReplayMismatch('answer-mismatch',`$.archive.items[${i}].expected.answer`,'Answer text differs.',n,exp.answer,p.a));if(mwCanonicalJSON(p.steps||[])!==mwCanonicalJSON(exp.steps))mismatches.push(mwReplayMismatch('steps-mismatch',`$.archive.items[${i}].expected.steps`,'Worked steps differ.',n,exp.steps,p.steps||[]));
    if(Object.prototype.hasOwnProperty.call(exp,'semanticSnapshot')&&mwCanonicalJSON(mwSemanticSnapshotOf(p)||null)!==mwCanonicalJSON(exp.semanticSnapshot))mismatches.push(mwReplayMismatch('semantic-snapshot-mismatch',`$.archive.items[${i}].expected.semanticSnapshot`,'Semantic snapshot differs.',n,exp.semanticSnapshot,mwSemanticSnapshotOf(p)||null));
    if(item.type==='mc'){
      const current=buildMCFromStem(p,item.unitId);if(!current)mismatches.push(mwReplayMismatch('choice-count-mismatch',`$.archive.items[${i}].mc`,'Current engine could not reconstruct MC choices.',n,item.mc.actualChoiceCount,0));else{
        if(current.choices.length!==exp.choices.length)mismatches.push(mwReplayMismatch('choice-count-mismatch',`$.archive.items[${i}].expected.choices`,'Choice count differs.',n,exp.choices.length,current.choices.length));else if(mwCanonicalJSON(current.choices)!==mwCanonicalJSON(exp.choices))mismatches.push(mwReplayMismatch('choice-text-mismatch',`$.archive.items[${i}].expected.choices`,'Choice text/order differs.',n,exp.choices,current.choices));
        if(current.correctIndex!==exp.correctIndex)mismatches.push(mwReplayMismatch('correct-index-mismatch',`$.archive.items[${i}].expected.correctIndex`,'Correct index differs.',n,exp.correctIndex,current.correctIndex));
        if(mwCanonicalJSON(current.__mcMeta?.shuffleOrder||[])!==mwCanonicalJSON(item.mc.shuffleOrder))mismatches.push(mwReplayMismatch('shuffle-order-mismatch',`$.archive.items[${i}].mc.shuffleOrder`,'Shuffle order differs.',n,item.mc.shuffleOrder,current.__mcMeta?.shuffleOrder||[]));
        const curProv=(current.__mcMeta?.choiceProvenance||[]).map((x,pos)=>({position:pos,role:x.role,origin:x.origin,sourceGeneratorId:x.sourceGeneratorId??null,sourceRuntimeIndex:x.sourceRuntimeIndex??null,sourceProblemKey:x.sourceProblemKey??null,sourceSeed:x.sourceSeed??null,trapIndex:x.trapIndex??null,semanticKey:x.semanticKey??null}));const expProv=item.mc.choices.map(x=>({position:x.position,role:x.role,origin:x.origin,sourceGeneratorId:x.sourceGeneratorId??null,sourceRuntimeIndex:x.sourceRuntimeIndex??null,sourceProblemKey:x.sourceProblemKey??null,sourceSeed:x.sourceSeed??null,trapIndex:x.trapIndex??null,semanticKey:x.semanticKey??null}));const direct=item.mc.choices.map(x=>mwDirectChoiceFromProvenance(p,x));
        if(mwCanonicalJSON(curProv)!==mwCanonicalJSON(expProv)||mwCanonicalJSON(direct)!==mwCanonicalJSON(exp.choices))mismatches.push(mwReplayMismatch('distractor-provenance-mismatch',`$.archive.items[${i}].mc.choices`,'Final distractor provenance differs.',n,expProv,curProv));
      }
    }
  }
  base.replayedItemCount=items.length;const digestSlim=mwPlainDeepClone(archive.blueprint);delete digestSlim.delivery;const expectedAssessment=mwAssessmentDigestForArchive(digestSlim,items);if(expectedAssessment!==archive.archive.assessmentDigest)mismatches.push(mwReplayMismatch('assessment-digest-mismatch','$.archive.assessmentDigest','Assessment digest does not recompute.',null,archive.archive.assessmentDigest,expectedAssessment));const expectedArchive=mwDigestValue({blueprint:digestSlim,sourceEngine:archive.source.engine,items});if(expectedArchive!==archive.archive.archiveDigest)mismatches.push(mwReplayMismatch('assessment-digest-mismatch','$.archive.archiveDigest','Archive digest does not recompute.',null,archive.archive.archiveDigest,expectedArchive));
  const pres=mwArchivePresentationComparison(archive);base.presentationExact=pres.exact;if(pres.warning)base.warnings.push(pres.warning);base.mismatches=mismatches;base.assessmentExact=mismatches.length===0;if(mismatches.length){base.status='mismatch';base.guarantee='none';}else if(mode==='strict'){base.status='exact';base.guarantee='guaranteed';}else{base.status='verified-exact';base.guarantee='verified';}EW_LAST_REPLAY_REPORT=base;return base;
}
function mwRenderReplayReport(report,archive){
  const host=document.getElementById('ewReplayPanel'); if(!host)return; host.style.display='block';
  const lines=[`Replay: ${report.status} · assessment exact: ${report.assessmentExact?'yes':'no'} · presentation exact: ${report.presentationExact===null?'n/a':(report.presentationExact?'yes':'no')}`];
  if(report.mismatches.length)lines.push(...report.mismatches.slice(0,12).map(x=>`${x.code}${x.itemNumber?` item ${x.itemNumber}`:''}: ${x.message}`));
  if(report.warnings.length)lines.push(...report.warnings);
  host.innerHTML=`<div style="font-weight:950">${escHtml(lines[0])}</div><pre style="white-space:pre-wrap;max-height:240px;overflow:auto">${escHtml(lines.slice(1).join('\n'))}</pre>`;
  if(!report.assessmentExact&&archive){ const d=document.createElement('details'); d.innerHTML='<summary>View archived expected snapshot (read-only)</summary><pre style="white-space:pre-wrap;max-height:320px;overflow:auto"></pre>';d.querySelector('pre').textContent=JSON.stringify(archive.archive?.items||[],null,2);host.appendChild(d); }
}
function mwHandleArchiveObject(archive){ const report=mwReplayArchive(archive,'strict'); mwRenderReplayReport(report,archive); EW_LAST_ARCHIVE=archive; return report; }
async function mwImportArchiveFile(file){ try{const obj=JSON.parse(await file.text()); mwHandleArchiveObject(obj);}catch(e){alert('Could not read archival replay: '+String(e&&e.message||e));} }
function mwVerifyCurrentArchive(){ if(!EW_LAST_ARCHIVE)return; const r=mwReplayArchive(EW_LAST_ARCHIVE,'verify-current');mwRenderReplayReport(r,EW_LAST_ARCHIVE); }

