// =====================================================================
// EquationWright v7.3 - Stage 4 protocol/runtime architecture (Pass 4B)
// Contract: Pass 4A PRO FINAL APPROVED. This layer exposes capabilities,
// provenance, replay and curriculum presentation. It does not create math.
// =====================================================================
const EW = window.EW = window.EW || {};
const EW_SCHEMA_REVISION = 1;
const EW_ASSESSMENT_COMPATIBILITY_ID = '__EW_ASSESSMENT_COMPATIBILITY_ID__';
const EW_CATALOG_DIGEST = 'sha256:4cb338d5f4c2acb69fc9ec12cc6404e845180cc21264c12d8f1453ceccd3c1c2';
const EW_CATALOG_ID = 'org.equationwright.full-math-catalog';
const EW_CATALOG_VERSION = '1.0.0';
const EW_DETERMINISM_PROTOCOL = 'equationwright-determinism-v1';
const EW_CAPABILITY_PROBE_PROTOCOL = 'equationwright-capability-probe-v1';
let EW_BLUEPRINT_UNIT_ORDER_OVERRIDE = null;
let EW_LAST_REPLAY_REPORT = null;
let EW_LAST_ARCHIVE = null;
const EW_SUPPORTED_EXTENSIONS = new Set();
function mwUnsupportedRequiredExtension(obj){ const req=Array.isArray(obj?.requiresExtensions)?obj.requiresExtensions:[]; return req.find(x=>!EW_SUPPORTED_EXTENSIONS.has(x))||null; }

// Small runtime schema-equivalent validators for public protocol objects. The
// authoritative JSON Schemas remain shipped beside the app; these checks enforce
// their required/additionalProperties/type/bounds rules before state mutation.
function mwIsPlainObject(v){ return !!v && typeof v==='object' && !Array.isArray(v); }
function mwKeysAllowed(obj,allowed){ if(!mwIsPlainObject(obj)) return false; const set=new Set(allowed); return Object.keys(obj).every(k=>set.has(k)); }
function mwHasRequired(obj,required){ return mwIsPlainObject(obj) && required.every(k=>Object.prototype.hasOwnProperty.call(obj,k)); }
function mwIdOk(v){ return typeof v==='string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(v); }
function mwLowerIdOk(v){ return typeof v==='string' && /^[a-z0-9][a-z0-9._:-]{0,127}$/.test(v); }
function mwDigestOk(v){ return typeof v==='string' && /^sha256:[0-9a-f]{64}$/.test(v); }
function mwCompatibilityIdOk(v){ return typeof v==='string' && /^ewac:sha256:[0-9a-f]{64}$/.test(v); }
function mwSemverOk(v){ return typeof v==='string' && /^\d+\.\d+\.\d+$/.test(v); }
function mwFiniteProtocolNumber(v){ return typeof v==='number' && Number.isFinite(v) && !Object.is(v,-0); }
function mwProtocolScalar(v){ return v===null || typeof v==='string' || typeof v==='boolean' || mwFiniteProtocolNumber(v); }
function mwVectorSchemaOk(v){ return Array.isArray(v) && v.length<=256 && v.every(x=>mwProtocolScalar(x) || (Array.isArray(x)&&x.length<=256&&x.every(mwProtocolScalar))); }
function mwExtensionEnvelopeOk(obj){
  if(!mwIsPlainObject(obj)) return false;
  if(Object.prototype.hasOwnProperty.call(obj,'requiresExtensions')){
    const r=obj.requiresExtensions; if(!Array.isArray(r)||new Set(r).size!==r.length||!r.every(mwIdOk)) return false;
  }
  if(Object.prototype.hasOwnProperty.call(obj,'extensions')){
    const e=obj.extensions; if(!mwIsPlainObject(e)||!Object.keys(e).every(k=>/^[A-Za-z0-9][A-Za-z0-9._:-]{2,127}$/.test(k))) return false;
  }
  return true;
}
function mwEngineFingerprintSchemaOk(e){
  return mwIsPlainObject(e) && mwKeysAllowed(e,['appVersion','assessmentCompatibilityId','determinismProtocol','catalogDigest']) &&
    mwHasRequired(e,['appVersion','assessmentCompatibilityId','determinismProtocol','catalogDigest']) &&
    typeof e.appVersion==='string' && e.appVersion.length>=1 && e.appVersion.length<=128 &&
    mwCompatibilityIdOk(e.assessmentCompatibilityId) && e.determinismProtocol==='equationwright-determinism-v1' && mwDigestOk(e.catalogDigest);
}
function mwEngineCompatibilityDecision(source){
  const runtime=mwEngineFingerprint();
  if(!mwEngineFingerprintSchemaOk(source)) return {same:false,code:'engine-fingerprint-invalid',runtime,source};
  const diffs=[];
  if(source.assessmentCompatibilityId!==runtime.assessmentCompatibilityId) diffs.push('assessmentCompatibilityId');
  if(source.determinismProtocol!==runtime.determinismProtocol) diffs.push('determinismProtocol');
  if(source.catalogDigest!==runtime.catalogDigest) diffs.push('catalogDigest');
  return {same:diffs.length===0,code:diffs.length?'source-engine-differs':'same-engine',differences:diffs,runtime,source:mwPlainDeepClone(source)};
}

function mwLexCompare(a,b){ a=String(a); b=String(b); return a < b ? -1 : (a > b ? 1 : 0); }
function mwPlainDeepClone(v){ return v == null ? v : JSON.parse(JSON.stringify(v)); }
function mwCanonicalize(v){
  if(v === null || typeof v === 'string' || typeof v === 'boolean') return v;
  if(typeof v === 'number'){
    if(!Number.isFinite(v)) throw new Error('canonical JSON forbids non-finite numbers');
    return Object.is(v,-0) ? 0 : v;
  }
  if(Array.isArray(v)) return v.map(mwCanonicalize);
  if(typeof v === 'object'){
    const out={};
    Object.keys(v).sort(mwLexCompare).forEach(k=>{ if(v[k] !== undefined) out[k]=mwCanonicalize(v[k]); });
    return out;
  }
  throw new Error('canonical JSON unsupported type');
}
function mwCanonicalJSON(v){ return JSON.stringify(mwCanonicalize(v)); }

// Compact synchronous SHA-256 for protocol digests. FNV remains the worksheet seed hash.
function mwSha256Hex(ascii){
  function rightRotate(value, amount){ return (value>>>amount) | (value<<(32-amount)); }
  let mathPow=Math.pow, maxWord=mathPow(2,32), lengthProperty='length';
  let i,j,result='', words=[];
  let hash=mwSha256Hex.h=mwSha256Hex.h||[], k=mwSha256Hex.k=mwSha256Hex.k||[], primeCounter=k[lengthProperty];
  let isComposite={};
  for(let candidate=2; primeCounter<64; candidate++){
    if(!isComposite[candidate]){
      for(i=0;i<313;i+=candidate) isComposite[i]=candidate;
      hash[primeCounter]=(mathPow(candidate,.5)*maxWord)|0;
      k[primeCounter++]=(mathPow(candidate,1/3)*maxWord)|0;
    }
  }
  ascii = unescape(encodeURIComponent(ascii));
  const asciiBitLength=ascii[lengthProperty]*8;
  ascii += '\x80';
  while(ascii[lengthProperty]%64-56) ascii += '\x00';
  for(i=0;i<ascii[lengthProperty];i++){
    j=ascii.charCodeAt(i); if(j>>8) throw new Error('SHA-256 byte conversion failed');
    words[i>>2] |= j << ((3-i)%4)*8;
  }
  words[words[lengthProperty]] = (asciiBitLength/maxWord)|0;
  words[words[lengthProperty]] = asciiBitLength;
  for(j=0;j<words[lengthProperty];){
    let w=words.slice(j,j+=16), oldHash=hash.slice(0); hash=hash.slice(0,8);
    for(i=0;i<64;i++){
      let w15=w[i-15], w2=w[i-2];
      let a=hash[0], e=hash[4];
      let temp1=hash[7] + (rightRotate(e,6)^rightRotate(e,11)^rightRotate(e,25)) + ((e&hash[5])^((~e)&hash[6])) + k[i] + (w[i]=(i<16)?w[i]:((w[i-16]+(rightRotate(w15,7)^rightRotate(w15,18)^(w15>>>3))+w[i-7]+(rightRotate(w2,17)^rightRotate(w2,19)^(w2>>>10)))|0));
      let temp2=(rightRotate(a,2)^rightRotate(a,13)^rightRotate(a,22)) + ((a&hash[1])^(a&hash[2])^(hash[1]&hash[2]));
      hash=[(temp1+temp2)|0].concat(hash); hash[4]=(hash[4]+temp1)|0; hash.pop();
    }
    for(i=0;i<8;i++) hash[i]=(hash[i]+oldHash[i])|0;
  }
  for(i=0;i<8;i++) for(j=3;j+1;j--){ let b=(hash[i]>>(j*8))&255; result += (b<16?'0':'')+b.toString(16); }
  return result;
}
function mwDigestValue(v){ return 'sha256:' + mwSha256Hex(mwCanonicalJSON(v)); }

function mwBuildVariant(){
  const meta=document.querySelector('meta[name="equationwright-build-variant"]');
  return meta && meta.content === 'offline' ? 'offline' : 'online';
}
function mwEngineFingerprint(){
  return {
    appVersion: MW_APP_VERSION,
    assessmentCompatibilityId: EW_ASSESSMENT_COMPATIBILITY_ID,
    determinismProtocol: EW_DETERMINISM_PROTOCOL,
    catalogDigest: EW_CATALOG_DIGEST
  };
}
function mwDeterminismAlgorithms(){
  return {
    protocol: EW_DETERMINISM_PROTOCOL,
    seedNormalization: 'trim-empty-to-Ultimate-v1',
    seedHash: 'fnv1a-32-js-utf16-v1',
    rng: 'xorshift32-v1',
    selection: 'equationwright-variety-picker-v1',
    multipleChoice: 'equationwright-capacity-aware-mc-v2',
    canonicalJson: 'equationwright-canonical-json-v1'
  };
}

const EW_REGISTRY_BY_ID = new Map();
const EW_REGISTRY_BY_UNIT_INDEX = new Map();
const EW_OBSERVED_BY_ID = new Map(EW_OBSERVED_GENERATORS.map(x=>[x.id,x]));
function mwInstallGeneratorRegistry(){
  EW_REGISTRY_BY_ID.clear(); EW_REGISTRY_BY_UNIT_INDEX.clear();
  const ids=new Set(), pairs=new Set();
  for(const rec of EW_GENERATOR_REGISTRY.generators){
    if(ids.has(rec.generatorId)) throw new Error('duplicate generatorId '+rec.generatorId);
    const pair=rec.unitId+'|'+rec.runtimeIndexV72;
    if(pairs.has(pair)) throw new Error('duplicate generator unit/runtime pair '+pair);
    ids.add(rec.generatorId); pairs.add(pair);
    EW_REGISTRY_BY_ID.set(rec.generatorId,rec); EW_REGISTRY_BY_UNIT_INDEX.set(pair,rec);
  }
  let live=0;
  for(const u of UNITS){
    const gs=Gens[u.id]||[];
    for(let i=0;i<gs.length;i++){
      live++;
      const rec=EW_REGISTRY_BY_UNIT_INDEX.get(u.id+'|'+i);
      if(!rec) throw new Error(`generator registry missing ${u.id}[${i}]`);
      gs[i].ewGeneratorId=rec.generatorId;
    }
  }
  if(live!==424 || ids.size!==424) throw new Error(`generator registry/live count mismatch ${ids.size}/${live}`);
  return {generatorCount:live,idCount:ids.size};
}
function mwGeneratorRegistryRecord(unitId,runtimeIndex){ return EW_REGISTRY_BY_UNIT_INDEX.get(String(unitId)+'|'+Number(runtimeIndex)) || null; }
function mwGeneratorId(unitId,runtimeIndex){ return mwGeneratorRegistryRecord(unitId,runtimeIndex)?.generatorId || null; }
function mwGeneratorById(generatorId){
  const rec=EW_REGISTRY_BY_ID.get(String(generatorId)); if(!rec) return null;
  const fn=(Gens[rec.unitId]||[])[rec.runtimeIndexV72] || null;
  return fn ? {rec,fn,runtimeIndex:rec.runtimeIndexV72} : null;
}

function mwCatalogIdentityObject(){
  const byUnit={};
  for(const rec of EW_GENERATOR_REGISTRY.generators){ (byUnit[rec.unitId]||(byUnit[rec.unitId]=[])).push(rec.generatorId); }
  return {
    catalogId: EW_CATALOG_ID,
    catalogVersion: EW_CATALOG_VERSION,
    unitOrder: UNITS.map(u=>u.id),
    units: UNITS.map(u=>({
      id:u.id,
      defaultLabel:u.label,
      defaultCount:u.defaultCount||0,
      topics:ensureUnitTopics(u.id).map(t=>({id:t.id,label:t.label})),
      generatorIds:byUnit[u.id]||[]
    })),
    generatorRegistryDigest:EW_GENERATOR_REGISTRY.registryDigest
  };
}
function mwAssertCatalogDigest(){
  const actual=mwDigestValue(mwCatalogIdentityObject());
  if(actual!==EW_CATALOG_DIGEST) throw new Error(`catalog digest mismatch: ${actual}`);
  return actual;
}


function mwObservedMetadataSource(unitId,runtimeIndex){
  const fn=(Gens[unitId]||[])[runtimeIndex]; if(!fn) return 'derived';
  const explicitFnMeta=!!fn._ewDeclaredTopicMetaAtRegistration;
  let anyProblemMeta=false;
  for(let s=0;s<80;s++){
    try{
      const p=fn(xorshift32(fnv1a(`capability-meta|${unitId}|${runtimeIndex}|${s}`)));
      if(p && p.meta && p.meta.topicId){ anyProblemMeta=true; break; }
    }catch(e){}
  }
  return explicitFnMeta && anyProblemMeta ? 'mixed' : ((explicitFnMeta || anyProblemMeta) ? 'explicit' : 'derived');
}

function mwBuildCapabilitiesManifest({artifactSha256=null,buildVariant=null}={}){
  mwInstallGeneratorRegistry(); mwAssertCatalogDigest();
  const byUnitIds={}; for(const r of EW_GENERATOR_REGISTRY.generators) (byUnitIds[r.unitId]||(byUnitIds[r.unitId]=[])).push(r.generatorId);
  const generators=EW_GENERATOR_REGISTRY.generators.map(rec=>{
    const obs=EW_OBSERVED_BY_ID.get(rec.generatorId)||{};
    return {
      id:rec.generatorId, unitId:rec.unitId, runtimeIndex:rec.runtimeIndexV72, topicId:rec.topicId,
      metadataSource:mwObservedMetadataSource(rec.unitId,rec.runtimeIndexV72), problemKeys:obs.problemKeys||rec.observedProblemKeys||[],
      problemKeyStability:obs.problemKeyStability||rec.problemKeyStabilityV72||'stable', outputs:obs.outputs||['worksheet','quiz'],
      traps:obs.traps||{support:(rec.observedMaxAuthoredTrapCount>0?'authored':'none'),maxObservedCount:rec.observedMaxAuthoredTrapCount||0,hasExplanations:rec.observedMaxAuthoredTrapCount>0},
      semantics:obs.semantics||[],
      mc:obs.mc||{supported:true,observedAnswerCapacity:rec.observedAnswerCapacity80||0,capacityErrorCount:rec.capacityErrorCount80||0,possibleChoiceCounts:[2,3,4]},
      observed:obs.observed||{probeProtocol:EW_CAPABILITY_PROBE_PROTOCOL,answerCapacitySamples:80,exampleCount:3}
    };
  });
  const units=UNITS.map(u=>({id:u.id,defaultLabel:u.label,defaultCount:u.defaultCount||0,topics:ensureUnitTopics(u.id).map(t=>({id:t.id,label:t.label})).sort((a,b)=>mwLexCompare(a.id,b.id)),generatorIds:(byUnitIds[u.id]||[])}));
  const topicCount=units.reduce((s,u)=>s+u.topics.length,0);
  const manifest={
    format:'equationwright-capabilities-v1',schemaRevision:1,
    engine:{id:'equationwright',appVersion:MW_APP_VERSION,assessmentCompatibilityId:EW_ASSESSMENT_COMPATIBILITY_ID,buildVariant:buildVariant||mwBuildVariant(),catalogDigest:EW_CATALOG_DIGEST},
    determinism:mwDeterminismAlgorithms(),
    catalog:{catalogId:EW_CATALOG_ID,catalogVersion:EW_CATALOG_VERSION,catalogDigest:EW_CATALOG_DIGEST,unitCount:UNITS.length,generatorFamilyCount:generators.length,topicCount,units,generators},
    formats:[
      ['equationwright-capabilities-v1',true,true,'current'],['equationwright-blueprint-slim-v1',true,true,'current'],['equationwright-blueprint-archive-v1',true,true,'current'],
      ['equationwright-diagnostic-provenance-v1',true,true,'current'],['equationwright-replay-report-v1',true,true,'current'],['equationwright-curriculum-profile-v1',true,true,'current'],
      ['UMWB_BLUEPRINT',true,false,'legacy'],['mw-quiz-results-v1',true,true,'current'],['mw-class-results-v1',true,true,'current']
    ].map(([format,read,write,status])=>({format,read,write,status})),
    features:[
      {id:'worksheet',status:'available'},{id:'quiz',status:'available',details:{choiceCounts:[2,3,4]}},{id:'latex-export',status:'available'},
      {id:'smart-review',status:'available'},{id:'personal-history',status:'available'},{id:'class-aggregation',status:'available'},
      {id:'diagnostic-provenance',status:'available'},{id:'strict-replay',status:'available'},{id:'curriculum-profiles',status:'available'},{id:'single-file-offline',status:'available'}
    ],
    limits:{blueprintPerUnitMax:MW_BLUEPRINT_UNIT_MAX,blueprintTotalMax:MW_BLUEPRINT_TOTAL_MAX,aiDrillMin:MW_AI_DRILL_MIN,aiDrillMax:MW_AI_DRILL_MAX,smartReviewMin:5,smartReviewMax:10,mcChoiceMin:2,mcChoiceMax:4},
    curriculumProfiles:EW_BUILTIN_PROFILES.map(p=>({profileId:p.profileId,profileVersion:p.profileVersion,profileDigest:p.profileDigest,label:p.label,builtIn:true}))
  };
  if(artifactSha256) manifest.engine.artifactSha256=artifactSha256.startsWith('sha256:')?artifactSha256:'sha256:'+artifactSha256;
  return manifest;
}
function mwExportCapabilities(){ downloadJSON(mwBuildCapabilitiesManifest(), 'equationwright_capabilities_v7_3.json'); }

