// Blueprint Export/Import (JSON)
// =====================
function exportTopicState(){
  const topicsOut = {};
  for(const [unitId, set] of Object.entries(topicFilters)){
    const sel = ensureTopicSet(unitId);
    topicsOut[unitId] = { list: Array.from(sel), none: !!sel.__none };
  }
  return topicsOut;
}
function sanitizeFileName(s){
  return String(s||'')
    .trim()
    .replace(/[\s]+/g,'_')
    .replace(/[^a-zA-Z0-9._-]/g,'_')
    .slice(0, 80) || 'blueprint';
}
function downloadJSON(obj, filename){
  const blob = new Blob([JSON.stringify(obj, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
function exportBlueprint(){
  if(!window.LAST_BLUEPRINT){ alert('No blueprint available yet. Click \"Generate worksheet\" first.'); return; }
  const bp = mwBuildSlimBlueprint(window.LAST_BLUEPRINT,{includeDelivery:true});
  if(!bp){ alert('No positive-count assessment is available to export.'); return; }
  const seedSafe=sanitizeFileName(bp.assessment.seed||'Ultimate');
  const courseSafe=sanitizeFileName(bp.curriculum.courseId||'course');
  const kind=bp.assessment.quizMode?'quiz':'worksheet';
  downloadJSON(bp,`${kind}_blueprint_${courseSafe}_${seedSafe}.json`);
}
async function importBlueprintFromFile(file){
  if(!file) return;
  let text = '';
  try{
    // Modern browsers
    if(typeof file.text === 'function'){
      text = await file.text();
    }else{
      // Fallback
      text = await new Promise((resolve, reject)=>{
        const r = new FileReader();
        r.onload = ()=>resolve(String(r.result||''));
        r.onerror = ()=>reject(r.error||new Error('read failed'));
        r.readAsText(file);
      });
    }
  }catch(e){
    alert('Could not read that file.');
    return;
  }

  let bp = null;
  try{
    bp = JSON.parse(text);
  }catch(e){
    alert('That file does not look like valid JSON.');
    return;
  }
  applyBlueprint(bp);
}
function mwApplyLegacyBlueprint(bp){
  if(!bp || typeof bp !== 'object'){
    alert('Blueprint format error: expected a JSON object.');
    return;
  }
  if(!mwConfirmBlueprintCompatibility(bp)) return;
  const preflight = mwPreflightBlueprint(bp);
  if(!preflight.ok){
    alert('Blueprint validation failed: ' + preflight.error + '.');
    return;
  }

  // Validate semantic snapshots before allowing them into replay state.
  if(Array.isArray(bp.picks)){
    try{
      for(const pickRec of bp.picks){
        const semantic = pickRec && pickRec.semantic;
        if(!semantic) continue;
        if(semantic.logicSpec && semantic.logicSpec.questionModel){
          mwValidateTruthColumnQuestionModel(semantic.logicSpec.questionModel);
          const spec = semantic.answerSpec;
          if(!spec || spec.validatorId !== 'logic-truth-column-v1' ||
             !mwTruthColumnAnswerIsCorrect(
               semantic.logicSpec.questionModel,
               spec.model
             )){
            throw new Error('invalid MTH 288 semantic snapshot');
          }
        }
        if(semantic.deSpec && semantic.deSpec.questionModel){
          const questionModel = semantic.deSpec.questionModel;
          mwValidateDEQuestionModel(questionModel);
          const spec = semantic.answerSpec;
          const regenerated = mwDESolveQuestion(questionModel);
          if(!spec || spec.validatorId !== 'de-solution-v1' ||
             mwDEVerifySolution(questionModel, spec.model).status !== 'pass' ||
             mwDESolutionKey(regenerated) !== spec.key){
            throw new Error('invalid MTH 289 semantic snapshot');
          }
        }
      }
    }catch(e){
      alert(`Blueprint semantic validation failed: ${e && e.message ? e.message : String(e)}`);
      return;
    }
  }

  const seed = (bp.seed!=null ? String(bp.seed) : '').trim() || 'Ultimate';
  const mode = (bp.mode!=null ? String(bp.mode) : 'MIX');
  const variety = (bp.variety!=null ? +bp.variety : 1) || 1;
  const quizMode = !!bp.quizMode;

  const pages = bp.pages || {};
  const showAnswers = (pages.answers!=null ? !!pages.answers : !quizMode); // quiz drills default keyless
  const showSolutions = (pages.workedSolutions!=null ? !!pages.workedSolutions : false);

  const seedInput = document.getElementById('seedInput');
  const modeSelect = document.getElementById('modeSelect');
  const varietyInput = document.getElementById('varietyInput');
  const toggleQuizMode = document.getElementById('toggleQuizMode');
  const toggleAnswers = document.getElementById('toggleAnswers');
  const toggleSolutions = document.getElementById('toggleSolutions');

  if(seedInput) seedInput.value = seed;

  if(modeSelect){
    const has = Array.from(modeSelect.options || []).some(o => o.value === mode);
    modeSelect.value = has ? mode : 'MIX';
  }

  // Rebuild UI for the selected mode first so inputs exist
  buildCoveragePills();
  buildUnitControls();

  if(varietyInput) varietyInput.value = variety;
  updateVarietyLabel();

  if(toggleQuizMode) toggleQuizMode.checked = quizMode;
  if(toggleAnswers) toggleAnswers.checked = showAnswers;
  if(toggleSolutions) toggleSolutions.checked = showSolutions;

  // Apply counts. A blueprint is authoritative: omitted visible units are zero,
  // otherwise sparse MIX blueprints inherit UI defaults and inflate the drill.
  const counts = preflight.counts;
  countInputs.forEach(inp => { inp.value = 0; });
  countInputs.forEach(inp => {
    const unitId = inp.dataset.unit;
    if(counts && Object.prototype.hasOwnProperty.call(counts, unitId)){
      const n = Math.max(0, parseInt(counts[unitId]||0, 10));
      inp.value = n;
    }
  });

  // Student-lock: link opens in Student mode; Teacher requires the PIN
  if(bp.lock && bp.lockPin){
    try{ sessionStorage.setItem('MW_LOCK', String(bp.lockPin)); }catch(e){}
    setTimeout(()=>{ try{ setUserMode('student'); }catch(e){} }, 0);
  }

  // Restore class-submission settings, if present
  const subEl = document.getElementById('submitUrlInput');
  const cidEl = document.getElementById('classIdInput');
  const aidEl = document.getElementById('assignmentIdInput');
  if(subEl){
    const incomingSubmitUrl = (bp.submitUrl != null ? String(bp.submitUrl) : '');
    subEl.value = incomingSubmitUrl;
    if(incomingSubmitUrl){
      subEl.dataset.mwExternalSubmitUrl = 'blueprint';
      delete subEl.dataset.mwConfirmedSubmitUrl;
    }else{
      delete subEl.dataset.mwExternalSubmitUrl;
      delete subEl.dataset.mwConfirmedSubmitUrl;
    }
  }
  if(cidEl) cidEl.value = (bp.classId != null ? String(bp.classId) : '');
  if(aidEl) aidEl.value = (bp.assignmentId != null ? String(bp.assignmentId) : '');

  // Apply topic filters authoritatively. A blueprint never inherits hidden
  // browser topic state: omitted/empty topics mean all topics for every visible unit.
  const visible = visibleUnits();
  const visibleIds = new Set(visible.map(u => u.id));
  for(const u of visible){
    const sel = ensureTopicSet(u.id);
    sel.clear();
    delete sel.__none;
  }
  const topics = bp.topics || bp.topicFilters || null;
  if(topics && typeof topics === 'object'){
    for(const [unitId, rec] of Object.entries(topics)){
      if(!visibleIds.has(unitId) || !rec || typeof rec !== 'object') continue;
      const sel = ensureTopicSet(unitId);
      const validTopicIds = new Set(ensureUnitTopics(unitId).map(t => t.id));
      if(Array.isArray(rec.list)){
        for(const x of rec.list){
          if(typeof x === 'string' && validTopicIds.has(x)) sel.add(x);
        }
      }
      if(rec.none) sel.__none = true;
    }
  }

  // Update topic UI for visible units
  visible.forEach(u => updateTopicUI(u.id));

  // Persist and re-render
  saveState();
  const importedSemanticPicks = Array.isArray(bp.picks)
    ? bp.picks.map(p => p && p.semantic ? p.semantic : null)
    : null;
  renderSheet();

  // Same-version semantic replay check. The archived question model remains in
  // the blueprint even though normal replay is still seed/settings driven.
  if(importedSemanticPicks && importedSemanticPicks.some(Boolean)){
    const regenerated = (window.LAST_BLUEPRINT && Array.isArray(window.LAST_BLUEPRINT.picks))
      ? window.LAST_BLUEPRINT.picks.map(p => p && p.semantic ? p.semantic : null)
      : [];
    const incoming = importedSemanticPicks.filter(Boolean);
    const outgoing = regenerated.filter(Boolean);
    if(JSON.stringify(incoming) !== JSON.stringify(outgoing)){
      alert('Blueprint replay warning: semantic answer snapshots did not reproduce exactly in this app version.');
    }
  }

  // Reset file input (allows importing the same file twice)
  const fileInp = document.getElementById('importBlueprintFile');
  if(fileInp) fileInp.value = '';
}

// =====================

function mwCurrentProfileRef(modeOverride){
  const profile=EW_ACTIVE_PROFILE || EW_BUILTIN_PROFILES[1] || EW_BUILTIN_PROFILES[0];
  const mode=modeOverride||document.getElementById('modeSelect')?.value||'MIX';
  const course=mwCourseForMode(profile,mode) || profile.courses[0];
  const ref={profileId:profile.profileId,profileVersion:profile.profileVersion,profileDigest:profile.profileDigest,courseId:course.courseId};
  if(course.legacyModeAliases&&course.legacyModeAliases[0]) ref.legacyMode=course.legacyModeAliases[0];
  return ref;
}
function mwNormalizeTopicFiltersForSlim(fullBp,positiveUnits){
  const raw=(fullBp&&fullBp.topics)||{}; const out={};
  for(const uid of positiveUnits){
    const rec=raw[uid]; if(!rec||!Array.isArray(rec.list)||rec.none) continue;
    const valid=new Set(ensureUnitTopics(uid).map(t=>t.id));
    const vals=[...new Set(rec.list.filter(x=>typeof x==='string'&&valid.has(x)))].sort(mwLexCompare);
    const allCount=valid.size; if(vals.length && vals.length<allCount) out[uid]=vals;
  }
  return out;
}
function mwBuildSlimBlueprint(fullBp=window.LAST_BLUEPRINT,{includeDelivery=true,studentLockHash=null}={}){
  if(!fullBp) return null;
  const mode=fullBp.mode!=null?String(fullBp.mode):document.getElementById('modeSelect')?.value||'MIX';
  const countsIn=fullBp.counts||{}; const visibleOrder=(Array.isArray(EW_BLUEPRINT_UNIT_ORDER_OVERRIDE?.unitOrder)?EW_BLUEPRINT_UNIT_ORDER_OVERRIDE.unitOrder:unitsForMode(mode).map(u=>u.id));
  const unitOrder=visibleOrder.filter(uid=>Number.isInteger(Number(countsIn[uid]))&&Number(countsIn[uid])>0);
  const counts={}; unitOrder.forEach(uid=>{counts[uid]=Number(countsIn[uid]);});
  if(!unitOrder.length) return null;
  const slim={format:'equationwright-blueprint-slim-v1',schemaRevision:1,engine:mwEngineFingerprint(),curriculum:mwCurrentProfileRef(mode),assessment:{
    seed:mwNormalizeWorksheetSeed(fullBp.seed),quizMode:!!fullBp.quizMode,variety:Math.max(1,Math.min(3,Number(fullBp.variety)||1)),unitOrder,counts,
    topicFilters:mwNormalizeTopicFiltersForSlim(fullBp,unitOrder),pages:{answers:!!fullBp.pages?.answers,workedSolutions:!!fullBp.pages?.workedSolutions}
  }};
  if(includeDelivery){
    const d={}; const classId=(document.getElementById('classIdInput')?.value||fullBp.classId||'').trim(); const assignmentId=(document.getElementById('assignmentIdInput')?.value||fullBp.assignmentId||'').trim(); const submitUrl=(document.getElementById('submitUrlInput')?.value||fullBp.submitUrl||'').trim();
    if(classId)d.classId=classId;if(assignmentId)d.assignmentId=assignmentId;if(submitUrl)d.submitUrl=submitUrl;
    const lockHash=studentLockHash || (fullBp.lockPin?String(fullBp.lockPin):null); if(lockHash)d.studentLock={algorithm:'fnv1a-32-v1',hash:String(lockHash)};
    if(Object.keys(d).length) slim.delivery=d;
  }
  return slim;
}
function mwValidateCurriculumRefSchema(c){
  if(!mwIsPlainObject(c)||!mwKeysAllowed(c,['profileId','profileVersion','profileDigest','courseId','legacyMode'])||!mwHasRequired(c,['profileId','profileVersion','profileDigest','courseId'])) return {ok:false,code:'curriculum-schema-invalid',message:'Curriculum reference does not match slim v1.'};
  if(!mwLowerIdOk(c.profileId)||!mwSemverOk(c.profileVersion)||!mwDigestOk(c.profileDigest)||!mwLowerIdOk(c.courseId)||(c.legacyMode!==undefined&&!mwIdOk(c.legacyMode))) return {ok:false,code:'curriculum-schema-invalid',message:'Curriculum reference fields are invalid.'};
  return {ok:true};
}
function mwValidatePagesSchema(p){
  return mwIsPlainObject(p)&&mwKeysAllowed(p,['answers','workedSolutions'])&&mwHasRequired(p,['answers','workedSolutions'])&&typeof p.answers==='boolean'&&typeof p.workedSolutions==='boolean';
}
function mwValidateDeliverySchema(d){
  if(!mwIsPlainObject(d)||!mwKeysAllowed(d,['classId','assignmentId','submitUrl','studentLock'])) return false;
  if(d.classId!==undefined&&(typeof d.classId!=='string'||d.classId.length>240))return false;
  if(d.assignmentId!==undefined&&(typeof d.assignmentId!=='string'||d.assignmentId.length>240))return false;
  if(d.submitUrl!==undefined&&(typeof d.submitUrl!=='string'||d.submitUrl.length<1||d.submitUrl.length>2048))return false;
  if(d.studentLock!==undefined){const x=d.studentLock;if(!mwIsPlainObject(x)||!mwKeysAllowed(x,['algorithm','hash'])||!mwHasRequired(x,['algorithm','hash'])||x.algorithm!=='fnv1a-32-v1'||typeof x.hash!=='string'||!/^\d{1,10}$/.test(x.hash))return false;}
  return true;
}
function mwValidateSlimBlueprintSchema(bp){
  if(!mwIsPlainObject(bp)||!mwKeysAllowed(bp,['format','schemaRevision','engine','curriculum','assessment','delivery','requiresExtensions','extensions'])||!mwHasRequired(bp,['format','schemaRevision','engine','curriculum','assessment'])) return {ok:false,code:'schema-invalid',message:'Slim blueprint fields do not match the v1 schema.'};
  if(bp.format!=='equationwright-blueprint-slim-v1'||bp.schemaRevision!==1) return {ok:false,code:'unsupported-format',message:'Not a slim v1 blueprint.'};
  if(!mwExtensionEnvelopeOk(bp)) return {ok:false,code:'schema-invalid',message:'Slim blueprint extension fields are invalid.'};
  if(!mwEngineFingerprintSchemaOk(bp.engine)) return {ok:false,code:'engine-fingerprint-invalid',message:'Blueprint engine fingerprint is invalid.'};
  const cr=mwValidateCurriculumRefSchema(bp.curriculum); if(!cr.ok)return cr;
  const a=bp.assessment;
  if(!mwIsPlainObject(a)||!mwKeysAllowed(a,['seed','quizMode','variety','unitOrder','counts','topicFilters','pages'])||!mwHasRequired(a,['seed','quizMode','variety','unitOrder','counts','topicFilters','pages'])) return {ok:false,code:'assessment-schema-invalid',message:'Assessment fields do not match slim v1.'};
  if(typeof a.seed!=='string'||a.seed.length<1||a.seed.length>512||typeof a.quizMode!=='boolean'||!Number.isInteger(a.variety)||a.variety<1||a.variety>3) return {ok:false,code:'assessment-invalid',message:'Assessment settings are invalid.'};
  if(!Array.isArray(a.unitOrder)||a.unitOrder.length<1||a.unitOrder.length>500||new Set(a.unitOrder).size!==a.unitOrder.length||!a.unitOrder.every(mwIdOk)) return {ok:false,code:'unit-order-invalid',message:'Positive unit order is invalid.'};
  if(!mwIsPlainObject(a.counts)||Object.keys(a.counts).length<1||Object.keys(a.counts).length>500||!Object.keys(a.counts).every(mwIdOk)||!Object.values(a.counts).every(n=>Number.isInteger(n)&&n>=1&&n<=100)) return {ok:false,code:'count-invalid',message:'Count map does not match slim v1.'};
  if(!mwIsPlainObject(a.topicFilters)||!Object.keys(a.topicFilters).every(mwIdOk)) return {ok:false,code:'topic-filter-invalid',message:'Topic filters are invalid.'};
  for(const tids of Object.values(a.topicFilters)){if(!Array.isArray(tids)||tids.length<1||tids.length>200||new Set(tids).size!==tids.length||!tids.every(mwIdOk))return {ok:false,code:'topic-filter-invalid',message:'Topic filter list is invalid.'};}
  if(!mwValidatePagesSchema(a.pages)) return {ok:false,code:'pages-invalid',message:'Page settings are invalid.'};
  if(bp.delivery!==undefined&&!mwValidateDeliverySchema(bp.delivery)) return {ok:false,code:'delivery-invalid',message:'Delivery metadata is invalid.'};
  return {ok:true};
}
function mwValidateSlimBlueprint(bp){
  try{
    const schema=mwValidateSlimBlueprintSchema(bp); if(!schema.ok)return schema;
    const reqExt=mwUnsupportedRequiredExtension(bp); if(reqExt) return {ok:false,code:'required-extension-unsupported',message:`Required extension ${reqExt} is not supported.`};
    const a=bp.assessment;
    const keys=Object.keys(a.counts); if(keys.length!==a.unitOrder.length||!a.unitOrder.every(x=>Object.prototype.hasOwnProperty.call(a.counts,x))) return {ok:false,code:'counts-order-mismatch',message:'unitOrder and counts must name exactly the same units.'};
    const live=new Set(UNITS.map(u=>u.id)); let total=0; for(const uid of a.unitOrder){ const n=a.counts[uid]; if(!live.has(uid)) return {ok:false,code:'unknown-unit',message:`Unknown unit ${uid}.`}; total+=n; }
    if(total>MW_BLUEPRINT_TOTAL_MAX) return {ok:false,code:'count-total-invalid',message:'Blueprint question total is too large.'};
    for(const [uid,tids] of Object.entries(a.topicFilters)){ if(!a.unitOrder.includes(uid)) return {ok:false,code:'topic-filter-invalid',message:`Topic filter unit ${uid} is not selected.`}; const valid=new Set(ensureUnitTopics(uid).map(t=>t.id)); if(tids.some(t=>!valid.has(t))) return {ok:false,code:'topic-filter-invalid',message:`Unknown topic in ${uid}.`}; }
    const prof=EW_PROFILE_STORE.get(mwProfileKey(bp.curriculum.profileId,bp.curriculum.profileVersion));
    if(!prof) return {ok:false,code:'profile-unavailable',message:'The curriculum profile used by this blueprint is not loaded.'};
    if(prof.profileDigest!==bp.curriculum.profileDigest) return {ok:false,code:'profile-digest-mismatch',message:'The curriculum profile digest differs from the blueprint.'};
    const course=(prof.courses||[]).find(c=>c.courseId===bp.curriculum.courseId); if(!course) return {ok:false,code:'profile-course-unavailable',message:'The blueprint course is not available in the profile.'};
    const compatibility=mwEngineCompatibilityDecision(bp.engine);
    return {ok:true,profile:prof,course,total,compatibility};
  }catch(e){return {ok:false,code:'invalid-blueprint',message:String(e&&e.message||e)};}
}
function mwResolveGenerationOrder(counts,mode,seed,variety,quizMode){
  const o=EW_BLUEPRINT_UNIT_ORDER_OVERRIDE;
  if(o){
    const positive={}; Object.entries(counts||{}).forEach(([k,v])=>{if(Number(v)>0)positive[k]=Number(v);});
    const same=o.seed===mwNormalizeWorksheetSeed(seed)&&o.mode===mode&&o.variety===Number(variety)&&o.quizMode===!!quizMode&&mwCanonicalJSON(o.counts)===mwCanonicalJSON(positive);
    if(same && o.unitOrder.every(uid=>Object.prototype.hasOwnProperty.call(positive,uid))) return o.unitOrder.slice();
    EW_BLUEPRINT_UNIT_ORDER_OVERRIDE=null;
  }
  return unitsForMode(mode).map(u=>u.id);
}
function mwApplySlimBlueprint(bp){
  const v=mwValidateSlimBlueprint(bp); if(!v.ok){ alert('Blueprint validation failed: '+v.message); return false; }
  if(v.compatibility && !v.compatibility.same){
    const diffs=(v.compatibility.differences||[]).join(', ')||'engine identity';
    if(!confirm('Blueprint compatibility warning:\n\nThis slim blueprint was created by a different assessment engine ('+diffs+'). Ordinary seed/settings replay may produce different questions. Continue with ordinary replay?')) return false;
  }
  EW_ACTIVE_PROFILE=v.profile; mwRefreshProfileSelect(); mwRefreshModeOptions(null);
  const mode=mwModeValueForCourse(v.course); const modeSelect=document.getElementById('modeSelect'); if(modeSelect) modeSelect.value=mode;
  document.getElementById('seedInput').value=mwNormalizeWorksheetSeed(bp.assessment.seed);
  document.getElementById('varietyInput').value=bp.assessment.variety; updateVarietyLabel();
  document.getElementById('toggleQuizMode').checked=!!bp.assessment.quizMode;
  document.getElementById('toggleAnswers').checked=!!bp.assessment.pages?.answers;
  document.getElementById('toggleSolutions').checked=!!bp.assessment.pages?.workedSolutions;
  buildCoveragePills(); buildUnitControls(); countInputs.forEach(inp=>{inp.value=bp.assessment.counts[inp.dataset.unit]||0;});
  for(const u of visibleUnits()){ const sel=ensureTopicSet(u.id); sel.clear(); delete sel.__none; }
  for(const [uid,tids] of Object.entries(bp.assessment.topicFilters||{})){ const sel=ensureTopicSet(uid); tids.forEach(t=>sel.add(t)); }
  visibleUnits().forEach(u=>updateTopicUI(u.id));
  const d=bp.delivery||{}; const sub=document.getElementById('submitUrlInput'); if(sub){sub.value=d.submitUrl||''; if(d.submitUrl){sub.dataset.mwExternalSubmitUrl='blueprint';delete sub.dataset.mwConfirmedSubmitUrl;}else{delete sub.dataset.mwExternalSubmitUrl;delete sub.dataset.mwConfirmedSubmitUrl;}}
  const cid=document.getElementById('classIdInput');if(cid)cid.value=d.classId||'';const aid=document.getElementById('assignmentIdInput');if(aid)aid.value=d.assignmentId||'';
  if(d.studentLock?.algorithm==='fnv1a-32-v1'&&d.studentLock.hash){try{sessionStorage.setItem('MW_LOCK',String(d.studentLock.hash));}catch(e){}setTimeout(()=>{try{setUserMode('student');}catch(e){}},0);}
  EW_BLUEPRINT_UNIT_ORDER_OVERRIDE={unitOrder:bp.assessment.unitOrder.slice(),counts:mwPlainDeepClone(bp.assessment.counts),seed:mwNormalizeWorksheetSeed(bp.assessment.seed),mode,variety:bp.assessment.variety,quizMode:!!bp.assessment.quizMode};
  saveState(); renderSheet(); return true;
}
function applyBlueprint(bp){
  if(bp&&bp.format==='equationwright-blueprint-slim-v1') return mwApplySlimBlueprint(bp);
  if(bp&&bp.format==='equationwright-blueprint-archive-v1') return mwHandleArchiveObject(bp);
  if(bp&&bp.format===MW_BLUEPRINT_FORMAT) return mwApplyLegacyBlueprint(bp);
  alert('Blueprint validation failed: unsupported or unknown major format.');
  return false;
}

function mwAssessmentDigestForArchive(slim,items){ return mwDigestValue({blueprintAssessment:slim.assessment,items}); }
function mwChoiceReplayFromMeta(q,position){
  const p=q.__mcMeta?.choiceProvenance?.[position]; if(!p) return null;
  return {position,role:p.role,origin:p.origin,sourceGeneratorId:p.sourceGeneratorId??null,sourceRuntimeIndex:p.sourceRuntimeIndex??null,sourceProblemKey:p.sourceProblemKey??null,sourceSeed:p.sourceSeed??null,trapIndex:p.trapIndex??null,semanticKey:p.semanticKey??null};
}
function mwArchiveItemFromQuestion(q,index){
  const rec=mwGeneratorRegistryRecord(q.cat,q._genIdx); if(!rec) throw new Error(`No stable generator ID for ${q.cat}[${q._genIdx}]`);
  const expected={question:String(q.q??''),answer:String(q.a??''),steps:(q.steps||[]).map(String)};
  const semantic=mwSemanticSnapshotOf(q); if(semantic) expected.semanticSnapshot=semantic;
  const item={n:index+1,unitId:q.cat,generatorId:rec.generatorId,runtimeIndex:q._genIdx,problemKey:String(q.key||''),itemSeed:String(q._seed||''),vector:mwPlainDeepClone(q.vec||[]),topicId:q.topicKey??null,type:q.type==='mc'?'mc':'fr',expected};
  if(q.type==='mc'){
    expected.choices=(q.choices||[]).map(String); expected.correctIndex=q.correctIndex;
    const meta=q.__mcMeta||{}; const choices=(q.choices||[]).map((_,pos)=>mwChoiceReplayFromMeta(q,pos));
    if(choices.some(x=>!x)) throw new Error(`MC provenance unavailable for item ${index+1}`);
    item.mc={choicePolicy:String(meta.choicePolicy||''),initialTargetChoiceCount:meta.initialTargetChoiceCount,targetChoiceCount:meta.targetChoiceCount,actualChoiceCount:meta.actualChoiceCount,correctIndex:q.correctIndex,shuffleOrder:(meta.shuffleOrder||[]).slice(),semanticValidated:!!meta.semanticValidated,choices};
  }
  return item;
}
function mwPresentationSnapshot(slim){
  const cref=slim.curriculum||{};const profile=EW_PROFILE_STORE.get(mwProfileKey(cref.profileId,cref.profileVersion));const course=profile?(profile.courses||[]).find(c=>c.courseId===cref.courseId):null;
  const unitLabels={},topicLabels={};
  for(const uid of slim.assessment.unitOrder){
    unitLabels[uid]=(course&&course.unitLabelOverrides&&course.unitLabelOverrides[uid])||(UNITS.find(u=>u.id===uid)?.label)||uid;
    const tmap={};for(const t of ensureUnitTopics(uid))tmap[t.id]=(course&&course.topicLabelOverrides&&course.topicLabelOverrides[uid]&&course.topicLabelOverrides[uid][t.id])||t.label||topicLabelFor(uid,t.id,'');topicLabels[uid]=tmap;
  }
  return {courseLabel:course?(course.code?`${course.title} (${course.code})`:course.title):'',unitLabels,topicLabels};
}
function mwBuildArchiveBlueprint({includeDelivery=false}={}){
  if(!window.LAST_BLUEPRINT||!Array.isArray(window.LAST_QUESTIONS)||!window.LAST_QUESTIONS.length) return null;
  const slim=mwBuildSlimBlueprint(window.LAST_BLUEPRINT,{includeDelivery}); if(!slim) return null;
  if(!includeDelivery) delete slim.delivery;
  const items=window.LAST_QUESTIONS.map(mwArchiveItemFromQuestion);
  const source={engine:mwEngineFingerprint(),buildVariant:mwBuildVariant(),sourceRevision:'pass4b-high-v7.3'};
  const digestSlim=mwPlainDeepClone(slim); delete digestSlim.delivery;
  const assessmentDigest=mwAssessmentDigestForArchive(digestSlim,items);
  const archiveDigest=mwDigestValue({blueprint:digestSlim,sourceEngine:source.engine,items});
  const obj={format:'equationwright-blueprint-archive-v1',schemaRevision:1,blueprint:slim,source,archive:{createdAt:new Date().toISOString(),assessmentDigest,archiveDigest,items,presentation:mwPresentationSnapshot(slim)}};
  EW_LAST_ARCHIVE=obj; return obj;
}
function mwExportArchive(){ const a=mwBuildArchiveBlueprint({includeDelivery:false}); if(!a){alert('Generate a worksheet or quiz first.');return;} downloadJSON(a,`archival_replay_${sanitizeFileName(a.blueprint.assessment.seed)}.json`); }


function mwLegacyToSlim(legacy){
  if(!legacy||legacy.format!==MW_BLUEPRINT_FORMAT)return null;
  const mode=String(legacy.mode||'MIX'), counts={}, order=[]; for(const u of unitsForMode(mode)){const n=Number(legacy.counts?.[u.id]||0);if(Number.isInteger(n)&&n>0){counts[u.id]=n;order.push(u.id);}}
  if(!order.length)return null;
  const temp={...legacy,counts}; const slim=mwBuildSlimBlueprint(temp,{includeDelivery:true}); if(!slim)return null;
  slim.assessment.unitOrder=order;slim.assessment.counts=counts;return slim;
}

