function renderSheet(){
  const { seedInput, modeSelect, varietyInput, toggleAnswers, toggleSolutions, toggleQuizMode } = getEls();
  const seed = mwCurrentWorksheetSeed();
  if(seedInput && seedInput.value !== seed) seedInput.value = seed;
  const variety = parseInt(document.getElementById('varietyInput').value, 10);
  const showAnswers = document.getElementById('toggleAnswers').checked;
  const showSolutions = document.getElementById('toggleSolutions').checked;
  const quizMode = !!(document.getElementById('toggleQuizMode') && document.getElementById('toggleQuizMode').checked);
  const mode = document.getElementById('modeSelect').value;

  // read counts from currently visible inputs only
  const counts = {};
  let total = 0;
  document.querySelectorAll('.count-in').forEach(inp => {
    const cat = inp.dataset.unit || inp.dataset.cat;
    const n = Math.max(0, parseInt(inp.value || '0', 10));
    counts[cat] = n;
    total += n;
  });
  document.getElementById('totalDisplay').textContent = total;

  const order = (typeof mwResolveGenerationOrder === 'function') ? mwResolveGenerationOrder(counts, mode, seed, variety, quizMode) : visibleUnits().map(u => u.id);
  const chosen = [];
  const allQs = [];
  let qNum = 1;

  // reset generator error counters for this run
  GEN_ERROR_COUNT = 0;
  GEN_ERROR_SAMPLES = [];

  for(const cat of order){
    const n = counts[cat] || 0;
    for(let i=0;i<n;i++){
      let p = null;
      try{
        p = pickProblem(seed, cat, i, chosen, variety);
      }catch(e){
        GEN_ERROR_COUNT++;
        if(GEN_ERROR_SAMPLES.length < 6){
          const msg = (e && (e.message||String(e))) ? (e.message||String(e)) : 'error';
          const entry = `${cat}:pickProblem → ${msg}`;
          if(!GEN_ERROR_SAMPLES.includes(entry)) GEN_ERROR_SAMPLES.push(entry);
        }
        continue;
      }
      if(!p) continue;

      // Quiz mode wraps the stem into an intentional 2/3/4-choice item using capacity-aware sibling draws.
      if(quizMode){
        const mc = buildMCFromStem(p, cat);
        if(!mc) continue;
        p = mc;
      }

      p.num = qNum++;
      allQs.push(p);
      chosen.push(p);
    }
  }

  const out = document.getElementById('output');
  out.innerHTML = '';

  // Quiz state (interactive)
  if(quizMode){
    resetQuizState(allQs);
  }else{
    window.QUIZ_DATA = null;
  }

  // Show a non-fatal warning if any generators threw during this run
  const warnEl = document.getElementById('genWarn');
  if(warnEl){
    if(GEN_ERROR_COUNT > 0){
      warnEl.style.display = 'block';
      warnEl.textContent = `Skipped ${GEN_ERROR_COUNT} generator error(s). See console for details.`;
      console.warn('Generator errors (skipped):', GEN_ERROR_SAMPLES);
    }else{
      warnEl.style.display = 'none';
      warnEl.textContent = '';
    }
  }

  // Use the live catalog label instead of an old six-course title map.
  const selectedModeOption = modeSelect && modeSelect.options
    ? modeSelect.options[modeSelect.selectedIndex]
    : null;
  const modeName = selectedModeOption
    ? String(selectedModeOption.textContent || selectedModeOption.label || mode).trim()
    : (mode === 'MIX' ? 'Mixed (All Courses)' : mode);

  const titleLabel = quizMode ? `${modeName} Practice Quiz` : `${modeName} Worksheet`;

  let qsHtml = `<div class="page" id="pageQuestions">
    <div class="header">
      <div>
        <h1 style="font-size:28px; line-height:1.15; margin:0">${escHtml(titleLabel)}</h1>
        <div class="small" style="font-family: ui-monospace, monospace; margin-top:6px; opacity:0.85">ID (seed): <b>${escHtml(seed)}</b></div>
        <div class="name-row">
          <div>Name: <span class="line-input"></span></div>
          <div>Date: <span class="line-input" style="width:160px"></span></div>
        </div>
        ${quizMode ? `<div class="small quiz-mode-note">Quiz mode: click an option to answer. Worked solution unlocks after you answer. Tip: turn off Answer Key / Worked Solutions for students.</div>` : ``}
      </div>
      <div class="header-meta">
        <div>Variety: ${variety===1?'Low':(variety===2?'Medium':'High')}</div>
        <div style="margin-top:6px">Total: ${allQs.length} questions</div>
      </div>
    </div>

    ${quizMode ? `
    <div class="quiz-score-bar">
      <div>
        <div class="small" style="opacity:0.8">Score</div>
        <div class="quiz-score-num"><span id="quizScore">0</span> / ${allQs.length}</div>
      </div>
      <div style="text-align:right">
        <div class="small" style="opacity:0.8">Answered</div>
        <div style="font-size:18px; font-weight:950"><span id="quizAnswered">0</span> / ${allQs.length}</div>
      </div>
    </div>
    <div id="quizActions">
      <div id="quizResultLine"></div>
      <div id="aiTutorPanel" style="display:none; margin:10px 0; padding:12px; border:1px solid var(--line); border-radius:12px; background:rgba(52,211,153,0.06)"></div>
      <div class="qa-row">
        <button type="button" id="qaReviewMissed">Review missed questions</button>
        <button type="button" id="qaTrySimilar">Start Smart Review (local)</button>
        <button type="button" id="qaRetake">Retake this quiz</button>
        <button type="button" id="qaNewLike">New quiz like this</button>
        <button type="button" id="qaExportCSV">Export results (CSV)</button>
        <button type="button" id="qaExportJSON">Export results (JSON)</button>
        <button type="button" id="qaSubmitResults">Submit results</button>
        <button type="button" id="qaAskTutor">Ask AI tutor</button>
      </div>
    </div>` : ``}

    <div class="q-grid">`;

  allQs.forEach((q, idx) => {
    const isMC = (q && q.type === 'mc' && Array.isArray(q.choices));
    const steps = (q.steps || []).map(s => `<li>${cleanMathText(s)}</li>`).join('');
    const correctChoiceText = (isMC && q.choices && q.choices[q.correctIndex]!=null) ? q.choices[q.correctIndex] : q.a;

    const cardIdAttr = isMC ? `id="quizCard_${idx}"` : '';
    qsHtml += `
      <div class="card${isMC ? ' quiz-question' : ''}" ${cardIdAttr}>
        <div class="q-num-col">
          <div class="q-num">#${idx+1}</div>
          <div class="q-tag">${escHtml(unitLabel(q.cat))}</div>
          <div style="margin-top:6px">${stamp(q._seed)}</div>
        </div>
        <div class="q-body">
          <div class="q-text">${cleanMathText(q.q)}</div>
          ${isMC ? `
            <div class="quiz-choices">
              ${q.choices.map((choice, j) => `
                <button type="button" class="quiz-choice-btn" data-q="${idx}" data-choice="${j}">
                  ${letterOf(j)}) ${cleanMathText(choice)}
                </button>`).join('')}
            </div>
            <div id="quiz-feedback-${idx}"></div>
            <details class="quiz-solution" id="quiz-solution-${idx}" style="display:none">
              <summary>Show worked solution</summary>
              <ol>${steps}</ol>
              <div style="margin-top:10px; padding-top:10px; border-top:1px solid var(--line)">
                <b>Answer:</b> ${cleanMathText(correctChoiceText)}
              </div>
            </details>
            <div class="work-space">Work space:</div>
          ` : `
            <div class="work-space">Work space:</div>
          `}
        </div>
      </div>`;
  });
  qsHtml += `</div></div>`;
  out.innerHTML += qsHtml;

  if(showAnswers){
    let ansHtml = `<div class="page" id="pageAnswers">
      <div class="header">
        <div>
          <h1 style="font-size:26px;margin:0">Answer Key</h1>
          <div class="small" style="font-family: ui-monospace, monospace; margin-top:6px; opacity:0.85">ID (seed): <b>${escHtml(seed)}</b></div>
        </div>
        <div class="header-meta">Answers only</div>
      </div>
      <div class="q-grid" style="gap:10px">`;

    allQs.forEach((q, idx) => {
      const isMC = (q && q.type === 'mc' && Array.isArray(q.choices));
      const ansText = isMC
        ? `${letterOf(q.correctIndex)}) ${cleanMathText((q.choices && q.choices[q.correctIndex]!=null) ? q.choices[q.correctIndex] : q.a)}`
        : `${cleanMathText(q.a)}`;

      ansHtml += `
        <div class="card" style="align-items:center">
          <div class="q-num-col" style="min-width:62px">
            <div class="q-num" style="font-size:18px">#${idx+1}</div>
            <div style="margin-top:6px">${stamp(q._seed)}</div>
          </div>
          <div class="q-body">
            <div class="q-text" style="margin:0; font-size:15px"><b>Answer:</b> ${ansText}</div>
          </div>
        </div>`;
    });
    ansHtml += `</div></div>`;
    out.innerHTML += ansHtml;
  }

  if(showSolutions){
    let solHtml = `<div class="page" id="pageWorked">
      <div class="header">
        <div>
          <h1 style="font-size:26px;margin:0">Worked Solutions</h1>
          <div class="small" style="font-family: ui-monospace, monospace; margin-top:6px; opacity:0.85">ID (seed): <b>${escHtml(seed)}</b></div>
        </div>
        <div class="header-meta">Solution outlines + final answers</div>
      </div>
      <div class="q-grid">`;

    allQs.forEach((q, idx) => {
      const steps = (q.steps || []).map(s => `<li>${cleanMathText(s)}</li>`).join('');
      const isMC = (q && q.type === 'mc' && Array.isArray(q.choices));
      const finalLine = isMC
        ? `<b>Correct:</b> ${letterOf(q.correctIndex)}) ${cleanMathText((q.choices && q.choices[q.correctIndex]!=null) ? q.choices[q.correctIndex] : q.a)}`
        : `<b>Final:</b> ${cleanMathText(q.a)}`;

      solHtml += `
        <div class="card">
          <div class="q-num-col">
            <div class="q-num" style="font-size:18px">#${idx+1}</div>
            <div class="q-tag">${escHtml(unitLabel(q.cat))}</div>
            <div style="margin-top:6px">${stamp(q._seed)}</div>
          </div>
          <div class="q-body">
            <div class="q-text" style="font-size:14px; opacity:0.95">${cleanMathText(q.q)}</div>
            <div class="steps-box">
              <div style="font-weight:950; margin-bottom:6px">Solution outline</div>
              <ol>${steps}</ol>
              <div style="margin-top:10px; border-top:1px solid rgba(232,238,252,0.16); padding-top:8px">
                ${finalLine}
              </div>
            </div>
          </div>
        </div>`;
    });
    solHtml += `</div></div>`;
    out.innerHTML += solHtml;
  }

  const blueprint = {
    format: MW_BLUEPRINT_FORMAT,
    appVersion: MW_APP_VERSION,
    generatedAt: new Date().toISOString(),
    seed,
    mode,
    quizMode,
    counts,
    topics: exportTopicState(),
    variety,
    pages: { answers: showAnswers, workedSolutions: showSolutions },
    submitUrl: (document.getElementById('submitUrlInput')?.value || '').trim() || undefined,
    classId: (document.getElementById('classIdInput')?.value || '').trim() || undefined,
    assignmentId: (document.getElementById('assignmentIdInput')?.value || '').trim() || undefined,
    picks: allQs.map(q => ({
      num: q.num,
      unit: q.cat,
      key: q.key,
      seed: q._seed,
      vec: q.vec,
      type: q.type || 'fr',
      genIdx: (q._genIdx!=null ? q._genIdx : null),
      topic: (q.topicKey!=null ? q.topicKey : null),
      semantic: mwSemanticSnapshotOf(q),
      mc: (q.type==='mc' ? {
        correctIndex: q.correctIndex,
        shuffleOrder: (q.__mcMeta ? q.__mcMeta.shuffleOrder : null),
        distractorSeeds: (q.__mcMeta ? q.__mcMeta.distractorSeeds : null),
        distractorGenIdxs: (q.__mcMeta ? q.__mcMeta.distractorGenIdxs : null)
      } : null)
    }))
  };
  window.LAST_BLUEPRINT = blueprint;
  mwSyncSmartReviewNoticeToActiveAssessment();
  out.innerHTML += `
<!-- WORKSHEET_BLUEPRINT\n${JSON.stringify(blueprint, null, 2)}\nWORKSHEET_BLUEPRINT -->`;

  // Store questions for LaTeX export
  window.LAST_QUESTIONS = allQs;

  // Throttled MathJax rendering for performance
  scheduleTypeset();
}

// MathJax throttling to prevent lag on rapid input
let mjTimer = null;
function scheduleTypeset(){
  clearTimeout(mjTimer);
  mjTimer = setTimeout(() => {
    if (window.MathJax && window.MathJax.typesetPromise) {
      window.MathJax.typesetPromise();
    } else if (window.MathJax && window.MathJax.Hub && window.MathJax.Hub.Queue) {
      window.MathJax.Hub.Queue(["Typeset", window.MathJax.Hub]);
    }
  }, 60);
}

function exportToLaTeX(){
  const mode = document.getElementById('modeSelect').value;
  const seed = document.getElementById('seedInput').value;
  const allQs = window.LAST_QUESTIONS || [];

  // --- LaTeX export options ---
  const latexExactMode = (document.getElementById('latexExactMode') ? document.getElementById('latexExactMode').checked : true);
  const latexDiagramMode = (document.getElementById('latexDiagramMode') ? document.getElementById('latexDiagramMode').value : 'remove');

  function stripSvgsForLatex(html){
    const s = String(html ?? '');
    if(latexDiagramMode === 'placeholder'){
      return s.replace(/<svg[\s\S]*?<\/svg>/gi, '\n\n\\textit{[Diagram omitted]}\\\\\n\n');
    }
    return s.replace(/<svg[\s\S]*?<\/svg>/gi, '');
  }

  function protectInlineMathSegments(s) {
    const parts = [];
    let out = String(s ?? "");
    // Protect \(...\) and \[...\]
    // NOTE: We intentionally do NOT treat $...$ as math so currency like $5 can be escaped safely.
    out = out.replace(/(\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\])/g, (m) => {
      const idx = parts.length;
      parts.push(m);
      return `@@MATH${idx}@@`;
    });
    return { out, parts };
  }
  function restoreInlineMathSegments(s, parts, keepExact) {
    return String(s ?? "").replace(/@@MATH(\d+)@@/g, (_, k) => {
      let m = parts[+k] ?? "";

      // --- math-only cleanup ---
      // Degree symbols inside math
      m = m.replace(/\\textdegree/g, '^\\circ').replace(/°/g, '^\\circ');
      // Times symbol inside math
      m = m.replace(/×/g, '\\texttimes');
      // Common sign artifacts inside math
      m = m.replace(/[−–]/g, '-')
           .replace(/\+\s*-/g, ' - ')
           .replace(/-\s*-/g, ' + ')
           .replace(/-\s*\+/g, ' - ')
           .replace(/\(x--/g, '(x+')
           .replace(/\{x--/g, '{x+')
           .replace(/\bx--(\d+)/g, 'x+$1');

      // Snap long floats near integers (e.g., 431.9999999999999 -> 432)
      m = m.replace(/-?\d+\.\d{6,}/g, (numStr) => {
        const x = Number(numStr);
        if (!Number.isFinite(x)) return numStr;
        const r = Math.round(x);
        if (Math.abs(x - r) < 1e-6) return String(r);
        return fmtDec(x, 3); // otherwise 3 decimals
      });

      // Decimalize simple fractions in TeX only when Exact is OFF
      if (!keepExact) {
        // \frac{a}{b} where a,b are ints
        m = m.replace(/\\frac\s*\{\s*(-?\d+)\s*\}\s*\{\s*(\d+)\s*\}/g, (_, a, b) => {
          const val = Number(a) / Number(b);
          return Number.isFinite(val) ? fmtDec(val, 3) : `\\frac{${a}}{${b}}`;
        });
        // plain a/b (avoid \frac and command contexts)
        m = m.replace(/(?<![\\\w])(-?\d+)\s*\/\s*(\d+)(?![\w])/g, (_, a, b) => {
          const val = Number(a) / Number(b);
          return Number.isFinite(val) ? fmtDec(val, 3) : `${a}/${b}`;
        });
      }

      return m;
    });
  }

  const LATEX_SPECIALS = ['$', '&', '#', '%', '_', '{', '}'];

  function escapeLatexTextOutsideMath(s) {
    let t = String(s ?? "");
    // 1. Protect specials the generator already escaped (\$ \% \_ ...).
    //    Sentinel is letters+digits only, so step 2 cannot corrupt it.
    LATEX_SPECIALS.forEach((ch, i) => {
      t = t.split('\\' + ch).join('ZZLTXESC' + i + 'ZZ');
    });
    // 2. Escape any remaining bare specials.
    t = t.replace(/([$&#%_{}])/g, '\\$1');
    // 3. Restore already-escaped specials.
    LATEX_SPECIALS.forEach((ch, i) => {
      t = t.split('ZZLTXESC' + i + 'ZZ').join('\\' + ch);
    });
    return t;
  }

  function fixLatexSigns(s){
    let t = String(s ?? '');

    // Normalize unicode dashes
    t = t.replace(/[−–]/g, '-');

    // Fix common operator artifacts
    t = t.replace(/\+\s*-/g, ' - ');
    t = t.replace(/-\s*-/g, ' + ');
    t = t.replace(/-\s*\+/g, ' - ');
    t = t.replace(/\+-/g, ' - ');

    // Fix double-dash patterns in common contexts
    t = t.replace(/\(x--/g, '(x+');
    t = t.replace(/\{x--/g, '{x+');
    t = t.replace(/\bx--(\d+)/g, 'x+$1');

    // Clean spacing around operators
    t = t.replace(/\s*\+\s*/g, ' + ');
    t = t.replace(/\s*-\s*/g, ' - ');
    t = t.replace(/\s{2,}/g, ' ');

    return t;
  }

  // ✅ ADD THIS ENTIRE FUNCTION HERE
  function cleanCoefficientsAndSpacing(s) {
  let t = String(s ?? '');

  // Guard: sometimes '+' is a legitimate standalone answer (e.g., quadrant sign).
  // Don't let cleanup rules erase it.
  const _trim0 = t.trim();
  if (_trim0 === '+' || _trim0 === '-') return _trim0;

  // Protect LaTeX fractions so cleanup regex can't touch their insides
  const _stash = [];
  t = t.replace(/\\d?frac\{[^{}]*\}\{[^{}]*\}/g, (m) => {
    _stash.push(m);
    return `@@FRAC${_stash.length-1}@@`;
  });

  // Remove coefficient of 1 (but not exponent 1)
  t = t.replace(/\b1([a-z])\b/gi, '$1');           // 1x → x, 1y → y
  t = t.replace(/\\ln\(1([a-z])\)/gi, '\\ln($1)'); // \ln(1x) → \ln(x)

  // Remove exponent of 1 ONLY on variables (not integral limits)
  t = t.replace(/([a-z])\^(\{1\}|1)(?!\d)/gi, '$1');  // x^1 or x^{1} → x

  // Remove zero terms (conservative)
  t = t.replace(/\s*\+\s*0[a-z]+/gi, '');           // +0xy → ""
  t = t.replace(/\b0[a-z]+\s*\+/gi, '');            // 0x+ → ""

  // Fix double spaces
  t = t.replace(/\s{2,}/g, ' ');

  // Clean up orphaned operators
  t = t.replace(/\+\s*\+/g, '+');
  t = t.replace(/\s*\+\s*$/gm, '');

  // Restore protected fractions
  t = t.replace(/@@FRAC(\d+)@@/g, (_, i) => _stash[Number(i)] ?? _);

  return t;
}

  function toLatexText(s){
    const keepExact = !!latexExactMode;

    // 0) Remove diagrams & HTML
    let t = stripSvgsForLatex(s);
    // Normalize math delimiters in case any text contains double-backslash forms.
    t = t.replace(/\\\\\(/g, '\\(').replace(/\\\\\)/g, '\\)');
    t = t.replace(/\\\\\[/g, '\\[').replace(/\\\\\]/g, '\\]');

    t = t.replace(/<br\s*\/?>/gi, '\n\n');
    t = t.replace(/<\/p>/gi, '\n\n').replace(/<p[^>]*>/gi, '');
    t = t.replace(/<[^>]*>/g, '');
    t = t.replace(/&nbsp;/g, ' ').replace(/\u00a0/g, ' ');

    // 1) Protect math first (so we don't escape inside it)
    const pm = protectInlineMathSegments(t);
    let out = pm.out;

    // 2) Numeric cleanup and sign cleanup OUTSIDE math only
    out = keepExact ? roundLongDecimals(out) : cleanMathText(out);
    out = fixLatexSigns(out);

    // 3) Text-only symbol fixes (outside math)
    out = out.replace(/°/g, '\\textdegree');
    out = out.replace(/×/g, '\\texttimes');

    // 4) Escape plain text specials (currency $, etc.)
    out = escapeLatexTextOutsideMath(out);

    // 5) Restore math (and normalize degrees/floats within math)
    let restored = restoreInlineMathSegments(out, pm.parts, keepExact);
    restored = fixTexEscapes(restored);
    restored = cleanCoefficientsAndSpacing(restored);
    return restored.trim();
  }

  
  if(allQs.length === 0){
    alert('Please generate a worksheet first!');
    return;
  }
  
  const modeNames = {
    CA: 'Precalculus I (MTH 161)',
    TRIG: 'Precalculus II: Trigonometry (MTH 162)',
    PC: 'Precalculus with Trig (MTH 167)',
    C1: 'Calculus I (MTH 263)',
    C2: 'Calculus II (MTH 264)',
    C3: 'Calculus III (MTH 265)',
    MIX: 'Mixed (All Courses)'
  };
  
  let tex = `\\documentclass[12pt]{article}
\\usepackage{amsmath,amssymb}
\\usepackage{mathtools}
\\usepackage[utf8]{inputenc}
\\usepackage[margin=1in]{geometry}
\\usepackage{enumitem}
\\usepackage{textcomp}

\\title{${modeNames[mode] || 'Math'} Worksheet}
\\date{\\today}

\\begin{document}
\\maketitle

\\noindent\\textbf{Name:} \\underline{\\hspace{3in}} \\\\
\\textbf{Date:} \\underline{\\hspace{2in}} \\\\
\\textbf{Worksheet ID:} \\texttt{${seed.replace(/_/g, '\\_')}} \\\\[0.5cm]

\\noindent\\textbf{Instructions:} Show all work for full credit.

\\begin{enumerate}[leftmargin=*]
`;

  // Add questions
  allQs.forEach((q, idx) => {
    // Strip HTML and convert LaTeX
    let qText = toLatexText(q.q);

    if(q && q.type === 'mc' && Array.isArray(q.choices)){
      tex += `\\item ${qText}\n`;
      tex += `\\begin{enumerate}[label=\\Alph*.), leftmargin=2em]\n`;
      q.choices.forEach((c) => {
        tex += `  \\item ${toLatexText(c)}\n`;
      });
      tex += `\\end{enumerate}\n\n`;
      tex += `\\vspace{1.0in}\n\n`;
    }else{
      tex += `\\item ${qText}\n\n`;
      tex += `\\vspace{1.5in}\n\n`;
    }
  });
  
  tex += `\\end{enumerate}\n\n`;
  
  // Add answer key
  if(document.getElementById('toggleAnswers').checked){
    tex += `\\newpage\n\\section*{Answer Key}\n\n\\begin{enumerate}[leftmargin=*]\n`;
    allQs.forEach((q) => {
      if(q && q.type === 'mc' && typeof q.correctIndex === 'number'){
        tex += `\\item \\textbf{${letterOf(q.correctIndex)}}\n`;
      }else{
        let ans = toLatexText(q.a);
        tex += `\\item ${ans}\n`;
      }
    });
    tex += `\\end{enumerate}\n\n`;
  }
  
  // Add worked solutions
  if(document.getElementById('toggleSolutions').checked){
    tex += `\\newpage\n\\section*{Worked Solutions}\n\n\\begin{enumerate}[leftmargin=*]\n`;
    allQs.forEach((q) => {
      tex += `\\item \\textbf{Solution:}\n\\begin{itemize}\n`;
      (q.steps || []).forEach(step => {
        let stepText = toLatexText(step);
        tex += `  \\item ${stepText}\n`;
      });
      tex += `\\end{itemize}\n`;
      if(q && q.type === 'mc' && typeof q.correctIndex === 'number'){
        const ansTxt = (q.choices && q.choices[q.correctIndex] != null) ? toLatexText(q.choices[q.correctIndex]) : toLatexText(q.a);
        tex += `\\vspace{0.2cm}\\textbf{Correct:} ${letterOf(q.correctIndex)}\\\\\n`;
        tex += `\\textbf{Answer:} ${ansTxt}\\\\\n\\vspace{0.3cm}\n`;
      }else{
        tex += `\\vspace{0.3cm}\n`;
      }
    });
    tex += `\\end{enumerate}\n\n`;
  }
  
  tex += `\\end{document}`;
  
  // Export sanity checks (does not block download)
  const _warn = [];
  if (/\bNaN\b/.test(tex)) _warn.push('NaN');
  if (/\bInfinity\b/.test(tex)) _warn.push('Infinity');
  if (/\\text\{undefined\}/i.test(tex) || /\bundefined\b/i.test(tex)) _warn.push('undefined');
  // LaTeX/JS-escape hygiene checks (post auto-repair)
  const texScan = (typeof fixTexEscapes === 'function') ? fixTexEscapes(tex) : tex;

  // Control characters often come from JS escapes (e.g., "\frac" typed with a single backslash => \f form-feed)
  if (/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/.test(texScan)) _warn.push('control chars (possible JS escape leak)');

  // Missing leading backslash on TeX commands (avoid false positives from correct "\\frac{...}" etc.)
  if (/(^|[^A-Za-z\\])frac\{/.test(texScan))  _warn.push('frac{ (missing \\\\ before frac)');
  if (/(^|[^A-Za-z\\])dfrac\{/.test(texScan)) _warn.push('dfrac{ (missing \\\\ before dfrac)');
  if (/(^|[^A-Za-z\\])cdot\b/.test(texScan))  _warn.push('cdot (missing \\\\ before cdot)');
  if (/(^|[^A-Za-z\\])sqrt\{/.test(texScan))  _warn.push('sqrt{ (missing \\\\ before sqrt)');
  if (/(^|[^\\])infty\b/.test(texScan)) _warn.push('infty (missing \\\\ before infty)');
  if (/(^|[^A-Za-z\\])int\b/.test(texScan))  _warn.push('int (missing \\\\ before int)');
  if (/(^|[^A-Za-z\\])sum(?=\s*[_^\\\\])/.test(texScan))  _warn.push('sum_{...}/sum^{...} (missing \\\\ before \\sum)');
  if (/(^|[^A-Za-z\\])lim\b/.test(texScan))  _warn.push('lim (missing \\\\ before lim)');

  const _openInline = ((typeof texScan!=='undefined'?texScan:tex).match(/\\\(/g) || []).length;
  const _closeInline = ((typeof texScan!=='undefined'?texScan:tex).match(/\\\)/g) || []).length;
  if (_openInline !== _closeInline) _warn.push(`unbalanced \\( \\) (${_openInline} vs ${_closeInline})`);
  const _dbl = ((typeof texScan!=='undefined'?texScan:tex).match(/\$\$/g) || []).length;
  if (_dbl % 2 !== 0) _warn.push('unbalanced $$');
  if (_warn.length) {
    console.warn('[LaTeX Export] Potential issues:', _warn);
    alert('LaTeX export warning:\n- ' + _warn.join('\n- ') + '\n\nDownload will continue. Check output if something looks off.');
  }

  // Download
  // Transliterate unicode math/typography characters that pdflatex cannot digest.
  // \ensuremath is safe both inside and outside math mode.
  const UNI2TEX = [
    [/\u2260/g, '\\ensuremath{\\neq}'],
    [/\u2264/g, '\\ensuremath{\\le}'],
    [/\u2265/g, '\\ensuremath{\\ge}'],
    [/\u00d7/g, '\\ensuremath{\\times}'],
    [/\u00b0/g, '\\ensuremath{^\\circ}'],
    [/\u03c0/g, '\\ensuremath{\\pi}'],
    [/\u21d2/g, '\\ensuremath{\\Rightarrow}'],
    [/\u2192/g, '\\ensuremath{\\to}'],
    [/\u00b2/g, '\\ensuremath{{}^{2}}'],
    [/\u00b3/g, '\\ensuremath{{}^{3}}'],
    [/\u2022/g, '\\textbullet{} '],
    [/\u2014/g, '---'],
    [/\u2013/g, '--'],
    [/\u2212/g, '-'],
    [/[\u2018\u2019]/g, "'"],
    [/[\u201c\u201d]/g, '"'],
    [/\u221e/g, '\\ensuremath{\\infty}'],
    [/\u00b1/g, '\\ensuremath{\\pm}'],
    [/\u221a/g, '\\ensuremath{\\surd}'],
    [/\u2032/g, "\\ensuremath{'}"]
  ];
  for(const [re, rep] of UNI2TEX) tex = tex.replace(re, rep);
  const blob = new Blob([tex], {type: 'text/plain'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `worksheet_${seed}.tex`;
  a.click();
  URL.revokeObjectURL(url);
}

// =====================
