// UI builder (auto-creates unit count inputs)
// =====================
function unitsForMode(mode){
  if(typeof mwUnitsForProfileMode === 'function'){ const profUnits = mwUnitsForProfileMode(mode); if(profUnits) return profUnits; }
  if(mode === 'MIX') return UNITS;
  if(mode === 'PC'){
    // MTH 167 = Precalculus with Trig = union of MTH 161 + 162 + the PC-only topics
    return UNITS.filter(u => u.course === 'CA' || u.course === 'TRIG' || u.course === 'PC');
  }
  return UNITS.filter(u => u.course === mode || (u.also || []).includes(mode));
}
function visibleUnits(){
  return unitsForMode(document.getElementById('modeSelect').value);
}

function mwPreflightBlueprint(bp){
  if(!bp || typeof bp !== 'object') return { ok:false, error:'expected a JSON object' };
  const validModes = new Set(['MIX', ...UNITS.map(u => u.course)]);
  const mode = (bp.mode != null ? String(bp.mode) : '');
  if(!validModes.has(mode)) return { ok:false, error:`unknown mode "${mode || '(missing)'}"` };

  const countsIn = (bp.counts == null ? {} : bp.counts);
  if(!countsIn || typeof countsIn !== 'object' || Array.isArray(countsIn)){
    return { ok:false, error:'counts must be an object' };
  }

  const allowed = new Set(unitsForMode(mode).map(u => u.id));
  const counts = {};
  let total = 0;
  for(const [unitId, raw] of Object.entries(countsIn)){
    if(!allowed.has(unitId)){
      return { ok:false, error:`unit "${unitId}" is not available in mode "${mode}"` };
    }
    const n = Number(raw);
    if(!Number.isFinite(n) || !Number.isInteger(n) || n < 0){
      return { ok:false, error:`count for "${unitId}" must be a finite nonnegative integer` };
    }
    if(n > MW_BLUEPRINT_UNIT_MAX){
      return { ok:false, error:`count for "${unitId}" exceeds the per-unit limit of ${MW_BLUEPRINT_UNIT_MAX}` };
    }
    counts[unitId] = n;
    total += n;
    if(total > MW_BLUEPRINT_TOTAL_MAX){
      return { ok:false, error:`total question count exceeds the blueprint limit of ${MW_BLUEPRINT_TOTAL_MAX}` };
    }
  }
  return { ok:true, mode, counts, total, allowed };
}

function buildCoveragePills(){
  const host = document.getElementById('coveragePills');
  const modeSelect = document.getElementById('modeSelect');
  const mode = modeSelect ? modeSelect.value : 'MIX';
  const units = visibleUnits();
  if(!host) return;

  const modeLabel = (course) => {
    const opt = modeSelect && Array.from(modeSelect.options || []).find(o => o.value === course);
    return opt ? opt.textContent.trim() : course;
  };
  const unitStats = (u) => {
    const gens = Gens[u.id] || [];
    const topics = ensureUnitTopics(u.id);
    return { u, gens: gens.length, topics };
  };
  const appendPill = (label, detail, title='') => {
    const div = document.createElement('div');
    div.className = 'pill';
    if(title) div.title = title;
    div.innerHTML = `<b>${escHtml(label)}:</b> ${escHtml(detail)}`;
    host.appendChild(div);
  };

  host.innerHTML = '';

  if(mode === 'MIX'){
    // Each pill describes the exact selectable profile for that course mode.
    // Shared/aliased units (and the composite MTH 167 profile) therefore match
    // what the user actually sees after choosing that course.
    const courseModes = Array.from(modeSelect?.options || [])
      .map(option => option.value)
      .filter(course => course && course !== 'MIX');
    for(const course of courseModes){
      const profileMap = new Map(unitsForMode(course).map(u => [u.id, u]));
      const profileUnits = [...profileMap.values()];
      let genCount = 0;
      const topicKeys = new Set();
      for(const u of profileUnits){
        genCount += (Gens[u.id] || []).length;
        for(const topic of ensureUnitTopics(u.id)) topicKeys.add(`${u.id}|${topic.id}`);
      }
      appendPill(
        modeLabel(course),
        `${profileUnits.length} units · ${genCount} generators · ${topicKeys.size} topics`,
        profileUnits.map(u => unitLabel(u.id)).join(' • ')
      );
    }
    return;
  }

  // Single-course modes show each live unit. Topic names are derived, never hand-maintained.
  for(const {u, gens, topics} of units.map(unitStats)){
    const labels = topics.map(t => t.label);
    const preview = labels.slice(0, 4).join(', ');
    const more = labels.length > 4 ? ` +${labels.length - 4} more` : '';
    const detail = `${gens} generator${gens===1?'':'s'} · ${topics.length} topic${topics.length===1?'':'s'}` +
      (preview ? ` — ${preview}${more}` : '');
    appendPill(unitLabel(u.id), detail, labels.join(' • '));
  }
}
function buildUnitControls() {
  const countWrap = document.getElementById('unitControls');
  if (!countWrap) return;
  countWrap.innerHTML = '';
  countInputs.length = 0;

  const units = visibleUnits();
  units.forEach(u=>{
    const field = document.createElement('div');
    field.className = 'field';

    const lbl = document.createElement('label');
    lbl.textContent = unitLabel(u.id);

    const inp = document.createElement('input');
    inp.type = 'number';
    inp.min = 0;
    inp.value = u.defaultCount || 0;
    inp.dataset.unit = u.id;
    inp.className = 'count-in';
    inp.addEventListener('input', saveState);

    // Topics button + summary
    const topicRow = document.createElement('div');
    topicRow.style.display = 'flex';
    topicRow.style.gap = '10px';
    topicRow.style.alignItems = 'center';
    topicRow.style.marginTop = '8px';
    topicRow.style.flexWrap = 'wrap';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'topicBtn';
    btn.textContent = 'Topics';
    btn.addEventListener('click', ()=>openTopicModal(u.id));

    const summary = document.createElement('div');
    summary.className = 'topicSummary';
    summary.id = 'topicSummary_' + u.id;

    // Warm up metadata so the modal + pills are instant
    ensureUnitTopics(u.id);
    topicRow.appendChild(btn);
    topicRow.appendChild(summary);

    field.appendChild(lbl);
    field.appendChild(inp);
    field.appendChild(topicRow);

    countWrap.appendChild(field);
    countInputs.push(inp);
      updateTopicUI(u.id);
  });
}

function updateVarietyLabel(){
  const v = parseInt(document.getElementById('varietyInput').value, 10);
  document.getElementById('varietyLabel').textContent = (v===1 ? 'Low' : (v===2 ? 'Medium' : 'High'));
}

// =====================
// Variety selector + render
// =====================
function pickProblem(seedStr, cat, slotIndex, chosen, varietyStrength){
  const templatesAll = Gens[cat] || [];
  if(!templatesAll.length) return null;

  const sel = ensureTopicSet(cat);
  const none = !!sel.__none; // explicit none => fall back to all

  let templates = templatesAll;
  if(!none && sel.size){
    templates = templatesAll.filter(fn => sel.has(ensureGenTopicMeta(cat, fn)));
    if(!templates.length) templates = templatesAll; // safe fallback
  }

  const tries = (varietyStrength===1 ? 10 : (varietyStrength===2 ? 22 : 40));
  let best = null;
  let bestScore = -Infinity;

  for(let t=0;t<tries;t++){
    const keySeed = `${seedStr}|${cat}|slot${slotIndex}|try${t}`;
    const rng = xorshift32(fnv1a(keySeed));
    const gen = pick(rng, templates);
    let p = null;
    try{
      p = gen(rng);
    }catch(e){
      GEN_ERROR_COUNT++;
      if(GEN_ERROR_SAMPLES.length < 6){
        const name = gen && gen.name ? gen.name : 'anon';
        const msg = (e && (e.message||String(e))) ? (e.message||String(e)) : 'error';
        const entry = `${cat}:${name} → ${msg}`;
        if(!GEN_ERROR_SAMPLES.includes(entry)) GEN_ERROR_SAMPLES.push(entry);
      }
      continue;
    }
    if(!p || !p.vec) continue;

    p._seed = keySeed;
    p.cat = cat;
    p.key = p.key || keySeed;

    // Track generator name for variety scoring
    p._genName = (gen && gen.name) ? gen.name : 'anon';

    // Track generator index within the unit (helps quiz mode reproduce siblings)
    p._genIdx = templatesAll.indexOf(gen);

    // Repair common TeX escape leaks in generated strings (keeps UI/export clean)
    p.q = fixTexEscapes(p.q);
    p.a = fixTexEscapes(p.a);
    if(Array.isArray(p.steps)) p.steps = p.steps.map(fixTexEscapes);

    const topicId = (gen.meta && gen.meta.topicId) ? gen.meta.topicId : ((p.meta && p.meta.topicId) ? String(p.meta.topicId) : deriveTopicKeyFromKey(cat, p.key));
    p.topicKey = topicId;
    const rawTopicLabel = (gen.meta && gen.meta.topicLabel) ? gen.meta.topicLabel : ((p.meta && p.meta.topicLabel) ? String(p.meta.topicLabel) : humanizeTopicId(topicId));
    p.topicLabel = topicLabelFor(cat, topicId, rawTopicLabel);

    let minD = Infinity;
    for(const prev of chosen){
      const d = dist(p.vec, prev.vec);
      if(d < minD) minD = d;
    }
    if(chosen.length===0) minD = 999;

    const recent = chosen.slice(-12);

    // Scale penalties with variety strength (1=low, 2=med, 3=high)
    const w = (varietyStrength===1 ? 1.0 : (varietyStrength===2 ? 1.25 : 1.55));

    const repeats = recent.some(x => x.key === p.key && x.cat === p.cat);
    const repPenalty = repeats ? (0.75 * w) : 0;

    const last = chosen[chosen.length-1];
    const streakPenalty = (last && last.cat === p.cat) ? (0.15 * w) : 0;

    // Topic repetition penalty (last few picks within same unit)
    const recentTopicHits = recent.filter(x => (x.cat===cat) && ((x.topicKey||deriveTopicKeyFromKey(cat, x.key)) === topicId)).length;
    const topicPenalty = recentTopicHits * (0.18 * w);

    // Extra penalty for back-to-back same topic within a unit
    const lastTopic = last ? (last.topicKey||deriveTopicKeyFromKey(cat, last.key)) : null;
    const topicStreakPenalty = (last && last.cat===cat && lastTopic === topicId) ? (0.22 * w) : 0;

    // Mild penalty for repeatedly selecting the same generator function (even if topic differs)
    const recentGenHits = recent.filter(x => (x.cat===cat) && (x._genName === p._genName)).length;
    const genPenalty = recentGenHits * (0.10 * w);

    const score = minD - repPenalty - streakPenalty - topicPenalty - topicStreakPenalty - genPenalty;

    if(score > bestScore){
      bestScore = score;
      best = p;
    }
  }
  return best;
}


// =====================
