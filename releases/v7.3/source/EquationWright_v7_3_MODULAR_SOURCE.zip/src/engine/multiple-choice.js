// Quiz Mode (MC) helpers
// =====================
function letterOf(i){ return String.fromCharCode(65 + (i|0)); }

// Normalize answers for (lightweight) de-duplication of multiple-choice distractors.
function normalizeMCAnswer(s){
  let t = String(s ?? '');

  // Remove math wrappers/delimiters
  t = t.replace(/\\\(|\\\)|\\\[|\\\]/g, '');
  t = t.replace(/\$/g, '');
  t = t.replace(/\\left/g, '').replace(/\\right/g, '');

  // Normalize whitespace/braces
  t = t.replace(/\s+/g, '');
  t = t.replace(/[{}]/g, '');

  // Normalize common fraction commands: \frac, \dfrac, \tfrac -> "a/b"
  t = t.replace(/\\(?:dfrac|tfrac|frac)\{\s*(-?\d+)\s*\}\{\s*(\d+)\s*\}/g, '$1/$2');

  // Normalize multiplication + unicode minus variants
  t = t.replace(/\\cdot/g, '*').replace(/\\times/g, '*');
  t = t.replace(/[−–—]/g, '-');

  return t;
}

function shuffleOrder(rng, n){
  const order = Array.from({length:n}, (_,i)=>i);
  for(let i=n-1;i>0;i--){
    const j = Math.floor(rng()*(i+1));
    const tmp = order[i]; order[i] = order[j]; order[j] = tmp;
  }
  return order;
}

// Build a multiple-choice item using the same generator as the picked stem.
// (No generator changes required.)
function answerShapeFromKey(k){
  // numeric if "12", "-3.5", "7/2"
  if(/^[-]?\d+(\.\d+)?$/.test(k)) return 'num';
  if(/^[-]?\d+\/\d+$/.test(k)) return 'num';
  return 'sym';
}


// Optional semantic answer contract. Legacy generators continue using display strings.
const MW_ANSWER_VALIDATORS = Object.freeze({
  'logic-truth-column-v1': (questionModel, answerModel) =>
    mwTruthColumnAnswerIsCorrect(questionModel, answerModel),
  'de-solution-v1': (questionModel, answerModel) =>
    mwDEVerifySolution(questionModel, answerModel).status === 'pass'
});

function mwPlainClone(value){
  if(value == null) return value;
  return JSON.parse(JSON.stringify(value));
}

function mwAnswerSpecOf(problem){
  return (problem && problem.answerSpec && typeof problem.answerSpec === 'object')
    ? problem.answerSpec
    : null;
}

function mwQuestionModelOf(problem){
  if(problem && problem.logicSpec && problem.logicSpec.questionModel){
    return problem.logicSpec.questionModel;
  }
  if(problem && problem.deSpec && problem.deSpec.questionModel){
    return problem.deSpec.questionModel;
  }
  return problem ? (problem.questionModel || null) : null;
}

function mwSemanticContractOf(problem){
  const spec = mwAnswerSpecOf(problem);
  const questionModel = mwQuestionModelOf(problem);
  if(!spec || !spec.validatorId || !spec.choiceFamily || !spec.key ||
     !spec.model || !questionModel){
    return null;
  }
  const validator = MW_ANSWER_VALIDATORS[spec.validatorId];
  if(typeof validator !== 'function') return null;
  return {
    spec,
    questionModel,
    validator,
    validatorId: spec.validatorId,
    choiceFamily: spec.choiceFamily,
    semanticKey: spec.key
  };
}

function mwSemanticCandidateFitsRetained(retained, candidate){
  const retainedContract = mwSemanticContractOf(retained);
  const candidateSpec = mwAnswerSpecOf(candidate);
  if(!retainedContract || !candidateSpec || !candidateSpec.model) return null;
  if(candidateSpec.choiceFamily !== retainedContract.choiceFamily) return false;
  try{
    return !!retainedContract.validator(
      retainedContract.questionModel,
      candidateSpec.model
    );
  }catch(e){
    return false;
  }
}

function mwSemanticSnapshotOf(problem){
  if(!problem || (!problem.answerSpec && !problem.logicSpec && !problem.deSpec)){
    return null;
  }
  return mwPlainClone({
    answerSpec: problem.answerSpec || null,
    logicSpec: problem.logicSpec || null,
    deSpec: problem.deSpec || null
  });
}

// Capacity-aware MC policy. Semantic metadata is authoritative. For legacy
// generators, deterministic answer-capacity probes and unique authored traps
// both inform the intended 2/3/4-choice target. Capacity probe errors never
// classify a family as intentionally low-capacity.
const MW_MC_CAPACITY_SAMPLES = 80;
const MW_MC_CAPACITY_CACHE = new Map();

function mwLooksLikeSimpleCategoryAnswer(value){
  const s = String(value ?? '').trim();
  if(!s || s.length > 80) return false;
  if(/[0-9]/.test(s)) return false;
  if(/[\\$^_=<>]/.test(s)) return false;
  return true;
}

function mwUniqueStemTrapCount(stem, correctDisplayKey){
  const seen = new Set();
  for(const trap of (Array.isArray(stem?.traps) ? stem.traps : [])){
    const ans = fixTexEscapes(typeof trap === 'string' ? trap : (trap && trap.ans));
    const key = normalizeMCAnswer(ans);
    if(key && key !== correctDisplayKey) seen.add(key);
  }
  return seen.size;
}

function mwMCChoicePolicy(stem, cat, genIdx, genFn){
  const spec = mwAnswerSpecOf(stem);
  const explicit = Number(spec && spec.choiceCapacity != null ? spec.choiceCapacity : stem && stem.choiceCapacity);
  if(Number.isFinite(explicit) && explicit >= 2){
    return {
      target: Math.max(2, Math.min(4, Math.floor(explicit))),
      source: 'semantic-capacity',
      capacity: explicit,
      capacityErrors: 0
    };
  }

  const cacheKey = `${cat}|${genIdx}`;
  let cap = MW_MC_CAPACITY_CACHE.get(cacheKey);
  if(!cap){
    cap = mwAnswerCapacity(genFn, cat, MW_MC_CAPACITY_SAMPLES);
    MW_MC_CAPACITY_CACHE.set(cacheKey, cap);
  }
  const samples = Array.isArray(cap.answerSamples) ? cap.answerSamples : [];
  const capErrors = Array.isArray(cap.errors) ? cap.errors.length : 0;
  const categorical = capErrors === 0 && (cap.distinct === 2 || cap.distinct === 3) &&
    samples.length === cap.distinct && samples.every(mwLooksLikeSimpleCategoryAnswer);
  const trapTarget = Math.min(4, 1 + mwUniqueStemTrapCount(stem, normalizeMCAnswer(fixTexEscapes(stem?.a))));
  const baseTarget = categorical ? cap.distinct : 4;
  const target = Math.max(2, Math.min(4, Math.max(baseTarget, trapTarget)));
  let source = categorical ? 'legacy-categorical-capacity' : 'legacy-four-choice';
  if(categorical && target > cap.distinct) source = 'legacy-categorical-plus-traps';
  if(capErrors) source = 'legacy-four-choice-capacity-error';
  return {
    target,
    source,
    capacity: cap.distinct,
    capacityErrors: capErrors
  };
}

// Build a multiple-choice item using the same generator as the picked stem when possible.
// If the stem generator yields constant/duplicate answers, pull distractors deterministically
// from other generators in the same unit (prefer same topic/shape), keeping everything seeded.
function buildMCFromStem(stem, cat){
  if(!stem) return null;

  const unitGens = Gens[cat] || [];
  if(!unitGens.length) return null;

  const stemGenIdx =
    (Number.isInteger(stem._genIdx) && stem._genIdx >= 0 && stem._genIdx < unitGens.length)
      ? stem._genIdx
      : 0;

  const stemGen = unitGens[stemGenIdx];
  if(!stemGen) return null;

  const correctAns = fixTexEscapes(stem.a);
  const correctDisplayKey = normalizeMCAnswer(correctAns);
  const correctShape = answerShapeFromKey(correctDisplayKey);
  const semanticContract = mwSemanticContractOf(stem);
  const semanticMode = !!semanticContract;
  let choicePolicy = mwMCChoicePolicy(stem, cat, stemGenIdx, stemGen);
  const initialTargetChoiceCount = choicePolicy.target;
  let targetChoiceCount = initialTargetChoiceCount;

  const records = [{
    ans: correctAns,
    problem: stem,
    displayKey: correctDisplayKey,
    semanticKey: semanticMode ? semanticContract.semanticKey : null,
    seed: stem._seed,
    genIdx: stemGenIdx,
    trapIndex: null,
    origin: 'correct'
  }];

  const seenDisplay = new Set([correctDisplayKey]);
  const seenSemantic = new Set(
    semanticMode ? [semanticContract.semanticKey] : []
  );

  const wantTopic = stem.topicKey || null;

  function tryGenForUniqueAnswer(genIdx, genFn, dNum, maxTries, requireShape){
    for(let r=0; r<maxTries; r++){
      const dSeedStr = `${stem._seed}|mc|g${genIdx}|d${dNum}|r${r}`;
      const rng = xorshift32(fnv1a(dSeedStr));

      let dp = null;
      try{
        dp = genFn(rng);
      }catch(e){
        GEN_ERROR_COUNT++;
        continue;
      }
      if(!dp || dp.a == null) continue;

      const a = fixTexEscapes(dp.a);
      const displayKey = normalizeMCAnswer(a);
      if(!displayKey || displayKey === correctDisplayKey || seenDisplay.has(displayKey)) continue;

      if(requireShape && answerShapeFromKey(displayKey) !== correctShape){
        continue;
      }

      let semanticKey = null;
      if(semanticMode){
        const candidateContract = mwSemanticContractOf(dp);
        if(!candidateContract) continue;
        if(candidateContract.validatorId !== semanticContract.validatorId) continue;
        if(candidateContract.choiceFamily !== semanticContract.choiceFamily) continue;

        semanticKey = candidateContract.semanticKey;
        if(!semanticKey || seenSemantic.has(semanticKey)) continue;

        // A sibling answer may be valid for its own question but must not also
        // answer the retained question.
        if(mwSemanticCandidateFitsRetained(stem, dp) === true) continue;
      }

      return { ans:a, seed:dSeedStr, genIdx, problem:dp, displayKey, semanticKey, trapIndex:null, origin:'generator' };
    }
    return null;
  }

  const trapWhys = {};
  // Semantic families skip unmodeled traps because they cannot be checked
  // against the retained question. Legacy generators keep unique authored traps.
  if(!semanticMode && Array.isArray(stem.traps)){
    for(let trapIndex=0; trapIndex<stem.traps.length; trapIndex++){
      const t = stem.traps[trapIndex];
      if(records.length >= targetChoiceCount) break;
      const tAns = fixTexEscapes(typeof t === 'string' ? t : (t && t.ans));
      if(!tAns) continue;
      const displayKey = normalizeMCAnswer(tAns);
      if(!displayKey || seenDisplay.has(displayKey)) continue;

      const trapOrdinal = records.length;
      seenDisplay.add(displayKey);
      records.push({
        ans:tAns,
        problem:null,
        displayKey,
        semanticKey:null,
        seed:`${stem._seed}|mc|trap${trapOrdinal}`,
        genIdx:stemGenIdx,
        trapIndex,
        origin:'trap'
      });
      if(t && typeof t === 'object' && t.why){
        trapWhys[displayKey] = String(t.why);
      }
    }
  }

  while(records.length < targetChoiceCount){
    const d = records.length;
    let picked = null;
    const sameGenTries = semanticMode ? 64 : 10;

    picked = tryGenForUniqueAnswer(
      stemGenIdx,
      stemGen,
      d,
      sameGenTries,
      true
    );

    if(!picked && wantTopic){
      const maxAlt = Math.min(8, Math.max(0, unitGens.length - 1));
      for(let step=1; step<=maxAlt; step++){
        const altIdx = (stemGenIdx + step) % unitGens.length;
        const altGen = unitGens[altIdx];
        if(!altGen) continue;

        const altTopic = ensureGenTopicMeta(cat, altGen);
        if(altTopic !== wantTopic) continue;

        picked = tryGenForUniqueAnswer(
          altIdx,
          altGen,
          d,
          semanticMode ? 48 : 8,
          true
        );
        if(picked) break;
      }
    }

    if(!picked){
      const maxAlt = Math.min(10, Math.max(0, unitGens.length - 1));
      for(let step=1; step<=maxAlt; step++){
        const altIdx = (stemGenIdx + step) % unitGens.length;
        const altGen = unitGens[altIdx];
        if(!altGen) continue;

        picked = tryGenForUniqueAnswer(
          altIdx,
          altGen,
          d,
          semanticMode ? 48 : 8,
          true
        );
        if(picked) break;
      }
    }

    // Legacy generators may relax display shape. Semantic families may not
    // cross families merely to fill four choices.
    if(!picked && !semanticMode){
      const maxAlt = Math.min(10, Math.max(0, unitGens.length - 1));
      for(let step=1; step<=maxAlt; step++){
        const altIdx = (stemGenIdx + step) % unitGens.length;
        const altGen = unitGens[altIdx];
        if(!altGen) continue;

        picked = tryGenForUniqueAnswer(altIdx, altGen, d, 8, false);
        if(picked) break;
      }
    }

    if(!picked){
      if(semanticMode){
        GEN_ERROR_COUNT++;
        const entry = `${cat}:semantic quiz could not collect ${targetChoiceCount} compatible choices`;
        if(GEN_ERROR_SAMPLES.length < 6 && !GEN_ERROR_SAMPLES.includes(entry)){
          GEN_ERROR_SAMPLES.push(entry);
        }
        return null;
      }
      break;
    }

    records.push(picked);
    seenDisplay.add(picked.displayKey);
    if(semanticMode && picked.semanticKey){
      seenSemantic.add(picked.semanticKey);
    }
  }

  // Entries are already unique, but retain a defensive final dedupe.
  const deduped = [];
  const finalDisplayKeys = new Set();
  const finalSemanticKeys = new Set();

  for(const record of records){
    if(finalDisplayKeys.has(record.displayKey)) continue;
    if(semanticMode && record.semanticKey && finalSemanticKeys.has(record.semanticKey)) continue;
    finalDisplayKeys.add(record.displayKey);
    if(semanticMode && record.semanticKey) finalSemanticKeys.add(record.semanticKey);
    deduped.push(record);
  }

  if(semanticMode){
    if(deduped.length !== targetChoiceCount){
      GEN_ERROR_COUNT++;
      return null;
    }
    const correctCount = deduped.filter(record =>
      record.problem && mwSemanticCandidateFitsRetained(stem, record.problem) === true
    ).length;
    if(correctCount !== 1){
      GEN_ERROR_COUNT++;
      const entry = `${cat}:semantic quiz expected one correct answer, found ${correctCount}`;
      if(GEN_ERROR_SAMPLES.length < 6 && !GEN_ERROR_SAMPLES.includes(entry)){
        GEN_ERROR_SAMPLES.push(entry);
      }
      return null;
    }
  }else{
    if(deduped.length < 2){
      GEN_ERROR_COUNT++;
      const entry = `${cat}:legacy quiz could not collect at least two unique choices`;
      if(GEN_ERROR_SAMPLES.length < 6 && !GEN_ERROR_SAMPLES.includes(entry)){
        GEN_ERROR_SAMPLES.push(entry);
      }
      return null;
    }
    if(deduped.length < targetChoiceCount){
      // The lower target is selected explicitly before the item is returned,
      // so metadata never claims a four-choice policy for a shorter quiz.
      targetChoiceCount = deduped.length;
      choicePolicy = {
        ...choicePolicy,
        source: `legacy-deterministic-${targetChoiceCount}-choice-fallback`
      };
    }
  }

  if(deduped.length !== targetChoiceCount){
    GEN_ERROR_COUNT++;
    return null;
  }

  const rngShuf = xorshift32(fnv1a(`${stem._seed}|mc|g${stemGenIdx}|shuffle`));
  const order = shuffleOrder(rngShuf, deduped.length);
  const shuffled = order.map(i => deduped[i]);
  const choices = shuffled.map(record => record.ans);
  const correctIndex = order.indexOf(0);

  if(semanticMode){
    const postShuffleCorrect = shuffled.filter(record =>
      record.problem && mwSemanticCandidateFitsRetained(stem, record.problem) === true
    ).length;
    if(postShuffleCorrect !== 1 || correctIndex < 0){
      GEN_ERROR_COUNT++;
      return null;
    }
  }else{
    const postShuffleCorrect = shuffled.filter(record => record.displayKey === correctDisplayKey).length;
    if(postShuffleCorrect !== 1 || correctIndex < 0){
      GEN_ERROR_COUNT++;
      return null;
    }
  }

  const finalDistractors = shuffled.filter((record, index) => index !== correctIndex);
  const distractorSeeds = finalDistractors.map(record => record.seed);
  const distractorGenIdxs = finalDistractors.map(record => record.genIdx);
  const choiceProvenance = shuffled.map((record, position) => ({
    position,
    role: position === correctIndex ? 'correct' : 'distractor',
    origin: record.origin === 'trap' ? 'authored-trap' : record.origin,
    sourceGeneratorId: (typeof mwGeneratorId === 'function') ? mwGeneratorId(cat, record.genIdx) : null,
    sourceRuntimeIndex: record.genIdx,
    sourceProblemKey: record.problem?.key || stem.key || null,
    sourceSeed: record.seed || stem._seed || null,
    trapIndex: Number.isInteger(record.trapIndex) ? record.trapIndex : null,
    semanticKey: record.semanticKey || null
  }));

  return {
    type: 'mc',
    cat: cat,
    key: stem.key,
    q: stem.q,
    a: correctAns,
    steps: stem.steps || [],
    vec: stem.vec,
    traps: stem.traps,
    answerSpec: stem.answerSpec || null,
    logicSpec: stem.logicSpec || null,
    deSpec: stem.deSpec || null,
    answerKey: stem.answerKey || null,
    choiceFamily: stem.choiceFamily || null,
    answerModel: stem.answerModel || null,
    questionModel: stem.questionModel || null,
    _seed: stem._seed,
    _genName: stem._genName,
    _genIdx: stemGenIdx,
    topicKey: stem.topicKey,
    topicLabel: stem.topicLabel,
    choices,
    correctIndex,
    trapWhys,
    __mcMeta: {
      genIdx: stemGenIdx,
      distractorSeeds,
      distractorGenIdxs,
      choiceProvenance,
      shuffleOrder: order,
      semanticKeys: shuffled.map(record => record.semanticKey || null),
      semanticValidated: semanticMode,
      choicePolicy: choicePolicy.source,
      choiceCapacity: choicePolicy.capacity,
      capacityErrors: choicePolicy.capacityErrors || 0,
      initialTargetChoiceCount,
      targetChoiceCount,
      actualChoiceCount: choices.length
    }
  };
}

function resetQuizState(allQs){
  if(!Array.isArray(allQs) || !allQs.length){
    window.QUIZ_DATA = null;
    return;
  }
  window.QUIZ_DATA = { questions: allQs, score: 0, answered: 0 };
}

function checkQuizAnswer(qIndex, choiceIndex){
  const data = window.QUIZ_DATA;
  if(!data || !data.questions || !data.questions[qIndex]) return;
  const q = data.questions[qIndex];
  if(q._answered) return;
  q._answered = true;

  const card = document.getElementById(`quizCard_${qIndex}`);
  if(!card) return;

  const btns = card.querySelectorAll('.quiz-choice-btn');
  btns.forEach(b => b.disabled = true);

  const _ck = (i)=> normalizeMCAnswer(String((q.choices||[])[i] ?? ''));
  const isCorrect = (choiceIndex === q.correctIndex) || (_ck(choiceIndex) !== '' && _ck(choiceIndex) === _ck(q.correctIndex));
  q._chosen = choiceIndex;
  q._wasCorrect = isCorrect;

  data.answered++;
  if(isCorrect) data.score++;

  // Mark buttons
  btns.forEach(b => {
    const idx = parseInt(b.dataset.choice||'-1', 10);
    if(idx === q.correctIndex) b.classList.add('correct');
    if(idx === choiceIndex && !isCorrect) b.classList.add('wrong');
  });

  const fb = document.getElementById(`quiz-feedback-${qIndex}`);
  if(fb){
    const correctLetter = letterOf(q.correctIndex);
    const correctText = (q.choices && q.choices[q.correctIndex] != null) ? cleanMathText(q.choices[q.correctIndex]) : cleanMathText(q.a);
    if(isCorrect){
      fb.innerHTML = `<div class="quiz-feedback correct">✓ Correct!</div>`;
    }else{
      let hint = '';
      try{
        const pickedKey = normalizeMCAnswer(String((q.choices||[])[choiceIndex] ?? ''));
        if(q.trapWhys && q.trapWhys[pickedKey]) hint = `<div class="small" style="margin-top:4px;">\u{1F4A1} ${escHtml(q.trapWhys[pickedKey])}</div>`;
      }catch(e){}
      fb.innerHTML = `<div class="quiz-feedback incorrect">✗ Incorrect. Correct: <b>${correctLetter}</b>) ${correctText}${hint}</div>`;
    }
  }

  const sol = document.getElementById(`quiz-solution-${qIndex}`);
  if(sol) sol.style.display = 'block';

  const scoreEl = document.getElementById('quizScore');
  const ansEl = document.getElementById('quizAnswered');
  if(scoreEl) scoreEl.textContent = String(data.score);
  try{ updateQuizActions(); }catch(e){}
  if(ansEl) ansEl.textContent = String(data.answered);

  scheduleTypeset();
}


function mwNormalizeWorksheetSeed(value){
  return String(value ?? '').trim() || 'Ultimate';
}
function mwCurrentWorksheetSeed(){
  return mwNormalizeWorksheetSeed(document.getElementById('seedInput')?.value);
}

