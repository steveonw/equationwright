// ---------- Quiz result actions ----------
let QUIZ_REVIEW_FILTER = false;

function updateQuizActions(){
  const panel = document.getElementById('quizActions');
  const data = window.QUIZ_DATA;
  if(!panel || !data) return;
  const total = data.questions.filter(q=>q.type==='mc').length;
  if(total < 1){ panel.style.display='none'; return; }
  panel.style.display = 'block';
  const missed = data.questions.filter(q=>q.type==='mc' && q._answered && !q._wasCorrect).length;
  const line = document.getElementById('quizResultLine');
  if(line){
    line.textContent = (data.answered >= total)
      ? `Quiz complete — Score: ${data.score} / ${total}` + (missed ? ` (${missed} missed)` : ' — perfect!')
      : `Progress: ${data.answered} / ${total} answered`;
  }
  const rev = document.getElementById('qaReviewMissed');
  const sim = document.getElementById('qaTrySimilar');
  if(rev){ rev.disabled = (missed === 0); rev.textContent = QUIZ_REVIEW_FILTER ? 'Show all questions' : 'Review missed questions'; }
  if(sim){ sim.disabled = false; sim.textContent = 'Start Smart Review (local)'; }
}

function qaReviewMissedFn(){
  const data = window.QUIZ_DATA; if(!data) return;
  QUIZ_REVIEW_FILTER = !QUIZ_REVIEW_FILTER;
  data.questions.forEach((q,qi)=>{
    const card = document.getElementById(`quizCard_${qi}`);
    if(!card) return;
    const isMissed = q._answered && !q._wasCorrect;
    card.style.display = (QUIZ_REVIEW_FILTER && !isMissed) ? 'none' : '';
    if(QUIZ_REVIEW_FILTER && isMissed){
      const sol = document.getElementById(`quiz-solution-${qi}`);
      if(sol) sol.style.display = 'block';
    }
  });
  updateQuizActions();
  if(QUIZ_REVIEW_FILTER){
    const first = data.questions.findIndex(q=>q._answered && !q._wasCorrect);
    if(first >= 0) document.getElementById(`quizCard_${first}`)?.scrollIntoView({behavior:'smooth', block:'start'});
  }
}

function qaRetakeFn(){
  QUIZ_REVIEW_FILTER = false;
  renderSheet();                          // same seed + settings => identical quiz
  document.getElementById('output')?.scrollIntoView({behavior:'smooth'});
}

function qaNewLikeFn(){
  QUIZ_REVIEW_FILTER = false;
  const s = document.getElementById('seedInput');
  if(s) s.value = mwRandomSeed();
  renderSheet();
  document.getElementById('output')?.scrollIntoView({behavior:'smooth'});
}

function qaTrySimilarFn(){
  const results = buildResultsJSON();
  if(!results){ alert('No quiz results are available yet.'); return; }
  const review = buildLocalRemediationBlueprint(results);
  if(!review.ok){ alert(`Smart Review unavailable: ${review.message} [${review.code}]`); return; }
  QUIZ_REVIEW_FILTER = false;
  applyBlueprint(review.blueprint);
  mwShowSmartReviewSummary(review,'Local Smart Review');
  document.getElementById('output')?.scrollIntoView({behavior:'smooth'});
}

function qaExportCSVFn(){
  const data = window.QUIZ_DATA; if(!data) return;
  const strip = (t)=> {
    let s = String(t ?? '');
    try { s = cleanMathText(s); } catch(e){}
    s = s.replace(/<[^>]*>/g,' ').replace(/\\[()\[\]]/g,'').replace(/\s+/g,' ').trim();
    return '"' + s.replace(/"/g,'""') + '"';
  };
  const rows = [['Question #','Unit','Topic','Question','Your answer','Correct answer','Result'].join(',')];
  data.questions.forEach((q,qi)=>{
    if(q.type!=='mc') return;
    const unit = (UNITS.find(u=>u.id===q.cat)||{}).label || q.cat;
    const your = q._answered ? (q.choices?.[q._chosen] ?? '') : '(unanswered)';
    const corr = q.choices?.[q.correctIndex] ?? q.a;
    const res = q._answered ? (q._wasCorrect ? 'Correct' : 'Incorrect') : 'Unanswered';
    rows.push([qi+1, strip(unit), strip(q.topicLabel||q.topicKey||q.key||''), strip(q.q), strip(your), strip(corr), res].join(','));
  });
  rows.push('');
  rows.push(['Score', data.score, 'of', data.questions.filter(q=>q.type==='mc').length, 'Seed', strip(document.getElementById('seedInput')?.value||'')].join(','));
  const blob = new Blob([rows.join('\n')], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const aEl = document.createElement('a');
  aEl.href = url;
  aEl.download = 'quiz_results_' + sanitizeFileName(document.getElementById('seedInput')?.value || 'quiz') + '.csv';
  aEl.click();
  URL.revokeObjectURL(url);
}

