// ---------- Local-first class analyzer (no server, no privacy surface) ----------
let CLASS_RESULTS = [];
let CLASS_SUMMARY = null;   // an imported mw-class-results-v1 (summary view)

function classAggregate(list, view){
  const v=view || document.getElementById('classGroupView')?.value || 'attempts';
  const data=mwClassViewData(list,v);
  const agg=data.aggregate;
  return {...agg, view:v, attemptCount:data.attemptCount, uniqueAliasCount:data.uniqueAliasCount,
    unaliasedAttemptCount:data.unaliasedAttemptCount, selected:data.selected, model:data.model};
}

function renderClassDash(){
  const host = document.getElementById('classDash');
  const exp = document.getElementById('exportClassSummaryBtn');
  if(!host) return;
  if(!CLASS_RESULTS.length && CLASS_SUMMARY){
    const s=CLASS_SUMMARY; if(exp) exp.disabled=false;
    const cp1=document.getElementById('copyClassSummaryBtn'); if(cp1) cp1.disabled=false;
    host.innerHTML=`<div style="border:1px solid var(--line);border-radius:12px;padding:12px"><div style="font-weight:950">Class summary (imported)</div><div class="small">${escHtml(JSON.stringify({view:s.view||'unknown',attemptCount:s.attemptCount,uniqueAliasCount:s.uniqueAliasCount??s.studentCount,unaliasedAttemptCount:s.unaliasedAttemptCount,averagePercent:s.averagePercent}))}</div><div class="small" style="margin-top:6px;opacity:.7">Summary view — per-question detail needs individual result files.</div></div>`;
    return;
  }
  if(!CLASS_RESULTS.length){ host.innerHTML=''; if(exp) exp.disabled=true; const cp0=document.getElementById('copyClassSummaryBtn'); if(cp0) cp0.disabled=true; return; }
  if(exp) exp.disabled=false; const cp=document.getElementById('copyClassSummaryBtn'); if(cp) cp.disabled=false;
  const view=document.getElementById('classGroupView')?.value || 'attempts';
  const data=mwClassViewData(CLASS_RESULTS,view); const records=data.selected; const agg=data.aggregate;
  const avg=records.length?Math.round((agg.pctSum/records.length)*10)/10:0;
  const top=(obj,k=5)=>Object.entries(obj||{}).sort((a,b)=>(b[1]-a[1])||mwLexCmp(a[0],b[0])).slice(0,k);
  const li=(arr,labelFn)=>arr.length?arr.map(([k,v])=>`<div style="display:flex;gap:8px;justify-content:space-between;border-bottom:1px dashed var(--line);padding:4px 0"><span>${escHtml(labelFn?labelFn(k):k)}</span><b>${v}</b></div>`).join(''):'<div class="small">none recorded</div>';
  const topicLabel=(key)=>{ const [u,t]=String(key).split('\u0000'); return ((UNITS.find(x=>x.id===u)||{}).label||u)+' — '+t; };
  const aliasRows=data.aliasGroups.map(g=>{ const latest=g.attempts[g.attempts.length-1]; const acc=latest.metrics.accuracy==null?'—':(latest.metrics.accuracy*100).toFixed(1)+'%'; const comp=(latest.metrics.completion*100).toFixed(1)+'%'; return `<div>${escHtml(g.display)}: ${g.attemptCount} attempt${g.attemptCount===1?'':'s'} · latest ${latest.exported.valid?escHtml(latest.exported.iso):'date unavailable'} · ${latest.metrics.score}/${latest.metrics.total} · accuracy ${acc} · completion ${comp}</div>`; }).join('');
  host.innerHTML=`<div style="border:1px solid var(--line);border-radius:12px;padding:12px"><div style="font-weight:950;margin-bottom:6px">Class snapshot — ${view==='unique'?'Unique aliases':'Attempts'} view — ${view==='unique'?data.uniqueAliasCount:data.attemptCount} counted · ${data.attemptCount} attempts · ${data.uniqueAliasCount} unique aliases${data.unaliasedAttemptCount?` · Unaliased attempts: ${data.unaliasedAttemptCount}`:''} · average ${avg}%</div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px"><div><div class="small" style="font-weight:900">Missed by unit</div>${li(top(agg.missedByUnit),id=>(UNITS.find(u=>u.id===id)||{}).label||id)}</div><div><div class="small" style="font-weight:900">Missed by topic</div>${li(top(agg.missedByTopic),topicLabel)}</div><div><div class="small" style="font-weight:900">Top mistake patterns</div>${li(top(agg.mistakePatterns))}</div></div><div class="small" style="margin-top:8px">${aliasRows||'No aliased learners.'}</div></div>`;
}

function importClassResultsFn(){ document.getElementById('importClassResultsFile')?.click(); }

async function onClassFilesChosen(ev){
  const files=[...(ev.target.files||[])]; if(!files.length) return;
  let added=0,summaries=0,blueprints=0,unknown=0;
  for(const f of files){
    try{ const obj=JSON.parse(await f.text()); if(obj&&obj.format==='mw-quiz-results-v1'){CLASS_RESULTS.push(obj);added++;} else if(obj&&obj.format==='mw-class-results-v1'){CLASS_SUMMARY=obj;summaries++;} else if(obj&&obj.format==='UMWB_BLUEPRINT'){blueprints++;} else unknown++; }catch(e){unknown++;}
  }
  ev.target.value=''; renderClassDash();
  const notes=[]; if(added)notes.push(`${added} result file(s) loaded`); if(summaries)notes.push('class summary loaded'); if(blueprints)notes.push(`${blueprints} blueprint file(s) skipped`); if(unknown)notes.push(`${unknown} unrecognized file(s) skipped`); if(notes.length&&(summaries||blueprints||unknown))alert(notes.join('. ')+'.');
}

function buildClassSummaryObj(){
  if(!CLASS_RESULTS.length) return CLASS_SUMMARY || null;
  const view=document.getElementById('classGroupView')?.value || 'attempts';
  const data=mwClassViewData(CLASS_RESULTS,view); const agg=data.aggregate; const records=data.selected; const n=records.length;
  const out={format:'mw-class-results-v1',exportedAt:new Date().toISOString(),view,
    classId:(document.getElementById('classIdInput')?.value||'').trim()||(CLASS_RESULTS[0].classId??null),
    assignmentId:(document.getElementById('assignmentIdInput')?.value||'').trim()||(CLASS_RESULTS[0].assignmentId??null),
    mode:records[0]?.mode||CLASS_RESULTS[0].mode||CLASS_RESULTS[0].blueprint?.mode||null,
    // Compatibility alias: studentCount always means unique nonempty aliases, never attempts.
    studentCount:data.uniqueAliasCount, attemptCount:data.attemptCount, uniqueAliasCount:data.uniqueAliasCount, unaliasedAttemptCount:data.unaliasedAttemptCount,
    countedRecordCount:n,
    averageScore:n?Math.round((agg.scoreSum/n)*100)/100:0, averagePercent:n?Math.round((agg.pctSum/n)*10)/10:0,
    totalUnanswered:agg.unansweredSum, missedByUnit:agg.missedByUnit,
    missedByUnitTopic:mwNestedUnitTopicFromFlat(agg.missedByTopic), missedByTopic:agg.missedByTopic, missedByTopicScope:'unit-scoped-flat-compatibility-map',
    mistakePatterns:agg.mistakePatterns, unansweredByUnit:agg.unansweredByUnit,
    learnerAliases:data.aliasGroups.map(g=>{const r=g.attempts[g.attempts.length-1];return {studentAlias:g.display,attemptCount:g.attemptCount,score:r.metrics.score,total:r.metrics.total,percent:Math.round(r.metrics.quizPercent*1000)/10,accuracyOnAnswered:r.metrics.accuracy==null?null:Math.round(r.metrics.accuracy*1000)/10,completionRate:Math.round(r.metrics.completion*1000)/10,unanswered:r.metrics.unanswered};}),
    blueprint:stripBlueprintForAI(CLASS_RESULTS[0].blueprint)};
  // Backward-compatible alias; authoritative v7.2 name is learnerAliases.
  out.students=out.learnerAliases;
  return out;
}
function exportClassSummaryFn(){ const out=buildClassSummaryObj(); if(!out)return; const blob=new Blob([JSON.stringify(out,null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const aEl=document.createElement('a'); aEl.href=url; aEl.download='class_summary_'+sanitizeFileName(out.classId||out.assignmentId||'class')+'.json'; aEl.click(); URL.revokeObjectURL(url); }

async function analyzeClassWithAIFn(){
  const summary = buildClassSummaryObj();
  if(!summary){ alert('Import class results first.'); return; }
  const host = document.getElementById('classAiOut');
  const btn = document.getElementById('analyzeClassAIBtn');
  if(host){ host.style.display='block'; host.innerHTML = '<div class="small">Asking your AI (your key, directly from this browser)…</div>'; }
  if(btn) btn.disabled = true;
  try{
    const out = await aiCallTutor(summary);
    const diag = escHtml(String(out.diagnosis || '(no text returned)'));
    const safeBp = sanitizeAIBlueprint(out.blueprint);
    AI_PENDING_BP = safeBp;
    if(host){
      host.innerHTML = '<div style="font-weight:950; margin-bottom:6px">Class AI analysis</div>' +
        '<div style="white-space:pre-wrap; line-height:1.5">' + diag + '</div>' +
        (safeBp ? '<div style="margin-top:10px"><button type="button" id="aiStartDrillBtn">Load class warm-up (' +
          Object.values(safeBp.counts).reduce((a,b)=>a+b,0) + ' questions, seed ' + escHtml(safeBp.seed) + ')</button></div>' : '');
    }
  }catch(err){
    if(host) host.innerHTML = '<div class="small">AI error: ' + escHtml(String(err.message||err)) +
      ' — you can still Export class summary (JSON) and paste it into any chatbot.</div>';
  }finally{ if(btn) btn.disabled = false; }
}
async function loadClassFromUrlFn(){
  let url = '';
  try{ url = localStorage.getItem('MW_READ_URL') || ''; }catch(e){}
  url = (prompt('Read URL of the results storage (from your teacher or study group):', url) || '').trim();
  if(!url) return;
  try{ localStorage.setItem('MW_READ_URL', url); }catch(e){}
  const host = document.getElementById('classDash');
  if(host) host.innerHTML = '<div class="small">Loading results from storage…</div>';
  try{
    const res = await fetch(url, { method:'GET' });
    if(!res.ok) throw new Error('HTTP ' + res.status);
    let data = await res.json();
    if(data && Array.isArray(data.results)) data = data.results;   // tolerate {results:[...]} wrappers
    if(!Array.isArray(data)) data = [data];
    let added = 0;
    for(const obj of data){
      if(obj && obj.format === 'mw-quiz-results-v1'){ CLASS_RESULTS.push(obj); added++; }
    }
    renderClassDash();
    if(!added) alert('Storage reachable, but no mw-quiz-results-v1 records found.');
  }catch(err){
    if(host) host.innerHTML = '';
    alert('Could not load from that URL (' + String(err.message||err) +
          '). If it is a Google Apps Script, make sure the web app is deployed with read access, or import JSON files instead.');
  }
}
document.getElementById('loadClassUrlBtn')?.addEventListener('click', loadClassFromUrlFn);
// offline math engine setting
try{
  const mj = document.getElementById('mathjaxSrcInput');
  if(mj) mj.value = localStorage.getItem('MW_MATHJAX_SRC') || '';
}catch(e){}
document.getElementById('mathjaxSrcSave')?.addEventListener('click', ()=>{
  const v = (document.getElementById('mathjaxSrcInput')?.value || '').trim();
  try{
    if(v) localStorage.setItem('MW_MATHJAX_SRC', v);
    else localStorage.removeItem('MW_MATHJAX_SRC');
  }catch(e){}
  location.reload();
});
document.getElementById('personalHistoryImportBtn')?.addEventListener('click', mwPersonalHistoryImportFn);
document.getElementById('personalHistoryFile')?.addEventListener('change', mwOnPersonalHistoryFiles);
document.getElementById('personalHistoryClearBtn')?.addEventListener('click', ()=>{ PERSONAL_HISTORY_RAW=[]; PERSONAL_HISTORY_IMPORT_SKIPPED={}; MW_HISTORY_MODEL=null; mwRenderPersonalHistory(); });
document.addEventListener('click', (ev)=>{ const b=ev.target?.closest?.('.historyStartReviewBtn'); if(b) mwStartHistoryReview(Number(b.dataset.historyIndex)); });
document.getElementById('importClassResultsBtn')?.addEventListener('click', importClassResultsFn);
document.getElementById('importClassResultsFile')?.addEventListener('change', onClassFilesChosen);
document.getElementById('classGroupView')?.addEventListener('change', renderClassDash);
document.getElementById('exportClassSummaryBtn')?.addEventListener('click', exportClassSummaryFn);
document.getElementById('copyClassSummaryBtn')?.addEventListener('click', ()=>{
  const out = buildClassSummaryObj(); if(!out) return;
  const text = JSON.stringify(out, null, 1);
  if(navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(
      ()=>alert('Class summary copied — paste it to your AI tutor.'),
      ()=>prompt('Copy this JSON:', text));
  else prompt('Copy this JSON:', text);
});
document.getElementById('analyzeClassAIBtn')?.addEventListener('click', analyzeClassWithAIFn);

document.getElementById('bpLibSave')?.addEventListener('click', bpLibSaveFn);
document.getElementById('bpLibLoad')?.addEventListener('click', bpLibLoadFn);
document.getElementById('bpLibDelete')?.addEventListener('click', bpLibDeleteFn);
bpLibRefresh();
try{ const m = localStorage.getItem('MW_USER_MODE'); if(m==='student') setUserMode('student'); }catch(e){}

function updateGenBtnLabel(){
  const btn = document.getElementById('genBtn');
  if(btn) btn.textContent = document.getElementById('toggleQuizMode')?.checked ? 'Generate quiz' : 'Generate worksheet';
}
document.getElementById('toggleQuizMode')?.addEventListener('change', updateGenBtnLabel);
updateGenBtnLabel();
document.getElementById('genBtn').addEventListener('click', ()=>{ renderSheet(); updateGenBtnLabel(); const out=document.getElementById('output'); if(out) out.scrollIntoView({behavior:'smooth', block:'start'}); });
document.getElementById('printBtn').addEventListener('click', () => window.print());
document.getElementById('latexBtn').addEventListener('click', exportToLaTeX);

// Blueprint export/import
const _bpExportBtn = document.getElementById('exportBlueprintBtn');
if(_bpExportBtn) _bpExportBtn.addEventListener('click', exportBlueprint);

const _bpImportBtn = document.getElementById('importBlueprintBtn');
const _bpImportFile = document.getElementById('importBlueprintFile');
if(_bpImportBtn && _bpImportFile){
  _bpImportBtn.addEventListener('click', ()=>_bpImportFile.click());
  _bpImportFile.addEventListener('change', (ev)=>{
    const f = ev && ev.target && ev.target.files ? ev.target.files[0] : null;
    if(f) importBlueprintFromFile(f);
  });
}


