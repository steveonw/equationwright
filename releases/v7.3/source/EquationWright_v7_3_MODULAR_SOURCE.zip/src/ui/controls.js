// Hooks
// =====================
function updateTopicUI(unitId){
  const host = document.getElementById('topicSummary_' + unitId);
  if(!host) return;

  const topics = ensureUnitTopics(unitId);
  const sel = ensureTopicSet(unitId);

  host.innerHTML = '';
  if(sel.__none){
    const pill = document.createElement('span');
    pill.className = 'topicPill off';
    pill.textContent = 'None (will fall back to all)';
    host.appendChild(pill);
    return;
  }

  if(!sel.size){
    const pill = document.createElement('span');
    pill.className = 'topicPill on';
    pill.textContent = 'All topics';
    host.appendChild(pill);
    return;
  }

  for(const t of topics){
    const pill = document.createElement('span');
    pill.className = 'topicPill ' + (sel.has(t.id) ? 'on' : 'off');
    pill.textContent = t.label;
    host.appendChild(pill);
  }
}

let lastFocusEl = null;

function openTopicModal(unitId){
  document.body.classList.add('modal-open');
  lastFocusEl = document.activeElement;

  activeTopicUnit = unitId;
  const unit = UNITS.find(u=>u.id===unitId);
  document.getElementById('topicModalTitle').textContent = (unit ? unit.label : 'Topics');
  document.getElementById('topicHintText').textContent = 'Uncheck topics you don\'t want included when generating.';
  renderTopicModal();

  const backdrop = document.getElementById('topicModalBackdrop');
  const modal = document.getElementById('topicModal');

  // Visually show modal
  backdrop.classList.add('show');
  modal.classList.add('show');
  document.body.classList.add('modal-open');

  // Hide background from assistive tech + block focus outside (best-effort)
  const wrap = document.querySelector('.wrap');
  if(wrap){
    wrap.setAttribute('aria-hidden','true');
    try{ wrap.inert = true; }catch(e){}
  }
  if(backdrop) backdrop.setAttribute('aria-hidden','false');

  // Focus the close button (or first focusable)
  const closeBtn = document.getElementById('topicModalCloseBtn');
  const first = closeBtn || modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
  if(first && first.focus) first.focus({ preventScroll:true });
  else if(modal && modal.focus) modal.focus({ preventScroll:true });
}
function closeTopicModal(){
  document.body.classList.remove('modal-open');
  const backdrop = document.getElementById('topicModalBackdrop');
  const modal = document.getElementById('topicModal');

  if(backdrop) backdrop.classList.remove('show');
  if(modal) modal.classList.remove('show');
  document.body.classList.remove('modal-open');

  const wrap = document.querySelector('.wrap');
  if(wrap){
    wrap.removeAttribute('aria-hidden');
    try{ wrap.inert = false; }catch(e){}
  }
  if(backdrop) backdrop.setAttribute('aria-hidden','true');

  activeTopicUnit = null;

  // Restore focus to whatever opened the modal
  if(lastFocusEl && lastFocusEl.focus){
    try{ lastFocusEl.focus({ preventScroll:true }); }catch(e){ lastFocusEl.focus(); }
  }
  lastFocusEl = null;
}
function renderTopicModal(){
  if(!activeTopicUnit) return;
  const topics = ensureUnitTopics(activeTopicUnit);
  const sel = ensureTopicSet(activeTopicUnit);
  const list = document.getElementById('topicList');
  list.innerHTML = '';

  const impliedAll = (!sel.size && !sel.__none);

  topics.forEach(t=>{
    const row = document.createElement('label');
    row.className = 'topicRow';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = impliedAll ? true : (!!sel.size ? sel.has(t.id) : false);

    cb.addEventListener('change', ()=>{
      if(!sel.size && !sel.__none){
        // Convert implied-all into explicit set on first edit
        topics.forEach(x=>sel.add(x.id));
      }
      if(sel.__none) delete sel.__none;

      if(cb.checked) sel.add(t.id);
      else sel.delete(t.id);

      updateTopicUI(activeTopicUnit);
      saveState();
    });

    const txt = document.createElement('div');
    txt.textContent = t.label;

    row.appendChild(cb);
    row.appendChild(txt);
    list.appendChild(row);
  });
}

// Topic modal wiring
window.addEventListener('DOMContentLoaded', ()=>{
  const closeBtn = document.getElementById('topicModalCloseBtn');
  const doneBtn = document.getElementById('topicDoneBtn');
  const backdrop = document.getElementById('topicModalBackdrop');
  const allBtn = document.getElementById('topicSelectAllBtn');
  const clearBtn = document.getElementById('topicClearBtn');

  if(closeBtn) closeBtn.addEventListener('click', closeTopicModal);
  if(doneBtn) doneBtn.addEventListener('click', closeTopicModal);
  if(backdrop) backdrop.addEventListener('click', closeTopicModal);

  if(allBtn) allBtn.addEventListener('click', ()=>{
    if(!activeTopicUnit) return;
    const sel = ensureTopicSet(activeTopicUnit);
    sel.clear();
    delete sel.__none; // empty => all
    updateTopicUI(activeTopicUnit);
    saveState();
    renderTopicModal();
  });

  if(clearBtn) clearBtn.addEventListener('click', ()=>{
    if(!activeTopicUnit) return;
    const sel = ensureTopicSet(activeTopicUnit);
    sel.clear();
    sel.__none = true;
    updateTopicUI(activeTopicUnit);
    saveState();
    renderTopicModal();
  });
});

document.addEventListener('keydown', (e)=>{
  const modal = document.getElementById('topicModal');
  const isOpen = !!(modal && modal.classList.contains('show'));
  if(!isOpen) return;

  if(e.key === 'Escape'){
    e.preventDefault();
    closeTopicModal();
    return;
  }

  // Trap focus inside the modal while open (Tab / Shift+Tab)
  if(e.key === 'Tab'){
    const focusables = Array.from(modal.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])'))
      .filter(el => !el.disabled && el.getAttribute('aria-hidden') !== 'true' && el.offsetParent !== null);

    if(focusables.length === 0){
      e.preventDefault();
      modal.focus();
      return;
    }

    const first = focusables[0];
    const last = focusables[focusables.length - 1];
    const active = document.activeElement;

    if(e.shiftKey){
      if(active === first || active === modal){
        e.preventDefault();
        last.focus();
      }
    }else{
      if(active === last){
        e.preventDefault();
        first.focus();
      }
    }
  }
});

// =======================================================

// SELF-TEST (generator sanity checks)
// =======================================================
function selfTest_getUnitIds(scope){
  if(scope === 'all') return UNITS.map(u => u.id);
  // default: current mode's visible units
  return visibleUnits().map(u => u.id);
}

function selfTest_scanLatexHygiene(text, where){
  const issues = [];
  const s = String(text ?? '');
  if(!s) return issues;

  // Control characters (often caused by JS escapes like \f in "\frac")
  // allow \n and \t, but flag other non-printables
  if(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/.test(s)){
    issues.push(`${where} contains control characters (likely unescaped TeX in JS strings; use \\\\frac not \\frac)`);
  }

  // High-signal "backslash got eaten" patterns
  // Detect missing leading backslash on TeX commands (avoid false positives from "\\frac" containing "rac{")
  if(/(^|[^A-Za-z\\])frac\{/.test(s))  issues.push(`${where} looks like "\\\\frac" is missing its backslash (found "frac{")`);
  if(/(^|[^A-Za-z\\])dfrac\{/.test(s)) issues.push(`${where} looks like "\\\\dfrac" is missing its backslash (found "dfrac{")`);
  if(/(^|[^A-Za-z\\])cdot\b/.test(s))  issues.push(`${where} looks like "\\\\cdot" is missing its backslash (found "cdot")`);
  if(/(^|[^A-Za-z\\])sqrt\{/.test(s))  issues.push(`${where} looks like "\\\\sqrt" is missing its backslash (found "sqrt{")`);
  if(/(^|[^\\])infty\b/.test(s)) issues.push(`${where} looks like "\\\\infty" is missing its backslash (found "infty")`);


  {
    const sNoHtml = s.replace(/<svg[\s\S]*?<\/svg>/gi,'').replace(/<\/?(br|b|i|em|strong|sub|sup|div|span)\b[^>]*>/gi,'');
    if(/<[A-Za-z]/.test(sNoHtml)) issues.push(`${where} contains "<" followed by a letter (browser will parse it as an HTML tag; add a space: "x < h")`);
  }
  if(/(^|[^\\A-Za-z])int\b/.test(s))  issues.push(`${where} looks like \\int lost its backslash (found "int")`);
  if(/(^|[^\\])sum(?=\s*[_^\\\\])/.test(s)) issues.push(`${where} looks like \\sum lost its backslash (found "sum")`);
  if(/(^|[^\\A-Za-z])lim\b/.test(s))  issues.push(`${where} looks like \\lim lost its backslash (found "lim")`);

  return issues;
}


function selfTest_validateProblem(p, unitId){
  const issues = [];
  if(!p || typeof p !== 'object'){ issues.push('Return is not an object'); return issues; }

  if(typeof p.q !== 'string' || !p.q.trim()) issues.push('Missing/empty q');
  if(typeof p.a !== 'string' || !p.a.trim()) issues.push('Missing/empty a');

  if(p.steps != null && !Array.isArray(p.steps)) issues.push('steps is not an array');
  if(Array.isArray(p.steps) && p.steps.some(x => typeof x !== 'string')) issues.push('steps contains non-strings');

  if(!Array.isArray(p.vec)) issues.push('Missing vec (expected array)');
  else{
    const expected = unitIndex(unitId);
    if(typeof p.vec[0] !== 'number') issues.push('vec[0] is not a number');
    else if(p.vec[0] !== expected) issues.push(`vec[0] mismatch (got ${p.vec[0]}, expected ${expected})`);
    if(p.vec.some(v => typeof v !== 'number' || !Number.isFinite(v))) issues.push('vec contains non-numbers/NaN/Infinity');
  }

  const badSnippets = ['undefined','NaN','Infinity'];

  const scanField = (str, where) => {
    const raw = String(str ?? '');
    const s = fixTexEscapes(raw);

    // Hard error snippets (post-fix)
    for(const b of badSnippets){
      if(s.includes(b)) issues.push(`${where} contains "${b}"`);
    }

    // TeX hygiene scan:
    // - If raw had issues but fixTexEscapes removed them, record as AUTO-FIX (won't count as failure)
    const pre = selfTest_scanLatexHygiene(raw, where);
    const post = selfTest_scanLatexHygiene(s, where);
    if(pre.length && !post.length){
      issues.push(`AUTO-FIX: ${where} TeX escape leak(s) repaired`);
    }else{
      issues.push(...post);
    }
  };

  scanField(p.q, 'q');
  scanField(p.a, 'a');

  if(Array.isArray(p.steps)){
    p.steps.forEach((step, i) => scanField(step, `steps[${i}]`));
  }

  // Optional semantic answer checks. These are exact for registered families.
  const contract = mwSemanticContractOf(p);
  if(contract){
    try{
      const correct = contract.validator(contract.questionModel, contract.spec.model);
      if(correct !== true) issues.push('semantic answer model does not answer its question model');

      if(contract.spec.type === 'truth-sequence'){
        const rendered = mwRenderTruthSequence(contract.spec.model.values);
        if(normalizeMCAnswer(rendered) !== normalizeMCAnswer(p.a)){
          issues.push('displayed answer does not match truth-sequence answer model');
        }

        const rebuilt = mwBuildTruthSequenceAnswerSpec(
          contract.spec.model.variables,
          contract.spec.model.values
        );
        if(rebuilt.key !== contract.spec.key) issues.push('semantic answer key mismatch');
        if(rebuilt.choiceFamily !== contract.spec.choiceFamily) issues.push('choiceFamily mismatch');
      }
      if(contract.spec.type === 'de-explicit-solution'){
        const rendered = `\\(${mwRenderDESolution(contract.questionModel, contract.spec.model)}\\)`;
        if(normalizeMCAnswer(rendered) !== normalizeMCAnswer(p.a)){
          issues.push('displayed answer does not match DE answer model');
        }
        const rebuilt = mwBuildDEAnswerSpec(contract.questionModel, contract.spec.model);
        if(rebuilt.key !== contract.spec.key) issues.push('DE semantic answer key mismatch');
        if(rebuilt.choiceFamily !== contract.spec.choiceFamily) issues.push('DE choiceFamily mismatch');
      }
    }catch(e){
      issues.push(`semantic validation threw: ${e && e.message ? e.message : String(e)}`);
    }
  }

  return issues;
}

function selfTest_sleep0(){
  return new Promise(r => setTimeout(r, 0));
}

function selfTestReplayPayload(rec){
  if(!rec) return null;
  return {
    format: 'equationwright-selftest-replay-v1',
    appVersion: MW_APP_VERSION,
    unitId: rec.unitId,
    unitLabel: rec.unitLabel,
    genIndex: rec.genIndex,
    key: rec.key,
    runSeed: rec.runSeed >>> 0,
    issues: Array.isArray(rec.issues) ? rec.issues.slice() : []
  };
}

function selfTestReplayFailure(index=0){
  const rec = (window.MW_SELFTEST_FAILURES || [])[index];
  const outEl = document.getElementById('selfTestOut');
  if(!rec){
    if(outEl) outEl.textContent += '\nNo stored self-test failure to replay.\n';
    return null;
  }
  const genFn = (Gens[rec.unitId] || [])[rec.genIndex];
  if(typeof genFn !== 'function'){
    if(outEl) outEl.textContent += `\nREPLAY FAILED: generator ${rec.unitId}#${rec.genIndex} no longer exists.\n`;
    return null;
  }
  let p = null;
  let issues = [];
  try{
    p = genFn(xorshift32(rec.runSeed >>> 0));
    issues = selfTest_validateProblem(p, rec.unitId);
  }catch(error){
    issues = [`THREW: ${error && error.message ? error.message : String(error)}`];
  }
  const result = {
    ...selfTestReplayPayload(rec),
    replayKey: p && p.key ? p.key : '(no key)',
    replayIssues: issues
  };
  if(outEl){
    outEl.textContent += `\nREPLAY ${rec.unitId} | gen#${rec.genIndex} | runSeed=${rec.runSeed >>> 0}\n`;
    outEl.textContent += `Key: ${result.replayKey}\n`;
    if(issues.length) issues.forEach(x => { outEl.textContent += `  • ${x}\n`; });
    else outEl.textContent += '  No issues reproduced.\n';
  }
  return result;
}

function selfTestCopyFirstFailure(){
  const rec = (window.MW_SELFTEST_FAILURES || [])[0];
  if(!rec) return null;
  const payload = selfTestReplayPayload(rec);
  const text = JSON.stringify(payload, null, 2);
  const done = () => {
    const status = document.getElementById('selfTestStatus');
    if(status) status.textContent = 'Replay copied';
  };
  if(navigator.clipboard?.writeText){
    navigator.clipboard.writeText(text).then(done, () => prompt('Copy self-test replay JSON:', text));
  }else{
    prompt('Copy self-test replay JSON:', text);
  }
  return payload;
}

async function runSelfTest(){
  const btn = document.getElementById('selfTestBtn');
  const outEl = document.getElementById('selfTestOut');
  const prog = document.getElementById('selfTestProg');
  const status = document.getElementById('selfTestStatus');

  const scope = (document.getElementById('stScope') || {}).value || 'visible';
  const samples = Math.max(1, Math.min(200, parseInt((document.getElementById('stSamples') || {}).value || '25', 10) || 25));
  const maxExamples = Math.max(1, Math.min(50, parseInt((document.getElementById('stMaxExamples') || {}).value || '10', 10) || 10));
  const capacitySamples = Math.max(0, Math.min(200, parseInt((document.getElementById('stCapacitySamples') || {}).value || '0', 10) || 0));

  const replayBtn = document.getElementById('selfTestReplayBtn');
  const copyBtn = document.getElementById('selfTestCopyBtn');
  if(replayBtn) replayBtn.disabled = true;
  if(copyBtn) copyBtn.disabled = true;
  window.MW_SELFTEST_FAILURES = [];

  const seedStr = (document.getElementById('seedInput') || {}).value || '';
  const baseSeed = hashStringToUint32('SELFTEST|' + seedStr);

  const unitIds = selfTest_getUnitIds(scope);

  // Precompute run count for progress bar
  let totalRuns = 0;
  for(const uid of unitIds){
    const gens = Gens[uid] || [];
    totalRuns += gens.length * samples;
  }
  prog.max = Math.max(1, totalRuns);
  prog.value = 0;

  let runs = 0;
  let failures = 0;
  let autoFixes = 0;
  let throws = 0;
  let emptyUnits = 0;
  const perUnit = [];
  const examples = [];
  const fixByKey = Object.create(null);

  const startedAt = Date.now();
  const log = (line) => { outEl.textContent += line + '\n'; };

  outEl.textContent = '';
  status.textContent = 'Running…';
  btn.disabled = true;

  log(`SELF-TEST`);
  log(`Scope: ${scope === 'all' ? 'all units' : 'current mode units'}`);
  log(`Samples per generator: ${samples}`);
  log(`Answer-capacity scan: ${capacitySamples ? capacitySamples + ' samples / generator' : 'off'}`);
  log(`Seed: ${seedStr || '(empty)'}`);
  log(`Started: ${new Date().toLocaleString()}`);
  log('');

  for(const uid of unitIds){
    const gens = Gens[uid] || [];
    if(gens.length === 0){
      emptyUnits += 1;
      perUnit.push({ unitId: uid, label: unitLabel(uid), gens: 0, runs: 0, fails: 0, throws: 0 });
      continue;
    }

    let unitFails = 0;
    let unitThrows = 0;

    for(let gi=0; gi<gens.length; gi++){
      const genFn = gens[gi];
      for(let i=0; i<samples; i++){
        const runSeed = (baseSeed ^ hashStringToUint32(uid + '|' + gi + '|' + i)) >>> 0;
        const rng = xorshift32(runSeed);

        let p = null;
        let issues = null;

        try{
          p = genFn(rng);
          issues = selfTest_validateProblem(p, uid);
        }catch(err){
          issues = [`THREW: ${err && err.message ? err.message : String(err)}`];
          throws += 1;
          unitThrows += 1;
        }

                if(issues && issues.length){
          const realIssues = issues.filter(x => !String(x).startsWith('AUTO-FIX:'));
          const fixIssues = issues.filter(x => String(x).startsWith('AUTO-FIX:'));
          autoFixes += fixIssues.length;
          if(p && p.key){ fixByKey[p.key] = (fixByKey[p.key]||0) + fixIssues.length; }
          if(realIssues.length){
            failures += 1;
            unitFails += 1;
            if(examples.length < maxExamples){
              examples.push({
                unitId: uid,
                unitLabel: unitLabel(uid),
                genIndex: gi,
                key: (p && p.key) ? p.key : '(no key)',
                runSeed: runSeed >>> 0,
                issues: realIssues.slice(0, 4),
                q: (p && p.q) ? String(p.q).slice(0, 220) : ''
              });
            }
          }
        }

        runs += 1;
        if((runs % 200) === 0){
          prog.value = runs;
          status.textContent = `${Math.min(100, Math.floor(100 * runs / prog.max))}%`;
          await selfTest_sleep0();
        }
      }
    }

    perUnit.push({ unitId: uid, label: unitLabel(uid), gens: gens.length, runs: gens.length * samples, fails: unitFails, throws: unitThrows });
  }

  prog.value = runs;

  // Specialized suites are part of every self-test run, not hidden one-off code.
  status.textContent = 'Specialized suites…';
  const specializedSuites = [];
  for(const [name, fn] of [
    ['Statistics', mwRunStatsSmokeTests],
    ['Logic', mwRunLogicSpikeSelfTests],
    ['Differential equations', mwRunDESpikeSelfTests]
  ]){
    try{
      const report = fn();
      specializedSuites.push({ name, ...report });
    }catch(error){
      specializedSuites.push({
        name,
        passed:0,
        failed:1,
        results:[{name:'suite threw', pass:false, detail:error && error.message ? error.message : String(error)}]
      });
    }
  }

  // Low answer capacity is informational. Generator exceptions discovered
  // during the diagnostic are real Self-test issues and are reported separately.
  const capacityFlags = [];
  const capacityErrors = [];
  if(capacitySamples > 0){
    status.textContent = 'Capacity scan…';
    for(const uid of unitIds){
      const gens = Gens[uid] || [];
      for(let gi=0; gi<gens.length; gi++){
        const cap = mwAnswerCapacity(gens[gi], uid, capacitySamples);
        if(cap.distinct < 4 || cap.errors.length){
          let key = '(unknown)';
          try{
            const probe = gens[gi](xorshift32(fnv1a(`capacity-key|${uid}|${gi}`)));
            if(probe && probe.key) key = probe.key;
          }catch(e){}
          const rec = { unitId:uid, unitLabel:unitLabel(uid), genIndex:gi, key, ...cap };
          if(cap.errors.length) capacityErrors.push(rec);
          else if(cap.distinct < 4) capacityFlags.push(rec);
        }
      }
      await selfTest_sleep0();
    }
  }

  const capacityErrorCount = capacityErrors.reduce((n, cap) => n + (cap.errors || []).length, 0);
  window.MW_SELFTEST_FAILURES = examples.map(ex => ({...ex}));
  if(replayBtn) replayBtn.disabled = examples.length === 0;
  if(copyBtn) copyBtn.disabled = examples.length === 0;
  window.MW_LAST_CAPACITY_SCAN = [...capacityErrors, ...capacityFlags];

  const suiteFailures = specializedSuites.reduce((n, r) => n + (r.failed || 0), 0);
  const ms = Date.now() - startedAt;
  status.textContent = (failures || suiteFailures || capacityErrorCount) ? 'Done — issues found' : 'Done';

  log('');
  log(`DONE`);
  log(`Total runs: ${runs}/${prog.max}`);
  log(`Failures (including throws): ${failures}`);
  log(`Throws: ${throws}`);
  log(`Auto-fixes: ${autoFixes}`);
  if(autoFixes){
    const top = Object.entries(fixByKey).sort((a,b)=>b[1]-a[1]).slice(0,10);
    if(top.length){
      log('Top auto-fix sources (by generator key):');
      for(const [k,c] of top) log(`- ${k}: ${c}`);
      log('');
    }
  }
  log(`Units with 0 generators: ${emptyUnits}`);
  log(`Elapsed: ${ms} ms`);
  log('');

  // Per-unit summary (only units with issues)
  const badUnits = perUnit.filter(u => u.fails > 0 || u.throws > 0);
  if(badUnits.length){
    log('Units with issues:');
    for(const u of badUnits){
      log(`- ${u.label} (${u.unitId}): gens=${u.gens}, fails=${u.fails}, throws=${u.throws}`);
    }
    log('');
  }else{
    log('No per-unit issues detected.');
    log('');
  }

  log('Specialized suites:');
  for(const suite of specializedSuites){
    log(`- ${suite.name}: ${suite.passed || 0} passed, ${suite.failed || 0} failed`);
    if(suite.failed){
      for(const result of (suite.results || []).filter(r => !r.pass).slice(0, 5)){
        log(`    • ${result.name}${result.detail ? ': ' + result.detail : ''}`);
      }
    }
  }
  log('');

  if(capacitySamples > 0){
    if(capacityErrors.length){
      log(`Answer-capacity ERRORS: ${capacityErrorCount} execution error${capacityErrorCount===1?'':'s'} across ${capacityErrors.length} generator famil${capacityErrors.length===1?'y':'ies'}.`);
      for(const cap of capacityErrors.slice(0, 30)){
        log(`- ${cap.unitLabel} | gen#${cap.genIndex} | key=${cap.key} | errors=${cap.errors.length}`);
        for(const err of cap.errors.slice(0, 3)) log(`    • ${err}`);
      }
      if(capacityErrors.length > 30) log(`  … ${capacityErrors.length - 30} more error families; full list is in window.MW_LAST_CAPACITY_SCAN`);
      log('');
    }
    log(`Answer-capacity informational: ${capacityFlags.length} generator families below 4 distinct answers.`);
    for(const cap of capacityFlags.slice(0, 30)){
      log(`- ${cap.unitLabel} | gen#${cap.genIndex} | key=${cap.key} | distinct=${cap.distinct}/${cap.samples}`);
    }
    if(capacityFlags.length > 30) log(`  … ${capacityFlags.length - 30} more; full list is in window.MW_LAST_CAPACITY_SCAN`);
    log('');
  }

  if(examples.length){
    log('Example failures:');
    for(const ex of examples){
      log(`- ${ex.unitLabel} | unit=${ex.unitId} | gen#${ex.genIndex} | key=${ex.key} | runSeed=${ex.runSeed}`);
      for(const iss of ex.issues) log(`    • ${iss}`);
      if(ex.q) log(`    q: ${ex.q}${ex.q.length>=220?'…':''}`);
    }
    log('Use “Replay first failure” to rerun the exact stored seed, or “Copy failure replay” to copy JSON.');
  }

  window.MW_LAST_SELFTEST_REPORT = {
    appVersion: MW_APP_VERSION,
    scope,
    samples,
    structural: { runs, failures, throws, autoFixes, emptyUnits, perUnit },
    specializedSuites,
    capacitySamples,
    capacityErrorCount,
    capacityErrors,
    capacityFlags,
    examples: window.MW_SELFTEST_FAILURES.map(selfTestReplayPayload)
  };

  btn.disabled = false;
}


// ===================================================================

// v5.1 features: quiz actions, presets, teacher/student mode, CSV,
// blueprint library
// ===================================================================

function unitCountInputs(){
  return [...document.querySelectorAll('.controls input[type=number]')]
    .filter(el => !el.closest('#selfTest'));
}

function mwRandomSeed(){
  const words = ['Apex','Nova','Quartz','Delta','Orbit','Prism','Vector','Echo','Zenith','Flux'];
  return words[Math.floor(Math.random()*words.length)] + '-' + Math.floor(Math.random()*9000+1000);
}

// =====================================================================

// ---------- Presets ----------
function mwShuffleItemsBySeed(items, seedStr){
  const src = Array.from(items || []);
  if(src.length < 2) return src;
  const order = shuffleOrder(xorshift32(fnv1a(seedStr)), src.length);
  return order.map(i => src[i]);
}

function distributeTotal(total){
  const inputs = countInputs.slice();
  const vis = visibleUnits();
  if(!inputs.length || !vis.length) return;
  const byUnit = new Map(inputs.map(inp => [inp.dataset.unit, inp]));
  const mode = document.getElementById('modeSelect')?.value || '';

  // Presets are authoritative: start from zero instead of inheriting prior counts.
  for(const inp of inputs) inp.value = 0;

  if(mode === 'MIX'){
    // Seeded course round-robin: a five-question MIX quiz samples five course
    // families when available, while remaining perfectly reproducible.
    const groups = [];
    const byCourse = new Map();
    for(const u of vis){
      if(!byCourse.has(u.course)){
        const rec = { course:u.course, units:[] };
        byCourse.set(u.course, rec);
        groups.push(rec);
      }
      byCourse.get(u.course).units.push(u);
    }
    const seed = mwCurrentWorksheetSeed();
    const orderedGroups = mwShuffleItemsBySeed(groups, `${seed}|mix-preset|courses|${total}`)
      .map(group => ({
        ...group,
        units: mwShuffleItemsBySeed(group.units, `${seed}|mix-preset|${group.course}|units|${total}`),
        cursor:0
      }));

    for(let i=0; i<Math.max(0, total); i++){
      const group = orderedGroups[i % orderedGroups.length];
      const unit = group.units[group.cursor % group.units.length];
      group.cursor += 1;
      const inp = byUnit.get(unit.id);
      if(inp) inp.value = (parseInt(inp.value || '0', 10) || 0) + 1;
    }
  }else{
    // Existing single-course behavior: spread as evenly as possible in visible order.
    const n = Math.min(inputs.length, vis.length);
    if(n > 0){
      const per = Math.floor(total / n);
      let extra = total - per * n;
      for(let i=0; i<n; i++){
        const inp = byUnit.get(vis[i].id) || inputs[i];
        if(inp) inp.value = per + (extra > 0 ? 1 : 0);
        if(extra > 0) extra--;
      }
    }
  }
  saveState();
}
function setToggle(id, on){
  const el = document.getElementById(id);
  if(el && el.checked !== on){ el.checked = on; el.dispatchEvent(new Event('change',{bubbles:true})); }
}
function applyPreset(name){
  if(name==='quick'){        setToggle('toggleQuizMode', true);  setToggle('toggleAnswers', false); setToggle('toggleSolutions', false); distributeTotal(5); }
  else if(name==='homework'){ setToggle('toggleQuizMode', false); setToggle('toggleAnswers', true);  setToggle('toggleSolutions', true);  distributeTotal(15); }
  else if(name==='review'){   setToggle('toggleQuizMode', false); setToggle('toggleAnswers', true);  setToggle('toggleSolutions', false); distributeTotal(20); }
  else if(name==='teacher'){  setToggle('toggleQuizMode', false); setToggle('toggleAnswers', true);  setToggle('toggleSolutions', true); }
  else if(name==='student'){  setToggle('toggleQuizMode', false); setToggle('toggleAnswers', false); setToggle('toggleSolutions', false); }
  renderSheet();
  document.getElementById('output')?.scrollIntoView({behavior:'smooth'});
}

// ---------- Teacher / Student mode ----------
function setUserMode(mode){
  if(mode === 'teacher'){
    let lockHash = null;
    try{ lockHash = sessionStorage.getItem('MW_LOCK'); }catch(e){}
    if(lockHash){
      const pin = prompt('Teacher mode is locked. Enter the PIN:') || '';
      if(String(fnv1a('MWLOCK|' + pin.trim())) !== lockHash){
        alert('Wrong PIN — staying in Student mode.');
        return;
      }
      try{ sessionStorage.removeItem('MW_LOCK'); }catch(e){}
    }
  }
  const student = (mode === 'student');
  document.body.classList.toggle('studentMode', student);
  document.getElementById('userModeTeacher')?.classList.toggle('active', !student);
  document.getElementById('userModeStudent')?.classList.toggle('active', student);
  if(student){
    setToggle('toggleQuizMode', true);
    setToggle('toggleAnswers', false);
    setToggle('toggleSolutions', false);
  }
  try{ localStorage.setItem('MW_USER_MODE', mode); }catch(e){}
}

// ---------- Blueprint library (localStorage) ----------
function bpLibRead(){ try{ return JSON.parse(localStorage.getItem('MW_BP_LIB')||'{}'); }catch(e){ return {}; } }
function bpLibWrite(lib){ try{ localStorage.setItem('MW_BP_LIB', JSON.stringify(lib)); }catch(e){ alert('Could not save (localStorage unavailable in this browser context).'); } }
function bpLibRefresh(){
  const sel = document.getElementById('bpLibSel'); if(!sel) return;
  const lib = bpLibRead();
  const names = Object.keys(lib).sort();
  sel.innerHTML = names.length
    ? names.map(n=>`<option value="${escHtml(n)}">${escHtml(n)}</option>`).join('')
    : '<option value="">— none saved —</option>';
}
function bpLibSaveFn(){
  if(!window.LAST_BLUEPRINT){ alert('Generate a worksheet or quiz first, then save it as a blueprint.'); return; }
  const slim=mwBuildSlimBlueprint(window.LAST_BLUEPRINT,{includeDelivery:true}); if(!slim){alert('No positive-count assessment is available to save.');return;}
  const name=prompt('Name this blueprint:',(slim.curriculum.courseId||'')+' '+(slim.assessment.seed||'')); if(!name)return;
  const lib=bpLibRead(); lib[name.trim()]=slim; bpLibWrite(lib); bpLibRefresh(); const sel=document.getElementById('bpLibSel');if(sel)sel.value=name.trim();
}
function bpLibLoadFn(){
  const sel = document.getElementById('bpLibSel');
  const lib = bpLibRead();
  const bp = sel && lib[sel.value];
  if(!bp){ alert('Select a saved blueprint first.'); return; }
  applyBlueprint(bp);
  document.getElementById('output')?.scrollIntoView({behavior:'smooth'});
}
function bpLibDeleteFn(){
  const sel = document.getElementById('bpLibSel');
  if(!sel || !sel.value) return;
  if(!confirm(`Delete blueprint "${sel.value}"?`)) return;
  const lib = bpLibRead(); delete lib[sel.value];
  bpLibWrite(lib); bpLibRefresh();
}

// ---------- Wire up ----------
document.getElementById('userModeTeacher')?.addEventListener('click', ()=> setUserMode('teacher'));
document.getElementById('userModeStudent')?.addEventListener('click', ()=> setUserMode('student'));
document.querySelectorAll('.presetRow [data-preset]').forEach(btn =>
  btn.addEventListener('click', ()=> applyPreset(btn.dataset.preset)));
document.addEventListener('click', (ev)=>{
  const id = ev.target?.id;
  if(id==='qaReviewMissed') qaReviewMissedFn();
  else if(id==='qaRetake') qaRetakeFn();
  else if(id==='qaNewLike') qaNewLikeFn();
  else if(id==='qaTrySimilar') qaTrySimilarFn();
  else if(id==='qaExportCSV') qaExportCSVFn();
  else if(id==='qaExportJSON') qaExportJSONFn();
  else if(id==='qaSubmitResults') qaSubmitResultsFn();
  else if(id==='qaAskTutor') qaAskTutorFn();
  else if(id==='aiStartDrillBtn') aiStartDrillFn();
  else if(id==='localSmartReviewStartBtn') localSmartReviewStartFn();
  else if(id==='aiCancelTutor') aiCancelTutorFn();
});

