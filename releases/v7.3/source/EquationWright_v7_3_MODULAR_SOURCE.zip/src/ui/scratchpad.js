
/* ===== EquationWright v7.1: Floating Scratch Pad v1.0 ===== */
(()=>{
'use strict';
const $=id=>document.getElementById(id);
const panel=$('scratchPanel'),launch=$('scratchLaunch'),canvas=$('scratchCanvas'),wrap=$('spWrap'),ctx=canvas.getContext('2d');
const workspaceSelect=$('spWorkspace'),paperSelect=$('spPaper'),sizeStatus=$('spSizeStatus');
let tool='pen',ink='#111827',drawing=false,start=null,last=null,lineBase=null,history=[],redo=[],drag=null,minimized=false;
let pages=[null],pageIndex=0;
const MAX_PAGES=5;
function clamp(n,min,max){return Math.max(min,Math.min(max,n))}
function currentSnapshot(){try{return canvas.toDataURL('image/png')}catch(_){return null}}
function savePage(){pages[pageIndex]=currentSnapshot()}
function updatePageUI(){
  $('spPageLabel').textContent='Page '+(pageIndex+1)+'/'+pages.length;
  $('spPrev').disabled=pageIndex===0;$('spNext').disabled=pageIndex===pages.length-1;
  $('spNew').disabled=pages.length>=MAX_PAGES;$('spDelete').disabled=pages.length===1;
}
function applyWorkspaceSize(mode=workspaceSelect.value){
  if(minimized)return;
  const vw=Math.max(320,window.innerWidth),vh=Math.max(480,window.innerHeight),mobile=vw<=600;
  const maxW=Math.max(300,vw-(mobile?16:36)),maxCanvasH=Math.max(240,Math.floor(vh*(mobile?.58:.66)));
  let targetW,targetH,label;
  if(mode==='small'){targetW=420;targetH=300;label='Small workspace'}
  else if(mode==='medium'){targetW=560;targetH=430;label='Medium workspace'}
  else if(mode==='large'){targetW=760;targetH=600;label='Large workspace'}
  else{targetW=mobile?vw-16:Math.round(vw*.46);targetH=Math.round(vh*(mobile?.46:.48));label='Auto workspace'}
  targetW=clamp(targetW,320,Math.min(760,maxW));targetH=clamp(targetH,240,Math.min(600,maxCanvasH));
  if(mobile){panel.style.left='8px';panel.style.right='8px';panel.style.width='auto';panel.style.top='auto';panel.style.bottom='68px'}
  else{panel.style.width=targetW+'px';panel.style.left='auto';panel.style.right='18px';panel.style.top='auto';panel.style.bottom='72px'}
  wrap.style.height=targetH+'px';sizeStatus.textContent=label+' ('+Math.round(targetW)+'×'+Math.round(targetH)+')';requestAnimationFrame(()=>fit(true));
}
function fit(preserve=true){
  const r=wrap.getBoundingClientRect();if(!r.width||!r.height)return;
  const dpr=Math.max(1,window.devicePixelRatio||1),old=document.createElement('canvas');
  old.width=canvas.width;old.height=canvas.height;if(preserve&&old.width&&old.height)old.getContext('2d').drawImage(canvas,0,0);
  canvas.width=Math.max(1,Math.floor(r.width*dpr));canvas.height=Math.max(1,Math.floor(r.height*dpr));canvas.style.width=r.width+'px';canvas.style.height=r.height+'px';ctx.setTransform(dpr,0,0,dpr,0,0);ctx.lineCap='round';ctx.lineJoin='round';
  if(preserve&&old.width&&old.height)ctx.drawImage(old,0,0,old.width,old.height,0,0,r.width,r.height);
}
function snap(){const s=currentSnapshot();if(s){history.push(s);if(history.length>40)history.shift()}redo=[]}
function restore(url){
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.restore();
  if(!url)return;
  const im=new Image();im.onload=()=>{const r=canvas.getBoundingClientRect();ctx.drawImage(im,0,0,r.width,r.height)};im.src=url;
}
function setTool(t){tool=t;['spPen','spLine','spErase'].forEach(id=>$(id).classList.remove('active'));$(t==='pen'?'spPen':t==='line'?'spLine':'spErase').classList.add('active');canvas.style.cursor=t==='erase'?'cell':'crosshair'}
function point(e){const r=canvas.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top}}
function drawSegment(a,b){ctx.globalCompositeOperation=tool==='erase'?'destination-out':'source-over';ctx.strokeStyle=ink;ctx.lineWidth=Number($('spSize').value)*(tool==='erase'?3:1);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}
canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);snap();drawing=true;start=last=point(e);if(tool==='line'){lineBase=document.createElement('canvas');lineBase.width=canvas.width;lineBase.height=canvas.height;lineBase.getContext('2d').drawImage(canvas,0,0)}e.preventDefault()});
function restoreLineBase(){if(!lineBase)return;ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(lineBase,0,0);ctx.restore()}
canvas.addEventListener('pointermove',e=>{if(!drawing)return;const p=point(e);if(tool==='line'){restoreLineBase();ctx.globalCompositeOperation='source-over';ctx.strokeStyle=ink;ctx.lineWidth=Number($('spSize').value);ctx.beginPath();ctx.moveTo(start.x,start.y);ctx.lineTo(p.x,p.y);ctx.stroke()}else{drawSegment(last,p);last=p}e.preventDefault()});
function stop(e){if(!drawing)return;if(tool==='line'&&e){const p=point(e);restoreLineBase();ctx.globalCompositeOperation='source-over';ctx.strokeStyle=ink;ctx.lineWidth=Number($('spSize').value);ctx.beginPath();ctx.moveTo(start.x,start.y);ctx.lineTo(p.x,p.y);ctx.stroke();savePage()}else savePage();drawing=false;start=last=lineBase=null;ctx.globalCompositeOperation='source-over'}
canvas.addEventListener('pointerup',stop);canvas.addEventListener('pointercancel',()=>stop());
function setPaper(mode){wrap.classList.remove('grid','coord','dots');if(mode!=='plain')wrap.classList.add(mode);const names={plain:'Plain',grid:'Graph',coord:'Coordinate',dots:'Dots'};const q=$('spPaperQuick');if(q)q.textContent='Paper: '+(names[mode]||'Plain')}
function renderPaperTo(g,w,h,mode){
  g.fillStyle='#fff';g.fillRect(0,0,w,h);g.lineWidth=1;
  if(mode==='dots'){g.fillStyle='#cbd5e1';for(let y=0;y<h;y+=24)for(let x=0;x<w;x+=24){g.beginPath();g.arc(x,y,1.2,0,Math.PI*2);g.fill()}return}
  if(mode==='grid'||mode==='coord'){g.strokeStyle=mode==='coord'?'#eef2f7':'#e5e7eb';g.beginPath();for(let x=0;x<w;x+=24){g.moveTo(x,0);g.lineTo(x,h)}for(let y=0;y<h;y+=24){g.moveTo(0,y);g.lineTo(w,y)}g.stroke();if(mode==='coord'){g.strokeStyle='#64748b';g.lineWidth=2;g.beginPath();g.moveTo(w/2,0);g.lineTo(w/2,h);g.moveTo(0,h/2);g.lineTo(w,h/2);g.stroke()}}
}
function exportPNG(){
  const r=canvas.getBoundingClientRect(),out=document.createElement('canvas');out.width=Math.max(1,Math.round(r.width*2));out.height=Math.max(1,Math.round(r.height*2));const g=out.getContext('2d');g.scale(2,2);renderPaperTo(g,r.width,r.height,paperSelect.value);g.drawImage(canvas,0,0,canvas.width,canvas.height,0,0,r.width,r.height);const a=document.createElement('a');a.download='EquationWright-scratch-page-'+(pageIndex+1)+'.png';a.href=out.toDataURL('image/png');a.click();
}
function switchPage(next){if(next<0||next>=pages.length||next===pageIndex)return;savePage();pageIndex=next;history=[];redo=[];restore(pages[pageIndex]);updatePageUI()}
function newPage(){if(pages.length>=MAX_PAGES)return;savePage();pages.splice(pageIndex+1,0,null);pageIndex++;history=[];redo=[];restore(null);updatePageUI()}
function deletePage(){if(pages.length===1)return;pages.splice(pageIndex,1);if(pageIndex>=pages.length)pageIndex=pages.length-1;history=[];redo=[];restore(pages[pageIndex]);updatePageUI()}
function toggleMin(){minimized=!minimized;panel.classList.toggle('minimized',minimized);$('spMin').textContent=minimized?'▢':'—';$('spMin').title=minimized?'Restore scratch pad':'Minimize scratch pad';if(!minimized)requestAnimationFrame(()=>applyWorkspaceSize(workspaceSelect.value))}
function cyclePaper(){const vals=['plain','grid','coord','dots'];paperSelect.value=vals[(vals.indexOf(paperSelect.value)+1)%vals.length];setPaper(paperSelect.value)}
launch.addEventListener('click',()=>{panel.style.display='block';minimized=false;panel.classList.remove('minimized');$('spMin').textContent='—';applyWorkspaceSize();panel.focus()});
$('spClose').addEventListener('click',()=>{savePage();panel.style.display='none'});$('spMin').addEventListener('click',toggleMin);$('spMoreBtn').addEventListener('click',()=>{const more=$('spMore');const open=more.classList.toggle('open');$('spMoreBtn').classList.toggle('active',open);$('spMoreBtn').setAttribute('aria-expanded',open?'true':'false');$('spMoreBtn').textContent=open?'Less':'More';requestAnimationFrame(()=>fit(true))});$('spPen').addEventListener('click',()=>setTool('pen'));$('spLine').addEventListener('click',()=>setTool('line'));$('spErase').addEventListener('click',()=>setTool('erase'));
$('spUndo').addEventListener('click',()=>{if(!history.length)return;redo.push(currentSnapshot());restore(history.pop());setTimeout(savePage,30)});$('spRedo').addEventListener('click',()=>{if(!redo.length)return;history.push(currentSnapshot());restore(redo.pop());setTimeout(savePage,30)});$('spClear').addEventListener('click',()=>{snap();restore(null);savePage()});$('spSave').addEventListener('click',exportPNG);
document.querySelectorAll('.ink-dot').forEach(b=>b.addEventListener('click',()=>{ink=b.dataset.color;document.querySelectorAll('.ink-dot').forEach(x=>x.classList.toggle('active',x===b));if(tool==='erase')setTool('pen')}));
$('spPaperQuick').addEventListener('click',cyclePaper);
paperSelect.addEventListener('change',()=>setPaper(paperSelect.value));workspaceSelect.addEventListener('change',()=>applyWorkspaceSize(workspaceSelect.value));$('spPrev').addEventListener('click',()=>switchPage(pageIndex-1));$('spNext').addEventListener('click',()=>switchPage(pageIndex+1));$('spNew').addEventListener('click',newPage);$('spDelete').addEventListener('click',deletePage);
const ro=new ResizeObserver(()=>{if(panel.style.display!=='none'&&!minimized)fit(true)});ro.observe(wrap);let resizeTimer;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(panel.style.display!=='none'&&!minimized)applyWorkspaceSize(workspaceSelect.value)},80)});
const head=$('scratchHead');head.addEventListener('pointerdown',e=>{if(e.target.tagName==='BUTTON'||innerWidth<601)return;const r=panel.getBoundingClientRect();drag={dx:e.clientX-r.left,dy:e.clientY-r.top};head.setPointerCapture(e.pointerId)});head.addEventListener('pointermove',e=>{if(!drag)return;panel.style.left=Math.max(4,Math.min(innerWidth-panel.offsetWidth-4,e.clientX-drag.dx))+'px';panel.style.top=Math.max(4,Math.min(innerHeight-panel.offsetHeight-4,e.clientY-drag.dy))+'px';panel.style.right='auto';panel.style.bottom='auto'});head.addEventListener('pointerup',()=>drag=null);head.addEventListener('pointercancel',()=>drag=null);
window.addEventListener('keydown',e=>{if(panel.style.display==='none'||minimized)return;const tag=(e.target&&e.target.tagName)||'';if(tag==='INPUT'||tag==='SELECT'||tag==='TEXTAREA')return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();if(e.shiftKey)$('spRedo').click();else $('spUndo').click();return}if(e.ctrlKey||e.metaKey||e.altKey)return;const k=e.key.toLowerCase();if(k==='p')setTool('pen');else if(k==='l')setTool('line');else if(k==='e')setTool('erase');else if(k==='g')cyclePaper();else if(k==='escape')toggleMin()});
$('spPop').addEventListener('click',()=>{
  savePage();const image=currentSnapshot(),paper=paperSelect.value;
  const w=window.open('','EquationWrightScratchPad','width=760,height=780,resizable=yes');if(!w)return;
  w.document.write(`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>EquationWright Scratch Pad</title><style>*{box-sizing:border-box}html,body{margin:0;height:100%;overflow:hidden;font-family:system-ui}body{display:flex;flex-direction:column;background:#f8fafc}.bar{padding:8px;background:#e2e8f0;display:flex;flex-wrap:wrap;gap:6px;align-items:center}.bar button{min-height:40px;padding:7px 10px;border:1px solid #94a3b8;border-radius:8px;background:#fff;font-weight:700}.bar input{width:90px}.stage{position:relative;flex:1;background:#fff}.stage.grid{background-image:linear-gradient(#e5e7eb 1px,transparent 1px),linear-gradient(90deg,#e5e7eb 1px,transparent 1px);background-size:24px 24px}.stage.dots{background-image:radial-gradient(circle,#cbd5e1 1.2px,transparent 1.3px);background-size:24px 24px}.stage.coord{background-image:linear-gradient(#eef2f7 1px,transparent 1px),linear-gradient(90deg,#eef2f7 1px,transparent 1px);background-size:24px 24px}.stage.coord:before,.stage.coord:after{content:"";position:absolute;background:#64748b;pointer-events:none}.stage.coord:before{width:2px;top:0;bottom:0;left:50%}.stage.coord:after{height:2px;left:0;right:0;top:50%}canvas{position:absolute;inset:0;width:100%;height:100%;touch-action:none}</style><div class="bar"><b style="margin-right:auto">Scratch Pad</b><button id="p">Pen</button><button id="l">Line</button><button id="e">Eraser</button><button id="u">Undo</button><button id="c">Clear</button><label>Size <input id="s" type="range" min="1" max="18" value="3"></label></div><div id="stage" class="stage ${paper}"><canvas id="x"></canvas></div><script>const c=x,g=c.getContext('2d');let t='p',d=0,a,b,h=[];function fit(){let old=document.createElement('canvas');old.width=c.width;old.height=c.height;if(old.width)old.getContext('2d').drawImage(c,0,0);let r=stage.getBoundingClientRect(),q=devicePixelRatio||1;c.width=r.width*q;c.height=r.height*q;g.setTransform(q,0,0,q,0,0);g.lineCap='round';if(old.width)g.drawImage(old,0,0,old.width,old.height,0,0,r.width,r.height)}fit();onresize=fit;function pt(v){let r=c.getBoundingClientRect();return{x:v.clientX-r.left,y:v.clientY-r.top}}function snap(){h.push(c.toDataURL());if(h.length>30)h.shift()}c.onpointerdown=v=>{snap();d=1;a=b=pt(v);c.setPointerCapture(v.pointerId)};c.onpointermove=v=>{if(!d)return;let n=pt(v);if(t==='l'){let i=new Image;i.onload=()=>{g.clearRect(0,0,c.width,c.height);g.drawImage(i,0,0,c.width/(devicePixelRatio||1),c.height/(devicePixelRatio||1));g.strokeStyle='#111827';g.lineWidth=+s.value;g.beginPath();g.moveTo(a.x,a.y);g.lineTo(n.x,n.y);g.stroke()};i.src=h[h.length-1]}else{g.globalCompositeOperation=t==='e'?'destination-out':'source-over';g.strokeStyle='#111827';g.lineWidth=+s.value*(t==='e'?3:1);g.beginPath();g.moveTo(b.x,b.y);g.lineTo(n.x,n.y);g.stroke();b=n}};c.onpointerup=()=>{d=0;g.globalCompositeOperation='source-over'};p.onclick=()=>t='p';l.onclick=()=>t='l';e.onclick=()=>t='e';u.onclick=()=>{if(!h.length)return;let i=new Image;i.onload=()=>{g.clearRect(0,0,c.width,c.height);g.drawImage(i,0,0,c.width/(devicePixelRatio||1),c.height/(devicePixelRatio||1))};i.src=h.pop()};document.getElementById('c').onclick=()=>{snap();g.clearRect(0,0,c.width,c.height)};<\/script>`);w.document.close();setTimeout(()=>{try{const pc=w.document.getElementById('x'),pg=pc.getContext('2d'),im=new w.Image();im.onload=()=>{const r=pc.getBoundingClientRect();pg.drawImage(im,0,0,r.width,r.height)};im.src=image}catch(_){}},120)
});
setPaper('plain');updatePageUI();
})();
