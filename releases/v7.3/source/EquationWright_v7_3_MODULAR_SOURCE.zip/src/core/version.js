
// =====================
// Core utilities (seeded RNG + helpers)
// =====================
const MW_BLUEPRINT_FORMAT = 'UMWB_BLUEPRINT';
const MW_APP_VERSION = 'v7.3_full_catalog_protocols';
const MW_AI_DRILL_MIN = 5;
const MW_AI_DRILL_MAX = 15;
const MW_BLUEPRINT_UNIT_MAX = 100;
const MW_BLUEPRINT_TOTAL_MAX = 250;

function mwConfirmBlueprintCompatibility(bp){
  const warnings = [];
  if(bp.format !== MW_BLUEPRINT_FORMAT){
    warnings.push(`Blueprint format is ${bp.format ? '"' + String(bp.format) + '"' : 'missing'}; this app expects "${MW_BLUEPRINT_FORMAT}".`);
  }
  if(bp.appVersion !== MW_APP_VERSION){
    warnings.push(`Blueprint version is ${bp.appVersion ? '"' + String(bp.appVersion) + '"' : 'missing'}; this app is "${MW_APP_VERSION}".`);
  }
  if(!warnings.length) return true;
  return confirm('Blueprint compatibility warning:\n\n' + warnings.join('\n') +
    '\n\nContinuing may reproduce different questions or settings. Continue anyway?');
}
function fnv1a(str){
  let h = 0x811c9dc5;
  for(let i=0;i<str.length;i++){
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0);
}

function hashStringToUint32(str){ return fnv1a(str); }

// --- TeX hygiene auto-repair ---
// Repairs common JS string-escape leaks in LaTeX-heavy strings.
// Example: "\frac{1}{2}" should be written as "\\frac{1}{2}" in JS.
// If written as "\frac{1}{2}", JS interprets \f as a form-feed control char,
// leaving "rac{1}{2}" in the rendered text.
// This helper normalizes the most common leaks at runtime so UI/export stay clean.
function fixTexEscapes(s){
  if(s == null) return s;
  let t = String(s);

  // ---- display tidy (identity-preserving sign/coefficient cleanup) ----
  // "a + -b" -> "a - b"   and   "a - -b" -> "a + b"
  t = t.replace(/\+\s*-\s*(?=[\d\\a-zA-Z(])/g, '- ');
  t = t.replace(/-\s*-\s*(?=[\d(])/g, '+ ');
  // coefficient 1: "(+|-|=|{|space)1x" -> "x"   (protects 21x, \frac{1}{..})
  t = t.replace(/(^|[\s({}=+\-,&\\\\])1(?=(?!st\b|nd\b|rd\b|th\b)[a-z]{1,3}\b|[a-z]\^)/g, '$1');
  // exponent 1: "x^{1}" -> "x"
  t = t.replace(/\^\{1\}(?![\d])/g, '');
  // dead zero terms: "+ 0x", "+ 0x^{2}" -> removed
  t = t.replace(/\s*\+\s*0(?:x|y|z|t)(?:\^\{?\d+\}?)?(?=\s*[+\-=)\\]|\s*$)/g, '');

  // Normalize math delimiters if a generator accidentally produced double-backslash forms.
  // LaTeX wants \(...\) and \[...\] (single backslash), not \\(...\\).
  t = t.replace(/\\\\\(/g, '\\(').replace(/\\\\\)/g, '\\)');
  t = t.replace(/\\\\\[/g, '\\[').replace(/\\\\\]/g, '\\]');


  // Drop control chars except \n and \t
  t = t.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');

  // High-signal repairs (backslash got eaten or \f was consumed)
  // "\frac" leak often becomes a control char + "rac{..."; normalize both "rac{" and bare "frac{"
  t = t.replace(/(^|[^A-Za-z\\])rac\{/g, (m, pre) => pre + '\\frac{');
  t = t.replace(/(^|[^A-Za-z\\])frac\{/g, (m, pre) => pre + '\\frac{');
  t = t.replace(/(^|[^A-Za-z\\])dfrac\{/g, (m, pre) => pre + '\\dfrac{');

  t = t.replace(/(^|[^A-Za-z\\])cdot\b/g, (m, pre) => pre + '\\cdot');
  t = t.replace(/(^|[^A-Za-z\\])sqrt\{/g, (m, pre) => pre + '\\sqrt{');
  t = t.replace(/(^|[^A-Za-z\\])infty\b/g, (m, pre) => pre + '\\infty');


  // Common TeX commands that can lose their leading backslash (e.g., OCR or accidental stripping).
  // Only patch when token is used like a TeX command (followed by _ ^ { ( ).
  t = t.replace(/(^|[^A-Za-z\\])int(?=\s*[_^\{\(])/g, '$1\\int');
  t = t.replace(/(^|[^A-Za-z\\])sum(?=\s*[_^\{\(])/g, '$1\\sum');
  t = t.replace(/(^|[^A-Za-z\\])lim(?=\s*[_^\{\(])/g, '$1\\lim');

  return t;
}



