function xorshift32(seed){
  let x = (seed >>> 0) || 1;
  return function(){
    x ^= (x << 13); x >>>= 0;
    x ^= (x >>> 17); x >>>= 0;
    x ^= (x << 5);  x >>>= 0;
    return (x >>> 0) / 4294967296;
  };
}
const randInt = (rng, min, max) => min + Math.floor(rng() * (max - min + 1));
const pick = (rng, arr) => arr[Math.floor(rng() * arr.length)];
function escHtml(s){
  return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;').replaceAll("'","&#39;");
}
function gcd(a,b){ a=Math.abs(a); b=Math.abs(b); while(b){ const t=a%b; a=b; b=t; } return a||1; }
function simpFrac(n,d){
  if(d<0){ n=-n; d=-d; }
  const g=gcd(n,d);
  n/=g; d/=g;
  if(d===1) return `${n}`;
  return `\\(\\frac{${n}}{${d}}\\)`;
}
function fmtSigned(n){ return (n >= 0 ? `+${n}` : `${n}`); }
function termXPlus(n){ return `x${fmtSigned(n)}`; }
function parenXMinus(n){ return (n >= 0 ? `(x-${n})` : `(x+${Math.abs(n)})`); }

// --- numeric formatting controls ---
const DEC_PLACES = 3;

function fmtDec(n, places = DEC_PLACES) {
  const x = Number(n);
  if (!Number.isFinite(x)) return String(n);

  const r = Math.round(x);
  if (Math.abs(x - r) < 1e-12) return String(r);

  let s = x.toFixed(places);
  if (s === "-0.000") s = "0.000";
  return s;
}

function replaceNumericFractions(s) {
  return s.replace(/(^|[^\w\\])(-?\d+)\s*\/\s*(\d+)(?![\w])/g,
    (m, pre, a, b) => {
      const n = Number(a) / Number(b);
      if (!Number.isFinite(n)) return m;
      return pre + fmtDec(n);
    }
  );
}

function roundLongDecimals(s) {
  return s.replace(/(-?\d+\.\d{4,})/g, m => fmtDec(m));
}

function cleanMathText(s) {
  if (typeof s !== "string") return s;
  let out = s;
  out = replaceNumericFractions(out);
  out = roundLongDecimals(out);
  return out;
}

// =====================
