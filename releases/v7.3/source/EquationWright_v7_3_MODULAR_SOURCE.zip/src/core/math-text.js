// Exact Answer Helpers
// =====================
function isPerfectSquare(n){
  if(n < 0) return false;
  const sqrt = Math.sqrt(n);
  return sqrt === Math.floor(sqrt);
}
function simplifyRadical(n){
  if(n < 0) return `\\sqrt{${n}}`; // Will handle imaginary later if needed
  if(isPerfectSquare(n)) return `${Math.sqrt(n)}`;
  
  // Find largest perfect square factor
  let factor = 1;
  for(let i = 2; i * i <= n; i++){
    while(n % (i*i) === 0){
      factor *= i;
      n /= (i*i);
    }
  }
  if(factor === 1) return `\\sqrt{${n}}`;
  if(n === 1) return `${factor}`;
  return `${factor}\\sqrt{${n}}`;
}
function exactFrac(num, den){
  if(den === 0) return 'undefined';
  if(den < 0){ num = -num; den = -den; }
  const g = gcd(Math.abs(num), Math.abs(den));
  num /= g; den /= g;
  if(den === 1) return `${num}`;
  return `\\frac{${num}}{${den}}`;
}
function smartRound(n, places=3){
  // Check if close to integer
  if(Math.abs(n - Math.round(n)) < 0.0001) return `${Math.round(n)}`;
  // Check if close to half
  if(Math.abs(n*2 - Math.round(n*2)) < 0.0001) return `${(Math.round(n*2)/2).toFixed(1)}`;
  return n.toFixed(places);
}

// =====================
// SVG Diagram Generators
// =====================
function svgUnitCircle(angle, size=120){
  const r = size * 0.35;
  const cx = size / 2;
  const cy = size / 2;
  const x = cx + r * Math.cos(angle);
  const y = cy - r * Math.sin(angle); // SVG y is inverted
  
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#1a1a2e;border-radius:8px;">
    <circle cx="${cx}" cy="${cy}" r="${r}" stroke="#60a5fa" fill="none" stroke-width="1.5"/>
    <line x1="${cx}" y1="${cy}" x2="${cx+r}" y2="${cy}" stroke="#666" stroke-width="0.5"/>
    <line x1="${cx}" y1="${cy}" x2="${cx}" y2="${cy-r}" stroke="#666" stroke-width="0.5"/>
    <line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="#60a5fa" stroke-width="2"/>
    <circle cx="${x}" cy="${y}" r="3" fill="#60a5fa"/>
    <text x="${cx+r+4}" y="${cy+4}" fill="#888" font-size="10">0</text>
    <text x="${cx-6}" y="${cy-r-6}" fill="#888" font-size="10">π/2</text>
    <text x="${cx-r-10}" y="${cy+4}" fill="#888" font-size="10">π</text>
    <text x="${cx-6}" y="${cy+r+12}" fill="#888" font-size="10">3π/2</text>
  </svg>`;
}

function svgVector(vx, vy, size=120, label='v'){
  const scale = 15;
  const cx = size / 2;
  const cy = size / 2;
  const x = cx + vx * scale;
  const y = cy - vy * scale; // SVG y inverted
  
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#1a1a2e;border-radius:8px;">
    <defs>
      <marker id="arrowhead-${label}" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
        <polygon points="0 0, 10 3, 0 6" fill="#60a5fa"/>
      </marker>
    </defs>
    <line x1="0" y1="${cy}" x2="${size}" y2="${cy}" stroke="#444" stroke-width="0.5"/>
    <line x1="${cx}" y1="0" x2="${cx}" y2="${size}" stroke="#444" stroke-width="0.5"/>
    <line x1="${cx}" y1="${cy}" x2="${x}" y2="${y}" stroke="#60a5fa" stroke-width="2" marker-end="url(#arrowhead-${label})"/>
    <text x="${x+5}" y="${y-5}" fill="#60a5fa" font-size="12" font-weight="bold">${label}</text>
  </svg>`;
}

function svgCoordinatePlane(size=120){
  const cx = size / 2;
  const cy = size / 2;
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#1a1a2e;border-radius:8px;">
    <line x1="0" y1="${cy}" x2="${size}" y2="${cy}" stroke="#444" stroke-width="1"/>
    <line x1="${cx}" y1="0" x2="${cx}" y2="${size}" stroke="#444" stroke-width="1"/>
    <text x="${size-15}" y="${cy-5}" fill="#888" font-size="10">x</text>
    <text x="${cx+5}" y="12" fill="#888" font-size="10">y</text>
  </svg>`;
}

function svgTriangle(a, b, angleA, angleB, size=140){
  // Simple triangle diagram for Law of Sines/Cosines.
  // If b is unknown, draw with a reasonable placeholder so the triangle isn't degenerate.
  const padding = 18;
  const bDraw = (b===null || b===undefined || !isFinite(b) || b<=0) ? a*0.9 : b;
  const maxSide = Math.max(a, bDraw, 10);
  const scale = (size - 2*padding) / maxSide;

  // Place vertices A and B on the base.
  const Ax = padding;
  const Ay = size - padding;
  const Bx = Ax + bDraw * scale;
  const By = Ay;

  // Place C using side a and angleB (not to exact scale, just for a clean diagram).
  const Cx = Ax + a * scale * Math.cos(angleB);
  const Cy = Ay - a * scale * Math.sin(angleB);

  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#1a1a2e;border-radius:8px;">
    <polygon points="${Ax},${Ay} ${Bx},${By} ${Cx},${Cy}" fill="none" stroke="#60a5fa" stroke-width="2"/>
    <circle cx="${Ax}" cy="${Ay}" r="2" fill="#60a5fa"/>
    <circle cx="${Bx}" cy="${By}" r="2" fill="#60a5fa"/>
    <circle cx="${Cx}" cy="${Cy}" r="2" fill="#60a5fa"/>
    <text x="${Ax-10}" y="${Ay+15}" fill="#888" font-size="11" font-weight="bold">A</text>
    <text x="${Bx+5}" y="${By+15}" fill="#888" font-size="11" font-weight="bold">B</text>
    <text x="${Cx}" y="${Cy-8}" fill="#888" font-size="11" font-weight="bold">C</text>
    <text x="${(Bx+Cx)/2}" y="${(By+Cy)/2-5}" fill="#60a5fa" font-size="10">a=${a}</text>
    <text x="${(Ax+Bx)/2}" y="${Ay+20}" fill="#60a5fa" font-size="10">c</text>
    <text x="${(Ax+Cx)/2-18}" y="${(Ay+Cy)/2}" fill="#60a5fa" font-size="10">${(b===null||b===undefined)? "b" : `b=${smartRound(b,2)}`}</text>
  </svg>`;
}


function svgPolarGrid(r, theta, size=140){
  const cx = size / 2;
  const cy = size / 2;
  const maxR = size * 0.4;
  const scale = maxR / 5; // 5 concentric circles
  
  // Convert polar to cartesian
  const px = cx + r * scale * Math.cos(theta);
  const py = cy - r * scale * Math.sin(theta); // SVG y inverted
  
  let circles = '';
  for(let i = 1; i <= 5; i++){
    circles += `<circle cx="${cx}" cy="${cy}" r="${i*scale}" fill="none" stroke="#444" stroke-width="0.5"/>`;
  }
  
  // Radial lines at 30° intervals
  let radials = '';
  for(let angle = 0; angle < 2*Math.PI; angle += Math.PI/6){
    const x2 = cx + maxR * Math.cos(angle);
    const y2 = cy - maxR * Math.sin(angle);
    radials += `<line x1="${cx}" y1="${cy}" x2="${x2}" y2="${y2}" stroke="#444" stroke-width="0.5"/>`;
  }
  
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#1a1a2e;border-radius:8px;">
    ${circles}
    ${radials}
    <line x1="${cx}" y1="${cy}" x2="${px}" y2="${py}" stroke="#60a5fa" stroke-width="2"/>
    <circle cx="${px}" cy="${py}" r="3" fill="#60a5fa"/>
    <text x="${cx+maxR+5}" y="${cy+5}" fill="#888" font-size="9">0°</text>
    <text x="${cx-5}" y="${cy-maxR-5}" fill="#888" font-size="9">90°</text>
  </svg>`;
}

function svgVectorAddition(u, v, size=140){
  const scale = 12;
  const cx = size / 2;
  const cy = size / 2;
  
  // u vector from origin
  const ux = cx + u[0] * scale;
  const uy = cy - u[1] * scale;
  
  // v vector from origin
  const vx = cx + v[0] * scale;
  const vy = cy - v[1] * scale;
  
  // v vector from end of u (for addition)
  const vFromU_x = ux + v[0] * scale;
  const vFromU_y = uy - v[1] * scale;
  
  // Resultant (u + v)
  const sumx = cx + (u[0] + v[0]) * scale;
  const sumy = cy - (u[1] + v[1]) * scale;
  
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#1a1a2e;border-radius:8px;">
    <defs>
      <marker id="arrow-u" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <polygon points="0 0, 8 3, 0 6" fill="#60a5fa"/>
      </marker>
      <marker id="arrow-v" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
        <polygon points="0 0, 8 3, 0 6" fill="#34d399"/>
      </marker>
      <marker id="arrow-sum" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto">
        <polygon points="0 0, 10 3, 0 6" fill="#f59e0b"/>
      </marker>
    </defs>
    <line x1="0" y1="${cy}" x2="${size}" y2="${cy}" stroke="#444" stroke-width="0.5"/>
    <line x1="${cx}" y1="0" x2="${cx}" y2="${size}" stroke="#444" stroke-width="0.5"/>
    
    <!-- Vector u -->
    <line x1="${cx}" y1="${cy}" x2="${ux}" y2="${uy}" stroke="#60a5fa" stroke-width="2" marker-end="url(#arrow-u)"/>
    <text x="${ux+5}" y="${uy-5}" fill="#60a5fa" font-size="11" font-weight="bold">u</text>
    
    <!-- Vector v from origin (dashed) -->
    <line x1="${cx}" y1="${cy}" x2="${vx}" y2="${vy}" stroke="#34d399" stroke-width="1.5" stroke-dasharray="3,3"/>
    
    <!-- Vector v from end of u -->
    <line x1="${ux}" y1="${uy}" x2="${vFromU_x}" y2="${vFromU_y}" stroke="#34d399" stroke-width="2" marker-end="url(#arrow-v)"/>
    <text x="${vFromU_x+5}" y="${vFromU_y-5}" fill="#34d399" font-size="11" font-weight="bold">v</text>
    
    <!-- Resultant u+v -->
    <line x1="${cx}" y1="${cy}" x2="${sumx}" y2="${sumy}" stroke="#f59e0b" stroke-width="2.5" marker-end="url(#arrow-sum)"/>
    <text x="${sumx+5}" y="${sumy+12}" fill="#f59e0b" font-size="11" font-weight="bold">u+v</text>
  </svg>`;
}

function svgIntegrationRegion(a, b, size=140){
  // Simple shaded region under y = x^2 from a to b
  const padding = 20;
  const width = size - 2*padding;
  const height = size - 2*padding;
  
  // Scale to fit [a,b] on x-axis
  const xScale = width / (b - a);
  const yMax = Math.max(a*a, b*b);
  const yScale = height / (yMax * 1.2);
  
  // Generate curve points
  let points = `${padding},${size-padding}`;
  for(let t = 0; t <= 1; t += 0.05){
    const x = a + t * (b - a);
    const y = x * x;
    const sx = padding + (x - a) * xScale;
    const sy = size - padding - y * yScale;
    points += ` ${sx},${sy}`;
  }
  points += ` ${padding + width},${size-padding}`;
  
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#1a1a2e;border-radius:8px;">
    <!-- Axes -->
    <line x1="${padding}" y1="${size-padding}" x2="${size-padding}" y2="${size-padding}" stroke="#888" stroke-width="1"/>
    <line x1="${padding}" y1="${padding}" x2="${padding}" y2="${size-padding}" stroke="#888" stroke-width="1"/>
    
    <!-- Shaded region -->
    <polygon points="${points}" fill="#60a5fa" fill-opacity="0.3" stroke="none"/>
    
    <!-- Curve -->
    <path d="M${padding},${size-padding} ${points.split(' ').slice(1, -1).join(' ')}" fill="none" stroke="#60a5fa" stroke-width="2"/>
    
    <!-- Bounds -->
    <line x1="${padding}" y1="${size-padding}" x2="${padding}" y2="${size-padding-a*a*yScale}" stroke="#34d399" stroke-width="1.5" stroke-dasharray="2,2"/>
    <line x1="${padding+width}" y1="${size-padding}" x2="${padding+width}" y2="${size-padding-b*b*yScale}" stroke="#34d399" stroke-width="1.5" stroke-dasharray="2,2"/>
    
    <text x="${padding-5}" y="${size-padding+15}" fill="#888" font-size="10">${a}</text>
    <text x="${padding+width-5}" y="${size-padding+15}" fill="#888" font-size="10">${b}</text>
    <text x="${size-padding+5}" y="${padding}" fill="#888" font-size="10">y</text>
    <text x="${size-padding-10}" y="${size-padding-5}" fill="#888" font-size="10">x</text>
  </svg>`;
}

// =====================
// Stamp art (pixel/radar watermark)
// =====================
function stampPixel(seed, size=32, grid=8){
  const rng = xorshift32(fnv1a(seed + '|pix'));
  const p = 0.34 + 0.18*((fnv1a(seed + '|p') % 100)/100);
  const cell = size / grid;
  const rects = [];
  for(let y=0;y<grid;y++){
    for(let x=0;x<Math.ceil(grid/2);x++){
      if(rng() < p){
        const x1 = x*cell, x2 = (grid-1-x)*cell;
        rects.push(`<rect class="ink" x="${x1.toFixed(2)}" y="${(y*cell).toFixed(2)}" width="${cell.toFixed(2)}" height="${cell.toFixed(2)}"/>`);
        if(x2 !== x1){
          rects.push(`<rect class="ink" x="${x2.toFixed(2)}" y="${(y*cell).toFixed(2)}" width="${cell.toFixed(2)}" height="${cell.toFixed(2)}"/>`);
        }
      }
    }
  }
  return `<svg class="stamp" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect class="line" x="1" y="1" width="${size-2}" height="${size-2}" rx="6" ry="6" fill="none" stroke-width="1.2"/>
    ${rects.join('')}
  </svg>`;
}
function stampRadar(seed, size=32){
  const spokes = 8 + (fnv1a(seed + '|sp') % 5);
  const rng = xorshift32(fnv1a(seed + '|rad'));
  const cx = size/2, cy = size/2;
  const R = size*0.41;
  const pts = [];
  for(let i=0;i<spokes;i++){
    const m = 0.35 + 0.65*rng();
    const ang = (2*Math.PI*i)/spokes - Math.PI/2;
    pts.push([cx + Math.cos(ang)*R*m, cy + Math.sin(ang)*R*m]);
  }
  pts.push(pts[0]);
  const d = 'M ' + pts.map(p=>`${p[0].toFixed(2)} ${p[1].toFixed(2)}`).join(' L ');
  const ring1 = size*0.18, ring2 = size*0.30;
  return `<svg class="stamp" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect class="line" x="1" y="1" width="${size-2}" height="${size-2}" rx="6" ry="6" fill="none" stroke-width="1.2"/>
    <circle class="line" cx="${cx.toFixed(2)}" cy="${cy.toFixed(2)}" r="${ring1.toFixed(2)}" fill="none" stroke-width="1.1" opacity="0.75"/>
    <circle class="line" cx="${cx.toFixed(2)}" cy="${cy.toFixed(2)}" r="${ring2.toFixed(2)}" fill="none" stroke-width="1.1" opacity="0.55"/>
    <path class="line" d="${d}" fill="none" stroke-width="1.8" stroke-linejoin="round"/>
    <circle class="ink" cx="${cx.toFixed(2)}" cy="${cy.toFixed(2)}" r="2.0"/>
  </svg>`;
}
function stamp(seed){
  return (fnv1a(seed + '|style') % 2 === 0) ? stampPixel(seed) : stampRadar(seed);
}

// =====================
// Variety distance engine
// =====================
function distL1(a,b){
  let d = 0;
  const n = Math.max(a.length, b.length);
  for(let i=0;i<n;i++){
    const ai = a[i] ?? 0;
    const bi = b[i] ?? 0;
    const w = (i===0 ? 2.0 : (i===1 ? 1.5 : 1.0));
    d += w * Math.abs(ai - bi);
  }
  return d;
}

// Compatibility alias used by variety picker
function dist(a,b){
  return distL1(a,b);
}

function minDistToChosen(v, chosen){
  if(!chosen.length) return 999;
  let m = Infinity;
  for(const c of chosen) m = Math.min(m, distL1(v, c.vec));
  return m;
}

// =======================================================
// UNITS (course: CA/TRIG/PC/C1/C2/C3)
// =======================================================
