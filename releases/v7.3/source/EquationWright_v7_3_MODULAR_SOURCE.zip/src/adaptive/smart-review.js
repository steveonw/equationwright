// EquationWright v7.2 - deterministic adaptive practice (Pass 3B)
// Policy source: Pass 3A PRO FINAL APPROVED. This code selects only
// existing EquationWright units/topics; the generator engine still owns math.
// =====================================================================
const MW_SMART_REVIEW_MIN = 5;
const MW_SMART_REVIEW_MAX = 10;
const MW_HISTORY_UNALIASED_KEY = '__mw_unaliased__';

function mwAdaptiveFailure(code, message, details){
  return { ok:false, code:String(code||'adaptive-failure'), message:String(message||code||'Adaptive-practice failure.'), ...(details?{details}: {}) };
}
function mwNormalizeMode(value){ return String(value ?? '').trim(); }
function mwNormalizeId(value){ return String(value ?? '').trim(); }
function mwCanonicalText(value){
  if(value == null) return '';
  return String(value).normalize('NFKC').replace(/\r\n?/g,'\n').replace(/\s+/gu,' ').trim();
}
function mwCanonicalSortValue(value){
  if(Array.isArray(value)) return value.map(mwCanonicalSortValue);
  if(value && typeof value === 'object'){
    const out = {};
    for(const key of Object.keys(value).sort()) out[key] = mwCanonicalSortValue(value[key]);
    return out;
  }
  return value;
}
function mwCanonicalJSONString(value){ return JSON.stringify(mwCanonicalSortValue(value)); }
function mwLexCmp(a,b){ a=String(a); b=String(b); return a<b?-1:(a>b?1:0); }
function mwValidInt(value){ return Number.isFinite(Number(value)) && Number.isInteger(Number(value)) && Number(value)>=0; }
function mwValidDateRecord(value){
  if(typeof value !== 'string' || !value.trim()) return { valid:false, ms:null, iso:null };
  const ms = Date.parse(value);
  return Number.isFinite(ms) ? { valid:true, ms, iso:new Date(ms).toISOString() } : { valid:false, ms:null, iso:null };
}
function mwAliasInfo(value){
  const display = String(value ?? '').normalize('NFKC').replace(/\s+/gu,' ').trim();
  if(!display) return { key:MW_HISTORY_UNALIASED_KEY, display:'This learner (unaliased)', unaliased:true };
  return { key:display.toLowerCase(), display, unaliased:false };
}
function mwSortedUniqueIds(list){
  return [...new Set((Array.isArray(list)?list:[]).map(mwNormalizeId).filter(Boolean))].sort(mwLexCmp);
}
function mwCanonicalBlueprintSettings(bp, validateLive=false){
  if(!bp || typeof bp !== 'object') return null;
  const mode = mwNormalizeMode(bp.mode);
  const countsIn = bp.counts;
  if(!countsIn || typeof countsIn !== 'object' || Array.isArray(countsIn)) return null;
  const counts = [];
  for(const [rawId, rawCount] of Object.entries(countsIn)){
    const unitId = mwNormalizeId(rawId);
    if(!unitId || !mwValidInt(rawCount)) return null;
    const n = Number(rawCount);
    if(n>0) counts.push([unitId,n]);
  }
  counts.sort((a,b)=>mwLexCmp(a[0],b[0]));

  const topicSource = bp.topics || bp.topicFilters || {};
  if(topicSource && (typeof topicSource !== 'object' || Array.isArray(topicSource))) return null;
  const topics = [];
  for(const [rawId, rec] of Object.entries(topicSource||{})){
    const unitId = mwNormalizeId(rawId);
    if(!unitId || !rec || typeof rec !== 'object' || Array.isArray(rec)) return null;
    if(rec.list != null && !Array.isArray(rec.list)) return null;
    const list = mwSortedUniqueIds(rec.list||[]);
    if(!list.length) continue;
    if(validateLive){
      const allowedUnits = new Set(unitsForMode(mode).map(u=>u.id));
      if(!allowedUnits.has(unitId)) return null;
      const validTopics = new Set(ensureUnitTopics(unitId).map(t=>t.id));
      if(list.some(t=>!validTopics.has(t))) return null;
    }
    topics.push([unitId,list]);
  }
  topics.sort((a,b)=>mwLexCmp(a[0],b[0]));

  const variety = Number(bp.variety);
  if(!Number.isFinite(variety) || !Number.isInteger(variety)) return null;
  return { counts, topics, variety, quizMode:!!bp.quizMode };
}
function mwCanonicalQuestionTuple(row){
  return [
    row.n,
    row.unit,
    row.topicKey == null ? null : row.topicKey,
    row.generatorKey == null ? null : row.generatorKey,
    mwCanonicalText(row.question),
    mwCanonicalText(row.correctAnswer),
    row.result,
    row.chosenAnswer == null ? null : mwCanonicalText(row.chosenAnswer)
  ];
}
function mwCanonicalAttemptObject(appVersion, seed, mode, bpSettings, rows){
  const sortedRows = [...rows].sort((a,b)=> (a.n-b.n) || (a._index-b._index));
  return {
    schema:'equationwright-attempt-v1',
    appVersion:String(appVersion),
    seed:mwNormalizeWorksheetSeed(seed),
    mode:mwNormalizeMode(mode),
    blueprint:bpSettings,
    questions:sortedRows.map(mwCanonicalQuestionTuple)
  };
}
function mwRowMetrics(rows){
  let score=0, answered=0, incorrect=0, unanswered=0;
  const missedByUnit={}, missedByTopic={}, mistakePatterns={}, unansweredByUnit={};
  const topicAnswered={}, topicIncorrect={};
  for(const row of rows){
    if(row.result==='correct'){ score++; answered++; }
    else if(row.result==='incorrect'){
      answered++; incorrect++;
      missedByUnit[row.unit]=(missedByUnit[row.unit]||0)+1;
      if(row.topicKey){
        const tk=row.unit+'\u0000'+row.topicKey;
        missedByTopic[tk]=(missedByTopic[tk]||0)+1;
      }
      if(row.mistakeType){ mistakePatterns[row.mistakeType]=(mistakePatterns[row.mistakeType]||0)+1; }
    }else if(row.result==='unanswered'){
      unanswered++;
      unansweredByUnit[row.unit]=(unansweredByUnit[row.unit]||0)+1;
    }
    if(row.result!=='unanswered' && row.topicKey){
      const tk=row.unit+'\u0000'+row.topicKey;
      topicAnswered[tk]=(topicAnswered[tk]||0)+1;
      if(row.result==='incorrect') topicIncorrect[tk]=(topicIncorrect[tk]||0)+1;
    }
  }
  const total=rows.length;
  return {
    total, score, answered, incorrect, unanswered,
    quizPercent: total ? score/total : 0,
    accuracy: answered ? score/answered : null,
    completion: total ? answered/total : 0,
    missedByUnit, missedByTopic, mistakePatterns, unansweredByUnit,
    topicAnswered, topicIncorrect
  };
}
function mwNormalizeAdaptiveRow(raw,index, liveMode=null){
  if(!raw || typeof raw!=='object') return mwAdaptiveFailure('invalid-question-row','A question row is not an object.',{question:index+1});
  const n=Number(raw.n);
  if(!Number.isFinite(n)||!Number.isInteger(n)||n<1) return mwAdaptiveFailure('invalid-question-row','A question row has an invalid question number.',{question:index+1});
  const result=String(raw.result||'');
  if(!['correct','incorrect','unanswered'].includes(result)) return mwAdaptiveFailure('invalid-question-row','A question row has an invalid result value.',{question:n});
  const unit=mwNormalizeId(raw.unit);
  if(!unit) return mwAdaptiveFailure('invalid-question-row','A question row is missing its unit.',{question:n});
  if(liveMode){
    const allowed=new Set(unitsForMode(liveMode).map(u=>u.id));
    if(!allowed.has(unit)) return mwAdaptiveFailure('unit-out-of-mode',`Question ${n} uses unit "${unit}" outside mode "${liveMode}".`,{question:n,unit});
  }
  const topicKey = raw.topicKey==null || mwNormalizeId(raw.topicKey)==='' ? null : mwNormalizeId(raw.topicKey);
  if(liveMode && topicKey){
    const validTopics=new Set(ensureUnitTopics(unit).map(t=>t.id));
    if(!validTopics.has(topicKey)) return mwAdaptiveFailure('topic-invalid-for-unit',`Question ${n} uses topic "${topicKey}" outside unit "${unit}".`,{question:n,unit,topicKey});
  }
  return { ok:true, row:{
    _index:index, n, unit, topicKey,
    generatorKey: raw.generatorKey==null || mwNormalizeId(raw.generatorKey)==='' ? null : mwNormalizeId(raw.generatorKey),
    question: raw.question==null ? '' : String(raw.question),
    correctAnswer: raw.correctAnswer==null ? '' : String(raw.correctAnswer),
    chosenAnswer: raw.chosenAnswer==null ? null : String(raw.chosenAnswer),
    result,
    mistakeType: (result==='incorrect' && raw.mistakeType!=null && mwCanonicalText(raw.mistakeType)!=='') ? mwCanonicalText(raw.mistakeType) : null
  }};
}
function mwValidateAdaptiveResult(results){
  if(!results || typeof results!=='object' || results.format!=='mw-quiz-results-v1') return mwAdaptiveFailure('invalid-results-format','Smart Review requires an mw-quiz-results-v1 result object.');
  const bp=results.blueprint;
  if(!bp || typeof bp!=='object' || bp.format!==MW_BLUEPRINT_FORMAT) return mwAdaptiveFailure('missing-or-invalid-blueprint','The result is missing a valid EquationWright blueprint.');
  if(bp.appVersion!==MW_APP_VERSION) return mwAdaptiveFailure('version-mismatch',`This result was made by ${bp.appVersion||'an unknown version'}; Smart Review requires ${MW_APP_VERSION}.`);
  const bpMode=mwNormalizeMode(bp.mode);
  const resultMode=mwNormalizeMode(results.mode);
  if(!bpMode || resultMode!==bpMode) return mwAdaptiveFailure('mode-mismatch','The result mode does not match its blueprint mode.');
  const resultSeed=mwNormalizeWorksheetSeed(results.seed);
  const bpSeed=mwNormalizeWorksheetSeed(bp.seed);
  if(resultSeed!==bpSeed) return mwAdaptiveFailure('seed-mismatch','The result seed does not match its blueprint seed.');
  const pre=mwPreflightBlueprint(bp);
  if(!pre.ok) return mwAdaptiveFailure('blueprint-preflight-failed','The source blueprint failed common validation.',{error:pre.error});
  const bpSettings=mwCanonicalBlueprintSettings(bp,true);
  if(!bpSettings) return mwAdaptiveFailure('missing-or-invalid-blueprint','The source blueprint has invalid adaptive-practice settings.');
  if(!Array.isArray(results.questions) || !results.questions.length) return mwAdaptiveFailure('no-question-rows','The result contains no question rows.');
  const rows=[];
  for(let i=0;i<results.questions.length;i++){
    const nr=mwNormalizeAdaptiveRow(results.questions[i],i,bpMode);
    if(!nr.ok) return nr;
    rows.push(nr.row);
  }
  const metrics=mwRowMetrics(rows);
  for(const field of ['total','score','answered','unanswered']){
    if(Object.prototype.hasOwnProperty.call(results,field) && results[field]!=null){
      if(!mwValidInt(results[field]) || Number(results[field])!==metrics[field]){
        return mwAdaptiveFailure('results-count-mismatch',`The exported ${field} value contradicts the question rows.`,{field,reported:results[field],recomputed:metrics[field]});
      }
    }
  }
  const canonicalObject=mwCanonicalAttemptObject(bp.appVersion,bpSeed,bpMode,bpSettings,rows);
  const canonicalJSON=mwCanonicalJSONString(canonicalObject);
  return { ok:true, results, blueprint:bp, mode:bpMode, seed:bpSeed, rows, metrics, bpSettings, canonicalObject, canonicalJSON };
}

