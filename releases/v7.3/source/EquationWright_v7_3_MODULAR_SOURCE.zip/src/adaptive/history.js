function mwHistoryParseAttempt(results){
  if(!results || typeof results!=='object' || results.format!=='mw-quiz-results-v1') return mwAdaptiveFailure('invalid-results-format','Unsupported history file.');
  const bp=results.blueprint;
  if(!bp || typeof bp!=='object' || bp.format!==MW_BLUEPRINT_FORMAT || !String(bp.appVersion||'').trim()) return mwAdaptiveFailure('missing-or-invalid-blueprint','History result lacks a structurally valid blueprint.');
  const mode=mwNormalizeMode(bp.mode);
  if(!mode) return mwAdaptiveFailure('mode-mismatch','History result lacks a mode.');
  const seed=mwNormalizeWorksheetSeed(bp.seed);
  if(results.mode!=null && mwNormalizeMode(results.mode)!==mode) return mwAdaptiveFailure('mode-mismatch','History result mode does not match its blueprint.');
  if(results.seed!=null && mwNormalizeWorksheetSeed(results.seed)!==seed) return mwAdaptiveFailure('seed-mismatch','History result seed does not match its blueprint.');
  const bpSettings=mwCanonicalBlueprintSettings(bp,false);
  if(!bpSettings) return mwAdaptiveFailure('missing-or-invalid-blueprint','History blueprint settings are malformed.');
  if(!Array.isArray(results.questions)||!results.questions.length) return mwAdaptiveFailure('no-question-rows','History result contains no question rows.');
  const rows=[];
  for(let i=0;i<results.questions.length;i++){
    const nr=mwNormalizeAdaptiveRow(results.questions[i],i,null);
    if(!nr.ok) return nr;
    rows.push(nr.row);
  }
  const metrics=mwRowMetrics(rows);
  const canonicalObject=mwCanonicalAttemptObject(bp.appVersion,seed,mode,bpSettings,rows);
  const canonicalJSON=mwCanonicalJSONString(canonicalObject);
  const exported=mwValidDateRecord(results.exportedAt);
  const alias=mwAliasInfo(results.studentAlias);
  const positiveUnitSet=bpSettings.counts.map(pair=>pair[0]).sort(mwLexCmp);
  const repEvidence=mwCanonicalJSONString(rows.map(r=>[r.n,r.unit,r.topicKey,r.mistakeType,r.result]));
  return { ok:true, raw:results, blueprint:bp, appVersion:String(bp.appVersion), mode, seed, rows, metrics, bpSettings, canonicalObject, canonicalJSON, exported, alias, positiveUnitSet, repEvidence };
}

function mwEvidenceAnalysis(validated){
  const misses=validated.rows.filter(r=>r.result==='incorrect');
  const visible=unitsForMode(validated.mode);
  const vIndex=new Map(visible.map((u,i)=>[u.id,i]));
  const maps={mistake:new Map(),topic:new Map(),unit:new Map()};
  const add=(map,key,row,extra={})=>{
    if(!map.has(key)) map.set(key,{key,rows:[],...extra});
    map.get(key).rows.push(row);
  };
  for(const row of misses){
    if(row.mistakeType) add(maps.mistake,row.mistakeType,row,{type:'mistake',text:row.mistakeType});
    if(row.topicKey) add(maps.topic,row.unit+'\u0000'+row.topicKey,row,{type:'topic',unit:row.unit,topic:row.topicKey});
    add(maps.unit,row.unit,row,{type:'unit',unit:row.unit});
  }
  const finish=(rec)=>{
    rec.count=rec.rows.length;
    rec.earliestN=Math.min(...rec.rows.map(r=>r.n));
    rec.earliestIndex=Math.min(...rec.rows.filter(r=>r.n===rec.earliestN).map(r=>r._index));
    rec.units=[...new Set(rec.rows.map(r=>r.unit))];
    return rec;
  };
  const arr={mistake:[...maps.mistake.values()].map(finish),topic:[...maps.topic.values()].map(finish),unit:[...maps.unit.values()].map(finish)};
  const cmp=(type)=>(a,b)=>{
    if(b.count!==a.count) return b.count-a.count;
    if(a.earliestN!==b.earliestN) return a.earliestN-b.earliestN;
    if(a.earliestIndex!==b.earliestIndex) return a.earliestIndex-b.earliestIndex;
    if(type==='topic'){
      const ui=(vIndex.get(a.unit)??1e9)-(vIndex.get(b.unit)??1e9); if(ui) return ui;
      return mwLexCmp(a.topic,b.topic);
    }
    if(type==='unit') return (vIndex.get(a.unit)??1e9)-(vIndex.get(b.unit)??1e9);
    return mwLexCmp(a.text,b.text);
  };
  arr.mistake.sort(cmp('mistake')); arr.topic.sort(cmp('topic')); arr.unit.sort(cmp('unit'));
  let confidence='None', tier='none', candidates=[];
  const hm=arr.mistake.filter(x=>x.count>=2);
  const mt=arr.topic.filter(x=>x.count>=2);
  const mu=arr.unit.filter(x=>x.count>=2);
  if(hm.length){ confidence='High'; tier='mistake'; candidates=hm; }
  else if(mt.length){ confidence='Medium'; tier='topic'; candidates=mt; }
  else if(mu.length){ confidence='Medium'; tier='unit'; candidates=mu; }
  else if(misses.length){ confidence='Low'; tier='unit'; candidates=arr.unit; }
  return {misses,maps,arr,confidence,tier,candidates,visible,vIndex,cmp};
}
function mwSignalCountInAnalysis(analysis,type,key){
  const rec=analysis.arr[type]?.find(x=>x.key===key); return rec?rec.count:0;
}
function mwSignalRowsInAnalysis(analysis,type,key){
  const rec=analysis.arr[type]?.find(x=>x.key===key); return rec?rec.rows:[];
}
function mwSelectReviewSignal(latestAnalysis, historyAnalyses){
  if(latestAnalysis.confidence==='None') return null;
  const type=latestAnalysis.tier;
  let candidates=[...latestAnalysis.candidates];
  if(historyAnalyses && historyAnalyses.length>1){
    const latest=historyAnalyses[historyAnalyses.length-1];
    const prev=historyAnalyses[historyAnalyses.length-2]||null;
    const third=historyAnalyses[historyAnalyses.length-3]||null;
    candidates=candidates.map(c=>({...c,historyPriority:3*c.count+2*(prev?mwSignalCountInAnalysis(prev,type,c.key):0)+(third?mwSignalCountInAnalysis(third,type,c.key):0)}));
    const baseCmp=latestAnalysis.cmp(type);
    candidates.sort((a,b)=> (b.historyPriority-a.historyPriority) || (b.count-a.count) || baseCmp(a,b));
  }
  return candidates[0]||null;
}
function mwTargetUnitRecords(latestAnalysis, selectedSignal, historyAnalyses){
  if(!selectedSignal) return [];
  const latestRows=selectedSignal.rows;
  const vIndex=latestAnalysis.vIndex;
  const byUnit=new Map();
  for(const row of latestRows){
    if(!byUnit.has(row.unit)) byUnit.set(row.unit,{unit:row.unit,rows:[]});
    byUnit.get(row.unit).rows.push(row);
  }
  let recs=[...byUnit.values()].map(rec=>{
    rec.count=rec.rows.length;
    rec.earliestN=Math.min(...rec.rows.map(r=>r.n));
    rec.earliestIndex=Math.min(...rec.rows.filter(r=>r.n===rec.earliestN).map(r=>r._index));
    return rec;
  });
  if(historyAnalyses && historyAnalyses.length>1){
    const type=latestAnalysis.tier, key=selectedSignal.key;
    const prev=historyAnalyses[historyAnalyses.length-2]||null, third=historyAnalyses[historyAnalyses.length-3]||null;
    recs.forEach(rec=>{
      const pc=prev?mwSignalRowsInAnalysis(prev,type,key).filter(r=>r.unit===rec.unit).length:0;
      const tc=third?mwSignalRowsInAnalysis(third,type,key).filter(r=>r.unit===rec.unit).length:0;
      rec.historyPriority=3*rec.count+2*pc+tc;
    });
    recs.sort((a,b)=>(b.historyPriority-a.historyPriority)||(b.count-a.count)||(a.earliestN-b.earliestN)||(a.earliestIndex-b.earliestIndex)||((vIndex.get(a.unit)??1e9)-(vIndex.get(b.unit)??1e9)));
  }else{
    recs.sort((a,b)=>(b.count-a.count)||(a.earliestN-b.earliestN)||(a.earliestIndex-b.earliestIndex)||((vIndex.get(a.unit)??1e9)-(vIndex.get(b.unit)??1e9)));
  }
  return recs.slice(0,2);
}
function mwReviewTopicLocks(validated, analysis, selectedSignal, targetUnits){
  if(!selectedSignal || !['High','Medium'].includes(analysis.confidence)) return {};
  const out={};
  for(const tr of targetUnits){
    const rows=selectedSignal.rows.filter(r=>r.unit===tr.unit);
    if(!rows.length || rows.some(r=>!r.topicKey)) continue;
    const ids=[...new Set(rows.map(r=>r.topicKey))];
    if(ids.length!==1) continue;
    const valid=new Set(ensureUnitTopics(tr.unit).map(t=>t.id));
    if(valid.has(ids[0])) out[tr.unit]={list:[ids[0]],none:false};
  }
  return out;
}
function mwReviewUnitCapacity(unitId,candidateN){
  const n=(Gens[unitId]||[]).length;
  if(n<=0) return 0;
  if(n<=2) return 2;
  return candidateN;
}
function mwAdjacentReviewCandidates(validated,targetUnitIds){
  const visible=unitsForMode(validated.mode);
  const vIndex=new Map(visible.map((u,i)=>[u.id,i]));
  const targets=new Set(targetUnitIds);
  const sourcePositive=new Set((validated.bpSettings.counts||[]).filter(x=>x[1]>0).map(x=>x[0]));
  const available=visible.map(u=>u.id).filter(id=>!targets.has(id)&&(Gens[id]||[]).length>0);
  if(!targetUnitIds.length){
    return [
      ...available.filter(id=>sourcePositive.has(id)).sort((a,b)=>(vIndex.get(a)-vIndex.get(b))),
      ...available.filter(id=>!sourcePositive.has(id)).sort((a,b)=>(vIndex.get(a)-vIndex.get(b)))
    ];
  }
  const dist=id=>Math.min(...targetUnitIds.map(t=>Math.abs(vIndex.get(id)-vIndex.get(t))));
  const rank=list=>list.sort((a,b)=>(dist(a)-dist(b))||((vIndex.get(a)??1e9)-(vIndex.get(b)??1e9)));
  return [...rank(available.filter(id=>sourcePositive.has(id))),...rank(available.filter(id=>!sourcePositive.has(id)))];
}
function mwCycleAllocate(counts,list,amount,candidateN){
  let remain=amount, idx=0, stagnant=0;
  if(remain<=0) return true;
  if(!list.length) return false;
  while(remain>0){
    const unit=list[idx%list.length]; idx++;
    const cap=mwReviewUnitCapacity(unit,candidateN);
    if((counts[unit]||0)<cap){ counts[unit]=(counts[unit]||0)+1; remain--; stagnant=0; }
    else stagnant++;
    if(stagnant>=list.length) return false;
  }
  return true;
}
function mwTargetBudget(confidence,N){
  if(confidence==='High'||confidence==='Medium') return Math.floor((65*N+50)/100);
  if(confidence==='Low') return Math.floor((40*N)/100);
  return 0;
}
function mwTryAllocateReview(validated,analysis,targetUnits,requestedN,purpose){
  const visible=unitsForMode(validated.mode).map(u=>u.id);
  const targetIds=targetUnits.map(x=>x.unit);
  const adjacent=mwAdjacentReviewCandidates(validated,targetIds);
  for(let candidateN=requestedN; candidateN>=MW_SMART_REVIEW_MIN; candidateN--){
    const counts=Object.fromEntries(visible.map(id=>[id,0]));
    if(!targetIds.length){
      if(mwCycleAllocate(counts,adjacent,candidateN,candidateN)) return {ok:true,counts,N:candidateN,targetBudget:0,adjacent};
      continue;
    }
    const targetBudget=mwTargetBudget(analysis.confidence,candidateN);
    const weights=targetUnits.map(t=>t.count);
    const weightSum=weights.reduce((a,b)=>a+b,0);
    const provisional=[];
    let floorSum=0;
    for(let i=0;i<targetUnits.length;i++){
      const exact=targetBudget*weights[i]/weightSum;
      const floor=Math.floor(exact); floorSum+=floor;
      provisional.push({rec:targetUnits[i],count:floor,remainder:exact-floor});
    }
    let rem=targetBudget-floorSum;
    provisional.sort((a,b)=>(b.remainder-a.remainder)||(b.rec.count-a.rec.count)||(a.rec.earliestN-b.rec.earliestN)||(a.rec.earliestIndex-b.rec.earliestIndex)||((analysis.vIndex.get(a.rec.unit)??1e9)-(analysis.vIndex.get(b.rec.unit)??1e9)));
    for(let i=0;i<rem;i++) provisional[i%provisional.length].count++;
    let overflow=0;
    for(const p of provisional){
      const cap=mwReviewUnitCapacity(p.rec.unit,candidateN);
      counts[p.rec.unit]=Math.min(p.count,cap);
      overflow+=Math.max(0,p.count-cap);
    }
    const targetRank=targetUnits.map(t=>t.unit);
    if(overflow && !mwCycleAllocate(counts,targetRank,overflow,candidateN)){
      // target capacity exhausted: spill the rest to adjacent in the next step
      let allocatedTarget=targetRank.reduce((s,id)=>s+(counts[id]||0),0);
      overflow=Math.max(0,targetBudget-allocatedTarget);
    }else overflow=0;
    if(overflow && !mwCycleAllocate(counts,adjacent,overflow,candidateN)) continue;
    const ordinary=candidateN-targetBudget;
    if(!mwCycleAllocate(counts,adjacent,ordinary,candidateN)) continue;
    const total=Object.values(counts).reduce((a,b)=>a+b,0);
    if(total!==candidateN) continue;
    let capsOk=true;
    for(const id of visible) if(counts[id]>mwReviewUnitCapacity(id,candidateN)) capsOk=false;
    if(!capsOk) continue;
    return {ok:true,counts,N:candidateN,targetBudget,adjacent};
  }
  return mwAdaptiveFailure('insufficient-live-capacity','The current course profile does not have enough live generator capacity for a 5-question Smart Review.');
}
function mwReviewBranch(validated,analysis){
  const m=validated.metrics;
  if(m.incorrect===0 && m.unanswered===0) return {purpose:'challenge',requestedN:6,variety:3};
  if(m.incorrect===0 && m.answered>0 && m.unanswered>0) return {purpose:'pacing-retry',requestedN:5,variety:2};
  if(m.answered===0) return {purpose:'starter-diagnostic',requestedN:5,variety:2};
  return {purpose:'remediation',requestedN:Math.max(MW_SMART_REVIEW_MIN,Math.min(MW_SMART_REVIEW_MAX,m.incorrect+4)),variety:2};
}
function mwSortedCountMap(counts){ const out={}; for(const k of Object.keys(counts||{}).sort()) out[k]=counts[k]; return out; }
function mwSortedTopicLockMap(topics){
  const out={}; for(const k of Object.keys(topics||{}).sort()) out[k]={list:[...(topics[k].list||[])].sort(mwLexCmp),none:false}; return out;
}
function mwBuildSmartReviewSeed(validated, historyValidated, purpose, counts, topics, variety){
  const history=(historyValidated&&historyValidated.length?historyValidated:[validated]);
  const seedInput={
    schema:'equationwright-smart-review-seed-v1',
    appVersion:MW_APP_VERSION,
    historyWindow:history.map(v=>v.canonicalJSON),
    purpose,
    counts:mwSortedCountMap(counts),
    topics:mwSortedTopicLockMap(topics),
    variety
  };
  const proposed='SmartReview-'+String(fnv1a(mwCanonicalJSONString(seedInput))>>>0);
  return proposed===validated.seed ? proposed+'-R' : proposed;
}
function buildLocalRemediationBlueprint(results, options={}){
  const validated=mwValidateAdaptiveResult(results);
  if(!validated.ok) return validated;
  let historyValidated=Array.isArray(options.historyValidated)?options.historyValidated.filter(v=>v&&v.ok):[];
  if(!historyValidated.length || historyValidated[historyValidated.length-1].canonicalJSON!==validated.canonicalJSON) historyValidated=[validated];
  historyValidated=historyValidated.slice(-3);
  const historyAnalyses=historyValidated.map(mwEvidenceAnalysis);
  const analysis=historyAnalyses[historyAnalyses.length-1];
  const branch=mwReviewBranch(validated,analysis);
  let selectedSignal=null, targetUnits=[];
  if(analysis.confidence!=='None'){
    selectedSignal=mwSelectReviewSignal(analysis,historyAnalyses);
    targetUnits=mwTargetUnitRecords(analysis,selectedSignal,historyAnalyses);
  }
  const allocation=mwTryAllocateReview(validated,analysis,targetUnits,branch.requestedN,branch.purpose);
  if(!allocation.ok) return allocation;
  const topicLocks=mwReviewTopicLocks(validated,analysis,selectedSignal,targetUnits);
  const bp=JSON.parse(JSON.stringify(validated.blueprint));
  delete bp.picks; delete bp.generatedAt; delete bp.submitUrl; delete bp.classId; delete bp.assignmentId;
  bp.format=MW_BLUEPRINT_FORMAT; bp.appVersion=MW_APP_VERSION; bp.mode=validated.mode;
  bp.quizMode=true; bp.pages={answers:false,workedSolutions:false}; bp.counts=mwSortedCountMap(allocation.counts); bp.variety=branch.variety;
  delete bp.topicFilters;
  if(Object.keys(topicLocks).length) bp.topics=mwSortedTopicLockMap(topicLocks); else delete bp.topics;
  bp.seed=mwBuildSmartReviewSeed(validated,historyValidated,branch.purpose,bp.counts,bp.topics||{},bp.variety);
  const pre=mwPreflightBlueprint(bp);
  if(!pre.ok) return mwAdaptiveFailure('local-review-preflight-failed','The completed Local Smart Review failed common blueprint validation.',{error:pre.error});
  return {ok:true,blueprint:bp,meta:{purpose:branch.purpose,confidence:analysis.confidence,requestedN:branch.requestedN,finalN:allocation.N,targetBudget:allocation.targetBudget,targetUnits:targetUnits.map(x=>x.unit),targetSignal:selectedSignal?{type:analysis.tier,key:selectedSignal.key}:null,topicLocks:mwSortedTopicLockMap(topicLocks)}};
}

function mwHistoryRecordSort(a,b){
  if(a.exported.valid && b.exported.valid){ if(a.exported.ms!==b.exported.ms) return a.exported.ms-b.exported.ms; return mwLexCmp(a.canonicalJSON,b.canonicalJSON); }
  if(a.exported.valid) return -1;
  if(b.exported.valid) return 1;
  return mwLexCmp(a.canonicalJSON,b.canonicalJSON);
}
function mwHistoryRepSort(a,b){
  if(a.exported.valid && b.exported.valid && a.exported.ms!==b.exported.ms) return a.exported.ms-b.exported.ms;
  if(a.exported.valid!==b.exported.valid) return a.exported.valid?-1:1;
  const cj=mwLexCmp(a.canonicalJSON,b.canonicalJSON); if(cj) return cj;
  const ds=mwLexCmp(a.alias.display,b.alias.display); if(ds) return ds;
  return mwLexCmp(a.repEvidence,b.repEvidence);
}
function mwBuildHistoryModel(rawList){
  const groupsMap=new Map(), skipped={};
  for(const raw of (Array.isArray(rawList)?rawList:[])){
    const rec=mwHistoryParseAttempt(raw);
    if(!rec.ok){ skipped[rec.code]=(skipped[rec.code]||0)+1; continue; }
    if(!groupsMap.has(rec.alias.key)) groupsMap.set(rec.alias.key,{key:rec.alias.key,unaliased:rec.alias.unaliased,rawRecords:[]});
    groupsMap.get(rec.alias.key).rawRecords.push(rec);
  }
  const groups=[];
  for(const g of groupsMap.values()){
    const displayCandidates=[...g.rawRecords].sort(mwHistoryRepSort);
    g.display=g.unaliased?'This learner (unaliased)':(displayCandidates[0]?.alias.display||'Learner');
    const dedupMap=new Map();
    for(const rec of g.rawRecords){
      const old=dedupMap.get(rec.canonicalJSON);
      if(!old){ dedupMap.set(rec.canonicalJSON,{...rec,_duplicates:[rec]}); continue; }
      old._duplicates.push(rec);
      const candidates=[old,...old._duplicates].filter(Boolean).sort(mwHistoryRepSort);
      const best=candidates[0];
      // Preserve deterministic earliest timestamp and a deterministic raw representative.
      old.exported=best.exported;
      if(mwLexCmp(best.repEvidence,old.repEvidence)<0 || (best.exported.valid && (!old.exported.valid || best.exported.ms<=old.exported.ms))){ old.raw=best.raw; old.rows=best.rows; old.metrics=best.metrics; old.repEvidence=best.repEvidence; }
    }
    g.attempts=[...dedupMap.values()].sort(mwHistoryRecordSort);
    g.attemptCount=g.attempts.length;
    groups.push(g);
  }
  groups.sort((a,b)=> a.unaliased!==b.unaliased ? (a.unaliased?1:-1) : mwLexCmp(a.key,b.key));
  return {groups,skipped,acceptedAttempts:groups.reduce((s,g)=>s+g.attempts.length,0)};
}
function mwSamePositiveUnits(a,b){ return JSON.stringify(a.positiveUnitSet)===JSON.stringify(b.positiveUnitSet); }
function mwPctPoints(v){ return Math.round(v*1000)/10; }
function mwHistoryTrend(group){
  const attempts=group?.attempts||[]; if(!attempts.length) return {label:'Insufficient data',message:'No attempts.'};
  const latest=attempts[attempts.length-1];
  let prev=null;
  for(let i=attempts.length-2;i>=0;i--){ if(attempts[i].appVersion===latest.appVersion && attempts[i].mode===latest.mode){ prev=attempts[i]; break; } }
  if(!prev) return {label:'Insufficient data',latest,previous:null};
  const accDelta=(latest.metrics.accuracy==null||prev.metrics.accuracy==null)?null:mwPctPoints(latest.metrics.accuracy-prev.metrics.accuracy);
  const compDelta=mwPctPoints(latest.metrics.completion-prev.metrics.completion);
  if(!mwSamePositiveUnits(latest,prev)) return {label:'Different practice mix',message:'Different practice mix — no direct trend label.',latest,previous:prev,accuracyDelta:accDelta,completionDelta:compDelta};
  if(accDelta==null) return {label:'Insufficient data',latest,previous:prev,accuracyDelta:null,completionDelta:compDelta};
  let label='Mixed / stable';
  if((accDelta>=5 && compDelta>=-5)||(compDelta>=10 && accDelta>=-5)) label='Improving';
  else if((accDelta<=-5 && compDelta<5)||(compDelta<=-10 && accDelta<5)) label='Needs attention';
  return {label,latest,previous:prev,accuracyDelta:accDelta,completionDelta:compDelta};
}
function mwHistoryTopicTrends(group){
  const trend=mwHistoryTrend(group); if(!trend.latest||!trend.previous||trend.label==='Different practice mix') return [];
  const a=trend.previous.metrics,b=trend.latest.metrics, keys=[...new Set([...Object.keys(a.topicAnswered),...Object.keys(b.topicAnswered)])].sort(mwLexCmp);
  const out=[];
  for(const key of keys){
    const ae=a.topicAnswered[key]||0, be=b.topicAnswered[key]||0; if(ae<2||be<2) continue;
    const ar=(a.topicIncorrect[key]||0)/ae, br=(b.topicIncorrect[key]||0)/be, delta=mwPctPoints(br-ar);
    out.push({key,incorrectRateDelta:delta,label:delta<=-20?'Improving':'No improvement claim'});
  }
  return out;
}
function mwHistoryMistakeTrends(group){
  const trend=mwHistoryTrend(group); if(!trend.latest||!trend.previous||trend.label==='Different practice mix') return [];
  const prev=trend.previous, latest=trend.latest;
  const patterns=[...new Set([...Object.keys(prev.metrics.mistakePatterns||{}),...Object.keys(latest.metrics.mistakePatterns||{})])].sort(mwLexCmp);
  const out=[];
  for(const pattern of patterns){
    const previousCount=prev.metrics.mistakePatterns?.[pattern]||0;
    const latestCount=latest.metrics.mistakePatterns?.[pattern]||0;
    if(previousCount<2 && latestCount<2) continue;
    let label=latestCount>=2?'Recurring':'Count only';
    if(previousCount>=2 && latestCount<=1){
      const contexts=[];
      for(const row of prev.rows){
        if(row.result!=='incorrect'||row.mistakeType!==pattern) continue;
        const k=row.unit+'\u0000'+(row.topicKey||'');
        if(!contexts.some(c=>c.key===k)) contexts.push({key:k,unit:row.unit,topicKey:row.topicKey});
      }
      let exposure=0;
      for(const row of latest.rows){
        if(row.result==='unanswered') continue;
        if(contexts.some(c=>row.unit===c.unit && (c.topicKey==null || row.topicKey===c.topicKey))) exposure++;
      }
      if(exposure>=2) label='Resolved in latest';
    }
    out.push({pattern,previousCount,latestCount,label});
  }
  return out;
}
function mwHistoryCurrentWindow(group){
  const attempts=group?.attempts||[];
  let latestIndex=-1;
  for(let i=attempts.length-1;i>=0;i--){ if(attempts[i].appVersion===MW_APP_VERSION){ latestIndex=i; break; } }
  if(latestIndex<0) return mwAdaptiveFailure('version-mismatch','This history group has no current-version result for targeted Smart Review.');
  const latestRec=attempts[latestIndex];
  const latestV=mwValidateAdaptiveResult(latestRec.raw); if(!latestV.ok) return latestV;
  const window=[];
  for(let i=0;i<=latestIndex;i++){
    const rec=attempts[i];
    if(rec.appVersion!==MW_APP_VERSION||rec.mode!==latestRec.mode) continue;
    const v=mwValidateAdaptiveResult(rec.raw); if(v.ok) window.push(v);
  }
  const last3=window.slice(-3);
  if(!last3.length || last3[last3.length-1].canonicalJSON!==latestV.canonicalJSON) return mwAdaptiveFailure('missing-or-invalid-blueprint','Latest current-version history attempt is not eligible for targeted review.');
  return {ok:true,latest:latestV,historyValidated:last3};
}
function mwBuildHistorySmartReview(group){
  const w=mwHistoryCurrentWindow(group); if(!w.ok) return w;
  return buildLocalRemediationBlueprint(w.latest.results,{historyValidated:w.historyValidated});
}
function mwAggregateAttemptRecords(records){
  const agg={scoreSum:0,pctSum:0,unansweredSum:0,missedByUnit:{},missedByTopic:{},mistakePatterns:{},unansweredByUnit:{}};
  for(const rec of records){
    const m=rec.metrics; agg.scoreSum+=m.score; agg.pctSum+=m.quizPercent*100; agg.unansweredSum+=m.unanswered;
    for(const [k,v] of Object.entries(m.missedByUnit)) agg.missedByUnit[k]=(agg.missedByUnit[k]||0)+v;
    for(const [k,v] of Object.entries(m.missedByTopic)) agg.missedByTopic[k]=(agg.missedByTopic[k]||0)+v;
    for(const [k,v] of Object.entries(m.mistakePatterns)) agg.mistakePatterns[k]=(agg.mistakePatterns[k]||0)+v;
    for(const [k,v] of Object.entries(m.unansweredByUnit)) agg.unansweredByUnit[k]=(agg.unansweredByUnit[k]||0)+v;
  }
  return agg;
}
function mwNestedUnitTopicFromFlat(flat){
  const out={};
  for(const [key,value] of Object.entries(flat||{})){
    const pos=key.indexOf('\u0000'); if(pos<0) continue;
    const unitId=key.slice(0,pos), topicId=key.slice(pos+1);
    if(!unitId||!topicId) continue;
    if(!out[unitId]) out[unitId]={};
    out[unitId][topicId]=(out[unitId][topicId]||0)+value;
  }
  return out;
}
function mwClassViewData(rawList,view='attempts'){
  const model=mwBuildHistoryModel(rawList);
  const attempts=model.groups.flatMap(g=>g.attempts.map(rec=>({...rec,_group:g})));
  const aliasGroups=model.groups.filter(g=>!g.unaliased);
  const unaliasedGroup=model.groups.find(g=>g.unaliased)||null;
  const uniqueLatest=aliasGroups.map(g=>({...g.attempts[g.attempts.length-1],_group:g})).filter(Boolean);
  const selected=view==='unique'?uniqueLatest:attempts;
  return {model,view,attempts,uniqueLatest,selected,aliasGroups,attemptCount:attempts.length,uniqueAliasCount:aliasGroups.length,unaliasedAttemptCount:unaliasedGroup?unaliasedGroup.attempts.length:0,aggregate:mwAggregateAttemptRecords(selected)};
}

let PERSONAL_HISTORY_RAW=[];
let PERSONAL_HISTORY_IMPORT_SKIPPED={};
let MW_HISTORY_MODEL=null;
function mwHistoryTopicDisplay(key){
  const [unitId,topicId]=String(key).split('\u0000');
  return mwReviewTopicLabel(unitId,topicId||null);
}
function mwSignedPP(v){ if(v==null) return '—'; return (v>0?'+':'')+Number(v).toFixed(1)+' pp'; }
function mwRenderPersonalHistory(){
  const host=document.getElementById('personalHistoryDash'); if(!host) return;
  MW_HISTORY_MODEL=mwBuildHistoryModel(PERSONAL_HISTORY_RAW);
  const m=MW_HISTORY_MODEL;
  const skipped={...m.skipped}; for(const [k,v] of Object.entries(PERSONAL_HISTORY_IMPORT_SKIPPED)) skipped[k]=(skipped[k]||0)+v;
  const skipCount=Object.values(skipped).reduce((a,b)=>a+b,0);
  if(!m.groups.length){
    const skippedHtml=skipCount?'<div class="small" style="margin-top:6px">Skipped: '+Object.entries(skipped).sort((a,b)=>mwLexCmp(a[0],b[0])).map(([k,v])=>escHtml(k)+': '+v).join(' · ')+'</div>':'';
    host.innerHTML='<div class="small">No practice-history files loaded.</div>'+skippedHtml; return;
  }
  let html=`<div class="small" style="margin-bottom:8px">${m.acceptedAttempts} nonduplicate attempt${m.acceptedAttempts===1?'':'s'} in ${m.groups.length} learner group${m.groups.length===1?'':'s'}${skipCount?` · ${skipCount} skipped`:''}. Files stay in this tab only.</div>`;
  if(skipCount) html+=`<div class="small" style="margin-bottom:8px"><b>Skipped imports by reason:</b> ${Object.entries(skipped).sort((a,b)=>mwLexCmp(a[0],b[0])).map(([k,v])=>escHtml(k)+': '+v).join(' · ')}</div>`;
  m.groups.forEach((g,gi)=>{
    const latest=g.attempts[g.attempts.length-1]; const trend=mwHistoryTrend(g);
    const topics=mwHistoryTopicTrends(g); const mistakes=mwHistoryMistakeTrends(g);
    const acc=latest.metrics.accuracy==null?'—':(latest.metrics.accuracy*100).toFixed(1)+'%'; const comp=(latest.metrics.completion*100).toFixed(1)+'%';
    html+=`<div style="border:1px solid var(--line);border-radius:10px;padding:10px;margin:8px 0"><div style="font-weight:950">${escHtml(g.display)}</div><div class="small">${g.attemptCount} attempt${g.attemptCount===1?'':'s'} · latest ${latest.exported.valid?escHtml(latest.exported.iso):'date unavailable'} · accuracy ${acc} · completion ${comp}</div>`;
    let lastVersion=null;
    for(const rec of g.attempts){
      if(rec.appVersion!==lastVersion){ html+=`<div class="small" style="margin-top:8px;padding-top:6px;border-top:1px solid var(--line);font-weight:900">Version ${escHtml(rec.appVersion)}</div>`; lastVersion=rec.appVersion; }
      const racc=rec.metrics.accuracy==null?'—':(rec.metrics.accuracy*100).toFixed(1)+'%'; const rcomp=(rec.metrics.completion*100).toFixed(1)+'%';
      html+=`<div class="small" style="padding:3px 0">${rec.exported.valid?escHtml(rec.exported.iso):'date unavailable'} · ${escHtml(rec.mode)} · ${rec.metrics.score}/${rec.metrics.total} · accuracy ${racc} · completion ${rcomp}</div>`;
    }
    html+=`<div class="small" style="margin-top:7px">Trend: <b>${escHtml(trend.label)}</b>${trend.message?' — '+escHtml(trend.message):''}</div>`;
    if(trend.previous) html+=`<div class="small">Accuracy delta: ${escHtml(mwSignedPP(trend.accuracyDelta))} · Completion delta: ${escHtml(mwSignedPP(trend.completionDelta))}</div>`;
    if(topics.length) html+=`<div class="small" style="margin-top:6px"><b>Topic trends:</b> ${topics.map(t=>escHtml(mwHistoryTopicDisplay(t.key))+': '+escHtml(t.label)+' ('+escHtml(mwSignedPP(t.incorrectRateDelta))+')').join(' · ')}</div>`;
    if(mistakes.length) html+=`<div class="small" style="margin-top:6px"><b>Mistake patterns:</b> ${mistakes.map(x=>escHtml(x.pattern)+': '+escHtml(x.label)+' ('+x.previousCount+' → '+x.latestCount+')').join(' · ')}</div>`;
    html+=`<button type="button" class="miniBtn historyStartReviewBtn" data-history-index="${gi}" style="margin-top:8px">Start next Smart Review</button></div>`;
  });
  host.innerHTML=html;
}
function mwPersonalHistoryImportFn(){ document.getElementById('personalHistoryFile')?.click(); }
async function mwOnPersonalHistoryFiles(ev){
  const files=[...(ev.target.files||[])]; let added=0,unknown=0;
  for(const f of files){
    try{
      const obj=JSON.parse(await f.text()); PERSONAL_HISTORY_RAW.push(obj);
      if(obj&&obj.format==='mw-quiz-results-v1') added++; else unknown++;
    }catch(e){ unknown++; PERSONAL_HISTORY_IMPORT_SKIPPED['invalid-results-format']=(PERSONAL_HISTORY_IMPORT_SKIPPED['invalid-results-format']||0)+1; }
  }
  ev.target.value=''; mwRenderPersonalHistory();
  if(unknown) alert(`${added} result file(s) loaded; ${unknown} unsupported/malformed file(s) skipped.`);
}
function mwStartHistoryReview(index){
  const g=MW_HISTORY_MODEL?.groups?.[index]; if(!g) return;
  const review=mwBuildHistorySmartReview(g);
  if(!review.ok){ alert(`Smart Review unavailable: ${review.message} [${review.code}]`); return; }
  applyBlueprint(review.blueprint); mwShowSmartReviewSummary(review,'History Smart Review'); document.getElementById('output')?.scrollIntoView({behavior:'smooth'});
}

let LOCAL_REVIEW_PENDING_BP=null;
function mwPrepareLocalReviewOffer(results){
  const review=buildLocalRemediationBlueprint(results);
  if(!review.ok) return {state:'failure-only',review};
  return {state:'local-review',review};
}
