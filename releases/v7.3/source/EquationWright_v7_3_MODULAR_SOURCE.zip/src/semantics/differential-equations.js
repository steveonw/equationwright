// ===== MTH 289 TYPED DE KERNEL =====
/*
 * Math Worksheet Builder — MTH 289 Differential Equations Spike v1
 *
 * Scope:
 * - Exact rational arithmetic.
 * - Two typed IVP families:
 *     1) y' = a x^n y, y(0) = y0
 *     2) y' + a y = b, y(0) = y0
 * - Typed canonical solution models.
 * - Exact family-specific validation.
 * - Deterministic numerical audit as defense in depth.
 * - Canary generator factories compatible with q/a/steps/vec/key.
 *
 * Non-goals:
 * - General CAS, parser, differentiator, simplifier, or ODE solver.
 */

const MW_DE_SCHEMA_VERSION = 1;

const MW_DE_FAMILIES = Object.freeze({
  separablePowerY: Object.freeze({
    code: 101,
    id: 'separable-power-y-v1',
    choiceFamily: 'de-v1:separable-exp-power'
  }),
  linearConstantForcing: Object.freeze({
    code: 201,
    id: 'linear-constant-forcing-v1',
    choiceFamily: 'de-v1:linear-equilibrium-exp'
  })
});

const MW_DE_AUDIT_POINTS = Object.freeze([
  -1.25,
  -0.7,
  0.31,
  0.83,
  1.4
]);

function mwGreatestCommonDivisor(left, right){
  let a = Math.abs(left);
  let b = Math.abs(right);

  while(b !== 0){
    const remainder = a % b;
    a = b;
    b = remainder;
  }

  return a;
}

function mwRational(numerator, denominator = 1){
  if(
    !Number.isSafeInteger(numerator) ||
    !Number.isSafeInteger(denominator) ||
    denominator === 0
  ){
    throw new RangeError('Invalid rational value.');
  }

  let n = numerator;
  let d = denominator;

  if(d < 0){
    n = -n;
    d = -d;
  }

  if(n === 0){
    return Object.freeze({
      numerator: 0,
      denominator: 1
    });
  }

  const divisor = mwGreatestCommonDivisor(n, d);

  return Object.freeze({
    numerator: n / divisor,
    denominator: d / divisor
  });
}

function mwValidateRational(value){
  if(
    !value ||
    typeof value !== 'object' ||
    !Number.isSafeInteger(value.numerator) ||
    !Number.isSafeInteger(value.denominator) ||
    value.denominator <= 0
  ){
    throw new TypeError('Invalid rational model.');
  }

  const normalized = mwRational(
    value.numerator,
    value.denominator
  );

  if(
    normalized.numerator !== value.numerator ||
    normalized.denominator !== value.denominator
  ){
    throw new TypeError('Rational model is not normalized.');
  }

  return true;
}

function mwRationalAdd(left, right){
  mwValidateRational(left);
  mwValidateRational(right);

  return mwRational(
    left.numerator * right.denominator +
      right.numerator * left.denominator,
    left.denominator * right.denominator
  );
}

function mwRationalSubtract(left, right){
  return mwRationalAdd(
    left,
    mwRationalNegate(right)
  );
}

function mwRationalMultiply(left, right){
  mwValidateRational(left);
  mwValidateRational(right);

  return mwRational(
    left.numerator * right.numerator,
    left.denominator * right.denominator
  );
}

function mwRationalNegate(value){
  mwValidateRational(value);

  return mwRational(
    -value.numerator,
    value.denominator
  );
}

function mwRationalEqual(left, right){
  mwValidateRational(left);
  mwValidateRational(right);

  return (
    left.numerator === right.numerator &&
    left.denominator === right.denominator
  );
}

function mwRationalIsZero(value){
  mwValidateRational(value);
  return value.numerator === 0;
}

function mwRationalIsOne(value){
  mwValidateRational(value);
  return value.numerator === value.denominator;
}

function mwRationalIsNegativeOne(value){
  mwValidateRational(value);
  return value.numerator === -value.denominator;
}

function mwRationalToNumber(value){
  mwValidateRational(value);
  return value.numerator / value.denominator;
}

function mwRationalKey(value){
  mwValidateRational(value);
  return `${value.numerator}/${value.denominator}`;
}

function mwRenderRational(value){
  mwValidateRational(value);

  if(value.denominator === 1){
    return String(value.numerator);
  }

  const sign = value.numerator < 0 ? '-' : '';
  const absoluteNumerator = Math.abs(value.numerator);

  return (
    `${sign}\\frac{${absoluteNumerator}}` +
    `{${value.denominator}}`
  );
}

function mwValidateVariableName(name){
  if(
    typeof name !== 'string' ||
    !/^[A-Za-z][A-Za-z0-9_]*$/.test(name)
  ){
    throw new TypeError(
      `Invalid variable name: ${String(name)}`
    );
  }

  return true;
}

function mwCloneRational(value){
  mwValidateRational(value);
  return mwRational(value.numerator, value.denominator);
}

function mwCreateInitialCondition(
  independentValue,
  dependentValue
){
  mwValidateRational(independentValue);
  mwValidateRational(dependentValue);

  return {
    type: 'initial-value',
    independentValue:
      mwCloneRational(independentValue),
    dependentValue:
      mwCloneRational(dependentValue)
  };
}

function mwCreateSeparablePowerQuestion({
  a,
  n,
  y0,
  independentVariable = 'x',
  dependentVariable = 'y'
}){
  mwValidateRational(a);
  mwValidateRational(y0);
  mwValidateVariableName(independentVariable);
  mwValidateVariableName(dependentVariable);

  if(!Number.isSafeInteger(n) || n < 0 || n > 12){
    throw new RangeError(
      'Separable exponent n must be an integer from 0 through 12.'
    );
  }

  if(mwRationalIsZero(a)){
    throw new RangeError(
      'Separable coefficient a must be nonzero.'
    );
  }

  return {
    schemaVersion: MW_DE_SCHEMA_VERSION,
    type: 'de-ivp',
    family: MW_DE_FAMILIES.separablePowerY.id,
    independentVariable,
    dependentVariable,
    parameters: {
      a: mwCloneRational(a),
      n
    },
    condition: mwCreateInitialCondition(
      mwRational(0),
      y0
    ),
    requestedForm: 'explicit',
    domain: {
      type: 'all-real'
    }
  };
}

function mwCreateLinearConstantQuestion({
  a,
  b,
  y0,
  independentVariable = 'x',
  dependentVariable = 'y',
  teachingMethod = 'integrating-factor'
}){
  mwValidateRational(a);
  mwValidateRational(b);
  mwValidateRational(y0);
  mwValidateVariableName(independentVariable);
  mwValidateVariableName(dependentVariable);

  if(mwRationalIsZero(a)){
    throw new RangeError(
      'Linear coefficient a must be nonzero.'
    );
  }

  return {
    schemaVersion: MW_DE_SCHEMA_VERSION,
    type: 'de-ivp',
    family:
      MW_DE_FAMILIES.linearConstantForcing.id,
    independentVariable,
    dependentVariable,
    parameters: {
      a: mwCloneRational(a),
      b: mwCloneRational(b)
    },
    condition: mwCreateInitialCondition(
      mwRational(0),
      y0
    ),
    requestedForm: 'explicit',
    teachingMethod,
    domain: {
      type: 'all-real'
    }
  };
}

function mwValidateDEQuestionModel(question){
  if(
    !question ||
    typeof question !== 'object' ||
    question.schemaVersion !==
      MW_DE_SCHEMA_VERSION ||
    question.type !== 'de-ivp'
  ){
    throw new TypeError(
      'Invalid differential-equation question model.'
    );
  }

  mwValidateVariableName(
    question.independentVariable
  );

  mwValidateVariableName(
    question.dependentVariable
  );

  if(
    !question.condition ||
    question.condition.type !==
      'initial-value'
  ){
    throw new TypeError(
      'An initial-value condition is required.'
    );
  }

  mwValidateRational(
    question.condition.independentValue
  );

  mwValidateRational(
    question.condition.dependentValue
  );

  if(
    !mwRationalIsZero(
      question.condition.independentValue
    )
  ){
    throw new RangeError(
      'The v1 spike supports only initial point 0.'
    );
  }

  if(
    !question.domain ||
    question.domain.type !== 'all-real'
  ){
    throw new TypeError(
      'The v1 spike supports only all-real domains.'
    );
  }

  if(
    question.family ===
    MW_DE_FAMILIES.separablePowerY.id
  ){
    mwValidateRational(question.parameters.a);

    if(
      mwRationalIsZero(
        question.parameters.a
      ) ||
      !Number.isSafeInteger(
        question.parameters.n
      ) ||
      question.parameters.n < 0
    ){
      throw new TypeError(
        'Invalid separable question parameters.'
      );
    }

    return true;
  }

  if(
    question.family ===
    MW_DE_FAMILIES.linearConstantForcing.id
  ){
    mwValidateRational(question.parameters.a);
    mwValidateRational(question.parameters.b);

    if(
      mwRationalIsZero(
        question.parameters.a
      )
    ){
      throw new TypeError(
        'Invalid linear question parameters.'
      );
    }

    return true;
  }

  throw new RangeError(
    `Unsupported DE family: ${String(question.family)}`
  );
}

function mwCreateExpPowerSolution({
  amplitude,
  exponentCoefficient,
  exponentPower
}){
  mwValidateRational(amplitude);
  mwValidateRational(exponentCoefficient);

  if(
    !Number.isSafeInteger(exponentPower) ||
    exponentPower < 1
  ){
    throw new RangeError(
      'Exponent power must be a positive integer.'
    );
  }

  return {
    schemaVersion: MW_DE_SCHEMA_VERSION,
    type: 'exp-power',
    amplitude: mwCloneRational(amplitude),
    exponentCoefficient:
      mwCloneRational(exponentCoefficient),
    exponentPower
  };
}

function mwCreateEquilibriumExpSolution({
  equilibrium,
  transient,
  rate
}){
  mwValidateRational(equilibrium);
  mwValidateRational(transient);
  mwValidateRational(rate);

  return {
    schemaVersion: MW_DE_SCHEMA_VERSION,
    type: 'equilibrium-plus-exponential',
    equilibrium: mwCloneRational(equilibrium),
    transient: mwCloneRational(transient),
    rate: mwCloneRational(rate)
  };
}

function mwValidateDESolutionModel(solution){
  if(
    !solution ||
    typeof solution !== 'object' ||
    solution.schemaVersion !==
      MW_DE_SCHEMA_VERSION
  ){
    throw new TypeError(
      'Invalid differential-equation solution model.'
    );
  }

  if(solution.type === 'exp-power'){
    mwValidateRational(solution.amplitude);
    mwValidateRational(
      solution.exponentCoefficient
    );

    if(
      !Number.isSafeInteger(
        solution.exponentPower
      ) ||
      solution.exponentPower < 1
    ){
      throw new TypeError(
        'Invalid exp-power solution.'
      );
    }

    return true;
  }

  if(
    solution.type ===
    'equilibrium-plus-exponential'
  ){
    mwValidateRational(solution.equilibrium);
    mwValidateRational(solution.transient);
    mwValidateRational(solution.rate);
    return true;
  }

  throw new RangeError(
    `Unsupported DE solution type: ${String(solution.type)}`
  );
}

function mwDESolveQuestion(question){
  mwValidateDEQuestionModel(question);

  if(
    question.family ===
    MW_DE_FAMILIES.separablePowerY.id
  ){
    const exponentPower =
      question.parameters.n + 1;

    const exponentCoefficient =
      mwRational(
        question.parameters.a.numerator,
        question.parameters.a.denominator *
          exponentPower
      );

    return mwCreateExpPowerSolution({
      amplitude:
        question.condition.dependentValue,
      exponentCoefficient,
      exponentPower
    });
  }

  if(
    question.family ===
    MW_DE_FAMILIES.linearConstantForcing.id
  ){
    const a = question.parameters.a;
    const b = question.parameters.b;

    const equilibrium = mwRational(
      b.numerator * a.denominator,
      b.denominator * a.numerator
    );

    const transient = mwRationalSubtract(
      question.condition.dependentValue,
      equilibrium
    );

    return mwCreateEquilibriumExpSolution({
      equilibrium,
      transient,
      rate: mwRationalNegate(a)
    });
  }

  throw new RangeError(
    `No solver recipe for ${question.family}.`
  );
}

function mwDEVerificationReport({
  status,
  modelValid,
  familyCompatible,
  equationSatisfied,
  conditionsSatisfied,
  domainValid,
  requestedFormSatisfied,
  method,
  details = {}
}){
  return {
    status,
    modelValid,
    familyCompatible,
    equationSatisfied,
    conditionsSatisfied,
    domainValid,
    requestedFormSatisfied,
    method,
    details
  };
}

function mwDECheckSeparablePowerIVP(
  question,
  candidate
){
  try{
    mwValidateDEQuestionModel(question);
    mwValidateDESolutionModel(candidate);
  }catch(error){
    return mwDEVerificationReport({
      status: 'fail',
      modelValid: false,
      familyCompatible: false,
      equationSatisfied: false,
      conditionsSatisfied: false,
      domainValid: false,
      requestedFormSatisfied: false,
      method: 'exact-family-identity',
      details: {
        reason: error.message
      }
    });
  }

  const familyCompatible =
    question.family ===
      MW_DE_FAMILIES.separablePowerY.id &&
    candidate.type === 'exp-power';

  if(!familyCompatible){
    return mwDEVerificationReport({
      status: 'fail',
      modelValid: true,
      familyCompatible: false,
      equationSatisfied: false,
      conditionsSatisfied: false,
      domainValid: true,
      requestedFormSatisfied: false,
      method: 'exact-family-identity',
      details: {
        reason: 'family-or-solution-type-mismatch'
      }
    });
  }

  const expectedPower =
    question.parameters.n + 1;

  const equationSatisfied =
    candidate.exponentPower ===
      expectedPower &&
    mwRationalEqual(
      mwRationalMultiply(
        candidate.exponentCoefficient,
        mwRational(
          candidate.exponentPower
        )
      ),
      question.parameters.a
    );

  const conditionsSatisfied =
    mwRationalEqual(
      candidate.amplitude,
      question.condition.dependentValue
    );

  const requestedFormSatisfied = true;
  const domainValid = true;

  return mwDEVerificationReport({
    status:
      equationSatisfied &&
      conditionsSatisfied &&
      requestedFormSatisfied &&
      domainValid
        ? 'pass'
        : 'fail',
    modelValid: true,
    familyCompatible: true,
    equationSatisfied,
    conditionsSatisfied,
    domainValid,
    requestedFormSatisfied,
    method: 'exact-family-identity'
  });
}

function mwDECheckLinearConstantIVP(
  question,
  candidate
){
  try{
    mwValidateDEQuestionModel(question);
    mwValidateDESolutionModel(candidate);
  }catch(error){
    return mwDEVerificationReport({
      status: 'fail',
      modelValid: false,
      familyCompatible: false,
      equationSatisfied: false,
      conditionsSatisfied: false,
      domainValid: false,
      requestedFormSatisfied: false,
      method: 'exact-family-identity',
      details: {
        reason: error.message
      }
    });
  }

  const familyCompatible =
    question.family ===
      MW_DE_FAMILIES.linearConstantForcing.id &&
    candidate.type ===
      'equilibrium-plus-exponential';

  if(!familyCompatible){
    return mwDEVerificationReport({
      status: 'fail',
      modelValid: true,
      familyCompatible: false,
      equationSatisfied: false,
      conditionsSatisfied: false,
      domainValid: true,
      requestedFormSatisfied: false,
      method: 'exact-family-identity',
      details: {
        reason: 'family-or-solution-type-mismatch'
      }
    });
  }

  const equationSatisfied =
    mwRationalEqual(
      candidate.rate,
      mwRationalNegate(
        question.parameters.a
      )
    ) &&
    mwRationalEqual(
      mwRationalMultiply(
        question.parameters.a,
        candidate.equilibrium
      ),
      question.parameters.b
    );

  const conditionsSatisfied =
    mwRationalEqual(
      mwRationalAdd(
        candidate.equilibrium,
        candidate.transient
      ),
      question.condition.dependentValue
    );

  const requestedFormSatisfied = true;
  const domainValid = true;

  return mwDEVerificationReport({
    status:
      equationSatisfied &&
      conditionsSatisfied &&
      requestedFormSatisfied &&
      domainValid
        ? 'pass'
        : 'fail',
    modelValid: true,
    familyCompatible: true,
    equationSatisfied,
    conditionsSatisfied,
    domainValid,
    requestedFormSatisfied,
    method: 'exact-family-identity'
  });
}

function mwDEVerifySolution(question, candidate){
  mwValidateDEQuestionModel(question);

  if(
    question.family ===
    MW_DE_FAMILIES.separablePowerY.id
  ){
    return mwDECheckSeparablePowerIVP(
      question,
      candidate
    );
  }

  if(
    question.family ===
    MW_DE_FAMILIES.linearConstantForcing.id
  ){
    return mwDECheckLinearConstantIVP(
      question,
      candidate
    );
  }

  return mwDEVerificationReport({
    status: 'inconclusive',
    modelValid: false,
    familyCompatible: false,
    equationSatisfied: false,
    conditionsSatisfied: false,
    domainValid: false,
    requestedFormSatisfied: false,
    method: 'unsupported-family',
    details: {
      reason: question.family
    }
  });
}

function mwNearlyEqual(
  left,
  right,
  absoluteTolerance = 1e-10,
  relativeTolerance = 1e-9
){
  if(
    !Number.isFinite(left) ||
    !Number.isFinite(right)
  ){
    return false;
  }

  const difference = Math.abs(left - right);
  const scale = Math.max(
    1,
    Math.abs(left),
    Math.abs(right)
  );

  return (
    difference <=
      absoluteTolerance +
      relativeTolerance * scale
  );
}

function mwDEEvaluateSolution(solution, x){
  mwValidateDESolutionModel(solution);

  if(!Number.isFinite(x)){
    throw new TypeError(
      'Evaluation point must be finite.'
    );
  }

  if(solution.type === 'exp-power'){
    const amplitude =
      mwRationalToNumber(solution.amplitude);

    const coefficient =
      mwRationalToNumber(
        solution.exponentCoefficient
      );

    return amplitude * Math.exp(
      coefficient *
      Math.pow(x, solution.exponentPower)
    );
  }

  const equilibrium =
    mwRationalToNumber(solution.equilibrium);

  const transient =
    mwRationalToNumber(solution.transient);

  const rate =
    mwRationalToNumber(solution.rate);

  return (
    equilibrium +
    transient * Math.exp(rate * x)
  );
}

function mwDEEvaluateDerivative(solution, x){
  mwValidateDESolutionModel(solution);

  if(solution.type === 'exp-power'){
    const y = mwDEEvaluateSolution(
      solution,
      x
    );

    const coefficient =
      mwRationalToNumber(
        solution.exponentCoefficient
      );

    return (
      y *
      coefficient *
      solution.exponentPower *
      Math.pow(
        x,
        solution.exponentPower - 1
      )
    );
  }

  const transient =
    mwRationalToNumber(solution.transient);

  const rate =
    mwRationalToNumber(solution.rate);

  return (
    transient *
    rate *
    Math.exp(rate * x)
  );
}

function mwDENumericAudit(
  question,
  solution,
  points = MW_DE_AUDIT_POINTS
){
  mwValidateDEQuestionModel(question);
  mwValidateDESolutionModel(solution);

  const failures = [];

  for(const x of points){
    const y = mwDEEvaluateSolution(
      solution,
      x
    );

    const derivative =
      mwDEEvaluateDerivative(
        solution,
        x
      );

    let left;
    let right;

    if(
      question.family ===
      MW_DE_FAMILIES.separablePowerY.id
    ){
      left = derivative;

      right =
        mwRationalToNumber(
          question.parameters.a
        ) *
        Math.pow(
          x,
          question.parameters.n
        ) *
        y;
    }else{
      left =
        derivative +
        mwRationalToNumber(
          question.parameters.a
        ) *
        y;

      right =
        mwRationalToNumber(
          question.parameters.b
        );
    }

    if(!mwNearlyEqual(left, right)){
      failures.push({
        x,
        left,
        right,
        difference: Math.abs(left - right)
      });
    }
  }

  const initialX =
    mwRationalToNumber(
      question.condition.independentValue
    );

  const initialExpected =
    mwRationalToNumber(
      question.condition.dependentValue
    );

  const initialActual =
    mwDEEvaluateSolution(
      solution,
      initialX
    );

  const initialConditionPassed =
    mwNearlyEqual(
      initialActual,
      initialExpected
    );

  return {
    status:
      failures.length === 0 &&
      initialConditionPassed
        ? 'pass'
        : 'fail',
    method: 'deterministic-numeric-audit',
    points: [...points],
    residualFailures: failures,
    initialConditionPassed,
    initialActual,
    initialExpected
  };
}

function mwRenderMonomial(
  coefficient,
  variable,
  power
){
  mwValidateRational(coefficient);
  mwValidateVariableName(variable);

  if(
    !Number.isSafeInteger(power) ||
    power < 0
  ){
    throw new RangeError(
      'Monomial power must be nonnegative.'
    );
  }

  const variablePart =
    power === 0
      ? ''
      : power === 1
        ? variable
        : `${variable}^{${power}}`;

  if(!variablePart){
    return mwRenderRational(coefficient);
  }

  if(mwRationalIsOne(coefficient)){
    return variablePart;
  }

  if(mwRationalIsNegativeOne(coefficient)){
    return `-${variablePart}`;
  }

  return (
    `${mwRenderRational(coefficient)}` +
    `${variablePart}`
  );
}

function mwRenderExponentTerm(
  coefficient,
  variable,
  power
){
  return mwRenderMonomial(
    coefficient,
    variable,
    power
  );
}

function mwRenderExpPowerSolution(
  solution,
  dependentVariable = 'y',
  independentVariable = 'x'
){
  mwValidateDESolutionModel(solution);

  if(solution.type !== 'exp-power'){
    throw new TypeError(
      'Expected exp-power solution.'
    );
  }

  const exponent = mwRenderExponentTerm(
    solution.exponentCoefficient,
    independentVariable,
    solution.exponentPower
  );

  let leading;

  if(mwRationalIsOne(solution.amplitude)){
    leading = '';
  }else if(
    mwRationalIsNegativeOne(
      solution.amplitude
    )
  ){
    leading = '-';
  }else{
    leading =
      mwRenderRational(
        solution.amplitude
      );
  }

  return (
    `${dependentVariable}=` +
    `${leading}e^{${exponent}}`
  );
}

function mwRenderLinearSolution(
  solution,
  dependentVariable = 'y',
  independentVariable = 'x'
){
  mwValidateDESolutionModel(solution);

  if(
    solution.type !==
    'equilibrium-plus-exponential'
  ){
    throw new TypeError(
      'Expected equilibrium-plus-exponential solution.'
    );
  }

  const equilibrium =
    solution.equilibrium;

  const transient =
    solution.transient;

  const exponent = mwRenderMonomial(
    solution.rate,
    independentVariable,
    1
  );

  let exponentialTerm;

  if(mwRationalIsOne(transient)){
    exponentialTerm = `e^{${exponent}}`;
  }else if(
    mwRationalIsNegativeOne(transient)
  ){
    exponentialTerm = `-e^{${exponent}}`;
  }else{
    exponentialTerm =
      `${mwRenderRational(transient)}` +
      `e^{${exponent}}`;
  }

  if(mwRationalIsZero(equilibrium)){
    return (
      `${dependentVariable}=` +
      `${exponentialTerm}`
    );
  }

  const equilibriumText =
    mwRenderRational(equilibrium);

  if(transient.numerator < 0){
    const positiveTransient =
      mwRational(
        -transient.numerator,
        transient.denominator
      );

    const positiveTerm =
      mwRationalIsOne(positiveTransient)
        ? `e^{${exponent}}`
        : `${mwRenderRational(positiveTransient)}` +
          `e^{${exponent}}`;

    return (
      `${dependentVariable}=` +
      `${equilibriumText}-${positiveTerm}`
    );
  }

  return (
    `${dependentVariable}=` +
    `${equilibriumText}+${exponentialTerm}`
  );
}

function mwRenderDESolution(
  question,
  solution
){
  mwValidateDEQuestionModel(question);
  mwValidateDESolutionModel(solution);

  if(solution.type === 'exp-power'){
    return mwRenderExpPowerSolution(
      solution,
      question.dependentVariable,
      question.independentVariable
    );
  }

  return mwRenderLinearSolution(
    solution,
    question.dependentVariable,
    question.independentVariable
  );
}

function mwRenderSeparableQuestion(question){
  mwValidateDEQuestionModel(question);

  const x = question.independentVariable;
  const y = question.dependentVariable;
  const a = question.parameters.a;
  const n = question.parameters.n;
  const y0 =
    question.condition.dependentValue;

  let rightSide;

  if(n === 0){
    if(mwRationalIsOne(a)){
      rightSide = y;
    }else if(mwRationalIsNegativeOne(a)){
      rightSide = `-${y}`;
    }else{
      rightSide =
        `${mwRenderRational(a)}${y}`;
    }
  }else{
    const xPart =
      n === 1 ? x : `${x}^{${n}}`;

    if(mwRationalIsOne(a)){
      rightSide = `${xPart}${y}`;
    }else if(mwRationalIsNegativeOne(a)){
      rightSide = `-${xPart}${y}`;
    }else{
      rightSide =
        `${mwRenderRational(a)}` +
        `${xPart}${y}`;
    }
  }

  return (
    `Solve the initial-value problem ` +
    `\\(\\frac{d${y}}{d${x}}=` +
    `${rightSide},\\quad ` +
    `${y}(0)=${mwRenderRational(y0)}\\).`
  );
}

function mwRenderLinearQuestion(question){
  mwValidateDEQuestionModel(question);

  const x = question.independentVariable;
  const y = question.dependentVariable;
  const a = question.parameters.a;
  const b = question.parameters.b;
  const y0 =
    question.condition.dependentValue;

  let leftSide = `${y}'`;

  if(a.numerator > 0){
    if(mwRationalIsOne(a)){
      leftSide += `+${y}`;
    }else{
      leftSide +=
        `+${mwRenderRational(a)}${y}`;
    }
  }else{
    const positiveA = mwRational(
      -a.numerator,
      a.denominator
    );

    if(mwRationalIsOne(positiveA)){
      leftSide += `-${y}`;
    }else{
      leftSide +=
        `-${mwRenderRational(positiveA)}${y}`;
    }
  }

  return (
    `Solve the initial-value problem ` +
    `\\(${leftSide}=` +
    `${mwRenderRational(b)},\\quad ` +
    `${y}(0)=${mwRenderRational(y0)}\\).`
  );
}

function mwRenderDEQuestion(question){
  mwValidateDEQuestionModel(question);

  if(
    question.family ===
    MW_DE_FAMILIES.separablePowerY.id
  ){
    return mwRenderSeparableQuestion(
      question
    );
  }

  return mwRenderLinearQuestion(
    question
  );
}

function mwBuildSeparableSteps(
  question,
  solution
){
  const x = question.independentVariable;
  const y = question.dependentVariable;
  const a = question.parameters.a;
  const n = question.parameters.n;
  const exponentPower =
    solution.exponentPower;
  const exponentCoefficient =
    solution.exponentCoefficient;
  const y0 =
    question.condition.dependentValue;

  const xPower =
    n === 0
      ? ''
      : n === 1
        ? x
        : `${x}^{${n}}`;

  const rightIntegral =
    mwRenderExponentTerm(
      exponentCoefficient,
      x,
      exponentPower
    );

  return [
    `Separate variables: ` +
      `\\(\\frac{1}{${y}}\\,d${y}=` +
      `${mwRenderRational(a)}` +
      `${xPower}\\,d${x}\\).`,

    `Integrate: ` +
      `\\(\\ln|${y}|=` +
      `${rightIntegral}+C_1\\).`,

    `Exponentiate and absorb the sign into the constant: ` +
      `\\(${y}=C_2e^{${rightIntegral}}\\).`,

    `Use \\(${y}(0)=${mwRenderRational(y0)}\\), ` +
      `so \\(C_2=${mwRenderRational(y0)}\\).`,

    `Therefore, ` +
      `\\(${mwRenderDESolution(question, solution)}\\).`,

    `Check: the exact identities are ` +
      `\\(m=n+1\\), \\(Cm=a\\), and ` +
      `\\(A=${mwRenderRational(y0)}\\).`
  ];
}

function mwBuildLinearSteps(
  question,
  solution
){
  const x = question.independentVariable;
  const y = question.dependentVariable;
  const a = question.parameters.a;
  const b = question.parameters.b;
  const y0 =
    question.condition.dependentValue;
  const equilibrium =
    solution.equilibrium;
  const transient =
    solution.transient;

  const ax = mwRenderMonomial(a, x, 1);
  const minusAx = mwRenderMonomial(
    mwRationalNegate(a),
    x,
    1
  );

  return [
    `The integrating factor is ` +
      `\\(\\mu(${x})=e^{${ax}}\\).`,

    `After multiplication, ` +
      `\\(\\left(e^{${ax}}${y}\\right)'=` +
      `${mwRenderRational(b)}e^{${ax}}\\).`,

    `Integrate: ` +
      `\\(e^{${ax}}${y}=` +
      `${mwRenderRational(equilibrium)}` +
      `e^{${ax}}+C\\).`,

    `Thus ` +
      `\\(${y}=${mwRenderRational(equilibrium)}` +
      `+Ce^{${minusAx}}\\).`,

    `Use \\(${y}(0)=${mwRenderRational(y0)}\\), ` +
      `giving \\(C=${mwRenderRational(transient)}\\).`,

    `Therefore, ` +
      `\\(${mwRenderDESolution(question, solution)}\\).`,

    `Check: \\(K=-a\\), \\(aE=b\\), and ` +
      `\\(E+T=${mwRenderRational(y0)}\\).`
  ];
}

function mwBuildDESteps(
  question,
  solution
){
  mwValidateDEQuestionModel(question);
  mwValidateDESolutionModel(solution);

  if(
    question.family ===
    MW_DE_FAMILIES.separablePowerY.id
  ){
    return mwBuildSeparableSteps(
      question,
      solution
    );
  }

  return mwBuildLinearSteps(
    question,
    solution
  );
}

function mwDESolutionKey(solution){
  mwValidateDESolutionModel(solution);

  if(solution.type === 'exp-power'){
    return [
      'de-answer-v1',
      'exp-power',
      mwRationalKey(solution.amplitude),
      mwRationalKey(
        solution.exponentCoefficient
      ),
      String(solution.exponentPower)
    ].join(':');
  }

  return [
    'de-answer-v1',
    'equilibrium-exp',
    mwRationalKey(solution.equilibrium),
    mwRationalKey(solution.transient),
    mwRationalKey(solution.rate)
  ].join(':');
}

function mwDEChoiceFamily(question){
  mwValidateDEQuestionModel(question);

  if(
    question.family ===
    MW_DE_FAMILIES.separablePowerY.id
  ){
    return (
      MW_DE_FAMILIES.separablePowerY
        .choiceFamily
    );
  }

  return (
    MW_DE_FAMILIES.linearConstantForcing
      .choiceFamily
  );
}

function mwBuildDEAnswerSpec(
  question,
  solution
){
  return {
    schemaVersion: MW_DE_SCHEMA_VERSION,
    type: 'de-explicit-solution',
    validatorId: 'de-solution-v1',
    model: solution,
    key: mwDESolutionKey(solution),
    choiceFamily:
      mwDEChoiceFamily(question),
    choiceCapacity: 256
  };
}

function mwDECountCorrectChoices(
  retainedProblem,
  candidateProblems
){
  const question =
    retainedProblem?.deSpec?.questionModel ||
    retainedProblem?.questionModel;

  return candidateProblems.filter(problem => {
    const solution =
      problem?.answerSpec?.model ||
      problem?.answerModel;

    if(!solution) return false;

    return (
      mwDEVerifySolution(
        question,
        solution
      ).status === 'pass'
    );
  }).length;
}

function mwPickRequired(rng, values, pickFn){
  if(typeof pickFn !== 'function'){
    throw new TypeError(
      'A seeded pick function is required.'
    );
  }

  return pickFn(rng, values);
}

const MW_DE_SEPARABLE_N_POOL =
  Object.freeze([0, 1, 2, 3]);

const MW_DE_MULTIPLIER_POOL =
  Object.freeze([-3, -2, -1, 1, 2, 3]);

const MW_DE_Y0_POOL =
  Object.freeze([
    -5, -4, -3, -2, -1,
    1, 2, 3, 4, 5
  ]);

const MW_DE_LINEAR_A_POOL =
  Object.freeze([-4, -3, -2, -1, 1, 2, 3, 4]);

const MW_DE_EQUILIBRIUM_POOL =
  Object.freeze([-4, -3, -2, -1, 0, 1, 2, 3, 4]);

const MW_DE_TRANSIENT_POOL =
  Object.freeze([-4, -3, -2, -1, 1, 2, 3, 4]);

function mwCreateSeparableIVPGenerator({
  unitId,
  pickFn,
  unitIndexFn,
  generatorKey =
    'd289_separable_power_ivp_v1'
}){
  if(
    typeof unitId !== 'string' ||
    !unitId
  ){
    throw new TypeError('unitId is required.');
  }

  if(typeof unitIndexFn !== 'function'){
    throw new TypeError(
      'unitIndexFn is required.'
    );
  }

  return function genD289SeparableIVP(rng){
    const n = mwPickRequired(
      rng,
      MW_DE_SEPARABLE_N_POOL,
      pickFn
    );

    const multiplier = mwPickRequired(
      rng,
      MW_DE_MULTIPLIER_POOL,
      pickFn
    );

    const y0Integer = mwPickRequired(
      rng,
      MW_DE_Y0_POOL,
      pickFn
    );

    const a = mwRational(
      multiplier * (n + 1)
    );

    const question =
      mwCreateSeparablePowerQuestion({
        a,
        n,
        y0: mwRational(y0Integer)
      });

    const solution =
      mwDESolveQuestion(question);

    const exactReport =
      mwDEVerifySolution(
        question,
        solution
      );

    const numericAudit =
      mwDENumericAudit(
        question,
        solution
      );

    if(
      exactReport.status !== 'pass' ||
      numericAudit.status !== 'pass'
    ){
      throw new Error(
        'Generated separable solution failed verification.'
      );
    }

    const answerSpec =
      mwBuildDEAnswerSpec(
        question,
        solution
      );

    const deSpec = {
      schemaVersion: MW_DE_SCHEMA_VERSION,
      familyId:
        MW_DE_FAMILIES.separablePowerY.id,
      familyCode:
        MW_DE_FAMILIES.separablePowerY.code,
      questionModel: question,
      verification: {
        exact: exactReport,
        numericAudit
      }
    };

    return {
      q: mwRenderDEQuestion(question),
      a:
        `\\(${mwRenderDESolution(
          question,
          solution
        )}\\)`,
      steps:
        mwBuildDESteps(
          question,
          solution
        ),
      vec: [
        unitIndexFn(unitId),
        MW_DE_FAMILIES
          .separablePowerY.code,
        a.numerator,
        a.denominator,
        n,
        y0Integer
      ],
      key: generatorKey,
      answerSpec,
      deSpec,

      // Temporary compatibility aliases.
      answerKey: answerSpec.key,
      choiceFamily:
        answerSpec.choiceFamily,
      choiceCapacity:
        answerSpec.choiceCapacity,
      answerModel:
        answerSpec.model,
      questionModel: question
    };
  };
}

function mwCreateLinearIVPGenerator({
  unitId,
  pickFn,
  unitIndexFn,
  generatorKey =
    'd289_linear_constant_ivp_v1'
}){
  if(
    typeof unitId !== 'string' ||
    !unitId
  ){
    throw new TypeError('unitId is required.');
  }

  if(typeof unitIndexFn !== 'function'){
    throw new TypeError(
      'unitIndexFn is required.'
    );
  }

  return function genD289LinearIVP(rng){
    const aInteger = mwPickRequired(
      rng,
      MW_DE_LINEAR_A_POOL,
      pickFn
    );

    const equilibriumInteger =
      mwPickRequired(
        rng,
        MW_DE_EQUILIBRIUM_POOL,
        pickFn
      );

    const transientInteger =
      mwPickRequired(
        rng,
        MW_DE_TRANSIENT_POOL,
        pickFn
      );

    const a = mwRational(aInteger);
    const equilibrium =
      mwRational(equilibriumInteger);
    const transient =
      mwRational(transientInteger);

    const b = mwRationalMultiply(
      a,
      equilibrium
    );

    const y0 = mwRationalAdd(
      equilibrium,
      transient
    );

    const question =
      mwCreateLinearConstantQuestion({
        a,
        b,
        y0
      });

    const solution =
      mwDESolveQuestion(question);

    const exactReport =
      mwDEVerifySolution(
        question,
        solution
      );

    const numericAudit =
      mwDENumericAudit(
        question,
        solution
      );

    if(
      exactReport.status !== 'pass' ||
      numericAudit.status !== 'pass'
    ){
      throw new Error(
        'Generated linear solution failed verification.'
      );
    }

    const answerSpec =
      mwBuildDEAnswerSpec(
        question,
        solution
      );

    const deSpec = {
      schemaVersion: MW_DE_SCHEMA_VERSION,
      familyId:
        MW_DE_FAMILIES
          .linearConstantForcing.id,
      familyCode:
        MW_DE_FAMILIES
          .linearConstantForcing.code,
      questionModel: question,
      verification: {
        exact: exactReport,
        numericAudit
      }
    };

    return {
      q: mwRenderDEQuestion(question),
      a:
        `\\(${mwRenderDESolution(
          question,
          solution
        )}\\)`,
      steps:
        mwBuildDESteps(
          question,
          solution
        ),
      vec: [
        unitIndexFn(unitId),
        MW_DE_FAMILIES
          .linearConstantForcing.code,
        a.numerator,
        a.denominator,
        b.numerator,
        b.denominator,
        y0.numerator,
        y0.denominator
      ],
      key: generatorKey,
      answerSpec,
      deSpec,

      // Temporary compatibility aliases.
      answerKey: answerSpec.key,
      choiceFamily:
        answerSpec.choiceFamily,
      choiceCapacity:
        answerSpec.choiceCapacity,
      answerModel:
        answerSpec.model,
      questionModel: question
    };
  };
}

function mwRunDESpikeSelfTests(){
  const results = [];

  function check(name, run){
    try{
      const pass = run() === true;

      results.push({
        name,
        pass,
        detail: pass
          ? ''
          : 'returned false'
      });
    }catch(error){
      results.push({
        name,
        pass: false,
        detail:
          error && error.message
            ? error.message
            : String(error)
      });
    }
  }

  check('Rational normalization', () => {
    const value = mwRational(-6, -8);

    return (
      value.numerator === 3 &&
      value.denominator === 4
    );
  });

  check('Rational arithmetic', () => {
    const left = mwRational(1, 2);
    const right = mwRational(1, 3);

    return (
      mwRationalEqual(
        mwRationalAdd(left, right),
        mwRational(5, 6)
      ) &&
      mwRationalEqual(
        mwRationalMultiply(left, right),
        mwRational(1, 6)
      )
    );
  });

  const separableQuestion =
    mwCreateSeparablePowerQuestion({
      a: mwRational(4),
      n: 3,
      y0: mwRational(5)
    });

  const separableSolution =
    mwDESolveQuestion(
      separableQuestion
    );

  check('Separable solution construction', () =>
    separableSolution.type ===
      'exp-power' &&
    mwRationalEqual(
      separableSolution.amplitude,
      mwRational(5)
    ) &&
    mwRationalEqual(
      separableSolution
        .exponentCoefficient,
      mwRational(1)
    ) &&
    separableSolution.exponentPower === 4
  );

  check('Separable exact verification', () =>
    mwDEVerifySolution(
      separableQuestion,
      separableSolution
    ).status === 'pass'
  );

  check('Separable numeric audit', () =>
    mwDENumericAudit(
      separableQuestion,
      separableSolution
    ).status === 'pass'
  );

  check('Separable mutation rejection', () => {
    const mutations = [
      {
        ...separableSolution,
        amplitude: mwRational(6)
      },
      {
        ...separableSolution,
        exponentCoefficient:
          mwRational(2)
      },
      {
        ...separableSolution,
        exponentPower: 3
      }
    ];

    return mutations.every(
      candidate =>
        mwDEVerifySolution(
          separableQuestion,
          candidate
        ).status === 'fail'
    );
  });

  const linearQuestion =
    mwCreateLinearConstantQuestion({
      a: mwRational(2),
      b: mwRational(6),
      y0: mwRational(1)
    });

  const linearSolution =
    mwDESolveQuestion(
      linearQuestion
    );

  check('Linear solution construction', () =>
    linearSolution.type ===
      'equilibrium-plus-exponential' &&
    mwRationalEqual(
      linearSolution.equilibrium,
      mwRational(3)
    ) &&
    mwRationalEqual(
      linearSolution.transient,
      mwRational(-2)
    ) &&
    mwRationalEqual(
      linearSolution.rate,
      mwRational(-2)
    )
  );

  check('Linear exact verification', () =>
    mwDEVerifySolution(
      linearQuestion,
      linearSolution
    ).status === 'pass'
  );

  check('Linear numeric audit', () =>
    mwDENumericAudit(
      linearQuestion,
      linearSolution
    ).status === 'pass'
  );

  check('Linear mutation rejection', () => {
    const mutations = [
      {
        ...linearSolution,
        equilibrium: mwRational(4)
      },
      {
        ...linearSolution,
        transient: mwRational(-3)
      },
      {
        ...linearSolution,
        rate: mwRational(-1)
      }
    ];

    return mutations.every(
      candidate =>
        mwDEVerifySolution(
          linearQuestion,
          candidate
        ).status === 'fail'
    );
  });

  check('Canonical rendering', () =>
    mwRenderDESolution(
      separableQuestion,
      separableSolution
    ) === 'y=5e^{x^{4}}' &&
    mwRenderDESolution(
      linearQuestion,
      linearSolution
    ) === 'y=3-2e^{-2x}'
  );

  function makeRng(seed){
    let state = seed >>> 0;

    return function next(){
      state =
        (1664525 * state +
          1013904223) >>> 0;

      return state / 4294967296;
    };
  }

  function localPick(rng, values){
    return values[
      Math.floor(rng() * values.length)
    ];
  }

  const unitIndexFn = unitId =>
    unitId === 'D289_Separable'
      ? 1
      : 2;

  const genSeparable =
    mwCreateSeparableIVPGenerator({
      unitId: 'D289_Separable',
      pickFn: localPick,
      unitIndexFn
    });

  const genLinear =
    mwCreateLinearIVPGenerator({
      unitId:
        'D289_LinearFirstOrder',
      pickFn: localPick,
      unitIndexFn
    });

  check('Separable generator deterministic', () =>
    JSON.stringify(
      genSeparable(makeRng(12345))
    ) ===
    JSON.stringify(
      genSeparable(makeRng(12345))
    )
  );

  check('Linear generator deterministic', () =>
    JSON.stringify(
      genLinear(makeRng(54321))
    ) ===
    JSON.stringify(
      genLinear(makeRng(54321))
    )
  );

  check('Generator vec values numeric', () =>
    [
      genSeparable(makeRng(1)),
      genLinear(makeRng(2))
    ].every(problem =>
      problem.vec.every(value =>
        typeof value === 'number' &&
        Number.isFinite(value)
      )
    )
  );

  function collectDistinct(
    generator,
    retainedSeed
  ){
    const retained =
      generator(
        makeRng(retainedSeed)
      );

    const choices = [retained];

    for(
      let seed = retainedSeed + 1;
      seed < retainedSeed + 1000 &&
      choices.length < 4;
      seed++
    ){
      const candidate =
        generator(makeRng(seed));

      if(
        candidate.choiceFamily ===
          retained.choiceFamily &&
        !choices.some(
          existing =>
            existing.answerKey ===
            candidate.answerKey
        ) &&
        !choices.some(
          existing =>
            existing.a === candidate.a
        ) &&
        mwDEVerifySolution(
          retained.deSpec.questionModel,
          candidate.answerSpec.model
        ).status !== 'pass'
      ){
        choices.push(candidate);
      }
    }

    return {
      retained,
      choices
    };
  }

  check(
    'Separable exact-one-correct choices',
    () => {
      const set = collectDistinct(
        genSeparable,
        100
      );

      return (
        set.choices.length === 4 &&
        mwDECountCorrectChoices(
          set.retained,
          set.choices
        ) === 1
      );
    }
  );

  check(
    'Linear exact-one-correct choices',
    () => {
      const set = collectDistinct(
        genLinear,
        200
      );

      return (
        set.choices.length === 4 &&
        mwDECountCorrectChoices(
          set.retained,
          set.choices
        ) === 1
      );
    }
  );

  check('Blueprint regeneration', () => {
    const problem =
      genLinear(makeRng(77));

    const regenerated =
      mwDESolveQuestion(
        problem.deSpec.questionModel
      );

    return (
      mwDESolutionKey(regenerated) ===
      problem.answerKey
    );
  });

  return {
    passed:
      results.filter(result => result.pass)
        .length,
    failed:
      results.filter(result => !result.pass)
        .length,
    results
  };
}

if(
  typeof module !== 'undefined' &&
  module.exports
){
  module.exports = {
    MW_DE_SCHEMA_VERSION,
    MW_DE_FAMILIES,
    MW_DE_AUDIT_POINTS,
    mwGreatestCommonDivisor,
    mwRational,
    mwValidateRational,
    mwRationalAdd,
    mwRationalSubtract,
    mwRationalMultiply,
    mwRationalNegate,
    mwRationalEqual,
    mwRationalIsZero,
    mwRationalToNumber,
    mwRationalKey,
    mwRenderRational,
    mwCreateInitialCondition,
    mwCreateSeparablePowerQuestion,
    mwCreateLinearConstantQuestion,
    mwValidateDEQuestionModel,
    mwCreateExpPowerSolution,
    mwCreateEquilibriumExpSolution,
    mwValidateDESolutionModel,
    mwDESolveQuestion,
    mwDECheckSeparablePowerIVP,
    mwDECheckLinearConstantIVP,
    mwDEVerifySolution,
    mwNearlyEqual,
    mwDEEvaluateSolution,
    mwDEEvaluateDerivative,
    mwDENumericAudit,
    mwRenderDEQuestion,
    mwRenderDESolution,
    mwBuildDESteps,
    mwDESolutionKey,
    mwDEChoiceFamily,
    mwBuildDEAnswerSpec,
    mwDECountCorrectChoices,
    mwCreateSeparableIVPGenerator,
    mwCreateLinearIVPGenerator,
    mwRunDESpikeSelfTests
  };
}

if(
  typeof require !== 'undefined' &&
  typeof module !== 'undefined' &&
  require.main === module
){
  const report =
    mwRunDESpikeSelfTests();

  for(const result of report.results){
    console.log(
      `${result.pass ? 'PASS' : 'FAIL'}: ` +
      `${result.name}` +
      (
        result.detail
          ? ` — ${result.detail}`
          : ''
      )
    );
  }

  console.log(
    `\n${report.passed} passed, ` +
    `${report.failed} failed.`
  );

  if(report.failed > 0){
    process.exitCode = 1;
  }
}


// ===== CUSTOM GENERATORS =====

// ===== MTH 289: DIFFERENTIAL EQUATIONS OF MATHEMATICAL PHYSICS =====
// NVCC-aligned full-catalog integration. The two first-order canaries use the
// typed DE validator; the remaining sections use exact, audit-friendly models.

function d289Trap(ans, why){
  return {ans, why};
}

function d289MakeProblem({
  unitId, genNum, q, a, steps, traps, vecTail, key, auditSpec
}){
  const clean = [];
  const seen = new Set([normalizeMCAnswer(fixTexEscapes(a))]);
  for(const trap of (traps || [])){
    if(!trap || trap.ans == null) continue;
    const k = normalizeMCAnswer(fixTexEscapes(trap.ans));
    if(!k || seen.has(k)) continue;
    seen.add(k);
    clean.push(trap);
  }
  return {
    q, a, steps,
    traps: clean,
    vec: [unitIndex(unitId), genNum, ...(vecTail || [])],
    key,
    auditSpec
  };
}

function d289FracParts(n, d){
  if(d === 0) throw new RangeError('zero denominator');
  if(d < 0){ n = -n; d = -d; }
  const g = gcd(Math.abs(n), Math.abs(d));
  return [n/g, d/g];
}

function d289FracTex(n, d, display = false){
  const [nn, dd] = d289FracParts(n, d);
  const body = dd === 1 ? `${nn}` : `\\dfrac{${nn}}{${dd}}`;
  return display ? `\\(${body}\\)` : body;
}

function d289PiFracTex(n, d, piPower = 1){
  const [nn, dd] = d289FracParts(n, d);
  const pi = piPower === 1 ? '\\pi' : `\\pi^{${piPower}}`;
  if(nn === 0) return '0';
  const sign = nn < 0 ? '-' : '';
  const mag = Math.abs(nn);
  const numerator = mag === 1 ? '' : `${mag}`;
  if(dd === 1) return `${sign}\\dfrac{${numerator || '1'}}{${pi}}`;
  return `${sign}\\dfrac{${numerator || '1'}}{${dd}${pi}}`;
}

function d289AttachTypedTraps(problem, traps, auditSpec){
  return {
    ...problem,
    traps,
    auditSpec
  };
}

// -------------------- First-order typed canaries --------------------
const d289SeparableBase = mwCreateSeparableIVPGenerator({
  unitId: 'D289_FirstOrder',
  pickFn: pick,
  unitIndexFn: unitIndex,
  generatorKey: 'd289_firstorder_separable_power_ivp'
});
const genD289Separable = (rng)=>{
  const p = d289SeparableBase(rng);
  return d289AttachTypedTraps(
    p,
    [
      d289Trap(`\\(y=${p.deSpec.questionModel.condition.dependentValue.numerator}e^{x}\\)`,
        'The exponent must come from integrating the full coefficient a x^n.'),
      d289Trap(`\\(y=e^{${p.deSpec.questionModel.condition.dependentValue.numerator}x}\\)`,
        'The initial value is the multiplicative constant, not the exponent coefficient.')
    ],
    {family:'typed-separable', questionModel:p.deSpec.questionModel, solutionModel:p.answerSpec.model}
  );
};
genD289Separable.meta = {topicId:'separable-ivp', topicLabel:'Separable IVPs'};

const d289LinearBase = mwCreateLinearIVPGenerator({
  unitId: 'D289_FirstOrder',
  pickFn: pick,
  unitIndexFn: unitIndex,
  generatorKey: 'd289_firstorder_linear_constant_ivp'
});
const genD289Linear = (rng)=>{
  const p = d289LinearBase(rng);
  return d289AttachTypedTraps(
    p,
    [
      d289Trap(`\\(y=${p.deSpec.questionModel.condition.dependentValue.numerator}e^{-x}\\)`,
        'A nonzero constant forcing creates an equilibrium term in addition to the transient exponential.'),
      d289Trap(`\\(y=${p.deSpec.questionModel.condition.dependentValue.numerator}\\)`,
        'The initial value alone does not satisfy the differential equation for all x.')
    ],
    {family:'typed-linear', questionModel:p.deSpec.questionModel, solutionModel:p.answerSpec.model}
  );
};
genD289Linear.meta = {topicId:'linear-ivp', topicLabel:'First-Order Linear IVPs'};

// -------------------- Systems of differential equations --------------------






// -------------------- Power-series solutions --------------------





// -------------------- Fourier series --------------------






// -------------------- Laplace transforms II --------------------






// -------------------- PDE classification and separation --------------------
function d289PDEClassificationProblem(rng, genNum){
  const kind = pick(rng,[0,1,2]);
  const k = pick(rng,[1,2,3,4,5]);
  const equations = [
    `u_t=${k}u_{xx}`,
    `u_{tt}=${k*k}u_{xx}`,
    `u_{xx}+u_{yy}=0`
  ];
  const labels = ['Heat equation','Wave equation','Laplace equation'];
  return d289MakeProblem({
    unitId:'D289_PDE', genNum,
    q:`Classify the PDE \\(${equations[kind]}\\).`,
    a:labels[kind],
    steps:[
      kind===0 ? `First order in time and second order in space is the heat equation.` :
      kind===1 ? `Second order in time and space is the wave equation.` :
                 `The sum of spatial second derivatives equal to zero is Laplace equation.`
    ],
    traps:[
      d289Trap(labels[(kind+1)%3], 'Compare the time derivative order and whether a time derivative appears.'),
      d289Trap(labels[(kind+2)%3], 'Use the canonical heat, wave, and Laplace forms.')
    ],
    vecTail:[kind,k], key:`d289_pde_classify_${genNum}`,
    auditSpec:{family:'pde-classification',kind,k,answer:labels[kind]}
  });
}



// -------------------- Boundary-value eigenproblems --------------------






// ---------- P283 (MTH 283) · Probability & Statistics (calculus-based) ----------

// ===== P283_Continuous =====




// ===== P283_ExpNormal =====



// ===== P283_CLT_Est =====



// ===== P283_LSQ =====



// ---------- S245 (MTH 245) · Statistics I (uses mw_stats_engine_v1) ----------

// ===== S245_Probability =====



// ===== S245_Binomial =====



// ===== S245_Sampling =====



// ===== S245_Inference =====




// ---------- S155 (MTH 155) · Statistical Reasoning (uses mw_stats_engine_v1) ----------

// ===== S155_Descriptive =====



// ===== S155_Normal =====




// ===== S155_Correlation =====


// ===== S155_Inference =====




// ---------- HP (MTH 133) · Math for Health Professions ----------

// ===== HP_Conversion =====



// ===== HP_Dosage =====




// ===== HP_IVRates =====





// ---------- DE (MTH 267) · Units 2-3: Second-Order & Laplace ----------

// ===== DE_SecondOrder =====







// ===== DE_Laplace =====






// ---------- LA (MTH 266) · Units 2-3: Matrix Algebra, Determinants, Eigen ----------

// ===== LA_MatrixAlg =====







// ===== LA_Eigen =====







// ---------- ST2 (MTH 246) · Statistics II ----------

// ===== ST2_ChiSquare =====



// ===== ST2_ANOVA =====



// ===== ST2_Regression =====




// ===== ST2_Design =====





// ---------- QR (MTH 154) · Quantitative Reasoning ----------

// ===== QR_Proportion =====




// ===== QR_Finance =====




// ===== QR_Logic =====




// ===== QR_Modeling =====




// ---------- AC1 (MTH 261) & AC2 (MTH 262) · Applied Calculus ----------

// ===== AC1_Marginal : Marginal Analysis =====





// ===== AC1_Elasticity : Elasticity of Demand =====




// ===== AC1_Finance : Continuous Growth & Finance =====




// ===== AC2_IntApps : Integration Applications (MTH 262) =====





// ===== AC2_Multivar : Multivariable Basics (MTH 262) =====





// ---------- DE (MTH 267) · Unit 1: First-Order Differential Equations ----------
// Outline coverage: classify order & linearity; direction-field reasoning; solve
// first-order linear & separable; IVPs; Euler's method; growth/decay applications.

// 1) Classify order and linearity

// 2) Which function solves y' = k y

// 3) Separable: y y' = a x  ->  y^2 = a x^2 + C

// 4) Separable IVP: y' = a y, y(0) = y0

// 5) Integrating factor for y' + a y = g(x)

// 6) Solve y' + a y = b (constants)

// 7) Linear IVP: y' + a y = b, y(0) = y0

// 8) Population doubling time

// 9) Radioactive decay: half-life -> k

// 10) Euler's method, two steps

// 11) Exactness test: M dx + N dy = 0

// 12) Equilibrium solutions of an autonomous equation


// ---------- LA (MTH 266) · Unit 1: Linear Systems & Row Reduction ----------
// Official outline coverage: matrix terminology; Gauss-Jordan to RREF; unique /
// none / infinite conditions; solution sets from RREF incl. free parameters;
// row operations; real-world systems.

function laMtx(rows){
  return '\\begin{bmatrix}' + rows.map(r => r.join(' & ')).join(' \\\\ ') + '\\end{bmatrix}';
}
function laAug(rows){ // rows: [a,b,c] => 2-var augmented; [a,b,c,d] => 3-var
  const n = rows[0].length - 1;
  const cols = 'c'.repeat(n) + '|c';
  return '\\left[\\begin{array}{' + cols + '}' +
    rows.map(r => r.join(' & ')).join(' \\\\ ') + '\\end{array}\\right]';
}
function laEqTex(a, b, c){ // ax + by = c with tidy signs (pipeline finishes the job)
  return `${a}x ${b<0?'-':'+'} ${Math.abs(b)}y = ${c}`;
}

// 1) Solve a 2x2 system (unique solution)

// 2) Solve a 3x3 system (unique, built for clean back-substitution)

// 3) Classify: unique / none / infinitely many

// 4) Value of h for consistency

// 5) Identify the RREF matrix

// 6) Apply a row operation

// 7) Identify the row operation

// 8) Back-substitution from triangular form

// 9) Infinitely many solutions — parametric form with a free variable

// 10) Rank of a small matrix

// 11) Matrix terminology

// 12) Real-world system (per the outline: model and solve)


// ============================================================
// NVCC OUTLINE GAP FILL — batch 2 (remaining checklist items)
// ============================================================

// Generic small function plot on axes, window [-6,6]x[-6,6]
function svgFnPlot(fn, size=180, dotAt=null){
  const pad = 16, cx = size/2, cy = size/2, unit = (size-2*pad)/12;
  const X = x => cx + x*unit, Y = y => cy - y*unit;
  let grid = '';
  for(let g=-6; g<=6; g++){
    grid += `<line x1="${X(g)}" y1="${pad}" x2="${X(g)}" y2="${size-pad}" stroke="#2a3555" stroke-width="0.5"/>`;
    grid += `<line x1="${pad}" y1="${Y(g)}" x2="${size-pad}" y2="${Y(g)}" stroke="#2a3555" stroke-width="0.5"/>`;
  }
  let segs = [], pts = [];
  for(let x=-6; x<=6; x+=0.08){
    let y;
    try { y = fn(x); } catch(e){ y = NaN; }
    if(isFinite(y) && y>=-6.5 && y<=6.5) pts.push(`${X(x).toFixed(1)},${Y(y).toFixed(1)}`);
    else { if(pts.length>1) segs.push(pts.join(' ')); pts = []; }
  }
  if(pts.length>1) segs.push(pts.join(' '));
  const dot = dotAt ? `<circle cx="${X(dotAt[0])}" cy="${Y(dotAt[1])}" r="3" fill="#f59e0b"/>` : '';
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#141c36;border-radius:8px;">
    ${grid}
    <line x1="${pad}" y1="${cy}" x2="${size-pad}" y2="${cy}" stroke="#556" stroke-width="1.2"/>
    <line x1="${cx}" y1="${pad}" x2="${cx}" y2="${size-pad}" stroke="#556" stroke-width="1.2"/>
    <text x="${size-14}" y="${cy-4}" fill="#889" font-size="10">x</text>
    <text x="${cx+4}" y="${pad+8}" fill="#889" font-size="10">y</text>
    <text x="${X(2)-3}" y="${cy+11}" fill="#889" font-size="8">2</text>
    <text x="${cx-11}" y="${Y(2)+3}" fill="#889" font-size="8">2</text>
    ${segs.map(s=>`<polyline points="${s}" fill="none" stroke="#60a5fa" stroke-width="2.2"/>`).join('')}
    ${dot}
  </svg>`;
}

// ---------- CA (MTH 161) ----------

// Even / odd / neither

// End behavior from the leading term

// Identify exp/log graph (answer-first curve question)

// Convert exponential <-> logarithmic form

// Range of a = sqrt / squared shifted function

// ---------- TRIG (MTH 162) ----------

// Sinusoidal model (Ferris wheel)

// Identify a sinusoid from its graph (answer-first curve question)

// ---------- C1 (MTH 263) ----------

// Inverse trig derivative: arctan(ax)

// Second related-rates scenario: expanding circle

// Net Change Theorem: displacement from velocity

// ---------- C2 (MTH 264) ----------

// Volumes by known cross-sections over a triangular base

// Work pumping a full cylindrical tank (symbolic density rho)

// Centroid of the triangle under y = x on [0, a]

// Trapezoidal rule estimate (n=2) for ∫0..a x² dx

// Limit of a sequence (rational in n)

// Maclaurin series of sin(ax): first three nonzero terms

// Conic from polar equation r = k/(1 + e cosθ)

// ---------- C3 (MTH 265) ----------

// Sphere equation: complete the square (answer-first)

// Identify quadric surface

// Curvature of a circle r(t)=<a cos t, a sin t>

// Unit tangent vector of a helix at t=0

// Motion in space: acceleration from position

// Multivariable chain rule

// Limit of two variables: exists (squeeze) or DNE (paths)

// Triple integral in spherical coordinates (ball volume element)

// Triple integral over a box

// Line integral of F·dr along a straight segment

// Flux of a constant vertical field through a horizontal disk

// Stokes' Theorem with a constant-curl field over a disk

// Divergence Theorem for a linear field through a sphere


// ============================================================
// NVCC OUTLINE GAP FILL — 19 high-priority generators
// (from the missing-generator audit vs official VCCS outlines)
// ============================================================

function mwNZ(rng, lo, hi){ let v = 0; while(v === 0) v = randInt(rng, lo, hi); return v; }
function mwFracTex(n, d){
  if(d < 0){ n = -n; d = -d; }
  const g = gcd(Math.abs(n), d) || 1;
  n /= g; d /= g;
  if(d === 1) return `${n}`;
  return (n < 0 ? `-\\frac{${-n}}{${d}}` : `\\frac{${n}}{${d}}`);
}

// ---------- MTH 161 (CA) ----------

// ★ Complex zeros: answer-first — pick p ± qi, build x^2 - 2p x + (p^2+q^2)

// ★ Polynomial inequality via sign chart: (x-r1)(x-r2) vs 0

// ★ Rational inequality: (x-a)/(x-b) <= 0 (or > 0) — denominator zero never included

// ---------- MTH 162 (TRIG) ----------

// ★ Solve a right triangle side (SOH-CAH-TOA)

// ★ Angle of elevation

// ---------- MTH 263 (C1) ----------

// ★ One-sided limit of a piecewise function

// ★ Derivative by the limit definition

// ★ Tangent line at a point

// ★ Quotient rule on (ax+b)/(cx+d)

// ★ Chain rule on (ax+b)^n

// ★ Trig derivatives: a sin x + b cos x

// ★ Area between y = ax and y = x^2 (intersect at 0 and a)

// ---------- MTH 264 (C2) ----------

// ★ L'Hopital's rule: sin(ax)/(bx) or (e^{ax}-1)/(bx) as x→0

// ---------- MTH 265 (C3) ----------

// ★ Cross product

// ★ Vector projection (answer-first: u = c*v + t*w with w ⟂ v)

// ★ Arc length of a helix (clean via 3-4-5 style pairs)

// ★ Gradient and directional derivative (3-4-5 direction)

// ★ Classify critical point of f(x,y) (second derivative test)

// ★ Curl and divergence of a linear field


// --- Answer-first curve generator: identify the parabola from its graph ---
// Pick the answer (vertex form) first; the drawn axes+curve IS the question.
function svgParabola(aCoef, h, k, size=180){
  const pad = 16, cx = size/2, cy = size/2, unit = (size-2*pad)/12; // window: x,y in [-6,6]
  const X = x => cx + x*unit, Y = y => cy - y*unit;
  let grid = '';
  for(let g=-6; g<=6; g++){
    grid += `<line x1="${X(g)}" y1="${pad}" x2="${X(g)}" y2="${size-pad}" stroke="#2a3555" stroke-width="0.5"/>`;
    grid += `<line x1="${pad}" y1="${Y(g)}" x2="${size-pad}" y2="${Y(g)}" stroke="#2a3555" stroke-width="0.5"/>`;
  }
  let pts = [];
  for(let x=-6; x<=6; x+=0.15){
    const y = aCoef*(x-h)*(x-h)+k;
    if(y>=-6.5 && y<=6.5) pts.push(`${X(x).toFixed(1)},${Y(y).toFixed(1)}`);
  }
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="display:block;margin:8px auto;background:#141c36;border-radius:8px;">
    ${grid}
    <line x1="${pad}" y1="${cy}" x2="${size-pad}" y2="${cy}" stroke="#556" stroke-width="1.2"/>
    <line x1="${cx}" y1="${pad}" x2="${cx}" y2="${size-pad}" stroke="#556" stroke-width="1.2"/>
    <text x="${size-14}" y="${cy-4}" fill="#889" font-size="10">x</text>
    <text x="${cx+4}" y="${pad+8}" fill="#889" font-size="10">y</text>
    <text x="${X(2)-3}" y="${cy+11}" fill="#889" font-size="8">2</text>
    <text x="${cx-11}" y="${Y(2)+3}" fill="#889" font-size="8">2</text>
    <polyline points="${pts.join(' ')}" fill="none" stroke="#60a5fa" stroke-width="2.2"/>
    <circle cx="${X(h)}" cy="${Y(k)}" r="3" fill="#f59e0b"/>
  </svg>`;
}


// Paste more generators here.
// =======================================================
// =======================================================
// COLLEGE ALGEBRA GENERATORS
// =======================================================

// ---- Linear Equations & Inequalities ----

// Solve linear equation: ax + b = cx + d

// Solve absolute value equation: |ax + b| = c

// Linear inequality: ax + b < cx + d


// --- NEW (MTH 161 priority): Systems of Linear Inequalities (feasible region) ---

// Feasible region (triangle) — list vertices

// Feasible region + objective (linear programming intro)

// Feasible region (rectangle clipped by a diagonal) — list vertices

// Feasible region (quadrilateral) — list vertices

// --- NEW (MTH 161 priority): Absolute Value graphing/representation ---

// Absolute value transformations: vertex + description

// Absolute value: write as piecewise

// Absolute value: intercepts (and a quick graph checklist)

// ---- Quadratic Functions ----

// Find vertex from vertex form

// Complete the square

// Quadratic formula

// Quadratic application: area/perimeter

// ---- Polynomial Functions ----

// Factor completely: difference of squares

// Synthetic division

// Find zeros of polynomial

// Rational Root Theorem


// --- NEW (MTH 161 priority): Radical equations (with extraneous-solution check) ---

// Radical equation: sqrt(ax+b) = x + c

// Radical equation: sqrt(ax+b) = x - d (often produces an extraneous root)

// Radical equation: sqrt(ax+b) = sqrt(cx+d)

// ---- Rational Functions ----

// Domain of rational function

// Vertical asymptotes

// Horizontal asymptote

// Holes in rational functions

// ---- Exponential & Logarithmic Functions ----

// Solve exponential equation: a^x = b

// Logarithm properties: expand

// Logarithm properties: condense

// Solve logarithmic equation

// Exponential growth/decay

// Change of base formula

// ---- Systems of Equations ----

// System of 2 equations (substitution)

// ---- 3×3 Gaussian Elimination (MTH 161 Systems) ----
const genCASystemClassification = (rng)=> {
  const type = pick(rng, ['unique','unique','unique','unique','unique','unique','unique','unique','none','infinite']); // 80/10/10

  // Helper to format a row for augmented matrix
  const rowTex = (R)=> `${R[0]}&${R[1]}&${R[2]}&${R[3]}`;
  const matTex = (R1,R2,R3)=> `\\left[\\begin{array}{ccc|c}${rowTex(R1)}\\\\${rowTex(R2)}\\\\${rowTex(R3)}\\end{array}\\right]`;

  // QUICK "dependent/contradiction" families for clean pedagogy
  if(type === 'infinite'){
    const r = randInt(rng, -8, 8);
    const s = randInt(rng, -8, 8);
    // x + z = r;  y - z = s;  x + y = r + s  (dependent)
    const R1 = [1,0,1,r];
    const R2 = [0,1,-1,s];
    const R3 = [1,1,0,r+s];
    const ans = `\\(\\text{Infinitely many solutions. Let } z=t.\\; x=${r}-t,\\; y=${s}+t,\\; z=t.\\)`;
    return {
      q: `Determine the solution set (if any) for the system:\n` +
         `\\[\\begin{cases}x+z=${r}\\\\y-z=${s}\\\\x+y=${r+s}\\end{cases}\\]`,
      a: ans,
      steps: [
        `Augmented matrix: \\(${matTex(R1,R2,R3)}\\).`,
        `Add the first two equations: \\((x+z)+(y-z)=x+y=${r+s}\\), which matches the third equation.`,
        `So one equation is redundant \\(\\Rightarrow\\) rank < number of variables.`,
        `Let \\(z=t\\). Then from eqn 1: \\(x=${r}-t\\). From eqn 2: \\(y=${s}+t\\).`
      ],
      vec: [unitIndex('CA_Systems'), 81, r, s, 0,0],
      key:'ca_gauss_infinite_clean'
    };
  }
  if(type === 'none'){
    const r = randInt(rng, -8, 8);
    const s = randInt(rng, -8, 8);
    const k = pick(rng, [-5,-4,-3,3,4,5]);
    // Same first two; third contradicts the implied x+y = r+s
    const R1 = [1,0,1,r];
    const R2 = [0,1,-1,s];
    const R3 = [1,1,0,r+s+k];
    return {
      q: `Determine the solution set (if any) for the system:\n` +
         `\\[\\begin{cases}x+z=${r}\\\\y-z=${s}\\\\x+y=${r+s+k}\\end{cases}\\]`,
      a: `\\(\\text{No solution (inconsistent system).}\\)`,
      steps: [
        `From the first two equations: \\((x+z)+(y-z)=x+y=${r+s}\\).`,
        `But the third equation says \\(x+y=${r+s+k}\\) with \\(k\\ne 0\\).`,
        `That would require \\(${r+s}=${r+s+k}\\Rightarrow 0=k\\), a contradiction.`,
        `Therefore the system has no solution.`
      ],
      vec: [unitIndex('CA_Systems'), 82, r, s, k,0],
      key:'ca_gauss_none_clean'
    };
  }

  // Unique-solution case (backward construction + integer-safe elimination)
  let tries = 0;
  while(tries++ < 250){
    const x = randInt(rng, -3, 3);
    const y = randInt(rng, -3, 3);
    const z = randInt(rng, -3, 3);

    const a11 = pick(rng, [1,2,3]);
    const a22 = pick(rng, [1,2,3]);
    const a33 = pick(rng, [1,2,3]);
    const a12 = randInt(rng, -3, 3);
    const a13 = randInt(rng, -3, 3);
    const a21 = randInt(rng, -3, 3);
    const a23 = randInt(rng, -3, 3);
    const a31 = randInt(rng, -3, 3);
    const a32 = randInt(rng, -3, 3);

    // Determinant check (cheap exact integer)
    const det = a11*(a22*a33 - a23*a32) - a12*(a21*a33 - a23*a31) + a13*(a21*a32 - a22*a31);
    if(det === 0) continue;

    const b1 = a11*x + a12*y + a13*z;
    const b2 = a21*x + a22*y + a23*z;
    const b3 = a31*x + a32*y + a33*z;

    const R1 = [a11,a12,a13,b1];
    const R2 = [a21,a22,a23,b2];
    const R3 = [a31,a32,a33,b3];

    // Eliminate x using integer-safe ops: R2 <- a11*R2 - a21*R1; R3 <- a11*R3 - a31*R1
    const comb = (A,RA,B,RB)=> RA.map((v,i)=> A*v + B*RB[i]);
    const E2 = comb(a11,R2,-a21,R1);
    const E3 = comb(a11,R3,-a31,R1);

    // Ensure we have a y-pivot in row2 (swap if needed)
    let P2 = E2, P3 = E3, swapFlag = false;
    if(P2[1] === 0 && P3[1] !== 0){ P2 = E3; P3 = E2; swapFlag = true; }
    if(P2[1] === 0) continue; // regenerate

    // Eliminate y: R3 <- p*R3 - (y3)*R2 (with p=P2[1])
    const p = P2[1];
    const y3 = P3[1];
    const F3 = comb(p,P3,-y3,P2);
    if(F3[2] === 0) continue; // avoid z-free in unique case

    // Solve
    const zSol = F3[3] / F3[2];
    const ySol = (P2[3] - P2[2]*zSol) / p;
    const xSol = (b1 - a12*ySol - a13*zSol) / a11;

    if(!Number.isFinite(xSol) || !Number.isFinite(ySol) || !Number.isFinite(zSol)) continue;
    if(Math.abs(xSol - x) > 1e-9 || Math.abs(ySol - y) > 1e-9 || Math.abs(zSol - z) > 1e-9) continue;

    // Pretty row-op strings
    const opR2 = `R_2\\leftarrow ${a11}R_2-${a21}R_1`;
    const opR3 = `R_3\\leftarrow ${a11}R_3-${a31}R_1`;
    const opSwap = swapFlag ? `Swap \\(R_2\\leftrightarrow R_3\\) to get a y-pivot.` : '';
    const opY = `R_3\\leftarrow ${p}R_3-${y3}R_2`;

    return {
      q: `Solve the system using Gaussian elimination:\n` +
         `\\[\\begin{cases}${a11}x ${fmtSigned(a12)}y ${fmtSigned(a13)}z = ${b1}\\\\` +
         `${a21}x ${fmtSigned(a22)}y ${fmtSigned(a23)}z = ${b2}\\\\` +
         `${a31}x ${fmtSigned(a32)}y ${fmtSigned(a33)}z = ${b3}\\end{cases}\\]`,
      a: `\\(x=${x},\\;y=${y},\\;z=${z}\\)`,
      steps: [
        `Write the augmented matrix: \\(${matTex(R1,R2,R3)}\\).`,
        `Eliminate \\(x\\): \\(${opR2}\\), \\(${opR3}\\).`,
        `This gives: \\(${matTex(R1,P2,P3)}\\).` + (opSwap ? ` ${opSwap}` : ''),
        `Eliminate \\(y\\): \\(${opY}\\). Now: \\(${matTex(R1,P2,F3)}\\).`,
        `Back-substitute: from last row solve \\(z=${z}\\); then \\(y=${y}\\); then \\(x=${x}\\).`
      ],
      vec: [unitIndex('CA_Systems'), 80, x, y, z, a11, a22],
      key:'ca_gauss_unique'
    };
  }
  // fallback (should be rare)
  return {
    q: `Solve the system using Gaussian elimination: \\(\\begin{cases}x+y+z=1\\\\2x-y+z=0\\\\x-2y+3z=4\\end{cases}\\)`,
    a: `\\(x=1,\\;y=0,\\;z=0\\)`,
    steps: [`(Regenerate if needed.)`],
    vec: [unitIndex('CA_Systems'), 89, 0,0,0],
    key:'ca_gauss_fallback'
  };
};
genCASystemClassification.meta = { topicId:'system-classification', topicLabel:'3×3 System Classification' };


// System of 2 equations (elimination)

// System with 3 variables (basic)

// Application: mixture problem

// ---- Function Operations ----

// Function composition

// ---- Difference Quotient (MTH 161 Function Operations) ----

// ---- Function Transformations (MTH 161) ----


// Find inverse function

// Domain of composition

// Piecewise function evaluation

// =======================================================
// TRIGONOMETRY GENERATORS
// =======================================================

// ---- Angle Conversions ----

// Degrees to radians

// Radians to degrees

// Arc length

// ---- Unit Circle & Trig Values ----

// Evaluate trig function at special angle

// Find reference angle

// Sign of trig function in quadrant

// Coterminal angles

// ---- Trig Identities ----

// Pythagorean identity: solve for sin or cos

// ---- Trig Graph Features (Amplitude / Period / Phase / Vertical shift) ----


// Simplify using identity

// Double angle formula

// Verify identity


// --- NEW (MTH 162 priority): Inverse trig composites, sum/difference, half-angle (with worked steps) ---

// sin(arctan(a/b))

// cos(arctan(a/b))

// tan(arcsin(p/q)) using a Pythagorean triple

// sin(arccos(p/q)) using a Pythagorean triple

// Sum formula: sin(75°) or sin(15°)

// Sum/difference: cos(15°) or cos(75°)

// tan(75°) using sum formula

// Half-angle: cos(22.5°) exact

// Half-angle: sin(22.5°) exact

// Recognize sine addition pattern: sin x cos a + cos x sin a

// ---- Solving Trig Equations ----

// Solve basic trig equation

// Solve quadratic trig equation

// Solve using identity

// ---- Law of Sines & Cosines ----

// Law of Sines: find side


// Law of Cosines: find side (FIXED: avoids float precision artifacts)

// Area of triangle (SAS)

// ---- Polar Coordinates ----

// Convert polar to rectangular

// Convert rectangular to polar

// Polar equation: identify curve

// =======================================================
// PRE-CALCULUS ADDITIONAL GENERATORS
// =======================================================

// ---- Conic Sections ----

// Circle: standard form

// ---- Conics: General form -> Standard form (Completing the square) ----


// Parabola: vertex form

// Ellipse: center and axes

// Hyperbola: identify

// ---- Sequences & Series ----

// Arithmetic sequence: find term

// Geometric sequence: find term

// Arithmetic series: sum

// Infinite geometric series

// ---- Vectors (Intro) ----

// Vector magnitude

// Vector addition

// Scalar multiplication

// Unit vector

// =======================================================
// DONE! 
// =======================================================
// Total generators added: ~80 problem types
// Coverage: College Algebra (7 units), Trigonometry (6 units), Pre-Calc additions (3 units)
// This makes the worksheet builder comprehensive for ALL lower-division math courses!

// =====================
