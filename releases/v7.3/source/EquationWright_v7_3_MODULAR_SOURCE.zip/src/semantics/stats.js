
// Limits: rational cancellation (fixed LaTeX delimiters)

// Limits at infinity (missing topic)

// Continuity: choose k for continuity (piecewise)

// Derivatives: product rule (x^m sin(ax))

// Derivatives: exp/log (missing topic)

// Derivatives: implicit

// Applications: MVT (missing topic)

// =======================================================
// NVCC Sprint 1 add-ons (adapted from multi-AI experiment)
// Helpers used by volumes/series/arc length/Jacobian generators
// =======================================================
function mwFrac(n, d=1){
  if(d === 0) return {n: 1, d: 0};
  if(d < 0){ n = -n; d = -d; }
  const g = gcd(Math.abs(n), Math.abs(d));
  return { n: n/g, d: d/g };
}
function mwAddF(A, B){ return mwFrac(A.n*B.d + B.n*A.d, A.d*B.d); }
function mwSubF(A, B){ return mwFrac(A.n*B.d - B.n*A.d, A.d*B.d); }
function mwMulF(A, B){ return mwFrac(A.n*B.n, A.d*B.d); }
function mwFracToTex(F){ return exactFrac(F.n, F.d); }

function mwPowInt(x, k){
  let r = 1;
  for(let i=0;i<k;i++) r *= x;
  return r;
}
// polynomials as arrays ascending: p[0] + p[1]x + p[2]x^2 + ...
function mwPolyMul(p, q){
  const r = Array(p.length + q.length - 1).fill(0);
  for(let i=0;i<p.length;i++){
    for(let j=0;j<q.length;j++){
      r[i+j] += p[i]*q[j];
    }
  }
  return r;
}
function mwPolyPow2(p){ return mwPolyMul(p, p); }
function mwPolyToTex(p, v='x'){
  // render descending, skip zeros
  const terms = [];
  for(let i=p.length-1;i>=0;i--){
    const c = p[i];
    if(c === 0) continue;
    const sign = c < 0 ? '-' : '+';
    const abs = Math.abs(c);
    let core = '';
    if(i === 0) core = `${abs}`;
    else if(i === 1) core = (abs === 1 ? '' : `${abs}`) + v;
    else core = (abs === 1 ? '' : `${abs}`) + `${v}^{${i}}`;
    terms.push({sign, core});
  }
  if(terms.length === 0) return '0';
  let out = (terms[0].sign === '-' ? '-' : '') + terms[0].core;
  for(let k=1;k<terms.length;k++){
    out += ` ${terms[k].sign} ${terms[k].core}`;
  }
  return out;
}
function mwPolyDefInt(p, a, b){
  // exact ∫_a^b p(x) dx
  let S = mwFrac(0,1);
  for(let k=0;k<p.length;k++){
    const c = p[k];
    if(c === 0) continue;
    const diff = mwPowInt(b, k+1) - mwPowInt(a, k+1);
    S = mwAddF(S, mwFrac(c*diff, k+1));
  }
  return S;
}
// sqrt(n) -> a*sqrt(b), b squarefree
function mwSqrtParts(n){
  let a = 1, b = Math.abs(n);
  for(let k=2;k*k<=b;k++){
    while(b % (k*k) === 0){
      b /= (k*k);
      a *= k;
    }
  }
  return { a, b };
}
function mwSqrtTex(n){
  const sign = (n < 0) ? 'i' : '';
  const parts = mwSqrtParts(n);
  const a = parts.a, b = parts.b;
  if(b === 1) return `${a}${sign}`;
  if(a === 1) return `${sign}\\sqrt{${b}}`;
  return `${sign}${a}\\sqrt{${b}}`;
}
// (num/den)*pi, simplified and pretty
function mwPiTex(num, den=1){
  const f = mwFrac(num, den);
  if(f.d === 0) return '\\text{DNE}';
  if(f.n === 0) return '0';
  if(f.d === 1){
    if(f.n === 1) return '\\pi';
    if(f.n === -1) return '-\\pi';
    return `${f.n}\\pi`;
  }
  const absn = Math.abs(f.n);
  const frac = (absn === 1) ? `\\frac{\\pi}{${f.d}}` : `\\frac{${absn}\\pi}{${f.d}}`;
  return (f.n < 0 ? '-' : '') + frac;
}
function mwPoly2Tex(a,b,c){
  return mwPolyToTex([c,b,a], 'x');
}

// ---- Linearization / Differentials (MTH 263 / Calc I Apps) ----

// --- NEW (Calc I priority): Fundamental Theorem of Calculus (derivative of an integral) ---






// Applications: related rates ladder (from C1 file)

// Integrals: Riemann sum + eval


// --- NEW (Calc I priority): Optimization + curve sketching synthesis ---

// Fence along a river: maximize area

// Open-top box from a square: maximize volume

// Closed cylinder: minimize surface area for a fixed volume

// Curve sketching synthesis (cubic)

// Curve sketching synthesis (rational)


// Integrals: substitution rule (missing topic)

// =======================================================
// CALC 2 GENERATORS (merged + expanded)
// =======================================================

// IBP: ∫ x e^{ax} dx


// --- NEW (Calc I priority): Average value of a function ---




// Trig identity: ∫ sin^2 x dx

// Partial fractions (missing topic)

// Trig substitution (missing topic) — standard form

// Improper p-integral (value/diverge)


// --- NEW (Calc II priority): Separable Differential Equations ---




// Improper integral type II (vertical asymptote) (missing)

// Series: geometric sum

// ---- Series Tests (Comparison / Limit Comparison / Root / Ratio) ----
const genC2SeriesConvergenceTests = (rng)=> {
  const kind = pick(rng, ['ratio','root','lct']);

  if(kind === 'ratio'){
    const c = pick(rng, [2,3,4,5]);
    const variant = pick(rng, ['cn_over_fact','fact_over_cn']);
    if(variant === 'cn_over_fact'){
      // Σ c^n / n!
      return {
        q: `Determine whether the series converges or diverges (use the Ratio Test):\n\\[\\sum_{n=0}^{\\infty} \\frac{${c}^n}{n!}\\]`,
        a: `Converges (Ratio Test gives limit 0).`,
        steps: [
          `Let \\(a_n=\\frac{${c}^n}{n!}\\).`,
          `\\(\\left|\\frac{a_{n+1}}{a_n}\\right|=\\frac{${c}^{n+1}}{(n+1)!}\\cdot\\frac{n!}{${c}^n}=\\frac{${c}}{n+1}\\to 0\\).`,
          `Since the limit is < 1, the series converges absolutely.`
        ],
        vec: [unitIndex('C2_Series'), 81, c, 1,0,0],
        key:'c2_ratio_cn_over_fact'
      };
    } else {
      // Σ n! / c^n (diverges)
      return {
        q: `Determine whether the series converges or diverges (use the Ratio Test):\n\\[\\sum_{n=1}^{\\infty} \\frac{n!}{${c}^n}\\]`,
        a: `Diverges (Ratio Test gives limit \\(\\infty\\)).`,
        steps: [
          `Let \\(a_n=\\frac{n!}{${c}^n}\\).`,
          `\\(\\left|\\frac{a_{n+1}}{a_n}\\right|=\\frac{(n+1)!}{${c}^{n+1}}\\cdot\\frac{${c}^n}{n!}=\\frac{n+1}{${c}}\\to \\infty\\).`,
          `Since the limit is > 1, the series diverges.`
        ],
        vec: [unitIndex('C2_Series'), 82, c, 2,0,0],
        key:'c2_ratio_fact_over_cn'
      };
    }
  }

  if(kind === 'root'){
    // Σ n^k (p/q)^n
    const k = pick(rng, [0,1,2,3]);
    let p,q;
    do{
      p = pick(rng, [-4,-3,-2,2,3,4]);
      q = pick(rng, [2,3,4,5,6]);
    } while (Math.abs(p) === q); // avoid L=1
    const fracTex = `\\left(\\frac{${p}}{${q}}\\right)^n`;
    const L = Math.abs(p/q);
    const conv = L < 1;
    return {
      q: `Determine whether the series converges or diverges (use the Root Test):\n\\[\\sum_{n=1}^{\\infty} n^{${k}} ${fracTex}\\]`,
      a: conv ? `Converges absolutely (Root Test gives \\(L=${exactFrac(Math.abs(p), q)}<1\\)).`
              : `Diverges (Root Test gives \\(L=${exactFrac(Math.abs(p), q)}>1\\)).`,
      steps: [
        `Let \\(a_n=n^{${k}}\\left(\\frac{${p}}{${q}}\\right)^n\\).`,
        `\\(\\sqrt[n]{|a_n|}=\\sqrt[n]{n^{${k}}}\\cdot\\left|\\frac{${p}}{${q}}\\right|\\to 1\\cdot ${exactFrac(Math.abs(p), q)}\\).`,
        `So \\(L=${exactFrac(Math.abs(p), q)}\\). ${conv?`Since \\(L<1\\), the series converges.`:`Since \\(L>1\\), the series diverges.`}`
      ],
      vec: [unitIndex('C2_Series'), 83, k, p, q,0],
      key:'c2_root_npqn'
    };
  }

  // Limit Comparison with a p-series
  const p = pick(rng, [1,2,3]); // p=1 diverges, p>1 converges
  const s = pick(rng, [1,2,3]);
  const A = pick(rng, [1,2,3,4]);
  const B = pick(rng, [1,2,3,4]);
  const C = randInt(rng, -5, 5);
  // a_n = (A n^s + C) / (B n^{s+p})
  const aTex = `\\frac{${A}n^{${s}}${C===0?'':(C>0?`+${C}`:`${C}`)}}{${B}n^{${s+p}}}`;
  const Ltex = exactFrac(A, B);
  const conv = (p > 1);

  return {
    q: `Determine whether the series converges or diverges (use the Limit Comparison Test):\n\\[\\sum_{n=1}^{\\infty} ${aTex}\\]`,
    a: conv ? `Converges (limit compares to \\(\\sum \\frac{1}{n^{${p}}}\\)).` : `Diverges (limit compares to \\(\\sum \\frac{1}{n}\\)).`,
    steps: [
      `Compare with \\(b_n=\\frac{1}{n^{${p}}}\\).`,
      `Compute \\(L=\\lim_{n\\to\\infty} \\frac{a_n}{b_n} = \\lim \\frac{\\frac{${A}n^{${s}}${C===0?'':(C>0?`+${C}`:`${C}`)}}{${B}n^{${s+p}}}}{\\frac{1}{n^{${p}}}}\\).`,
      `This simplifies to \\(\\lim_{n\\to\\infty} \\frac{${A}n^{${s}}${C===0?'':(C>0?`+${C}`:`${C}`)}}{${B}n^{${s}}} = ${Ltex}\\).`,
      `Since \\(0 < L < \\infty\\), \\(\\sum a_n\\) converges/diverges with \\(\\sum b_n\\).`,
      conv ? `\\(\\sum \\frac{1}{n^{${p}}}\\) converges (p-series with \\(p>1\\)).`
           : `\\(\\sum \\frac{1}{n}\\) diverges (harmonic series).`
    ],
    vec: [unitIndex('C2_Series'), 84, p,s,A,B,C],
    key:'c2_limit_comparison_clean'
  };
};
genC2SeriesConvergenceTests.meta = { topicId:'convergence-tests', topicLabel:'Series Convergence Tests' };


// Series: ratio test (missing topic)

// Series: alternating test (missing)

// Power series / Taylor (missing)

// Parametric dy/dx at t=c


// --- NEW (Calc II priority): Radius/Interval of Convergence + Alternating Error + Series Forms ---

// IOC for Σ x^n / n

// IOC for Σ (x-1)^n/(n·5^n)

// IOC for Σ n((x+2)/4)^n

// Alternating Series Estimation Theorem (error bound)

// Maclaurin series (first 4 nonzero terms)

// Geometric series form for 1/(1-ax)


// Polar area

// Applications of integration: arc length (missing)

// ---- Volumes of Revolution (Disk/Washer/Shell) ----

// ---- Arc Length: Parametric line (constant speed) ----


// ---- Added in mini-sprint: Volume of Revolution (aliases + extra variety) ----

// Alias-style: disk method with positive polynomial on [a,b]

// Extra variety: hemispherical tank volume via slicing


// ---- Arc Length: Polar circle r=R over an interval ----


// Applications: work (missing)

// Applications: area under curve

// =======================================================
// CALC 3 GENERATORS (merged + expanded)
// =======================================================

function vecTeX(v){ return `\\(\\langle ${v.join(', ')} \\rangle\\)`; }
function dot3(a,b){ return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; }
function cross3(a,b){
  return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]];
}
function normSq3(v){ return dot3(v,v); }
function norm3(v){ return Math.sqrt(normSq3(v)); }

// Vectors: dot


// --- NEW (Calc II priority): Surface Area of Revolution + Arc Length (y=f(x)) ---




// Vectors: plane equation

// Vectors: distance point to plane (missing)

// Partials: compute fx, fy at point for quadratic

// Partials: tangent plane (missing)

// Partials: Lagrange multipliers (missing, simple)

// Multiple integrals: rectangle (from C3)

// ---- Change of Variables / Jacobian (Polar Coordinates) ----


// Multiple integrals: polar (missing)

// Multiple integrals: triple cylindrical (missing, simple constant)

// Vector calculus: conservative line integral (from C3)

// Vector calculus: Green's theorem (missing, simple curl constant)

// =======================================================
// ===== STATS ENGINE (mw_stats_engine_v1 — SciPy-audited) =====
/*
 * Math Worksheet Builder — Small Statistics Engine v1
 *
 * Design contract
 * ----------------
 * - Pure numerical helpers only: no HTML, TeX, course IDs, quiz logic, or RNG.
 * - Use full JavaScript Number precision internally.
 * - Round only when a generator constructs its displayed `a` or `steps` strings.
 * - Invalid numerical inputs return NaN.
 * - Unsupported discrete table lookups throw RangeError because they indicate
 *   a generator-programming error.
 * - Binomial helpers are intentionally limited to 0 <= n <= 100.
 * - The inverse-normal helper is intentionally limited to probabilities
 *   represented by mwNormCdf on the bracket [-8, 8].
 *
 * Paste this block after the existing general numeric helpers and before UNITS.
 */

// =======================================================
// Probability utilities
// =======================================================

function mwClampProbability(value){
  value = Number(value);
  if(!Number.isFinite(value)) return NaN;
  if(value <= 0) return 0;
  if(value >= 1) return 1;
  return value;
}

// Standard normal density φ(z).
function mwNormPdf(z){
  z = Number(z);
  if(Number.isNaN(z)) return NaN;
  return Math.exp(-0.5 * z * z) / Math.sqrt(2 * Math.PI);
}

// Standard normal CDF Φ(z).
// Abramowitz–Stegun 7.1.26 error-function approximation.
function mwNormCdf(z){
  z = Number(z);

  if(Number.isNaN(z)) return NaN;
  if(z === Infinity) return 1;
  if(z === -Infinity) return 0;
  if(z === 0) return 0.5;

  const sign = z < 0 ? -1 : 1;
  const x = Math.abs(z) / Math.SQRT2;

  const p  = 0.3275911;
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;

  const t = 1 / (1 + p * x);
  const poly =
    (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t);

  const erf = sign * (1 - poly * Math.exp(-x * x));
  return mwClampProbability(0.5 * (1 + erf));
}

// Standard normal survival probability P(Z > z).
// This wrapper improves readability and avoids a separate `1 - cdf` operation.
// The A&S approximation still has limited relative accuracy in extreme tails.
function mwNormSf(z){
  return mwNormCdf(-Number(z));
}

// P(lower <= Z <= upper), with support for infinite endpoints.
function mwNormInterval(lower, upper){
  lower = Number(lower);
  upper = Number(upper);

  if(Number.isNaN(lower) ||
     Number.isNaN(upper) ||
     lower > upper){
    return NaN;
  }

  if(lower === upper) return 0;

  const value = lower >= 0
    ? mwNormSf(lower) - mwNormSf(upper)
    : mwNormCdf(upper) - mwNormCdf(lower);

  return mwClampProbability(value);
}

// Inverse standard normal CDF by bisection.
// Returns NaN instead of silently saturating when p is outside the supported
// CDF range of the fixed [-8, 8] bracket.
function mwInvNorm(p){
  p = Number(p);

  if(Number.isNaN(p) || p < 0 || p > 1) return NaN;
  if(p === 0) return -Infinity;
  if(p === 1) return Infinity;
  if(p === 0.5) return 0;

  let lo = -8;
  let hi = 8;

  const pLo = mwNormCdf(lo);
  const pHi = mwNormCdf(hi);

  if(p < pLo || p > pHi) return NaN;

  for(let i = 0; i < 60; i++){
    const mid = (lo + hi) / 2;

    if(mwNormCdf(mid) < p){
      lo = mid;
    }else{
      hi = mid;
    }
  }

  return (lo + hi) / 2;
}

// =======================================================
// Descriptive statistics
// =======================================================

// Arithmetic mean with compensated summation.
function mwMean(values){
  if(!Array.isArray(values) || values.length === 0) return NaN;

  let sum = 0;
  let correction = 0;

  for(const value of values){
    const x = Number(value);
    if(!Number.isFinite(x)) return NaN;

    const adjusted = x - correction;
    const next = sum + adjusted;
    correction = (next - sum) - adjusted;
    sum = next;
  }

  return sum / values.length;
}

// Median without mutating the caller's array.
function mwMedian(values){
  if(!Array.isArray(values) || values.length === 0) return NaN;

  const sorted = values.map(Number);
  if(sorted.some(x => !Number.isFinite(x))) return NaN;

  sorted.sort((a, b) => a - b);

  const n = sorted.length;
  const middle = Math.floor(n / 2);

  return n % 2 === 1
    ? sorted[middle]
    : (sorted[middle - 1] + sorted[middle]) / 2;
}

// Numerically stable single-pass mean and sum of squared deviations.
function mwWelford(values){
  if(!Array.isArray(values)){
    return { count: 0, mean: NaN, m2: NaN };
  }

  let count = 0;
  let mean = 0;
  let m2 = 0;

  for(const value of values){
    const x = Number(value);

    if(!Number.isFinite(x)){
      return { count: 0, mean: NaN, m2: NaN };
    }

    count++;
    const delta = x - mean;
    mean += delta / count;
    const delta2 = x - mean;
    m2 += delta * delta2;
  }

  return { count, mean, m2 };
}

function mwPopulationVariance(values){
  if(!Array.isArray(values) || values.length === 0) return NaN;

  const result = mwWelford(values);
  return result.count > 0 ? result.m2 / result.count : NaN;
}

function mwPopulationSD(values){
  const variance = mwPopulationVariance(values);
  return Number.isFinite(variance) ? Math.sqrt(Math.max(0, variance)) : NaN;
}

function mwSampleVariance(values){
  if(!Array.isArray(values) || values.length < 2) return NaN;

  const result = mwWelford(values);
  return result.count >= 2 ? result.m2 / (result.count - 1) : NaN;
}

function mwSampleSD(values){
  const variance = mwSampleVariance(values);
  return Number.isFinite(variance) ? Math.sqrt(Math.max(0, variance)) : NaN;
}

function mwZScore(x, mean, sd){
  x = Number(x);
  mean = Number(mean);
  sd = Number(sd);

  if(!Number.isFinite(x) ||
     !Number.isFinite(mean) ||
     !Number.isFinite(sd) ||
     sd <= 0){
    return NaN;
  }

  return (x - mean) / sd;
}

// =======================================================
// Counting and binomial distribution
// =======================================================

// Exact while the result remains a safe JavaScript integer.
function mwFactorial(n){
  n = Number(n);

  if(!Number.isInteger(n) || n < 0 || n > 170) return NaN;

  let result = 1;
  for(let k = 2; k <= n; k++) result *= k;

  return result;
}

// Exact integer result only. Returns NaN beyond Number.MAX_SAFE_INTEGER.
function mwCombination(n, r){
  n = Number(n);
  r = Number(r);

  if(!Number.isInteger(n) ||
     !Number.isInteger(r) ||
     n < 0 ||
     r < 0 ||
     r > n){
    return NaN;
  }

  r = Math.min(r, n - r);

  let result = 1;
  for(let k = 1; k <= r; k++){
    result = result * (n - r + k) / k;
  }

  const rounded = Math.round(result);
  return Number.isSafeInteger(rounded) ? rounded : NaN;
}

// P(X = x) for X ~ Binomial(n, p).
// Intended and audited for integer 0 <= n <= 100.
function mwBinomialPmf(n, p, x){
  n = Number(n);
  p = Number(p);
  x = Number(x);

  if(!Number.isInteger(n) ||
     !Number.isInteger(x) ||
     n < 0 ||
     n > 100 ||
     x < 0 ||
     x > n ||
     !Number.isFinite(p) ||
     p < 0 ||
     p > 1){
    return NaN;
  }

  if(p === 0) return x === 0 ? 1 : 0;
  if(p === 1) return x === n ? 1 : 0;

  const r = Math.min(x, n - x);
  let coefficient = 1;

  for(let k = 1; k <= r; k++){
    coefficient *= (n - r + k) / k;
  }

  return mwClampProbability(
    coefficient *
    Math.pow(p, x) *
    Math.pow(1 - p, n - x)
  );
}

// P(X <= x) for X ~ Binomial(n, p).
function mwBinomialCdf(n, p, x){
  n = Number(n);
  p = Number(p);
  x = Number(x);

  if(!Number.isFinite(x)) return NaN;
  x = Math.floor(x);

  if(!Number.isInteger(n) ||
     n < 0 ||
     n > 100 ||
     !Number.isFinite(p) ||
     p < 0 ||
     p > 1){
    return NaN;
  }

  if(x < 0) return 0;
  if(x >= n) return 1;
  if(p === 0) return 1;
  if(p === 1) return 0;

  let term = Math.pow(1 - p, n); // P(X = 0)
  let total = term;

  for(let k = 0; k < x; k++){
    term *=
      ((n - k) / (k + 1)) *
      (p / (1 - p));

    total += term;
  }

  return mwClampProbability(total);
}

// P(X >= x) for X ~ Binomial(n, p).
function mwBinomialSf(n, p, x){
  n = Number(n);
  p = Number(p);
  x = Number(x);

  if(!Number.isFinite(x)) return NaN;
  x = Math.ceil(x);

  if(!Number.isInteger(n) ||
     n < 0 ||
     n > 100 ||
     !Number.isFinite(p) ||
     p < 0 ||
     p > 1){
    return NaN;
  }

  if(x <= 0) return 1;
  if(x > n) return 0;
  if(p === 0) return 0;
  if(p === 1) return 1;

  let term = Math.pow(p, n); // P(X = n)
  let total = term;

  for(let k = n; k > x; k--){
    term *=
      (k / (n - k + 1)) *
      ((1 - p) / p);

    total += term;
  }

  return mwClampProbability(total);
}

// =======================================================
// Student-t critical-value table
// Columns are RIGHT-TAIL probabilities.
// Values independently generated/audited with scipy.stats.t.ppf(1-alpha, df).
// =======================================================

const MW_T_RIGHT_TAIL_ALPHAS = Object.freeze([
  0.100, 0.050, 0.025, 0.010, 0.005
]);

const MW_T_SUPPORTED_DFS = Object.freeze([
   1,  2,  3,  4,  5,  6,  7,  8,  9, 10,
  11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
  21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
  40, 60
]);

const MW_T_TABLE = Object.freeze({
  1: Object.freeze({'0.100': 3.078, '0.050': 6.314, '0.025': 12.706, '0.010': 31.821, '0.005': 63.657}),
  2: Object.freeze({'0.100': 1.886, '0.050': 2.920, '0.025': 4.303, '0.010': 6.965, '0.005': 9.925}),
  3: Object.freeze({'0.100': 1.638, '0.050': 2.353, '0.025': 3.182, '0.010': 4.541, '0.005': 5.841}),
  4: Object.freeze({'0.100': 1.533, '0.050': 2.132, '0.025': 2.776, '0.010': 3.747, '0.005': 4.604}),
  5: Object.freeze({'0.100': 1.476, '0.050': 2.015, '0.025': 2.571, '0.010': 3.365, '0.005': 4.032}),
  6: Object.freeze({'0.100': 1.440, '0.050': 1.943, '0.025': 2.447, '0.010': 3.143, '0.005': 3.707}),
  7: Object.freeze({'0.100': 1.415, '0.050': 1.895, '0.025': 2.365, '0.010': 2.998, '0.005': 3.499}),
  8: Object.freeze({'0.100': 1.397, '0.050': 1.860, '0.025': 2.306, '0.010': 2.896, '0.005': 3.355}),
  9: Object.freeze({'0.100': 1.383, '0.050': 1.833, '0.025': 2.262, '0.010': 2.821, '0.005': 3.250}),
  10: Object.freeze({'0.100': 1.372, '0.050': 1.812, '0.025': 2.228, '0.010': 2.764, '0.005': 3.169}),
  11: Object.freeze({'0.100': 1.363, '0.050': 1.796, '0.025': 2.201, '0.010': 2.718, '0.005': 3.106}),
  12: Object.freeze({'0.100': 1.356, '0.050': 1.782, '0.025': 2.179, '0.010': 2.681, '0.005': 3.055}),
  13: Object.freeze({'0.100': 1.350, '0.050': 1.771, '0.025': 2.160, '0.010': 2.650, '0.005': 3.012}),
  14: Object.freeze({'0.100': 1.345, '0.050': 1.761, '0.025': 2.145, '0.010': 2.624, '0.005': 2.977}),
  15: Object.freeze({'0.100': 1.341, '0.050': 1.753, '0.025': 2.131, '0.010': 2.602, '0.005': 2.947}),
  16: Object.freeze({'0.100': 1.337, '0.050': 1.746, '0.025': 2.120, '0.010': 2.583, '0.005': 2.921}),
  17: Object.freeze({'0.100': 1.333, '0.050': 1.740, '0.025': 2.110, '0.010': 2.567, '0.005': 2.898}),
  18: Object.freeze({'0.100': 1.330, '0.050': 1.734, '0.025': 2.101, '0.010': 2.552, '0.005': 2.878}),
  19: Object.freeze({'0.100': 1.328, '0.050': 1.729, '0.025': 2.093, '0.010': 2.539, '0.005': 2.861}),
  20: Object.freeze({'0.100': 1.325, '0.050': 1.725, '0.025': 2.086, '0.010': 2.528, '0.005': 2.845}),
  21: Object.freeze({'0.100': 1.323, '0.050': 1.721, '0.025': 2.080, '0.010': 2.518, '0.005': 2.831}),
  22: Object.freeze({'0.100': 1.321, '0.050': 1.717, '0.025': 2.074, '0.010': 2.508, '0.005': 2.819}),
  23: Object.freeze({'0.100': 1.319, '0.050': 1.714, '0.025': 2.069, '0.010': 2.500, '0.005': 2.807}),
  24: Object.freeze({'0.100': 1.318, '0.050': 1.711, '0.025': 2.064, '0.010': 2.492, '0.005': 2.797}),
  25: Object.freeze({'0.100': 1.316, '0.050': 1.708, '0.025': 2.060, '0.010': 2.485, '0.005': 2.787}),
  26: Object.freeze({'0.100': 1.315, '0.050': 1.706, '0.025': 2.056, '0.010': 2.479, '0.005': 2.779}),
  27: Object.freeze({'0.100': 1.314, '0.050': 1.703, '0.025': 2.052, '0.010': 2.473, '0.005': 2.771}),
  28: Object.freeze({'0.100': 1.313, '0.050': 1.701, '0.025': 2.048, '0.010': 2.467, '0.005': 2.763}),
  29: Object.freeze({'0.100': 1.311, '0.050': 1.699, '0.025': 2.045, '0.010': 2.462, '0.005': 2.756}),
  30: Object.freeze({'0.100': 1.310, '0.050': 1.697, '0.025': 2.042, '0.010': 2.457, '0.005': 2.750}),
  40: Object.freeze({'0.100': 1.303, '0.050': 1.684, '0.025': 2.021, '0.010': 2.423, '0.005': 2.704}),
  60: Object.freeze({'0.100': 1.296, '0.050': 1.671, '0.025': 2.000, '0.010': 2.390, '0.005': 2.660}),
  inf: Object.freeze({'0.100': 1.282, '0.050': 1.645, '0.025': 1.960, '0.010': 2.326, '0.005': 2.576})
});

function mwTCrit(df, rightTailAlpha){
  let rowKey;

  if(df === Infinity || df === 'inf'){
    rowKey = 'inf';
  }else{
    const numericDf = Number(df);

    if(!Number.isInteger(numericDf) || numericDf < 1){
      throw new RangeError(`Invalid t degrees of freedom: ${df}`);
    }

    rowKey = String(numericDf);
  }

  const alpha = Number(rightTailAlpha);

  if(!Number.isFinite(alpha)){
    throw new RangeError(`Invalid t right-tail alpha: ${rightTailAlpha}`);
  }

  const alphaKey = alpha.toFixed(3);
  const row = MW_T_TABLE[rowKey];

  if(!row || row[alphaKey] == null){
    throw new RangeError(
      `Unsupported t lookup: df=${df}, rightTailAlpha=${rightTailAlpha}`
    );
  }

  return row[alphaKey];
}

// =======================================================
// Regression smoke tests
// =======================================================

function mwRunStatsSmokeTests(){
  const tests = [
    { name:'Phi(0)', got:mwNormCdf(0), expected:0.5, tolerance:1e-12 },
    { name:'Phi(1.96)', got:mwNormCdf(1.96), expected:0.9750021049, tolerance:5e-6 },
    { name:'Phi(-1.96)', got:mwNormCdf(-1.96), expected:0.0249978951, tolerance:5e-6 },
    { name:'CDF + SF', got:mwNormCdf(1.25) + mwNormSf(1.25), expected:1, tolerance:1e-12 },
    { name:'Normal symmetry', got:mwNormCdf(1.25) + mwNormCdf(-1.25), expected:1, tolerance:1e-12 },
    { name:'Normal interval', got:mwNormInterval(-1.96, 1.96), expected:0.9500042097, tolerance:1e-5 },
    { name:'InvNorm(0.975)', got:mwInvNorm(0.975), expected:1.9599639845, tolerance:1e-4 },
    { name:'Mean', got:mwMean([2,4,6,8]), expected:5, tolerance:1e-12 },
    { name:'Median odd', got:mwMedian([9,1,5]), expected:5, tolerance:0 },
    { name:'Median even', got:mwMedian([1,2,8,10]), expected:5, tolerance:0 },
    { name:'Population variance', got:mwPopulationVariance([1,2,3,4,5]), expected:2, tolerance:1e-12 },
    { name:'Sample variance', got:mwSampleVariance([1,2,3,4,5]), expected:2.5, tolerance:1e-12 },
    { name:'Combination 10 choose 3', got:mwCombination(10,3), expected:120, tolerance:0 },
    { name:'Binomial PMF', got:mwBinomialPmf(10,0.5,3), expected:0.1171875, tolerance:1e-12 },
    { name:'Binomial CDF', got:mwBinomialCdf(10,0.5,3), expected:0.171875, tolerance:1e-12 },
    { name:'Binomial SF', got:mwBinomialSf(10,0.5,7), expected:0.171875, tolerance:1e-12 },
    { name:'t critical df=10 alpha=.025', got:mwTCrit(10,0.025), expected:2.228, tolerance:0 },
    { name:'t critical infinity alpha=.005', got:mwTCrit(Infinity,0.005), expected:2.576, tolerance:0 }
  ];

  const results = tests.map(test => ({
    ...test,
    pass:
      Number.isFinite(test.got) &&
      Math.abs(test.got - test.expected) <= test.tolerance
  }));

  results.push({
    name: 'Binomial CDF rejects NaN x',
    got: mwBinomialCdf(10, 0.5, NaN),
    expected: NaN,
    tolerance: 0,
    pass: Number.isNaN(mwBinomialCdf(10, 0.5, NaN))
  });

  return {
    passed: results.filter(result => result.pass).length,
    failed: results.filter(result => !result.pass).length,
    results
  };
}

// =======================================================
// Optional app-level generator diagnostic
// Requires the builder's existing fnv1a() and xorshift32() helpers.
// It does not alter Quiz Mode.
// =======================================================

function mwAnswerCapacity(genFn, unitId, samples = 200){
  if(typeof genFn !== 'function') return { samples:0, distinct:0, errors:['Generator is not a function.'] };

  const answers = new Set();
  const errors = [];

  for(let i = 0; i < samples; i++){
    try{
      const seed = `stats-capacity|${unitId}|${genFn.name || 'anonymous'}|${i}`;
      const rng = xorshift32(fnv1a(seed));
      const problem = genFn(rng);

      if(problem && typeof problem.a === 'string'){
        answers.add(problem.a);
      }else{
        errors.push(`Sample ${i} returned no answer string.`);
      }
    }catch(error){
      errors.push(`Sample ${i}: ${error && error.message ? error.message : String(error)}`);
    }
  }

  return {
    samples,
    distinct: answers.size,
    answerSamples: [...answers].slice(0, 12),
    errors
  };
}

// Conditional exports allow the same file to be audited under Node.
// They do nothing when this code is pasted into the browser HTML.
if(typeof module !== 'undefined' && module.exports){
  module.exports = {
    mwClampProbability,
    mwNormPdf,
    mwNormCdf,
    mwNormSf,
    mwNormInterval,
    mwInvNorm,
    mwMean,
    mwMedian,
    mwWelford,
    mwPopulationVariance,
    mwPopulationSD,
    mwSampleVariance,
    mwSampleSD,
    mwZScore,
    mwFactorial,
    mwCombination,
    mwBinomialPmf,
    mwBinomialCdf,
    mwBinomialSf,
    MW_T_RIGHT_TAIL_ALPHAS,
    MW_T_SUPPORTED_DFS,
    MW_T_TABLE,
    mwTCrit,
    mwRunStatsSmokeTests
  };
}


