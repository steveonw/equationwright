#!/usr/bin/env python3
"""Deterministically build EquationWright v7.3 online/offline one-file distributions.

Source of truth: src/ + profiles/ + schemas/ + registry/ + build/module-order.json.
Generated dist/ files are never hand edited.

Usage:
  python build_release.py
  python build_release.py --verify
  python build_release.py --release-gates   # build twice, then run release_gates.py
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

TOOL_VERSION = "1.2.0"
ONLINE_NAME = "Math_Worksheet_Builder_v7_3_0_FULL_CATALOG.html"
OFFLINE_NAME = "Math_Worksheet_Builder_v7_3_0_FULL_CATALOG_OFFLINE.html"
APP_VERSION = "v7.3_full_catalog_protocols"
MATHJAX_SHA256 = "d4295dc33744836935c1399feece5159577b34c5c8ffb9f1c6324cd82e03a882"


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return sha_bytes(path.read_bytes())


def digest_ref(path: Path) -> str:
    return "sha256:" + sha_file(path)


def compact(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def canonical_json(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _xor_hex(a: str, b: str) -> str:
    return bytes(x ^ y for x, y in zip(bytes.fromhex(a), bytes.fromhex(b))).hex()


def extract_register_blocks(region: str) -> list[tuple[str, str]]:
    """Return top-level registerGen calls in source order.

    This mirrors the original modular extractor: it tracks parenthesis depth while
    ignoring quoted/comment text, so inner ``});`` sequences do not truncate a
    generator registration.
    """
    lines = region.splitlines(keepends=True)
    blocks: list[tuple[str, str]] = []
    i = 0
    start_re = re.compile(r"^\s*registerGen\('([^']+)'\s*,")

    def paren_delta(line: str, state: dict) -> int:
        delta = 0
        quote = state.get("quote")
        block_comment = state.get("block_comment", False)
        esc = False
        j = 0
        while j < len(line):
            ch = line[j]
            nxt = line[j + 1] if j + 1 < len(line) else ""
            if block_comment:
                if ch == "*" and nxt == "/":
                    block_comment = False
                    j += 2
                    continue
                j += 1
                continue
            if quote:
                if esc:
                    esc = False
                    j += 1
                    continue
                if ch == "\\":
                    esc = True
                    j += 1
                    continue
                if ch == quote:
                    quote = None
                j += 1
                continue
            if ch == "/" and nxt == "/":
                break
            if ch == "/" and nxt == "*":
                block_comment = True
                j += 2
                continue
            if ch in ("'", '"', "`"):
                quote = ch
                j += 1
                continue
            if ch == "(":
                delta += 1
            elif ch == ")":
                delta -= 1
            j += 1
        state["quote"] = quote
        state["block_comment"] = block_comment
        return delta

    while i < len(lines):
        m = start_re.match(lines[i])
        if not m:
            i += 1
            continue
        uid = m.group(1)
        block: list[str] = []
        depth = 0
        state = {"quote": None, "block_comment": False}
        while i < len(lines):
            line = lines[i]
            block.append(line)
            depth += paren_delta(line, state)
            i += 1
            if depth == 0:
                break
            if depth < 0:
                raise RuntimeError(f"parenthesis underflow in registerGen {uid}")
        if depth != 0:
            raise RuntimeError(f"unterminated registerGen {uid}")
        blocks.append((uid, "".join(block)))
    return blocks


def compute_assessment_compatibility_id(root: Path, order: list[dict], registry: dict, profiles: list[dict]) -> tuple[str, dict]:
    critical_modules = []
    for m in order:
        if not m.get("determinismCritical"):
            continue
        critical_modules.append({
            "order": int(m["order"]),
            "path": m["path"],
            "role": m["role"],
            "sha256": digest_ref(root / m["path"]),
        })
    registry_identity = [{
        "generatorId": r["generatorId"],
        "unitId": r["unitId"],
        "publishedOrdinal": int(r["publishedOrdinal"]),
        "runtimeIndex": int(r["runtimeIndexV72"]),
        "status": r.get("status", "active"),
    } for r in registry["generators"]]
    payload = {
        "protocol": "equationwright-assessment-compatibility-input-v1",
        "algorithms": {
            "seedNormalization": "trim-empty-to-Ultimate-v1",
            "seedHash": "fnv1a-32-js-utf16-v1",
            "rng": "xorshift32-v1",
            "selection": "equationwright-variety-picker-v1",
            "multipleChoice": "equationwright-capacity-aware-mc-v2",
            "canonicalJson": "equationwright-canonical-json-v1",
        },
        "criticalModules": critical_modules,
        # Only assessment-relevant profile structure participates. Presentation
        # labels, descriptions, institution/crosswalk text and profile digests are
        # deliberately excluded from the assessment fingerprint.
        "profileAssessmentMappings": [
            {
                "profileId": p["profileId"],
                "courses": [
                    {
                        "courseId": c["courseId"],
                        "legacyModeAliases": list(c.get("legacyModeAliases", [])),
                        "unitOrder": list(c.get("unitOrder", [])),
                        "defaultCounts": dict(c.get("defaultCounts", {})),
                    }
                    for c in p.get("courses", [])
                ],
            }
            for p in sorted(profiles, key=lambda x: x["profileId"])
        ],
        "generatorRegistry": registry_identity,
    }
    raw = sha_bytes(canonical_json(payload).encode("utf-8"))
    return "ewac:sha256:" + raw, {"rawDigest": "sha256:" + raw, "payload": payload}


def read_lf(path: Path) -> str:
    return path.read_text(encoding="utf-8").replace("\r\n", "\n").replace("\r", "\n")


def write_lf(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.replace("\r\n", "\n").replace("\r", "\n"), encoding="utf-8", newline="\n")


def observed_from_registry(registry: dict) -> list[dict]:
    out = []
    for rec in registry["generators"]:
        traps = int(rec.get("observedMaxAuthoredTrapCount", 0) or 0)
        out.append({
            "id": rec["generatorId"],
            "unitId": rec["unitId"],
            "runtimeIndex": rec["runtimeIndexV72"],
            "topicId": rec["topicId"],
            "metadataSource": rec.get("metadataSourceV73", "derived"),
            "problemKeys": rec.get("observedProblemKeys", []),
            "problemKeyStability": rec.get("problemKeyStabilityV72", "stable"),
            "outputs": ["worksheet", "quiz"],
            "traps": {
                "support": "authored" if traps > 0 else "none",
                "maxObservedCount": traps,
                "hasExplanations": traps > 0,
            },
            "semantics": rec.get("semanticContracts", []),
            "mc": {
                "supported": True,
                "observedAnswerCapacity": rec.get("observedAnswerCapacity80", 0),
                "capacityErrorCount": rec.get("capacityErrorCount80", 0),
                "possibleChoiceCounts": [2, 3, 4],
            },
            "observed": {
                "probeProtocol": "equationwright-capability-probe-v1",
                "answerCapacitySamples": 80,
                "exampleCount": 3,
            },
        })
    return out


def inject_data(rel: str, text: str, registry: dict, profiles: list[dict], compatibility_id: str) -> str:
    if rel == "src/catalog/generator-registry.js":
        text = text.replace("/*__EW_GENERATOR_REGISTRY__*/ null", compact(registry))
        text = text.replace("/*__EW_OBSERVED_GENERATORS__*/ null", compact(observed_from_registry(registry)))
    elif rel == "src/protocols/profiles.js":
        text = text.replace("/*__EW_BUILTIN_PROFILES__*/ null", compact(profiles))
    elif rel == "src/protocols/capabilities.js":
        text = text.replace("__EW_ASSESSMENT_COMPATIBILITY_ID__", compatibility_id)
    if "__EW_" in text:
        raise RuntimeError(f"unresolved build placeholder in {rel}")
    return text


def load_inputs(root: Path):
    order_obj = json.loads((root / "build/module-order.json").read_text(encoding="utf-8"))
    order = order_obj["modules"]
    if len(order) != 48 or [m["order"] for m in order] != list(range(1, 49)):
        raise RuntimeError("module order must be exactly 1..48")
    registry = json.loads((root / "registry/EquationWright_Generator_Registry_v1.json").read_text(encoding="utf-8"))
    profiles = [
        json.loads((root / "profiles/org.equationwright.generic.json").read_text(encoding="utf-8")),
        json.loads((root / "profiles/edu.vccs.nvcc.math.json").read_text(encoding="utf-8")),
    ]
    bindings = json.loads((root / "build/generator-bindings-v1.json").read_text(encoding="utf-8"))
    return order, registry, profiles, bindings


def validate_source(root: Path, order: list[dict], registry: dict, profiles: list[dict], bindings: dict) -> None:
    errors: list[str] = []
    for module in order:
        if not (root / module["path"]).is_file():
            errors.append("missing module " + module["path"])

    ids = [r["generatorId"] for r in registry.get("generators", [])]
    pairs = [(r["unitId"], int(r["runtimeIndexV72"])) for r in registry.get("generators", [])]
    if len(ids) != 424:
        errors.append(f"registry count {len(ids)} != 424")
    if len(set(ids)) != len(ids):
        errors.append("duplicate generator IDs")
    if len(set(pairs)) != len(pairs):
        errors.append("duplicate unit/runtime registry pairs")

    # Freeze generator family -> stable-ID binding, not just counts. Each published
    # registry slot has a build-only registration-block fingerprint. Reordering two
    # families, or assigning a source family to another stable ID, therefore fails
    # before any distribution artifact is emitted.
    binding_rows = bindings.get("bindings", []) if isinstance(bindings, dict) else []
    binding_map = {(b.get("unitId"), int(b.get("runtimeIndex", -1))): b for b in binding_rows}
    if bindings.get("format") != "equationwright-generator-source-bindings-v1" or bindings.get("schemaRevision") != 1:
        errors.append("invalid generator source binding manifest")
    if len(binding_rows) != 424:
        errors.append(f"generator binding count {len(binding_rows)} != 424")
    actual_rows = []
    counters: dict[str, int] = {}
    for module in order:
        if module["role"] != "generator":
            continue
        text = read_lf(root / module["path"])
        for unit_id, block in extract_register_blocks(text):
            idx = counters.get(unit_id, 0)
            counters[unit_id] = idx + 1
            actual_rows.append((unit_id, idx, module["path"], "sha256:" + sha_bytes(block.encode("utf-8"))))
    if len(actual_rows) != 424:
        errors.append(f"source generator registration count {len(actual_rows)} != 424")
    reg_map = {(r["unitId"], int(r["runtimeIndexV72"])): r for r in registry.get("generators", [])}
    for unit_id, idx, source_module, block_digest in actual_rows:
        rec = reg_map.get((unit_id, idx))
        bind = binding_map.get((unit_id, idx))
        if not rec:
            errors.append(f"missing source registry slot {unit_id}[{idx}]")
            continue
        if not bind:
            errors.append(f"missing source binding {unit_id}[{idx}]")
            continue
        if bind.get("generatorId") != rec.get("generatorId"):
            errors.append(f"stable generator ID binding mismatch {unit_id}[{idx}]")
        if bind.get("sourceModule") != source_module:
            errors.append(f"generator source-module binding mismatch {unit_id}[{idx}]")
        if bind.get("registrationSha256") != block_digest:
            errors.append(f"generator source-family/order binding mismatch {unit_id}[{idx}] ({rec.get('generatorId')})")

    # Profiles are data-only.
    for profile in profiles:
        raw = compact(profile).lower()
        if profile.get("format") != "equationwright-curriculum-profile-v1":
            errors.append("bad built-in profile format")
        if "<script" in raw or "javascript:" in raw:
            errors.append("profile executable markup")

    # Validate all schemas/examples/profiles if jsonschema is available.
    try:
        from jsonschema import Draft202012Validator
        schemas = {p.name: json.loads(p.read_text(encoding="utf-8")) for p in (root / "schemas").glob("*.schema.json")}
        for name, schema in schemas.items():
            Draft202012Validator.check_schema(schema)
        mapping = {
            "equationwright-capabilities-v1.target-example.json": "equationwright-capabilities-v1.schema.json",
            "diagnostic-provenance.example.json": "equationwright-diagnostic-provenance-v1.schema.json",
            "blueprint-slim.example.json": "equationwright-blueprint-slim-v1.schema.json",
            "blueprint-archive.example.json": "equationwright-blueprint-archive-v1.schema.json",
            "replay-report.exact.example.json": "equationwright-replay-report-v1.schema.json",
            "curriculum-profile-generic.full-example.json": "equationwright-curriculum-profile-v1.schema.json",
            "curriculum-profile-vccs-nvcc.full-example.json": "equationwright-curriculum-profile-v1.schema.json",
            "build-manifest.example.json": "equationwright-build-manifest-v1.schema.json",
        }
        for filename, schema_name in mapping.items():
            obj = json.loads((root / "examples" / filename).read_text(encoding="utf-8"))
            failures = list(Draft202012Validator(schemas[schema_name]).iter_errors(obj))
            if failures:
                errors.append(f"example {filename} schema errors: {len(failures)}")
        profile_schema = schemas["equationwright-curriculum-profile-v1.schema.json"]
        for profile in profiles:
            failures = list(Draft202012Validator(profile_schema).iter_errors(profile))
            if failures:
                errors.append(f"profile {profile.get('profileId')} schema errors: {len(failures)}")
    except ImportError:
        pass

    if errors:
        raise RuntimeError("\n".join(errors))


def build_online(root: Path, order: list[dict], registry: dict, profiles: list[dict], compatibility_id: str) -> str:
    shell = read_lf(root / "src/shell/document.html")
    styles: list[str] = []
    runtime: list[str] = []
    scratchpad = ""

    for module in order:
        rel = module["path"]
        role = module["role"]
        if role == "html-shell":
            continue
        text = inject_data(rel, read_lf(root / rel), registry, profiles, compatibility_id)
        if role == "style":
            styles.append(text)
        elif rel == "src/ui/scratchpad.js":
            scratchpad = text
        else:
            runtime.append(text)

    if not scratchpad:
        raise RuntimeError("scratchpad module missing")
    markers = ["<!-- EQUATIONWRIGHT_STYLES -->", "<!-- EQUATIONWRIGHT_RUNTIME -->", "<!-- EQUATIONWRIGHT_SCRATCHPAD_RUNTIME -->"]
    if any(shell.count(m) != 1 for m in markers):
        raise RuntimeError("shell placeholder mismatch")

    out = shell.replace(markers[0], "<style>" + "".join(styles) + "</style>")
    out = out.replace(markers[1], "<script>" + "".join(runtime) + "</script>")
    out = out.replace(markers[2], "<script>" + scratchpad + "</script>")
    warning = "<!-- GENERATED DISTRIBUTION: do not hand-edit; rebuild from src/ + profiles/ + schemas/ + registry/. -->\n"
    if out.lower().startswith("<!doctype html>"):
        pos = out.find("\n")
        out = out[: pos + 1] + warning + out[pos + 1 :]
    else:
        out = warning + out
    return out


def derive_offline(online: str, mathjax: str) -> str:
    pattern = re.compile(r"<script>\s*/\* Math engine loader[\s\S]*?</script>", re.I)
    matches = list(pattern.finditer(online))
    if len(matches) != 1:
        raise RuntimeError(f"expected one MathJax loader, got {len(matches)}")
    safe = re.sub(r"</script\s*>", r"<\\/script>", mathjax, flags=re.I)
    embedded = "<script>\n/* MathJax 3.2.2 tex-svg EMBEDDED for EquationWright offline distribution. */\n" + safe + "\n</script>"
    m = matches[0]
    out = online[: m.start()] + embedded + online[m.end() :]
    out, n = re.subn(r'(<meta\s+name="equationwright-build-variant"\s+content=")online("\s*/?>)', r"\1offline\2", out, count=1, flags=re.I)
    if n != 1:
        raise RuntimeError("build variant marker not replaced")
    out, n = re.subn(r"(<title>[^<]*)(</title>)", lambda mm: mm.group(1) + " — Offline" + mm.group(2) if "Offline" not in mm.group(1) else mm.group(0), out, count=1, flags=re.I)
    if n != 1:
        raise RuntimeError("title not found")
    # Offline distribution already contains the pinned MathJax bundle; remove the
    # online-only CDN/custom-path instructions so the artifact is truthful and
    # contains no live MathJax network reference.
    offline_panel = re.compile(r'<details class="offlineTools">[\s\S]*?</details>', re.I)
    replacement = (
        '<details class="offlineTools"><summary>Offline math engine</summary>'
        '<div class="small" style="margin:8px 0; opacity:0.85">'
        'MathJax 3.2.2 (tex-svg) is embedded in this offline build. '
        'No network connection or external MathJax folder is required.'
        '</div></details>'
    )
    out, n = offline_panel.subn(replacement, out, count=1)
    if n != 1:
        raise RuntimeError("offline math-engine panel not found")
    return out



def export_capability_manifest(root: Path, html_path: Path, build_variant: str) -> dict:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise RuntimeError("Playwright is required to generate the live capability manifest") from exc
    text = html_path.read_text(encoding="utf-8")
    mock = r"""(()=>{const mk=()=>{const m=new Map();return {getItem:k=>m.has(String(k))?m.get(String(k)):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),key:i=>[...m.keys()][i]??null,get length(){return m.size;}}};Object.defineProperty(window,'localStorage',{value:mk(),configurable:true});Object.defineProperty(window,'sessionStorage',{value:mk(),configurable:true});})()"""
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True, executable_path="/usr/bin/chromium")
        page = browser.new_page()
        errors=[]
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.evaluate(mock)
        page.route("**/*", lambda route: route.abort())
        page.set_content(text, wait_until="domcontentloaded", timeout=30000)
        page.wait_for_function("typeof mwBuildCapabilitiesManifest==='function'", timeout=30000)
        manifest = page.evaluate("([sha,variant])=>mwBuildCapabilitiesManifest({artifactSha256:'sha256:'+sha,buildVariant:variant})", [sha_file(html_path), build_variant])
        browser.close()
    if errors:
        raise RuntimeError("capability manifest runtime errors: "+repr(errors))
    try:
        from jsonschema import Draft202012Validator
        schema=json.loads((root/'schemas/equationwright-capabilities-v1.schema.json').read_text(encoding='utf-8'))
        failures=list(Draft202012Validator(schema).iter_errors(manifest))
        if failures: raise RuntimeError("capability manifest schema errors: "+repr([e.message for e in failures[:5]]))
    except ImportError:
        pass
    return manifest

def make_build_manifest(root: Path, order: list[dict], online_path: Path, offline_path: Path, compatibility_id: str, compatibility_inputs: dict) -> dict:
    modules = [{**m, "sha256": digest_ref(root / m["path"])} for m in order]
    profiles = [{"path": str(p.relative_to(root)).replace("\\", "/"), "sha256": digest_ref(p)} for p in sorted((root / "profiles").glob("*.json"))]
    schemas = [{"path": str(p.relative_to(root)).replace("\\", "/"), "sha256": digest_ref(p)} for p in sorted((root / "schemas").glob("*.schema.json"))]
    vendor = [{"path": "vendor/mathjax/tex-svg.js", "sha256": digest_ref(root / "vendor/mathjax/tex-svg.js")}]
    return {
        "format": "equationwright-build-manifest-v1",
        "schemaRevision": 1,
        "buildToolVersion": TOOL_VERSION,
        "sourceRevision": "pass4b-high-v7.3",
        "encoding": "utf-8",
        "lineEndings": "lf",
        "moduleOrder": modules,
        "profiles": profiles,
        "schemas": schemas,
        "vendor": vendor,
        "outputs": {
            "online": {
                "path": "dist/" + online_path.name,
                "sha256": digest_ref(online_path),
                "buildVariant": "online",
                "appVersion": APP_VERSION,
                "assessmentCompatibilityId": compatibility_id,
            },
            "offline": {
                "path": "dist/" + offline_path.name,
                "sha256": digest_ref(offline_path),
                "buildVariant": "offline",
                "appVersion": APP_VERSION,
                "assessmentCompatibilityId": compatibility_id,
            },
        },
        "extensions": {
            "org.equationwright.build-inputs-v1": {
                "assessmentCompatibilityRawDigest": compatibility_inputs["rawDigest"],
                "files": [
                    {"path": "build/module-order.json", "sha256": digest_ref(root / "build/module-order.json")},
                    {"path": "registry/EquationWright_Generator_Registry_v1.json", "sha256": digest_ref(root / "registry/EquationWright_Generator_Registry_v1.json")},
                    {"path": "build/generator-bindings-v1.json", "sha256": digest_ref(root / "build/generator-bindings-v1.json")},
                    {"path": "RELEASE_NOTES_v7_3.md", "sha256": digest_ref(root / "RELEASE_NOTES_v7_3.md")},
                ],
            }
        },
    }


def copy_public_contracts(root: Path, dist: Path) -> None:
    # Keep schemas/examples beside the generated distributions so a release is self-describing.
    for folder in ("schemas", "examples"):
        target = dist / folder
        if target.exists():
            shutil.rmtree(target)
        shutil.copytree(root / folder, target)
    shutil.copy2(root / "registry/EquationWright_Generator_Registry_v1.json", dist / "EquationWright_Generator_Registry_v1.json")
    shutil.copy2(root / "profiles/org.equationwright.generic.json", dist / "EquationWright_Curriculum_Profile_Generic_v1.json")
    shutil.copy2(root / "profiles/edu.vccs.nvcc.math.json", dist / "EquationWright_Curriculum_Profile_VCCS_NVCC_v1.json")
    shutil.copy2(root / "RELEASE_NOTES_v7_3.md", dist / "RELEASE_NOTES_v7_3.md")


def build(root: Path, dist: Path) -> dict:
    order, registry, profiles, bindings = load_inputs(root)
    validate_source(root, order, registry, profiles, bindings)
    compatibility_id, compatibility_inputs = compute_assessment_compatibility_id(root, order, registry, profiles)
    if sha_file(root / "vendor/mathjax/tex-svg.js") != MATHJAX_SHA256:
        raise RuntimeError("pinned MathJax 3.2.2 digest mismatch")

    online = build_online(root, order, registry, profiles, compatibility_id)
    if f"const MW_APP_VERSION = '{APP_VERSION}';" not in online:
        raise RuntimeError("appVersion missing")
    if compatibility_id not in online:
        raise RuntimeError("assessment compatibility ID missing")

    offline = derive_offline(online, read_lf(root / "vendor/mathjax/tex-svg.js"))
    if f"const MW_APP_VERSION = '{APP_VERSION}';" not in offline:
        raise RuntimeError("offline appVersion diverged")
    if compatibility_id not in offline:
        raise RuntimeError("offline compatibility ID diverged")

    dist.mkdir(parents=True, exist_ok=True)
    online_path = dist / ONLINE_NAME
    offline_path = dist / OFFLINE_NAME
    write_lf(online_path, online)
    write_lf(offline_path, offline)
    copy_public_contracts(root, dist)
    online_cap = export_capability_manifest(root, online_path, "online")
    # Offline is derived from the exact online runtime and shares all capability/catalog
    # data; only packaging identity and artifact digest differ.  Derive the offline
    # manifest from the validated online manifest instead of executing MathJax again.
    offline_cap = json.loads(json.dumps(online_cap))
    offline_cap["engine"]["buildVariant"] = "offline"
    offline_cap["engine"]["artifactSha256"] = "sha256:" + sha_file(offline_path)
    write_lf(dist / "EquationWright_Capabilities_Online_v1.json", json.dumps(online_cap, indent=2, ensure_ascii=False) + "\n")
    write_lf(dist / "EquationWright_Capabilities_Offline_v1.json", json.dumps(offline_cap, indent=2, ensure_ascii=False) + "\n")

    manifest = make_build_manifest(root, order, online_path, offline_path, compatibility_id, compatibility_inputs)
    manifest_path = dist / "EquationWright_Build_Manifest_v1.json"
    write_lf(manifest_path, json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")

    try:
        from jsonschema import Draft202012Validator
        schema = json.loads((root / "schemas/equationwright-build-manifest-v1.schema.json").read_text(encoding="utf-8"))
        failures = list(Draft202012Validator(schema).iter_errors(manifest))
        if failures:
            raise RuntimeError("build manifest schema errors: " + str([e.message for e in failures[:5]]))
    except ImportError:
        pass

    return {
        "online": online_path,
        "offline": offline_path,
        "manifest": manifest_path,
        "onlineSha256": sha_file(online_path),
        "offlineSha256": sha_file(offline_path),
        "assessmentCompatibilityId": compatibility_id,
        "compatibilityRawDigest": compatibility_inputs["rawDigest"],
    }


def verify_repro(root: Path, first: dict) -> bool:
    with tempfile.TemporaryDirectory(prefix="ew-build-") as td:
        second = build(root, Path(td) / "dist")
        if first["onlineSha256"] != second["onlineSha256"]:
            raise RuntimeError("online build is not byte reproducible")
        if first["offlineSha256"] != second["offlineSha256"]:
            raise RuntimeError("offline build is not byte reproducible")
        if first["manifest"].read_bytes() != second["manifest"].read_bytes():
            raise RuntimeError("build manifest is not byte reproducible")
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--dist", default="dist")
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--release-gates", action="store_true")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    dist = Path(args.dist)
    if not dist.is_absolute():
        dist = (root / dist).resolve()
    if dist.exists():
        shutil.rmtree(dist)

    result = build(root, dist)
    reproducible = verify_repro(root, result) if (args.verify or args.release_gates) else None
    if reproducible:
        ev = dist / "test-evidence"
        ev.mkdir(parents=True, exist_ok=True)
        (ev / "EquationWright_Pass_4B_Build_Reproducibility.json").write_text(
            json.dumps({
                "format": "equationwright-pass4b-build-reproducibility-v1",
                "passed": True,
                "onlineSha256": result["onlineSha256"],
                "offlineSha256": result["offlineSha256"],
                "buildManifestByteIdentical": True,
                "command": "python build_release.py --release-gates" if args.release_gates else "python build_release.py --verify"
            }, indent=2) + "\n", encoding="utf-8"
        )
    output = {
        "online": str(result["online"]),
        "offline": str(result["offline"]),
        "onlineSha256": result["onlineSha256"],
        "offlineSha256": result["offlineSha256"],
        "assessmentCompatibilityId": result["assessmentCompatibilityId"],
        "reproducible": reproducible,
    }
    print(json.dumps(output, indent=2))

    if args.release_gates:
        gate_runner = root / "release_gates.py"
        if not gate_runner.is_file():
            raise RuntimeError("release_gates.py is required for --release-gates")
        subprocess.run([sys.executable, str(gate_runner), "--root", str(root), "--dist", str(dist)], check=True, cwd=root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
