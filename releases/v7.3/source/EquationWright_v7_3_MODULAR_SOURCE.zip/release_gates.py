#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, subprocess, sys
from pathlib import Path
from jsonschema import Draft202012Validator

ONLINE='Math_Worksheet_Builder_v7_3_0_FULL_CATALOG.html'
OFFLINE='Math_Worksheet_Builder_v7_3_0_FULL_CATALOG_OFFLINE.html'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(cmd,cwd):
    print('+',' '.join(map(str,cmd)),flush=True); subprocess.run(cmd,cwd=cwd,check=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='.');ap.add_argument('--dist',default='dist');args=ap.parse_args()
    root=Path(args.root).resolve();dist=Path(args.dist);dist=dist if dist.is_absolute() else (root/dist).resolve(); ev=dist/'test-evidence';ev.mkdir(parents=True,exist_ok=True)
    for script in ['stage4_acceptance.py','pass4c_focused_regressions.py','stage3_policy_56.py','stage3_d1_d6.py','math_gates.py','offline_parity.py','cross_variant_replay.py','ui_smoke.py']:
        run([sys.executable,str(root/'tests'/script)],root)
    partial=json.loads((ev/'EquationWright_Pass_4B_Stage4_Acceptance_1_72_partial.json').read_text())
    focused=json.loads((ev/'EquationWright_Pass_4C_HIGH_Focused_D1_D9.json').read_text())
    policy=json.loads((ev/'EquationWright_Pass_4B_Stage3_Policy_1_56.json').read_text())
    d=json.loads((ev/'EquationWright_Pass_4B_Stage3_D1_D6.json').read_text())
    math=json.loads((ev/'EquationWright_Pass_4B_Modular_Math_Gates.json').read_text())
    offline=json.loads((ev/'EquationWright_v7_3_Offline_Packaging_Smoke_Results.json').read_text())
    cross=json.loads((ev/'EquationWright_v7_3_Cross_Variant_Strict_Replay.json').read_text())
    ui=json.loads((ev/'EquationWright_Pass_4B_UI_Smoke.json').read_text())
    online=dist/ONLINE; off=dist/OFFLINE; online_text=online.read_text(); off_text=off.read_text()
    # The top-level build command already performs an independent second build
    # before invoking this gate runner. Consume that evidence rather than doing a
    # third Playwright-backed build inside the same long-running process.
    repro_path=ev/'EquationWright_Pass_4B_Build_Reproducibility.json'
    repro_obj=json.loads(repro_path.read_text()) if repro_path.is_file() else {}
    repro=(bool(repro_obj.get('passed')) and repro_obj.get('onlineSha256')==sha(online) and repro_obj.get('offlineSha256')==sha(off) and bool(repro_obj.get('buildManifestByteIdentical')))
    order=json.loads((root/'build/module-order.json').read_text())['modules']; reg=json.loads((root/'registry/EquationWright_Generator_Registry_v1.json').read_text())
    source_regs=[]
    for m in order:
        if m['role']=='generator': source_regs += re.findall(r"(?m)^\s*registerGen\('([^']+)'\s*,",(root/m['path']).read_text())
    manifest=json.loads((dist/'EquationWright_Build_Manifest_v1.json').read_text())
    ext_inputs=manifest.get('extensions',{}).get('org.equationwright.build-inputs-v1',{}).get('files',[])
    digests_ok=all(('sha256:'+sha(root/m['path']))==m['sha256'] for m in manifest['moduleOrder']) and all(('sha256:'+sha(root/x['path']))==x['sha256'] for x in manifest['profiles']+manifest['schemas']+manifest['vendor']) and all((root/x['path']).is_file() and ('sha256:'+sha(root/x['path']))==x['sha256'] for x in ext_inputs) and manifest['outputs']['online']['sha256']=='sha256:'+sha(online) and manifest['outputs']['offline']['sha256']=='sha256:'+sha(off)
    schemas={p.name:json.loads(p.read_text()) for p in (root/'schemas').glob('*.schema.json')}; schema_ok=True
    for s in schemas.values(): Draft202012Validator.check_schema(s)
    for capname in ['EquationWright_Capabilities_Online_v1.json','EquationWright_Capabilities_Offline_v1.json']:
        schema_ok &= not list(Draft202012Validator(schemas['equationwright-capabilities-v1.schema.json']).iter_errors(json.loads((dist/capname).read_text())))
    cases=partial['cases'][:64]
    buildcases={
      65:(all((root/x).exists() for x in ['src','profiles','schemas','registry']) and 'GENERATED DISTRIBUTION: do not hand-edit' in online_text and 'GENERATED DISTRIBUTION: do not hand-edit' in off_text),
      66:('<script type="module"' not in online_text.lower() and '<script type="module"' not in off_text.lower() and not partial.get('pageErrors')),
      67:(len(source_regs)==424 and len(reg['generators'])==424 and math['sweep']['same']),
      68:repro,
      69:(offline['passed'] and cross['passed'] and manifest['outputs']['online']['appVersion']==manifest['outputs']['offline']['appVersion'] and manifest['outputs']['online']['assessmentCompatibilityId']==manifest['outputs']['offline']['assessmentCompatibilityId']),
      70:(math['sweep']['same'] and not math['sweep']['candidate']['errors'] and not any(math['mc'][k] for k in ['nulls','dups','badCorrect','targetMismatch','provMismatch','semanticDup','throws','genErrors']) and math['suites']=={'stats':{'passed':19,'failed':0},'logic':{'passed':15,'failed':0},'de':{'passed':17,'failed':0}} and not math['matrix']['bad']),
      71:(schema_ok and digests_ok and [m['order'] for m in order]==list(range(1,49))),
      72:((root/'build_release.py').is_file() and (root/'release_gates.py').is_file() and (dist/'schemas').is_dir() and (dist/'examples').is_dir())
    }
    matrix=json.loads((root/'tests/data/EquationWright_Pass_4A_4B_Acceptance_Matrix.json').read_text())
    for n in range(65,73):
        meta=matrix['cases'][n-1];cases.append({'n':n,'area':meta['area'],'severity':meta['severity'],'name':meta['name'],'pass':bool(buildcases[n]),'detail':{'command':'python build_release.py --release-gates'} if n==72 else None})
    stage4={'format':'equationwright-pass4b-high-stage4-acceptance-v1','candidate':ONLINE,'candidateSha256':sha(online),'passed':sum(x['pass'] for x in cases),'failed':sum(not x['pass'] for x in cases),'cases':cases,'pageErrors':partial.get('pageErrors',[])}
    (ev/'EquationWright_Pass_4B_Stage4_Acceptance_1_72.json').write_text(json.dumps(stage4,indent=2))
    stage3={'format':'equationwright-pass4b-stage3-62-regression-v1','passed':policy['passed']+sum(bool(v) for v in d['checks'].values()),'failed':policy['failed']+sum(not bool(v) for v in d['checks'].values()),'policy56':{'passed':policy['passed'],'failed':policy['failed']},'d1d6':d['checks']}
    (ev/'EquationWright_Pass_4B_Stage3_62_Regression.json').write_text(json.dumps(stage3,indent=2))
    summary={'format':'equationwright-pass4c-high-return-release-gates-v1','focusedPass4C':{'passed':focused['passed'],'failed':focused['failed'],'checks':focused['checks']},'stage4':{'passed':stage4['passed'],'failed':stage4['failed']},'stage3':stage3,'math':math,'offlineParity':{'passed':offline['passed'],'cases':offline['parity']['cases'],'badCount':offline['parity']['badCount']},'crossVariantReplay':cross['passed'],'uiSmoke':ui['passed'],'reproducible':repro,'schemasAndDigests':schema_ok and digests_ok,'onlineSha256':sha(online),'offlineSha256':sha(off)}
    summary['passed']=(focused['failed']==0 and stage4['failed']==0 and stage3['failed']==0 and buildcases[70] and offline['passed'] and cross['passed'] and ui['passed'] and repro and schema_ok and digests_ok)
    (ev/'EquationWright_Pass_4B_Release_Gates.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({'passed':summary['passed'],'focusedPass4C':summary['focusedPass4C'],'stage4':summary['stage4'],'stage3':{'passed':stage3['passed'],'failed':stage3['failed']},'reproducible':repro,'offlineParity':summary['offlineParity'],'crossVariantReplay':cross['passed'],'uiSmoke':ui['passed'],'onlineSha256':summary['onlineSha256'],'offlineSha256':summary['offlineSha256']},indent=2))
    return 0 if summary['passed'] else 1
if __name__=='__main__': raise SystemExit(main())
