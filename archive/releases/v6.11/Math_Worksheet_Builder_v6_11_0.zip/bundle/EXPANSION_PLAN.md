# Expansion Plan v2 — Verified Against the Live NVCC Catalog (July 2026)

Catalog reconciliation (user list × AI list × catalog.nvcc.edu) fixed both lists.
The real lineup is **19 courses**. Status: **12 built and audited, 7 remaining**,
plus deeper units for 266/267. Every build below uses the proven per-session
workflow (scope from the official outline → sectioned generators with traps →
self-test → SymPy audit → browser pass → ship both editions + bundle).
Audit record so far: 420/420 instances verified across the six newest courses.

## Built (v6.8.0)
154 QR · 161 CA · 162 TRIG · 167 PC · 246 ST2 · 261 AC1 · 262 AC2 ·
263 C1 · 264 C2 · 265 C3 · 266 LA (unit 1 of 3) · 267 DE (unit 1 of 3)

## Build queue (in order)

**1. Finish MTH 266** — LA units 2–3 (~25 gens): matrix algebra (add/multiply/
transpose/inverse 2×2), determinants (2×2, 3×3 cofactor, properties), then
eigenvalues/eigenvectors of 2×2, basis/dimension/independence. All perfectly
SymPy-auditable. One session.

**2. Finish MTH 267** — DE units 2–3 (~25 gens): second-order homogeneous with
constant coefficients (real, repeated, complex roots), undetermined coefficients,
spring-mass setup; plus Laplace-transform basics (the 267 outline includes them).
One session.

**3. MTH 133 Math for Health Professions** (~30 gens, NEW discovery from the
catalog check): dosage calculations, dilutions, IV flow rates, dimensional
analysis/metric conversion, ratio & proportion in clinical context. Easiest math
in the catalog, biggest underserved audience (every nursing student). One session.

**4. MTH 111 Basic Technical Mathematics** (~28 gens): fractions/arithmetic, unit
conversion, geometry (area/volume/Pythagorean), applied basic trig. CTE-program
audience. One session.

**— MANDATORY EXPLORE BLOCK —** Six modes have never been touched by human
hands. No build past this line until real quizzes have been taken in QR, ST2,
AC1/2, LA, DE and screenshots of anything weird exist. Real use has out-found
AI review every single time in this project's history.

**5. Stats-engine spike + MTH 155 Statistical Reasoning** (~35 gens): implement
one self-contained normal-CDF (erf approximation) in the app — the single piece
of infrastructure still missing — then descriptive stats, z-scores, empirical
rule, correlation reading, basic CI/test interpretation. Honest limit: the
software/simulation outcomes in the outline resist seeded MC; document the gap.

**6. MTH 245 Statistics I** (~42 gens): shares 155's engine and machinery —
distributions, sampling/CLT, confidence intervals, hypothesis tests with
computed test statistics. Fast follow to 155.

**7. MTH 283 Probability and Statistics** (~40 gens): the calculus-based course —
continuous random variables via integration, expectation, CLT, estimation,
least squares. Needs both the stats engine and integral generators (both exist
by now).

**8. MTH 288 Discrete Mathematics** (~50 gens + infrastructure): truth tables,
sets, counting, relations, graphs, Boolean algebra, recurrences — and NEW answer
types (proofs become "pick the valid inductive step"). Budget the extra time;
this one touches the MC normalizer.

**9. MTH 289 Differential Equations Extended** (~38 gens): systems, series
solutions, Fourier, Laplace/Fourier transforms, PDEs, BVPs. Longest answers,
hardest MC fit — deliberately last.

**10. Full-catalog audit sweep + tag "full catalog" release.**

Skipped: MTH 166 (legacy catalog entry shadowing 167 — old numbering).

## Cadence & rules (unchanged, proven over 6 builds)
- Ship every session: versioned file + OFFLINE edition + bundle, no exceptions.
- Explore between builds; a real user's bug outranks the whole queue.
- Sections first, never mega-units — unit granularity is diagnostic granularity.
- Verify the verifier before accusing the app (all 11 audit "mismatches" so far
  were the auditor's fault; the 2 real findings were display bugs, both fixed).
- Definition of done ends with: you personally answered five questions.

Revised totals: ~19 courses, ~700 generators at current density.
Remaining effort: ~9 build sessions + explores ≈ one semester at one session/week.
