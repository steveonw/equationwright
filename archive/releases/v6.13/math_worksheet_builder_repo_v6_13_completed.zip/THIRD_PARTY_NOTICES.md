# Third-party notices

## MathJax

The fully offline build embeds MathJax 3.2.2 `tex-svg.js`. The copy at
`vendor/mathjax/tex-svg.js` reproduces the dependency already embedded in the
project's offline HTML build.

MathJax is distributed under the Apache License 2.0. Preserve its copyright and
license notices when redistributing an offline build.

Upstream: https://www.mathjax.org/

## SymPy

The independent symbolic mathematics audit scripts use SymPy, distributed
under the BSD 3-Clause License.

Upstream: https://www.sympy.org/

## NumPy

The MTH 155 and statistics-engine audits use NumPy, distributed under the BSD
3-Clause License.

Upstream: https://numpy.org/

## SciPy

The MTH 155 and statistics-engine audits use SciPy as an independent reference
implementation. SciPy is distributed under the BSD 3-Clause License.

Upstream: https://scipy.org/

## Playwright

The optional corpus-generation helper uses Playwright for Python, distributed
under the Apache License 2.0.

Upstream: https://playwright.dev/python/
