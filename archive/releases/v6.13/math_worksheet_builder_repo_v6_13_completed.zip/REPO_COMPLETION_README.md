# Repository completion overlay for v6.13

Copy this overlay into the repository root. It adds reproducible build, audit,
licensing, and CI support without replacing the worksheet application source.

## Added repository infrastructure

- Exact MathJax 3.2.2 `tex-svg.js` used by the existing offline build
- Missing Go embed copy at `gateway/localchat.html`
- `gateway/go.mod`
- Python dependency files, including NumPy and SciPy for the statistics audits
- Corpus generation for all current audit groups, including MTH 133 and MTH 155
- One-command audit runner, including `stats_engine_audit.py`
- Dynamic release builder that selects the newest standard HTML version
- Repository inventory checker
- GitHub Actions checks
- License, third-party, security, and contribution documents

## First commands

```bash
python -m pip install -r requirements-dev.txt
python -m playwright install chromium
python scripts/generate_audit_corpora.py
python scripts/run_all_audits.py
python scripts/build_release.py
python scripts/check_repo.py
```

## Generated corpus files

The corpus generator writes:

- `audit_corpus.json`
- `ac_corpus.json`
- `de_corpus.json`
- `de2_corpus.json`
- `hp_corpus.json`
- `la_corpus.json`
- `la2_corpus.json`
- `qr_corpus.json`
- `s155_corpus.json`
- `st2_corpus.json`

The overlay does not fabricate missing corpora. They should be generated from
the exact HTML release being audited.

## Current source-repository warnings

The v6.13 bundle still has a README generator count that is behind the app, and
`README.md` and `WORKSHEET_MANUAL.md` are duplicates. These are documentation
issues rather than build failures.

## License review

The supplied application says all rights reserved, while the gateway source
states MIT. Review the included license files before publishing or accepting
outside contributions.
