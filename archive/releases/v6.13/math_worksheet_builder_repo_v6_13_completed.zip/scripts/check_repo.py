#!/usr/bin/env python3
"""Check a Math Worksheet Builder checkout for reproducibility and release files."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path

REQUIRED = [
    "make_offline_build.py",
    "audit.py", "ac_audit.py", "de_audit.py", "de2_audit.py", "hp_audit.py",
    "la_audit.py", "la2_audit.py", "qr_audit.py", "s155_audit.py",
    "st2_audit.py", "stats_engine_audit.py", "mw_stats_engine_v1.js",
    "gateway/tutor-gateway-main.go", "gateway/tutor_gateway.py",
    "gateway/localchat.html", "gateway/go.mod",
    "vendor/mathjax/tex-svg.js", "requirements.txt", "LICENSE.md",
    "THIRD_PARTY_NOTICES.md", "SECURITY.md", "CONTRIBUTING.md",
    "scripts/generate_audit_corpora.py", "scripts/run_all_audits.py",
    "scripts/build_release.py", "scripts/check_repo.py",
]

GENERATED = [
    "audit_corpus.json", "ac_corpus.json", "de_corpus.json", "de2_corpus.json",
    "hp_corpus.json", "la_corpus.json", "la2_corpus.json", "qr_corpus.json",
    "s155_corpus.json", "st2_corpus.json",
]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def version_key(path: Path) -> tuple[int, ...]:
    match = re.search(r"_v([0-9_]+)(?:_OFFLINE)?\.html$", path.name)
    return tuple(int(part) for part in match.group(1).split("_")) if match else (0,)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--allow-missing-generated", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    failures: list[str] = []
    warnings: list[str] = []
    for relative in REQUIRED:
        if not (root / relative).is_file():
            failures.append(f"missing required file: {relative}")

    standards = sorted(
        [path for path in root.glob("Math_Worksheet_Builder_v*.html") if "_OFFLINE" not in path.stem],
        key=version_key,
    )
    if not standards:
        failures.append("missing standard Math_Worksheet_Builder_v*.html")
    for standard in standards:
        offline = standard.with_name(standard.stem + "_OFFLINE.html")
        if not offline.is_file():
            failures.append(f"missing matching offline build: {offline.name}")

    for relative in GENERATED:
        path = root / relative
        if not path.is_file():
            target = warnings if args.allow_missing_generated else failures
            target.append(f"missing generated audit corpus: {relative}")
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, list) or not data:
                failures.append(f"invalid or empty corpus: {relative}")
        except Exception as exc:
            failures.append(f"invalid JSON {relative}: {exc}")

    chat_source = root / "chat/LocalChat.html"
    chat_embed = root / "gateway/localchat.html"
    if chat_source.exists() and chat_embed.exists() and digest(chat_source) != digest(chat_embed):
        warnings.append("chat/LocalChat.html and gateway/localchat.html differ")

    readme = root / "README.md"
    manual = root / "WORKSHEET_MANUAL.md"
    if readme.exists() and manual.exists() and digest(readme) == digest(manual):
        warnings.append("README.md and WORKSHEET_MANUAL.md are duplicates")

    if standards and readme.exists():
        latest = standards[-1]
        app_text = latest.read_text(encoding="utf-8", errors="replace")
        readme_text = readme.read_text(encoding="utf-8", errors="replace")
        generator_count = len(re.findall(r"\bregisterGen\s*\(", app_text))
        claimed = re.search(r"from\s+(\d+)\s+deterministic problem generators", readme_text, re.I)
        if claimed and int(claimed.group(1)) != generator_count:
            warnings.append(
                f"README claims {claimed.group(1)} generators; {latest.name} contains "
                f"{generator_count} registerGen calls"
            )

    for app in root.glob("Math_Worksheet_Builder_v*.html"):
        text = app.read_text(encoding="utf-8", errors="replace")
        if "Copyright (c) 2026 Steveon William Walker" not in text:
            warnings.append(f"copyright notice not found in {app.name}")
        if re.search(r"(?:api[_-]?key|gateway[_-]?key)\s*[:=]\s*['\"][^'\"]{8,}", text, re.I):
            warnings.append(f"possible embedded credential in {app.name}")

    for warning in warnings:
        print("WARN:", warning)
    for failure in failures:
        print("FAIL:", failure)
    print(f"checked {root}: {len(failures)} failure(s), {len(warnings)} warning(s)")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
