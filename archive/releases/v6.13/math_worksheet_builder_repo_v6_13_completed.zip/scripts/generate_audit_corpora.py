#!/usr/bin/env python3
"""Generate deterministic audit corpora from the worksheet-builder app.

Requires Playwright. The script serves the repository on loopback, opens the
selected standard HTML build, invokes every registered generator with fixed
seeds, and writes the corpus JSON files consumed by the audit scripts.
"""
from __future__ import annotations

import argparse
import functools
import http.server
import json
import re
import socketserver
import threading
from pathlib import Path

GROUPS = {
    "audit_corpus.json": ["CA", "TRIG", "PC", "C1", "C2", "C3"],
    "ac_corpus.json": ["AC1", "AC2"],
    "de_corpus.json": ["DE_Basics", "DE_Methods", "DE_AppsNum"],
    "de2_corpus.json": ["DE_SecondOrder", "DE_Laplace"],
    "hp_corpus.json": ["HP"],
    "la_corpus.json": ["LA_Systems", "LA_RowRed", "LA_SolutionSets"],
    "la2_corpus.json": ["LA_MatrixAlg", "LA_Eigen"],
    "qr_corpus.json": ["QR"],
    "s155_corpus.json": ["S155"],
    "st2_corpus.json": ["ST2"],
}

JS = r"""
({selectors, samples}) => {
  const selected = new Set();
  for (const u of UNITS) {
    if (selectors.includes(u.course) || selectors.includes(u.id)) selected.add(u.id);
  }
  const rows = [];
  for (const unitId of selected) {
    const gens = Gens[unitId] || [];
    for (let gi = 0; gi < gens.length; gi++) {
      for (let sample = 0; sample < samples; sample++) {
        const seed = (fnv1a('AUDIT|' + unitId + '|' + gi + '|' + sample)) >>> 0;
        const problem = gens[gi](xorshift32(seed));
        rows.push({
          unitId,
          genIndex: gi,
          sample,
          seed,
          key: String(problem.key || ''),
          q: String(problem.q || ''),
          a: String(problem.a || ''),
          steps: Array.isArray(problem.steps) ? problem.steps : [],
          traps: Array.isArray(problem.traps) ? problem.traps : [],
          vec: Array.isArray(problem.vec) ? problem.vec : []
        });
      }
    }
  }
  return rows;
}
"""


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *_args: object) -> None:
        pass


def version_key(path: Path) -> tuple[int, ...]:
    match = re.search(r"_v([0-9_]+)\.html$", path.name)
    return tuple(int(part) for part in match.group(1).split("_")) if match else (0,)


def find_latest_app(root: Path) -> Path:
    apps = [p for p in root.glob("Math_Worksheet_Builder_v*.html") if "_OFFLINE" not in p.stem]
    if not apps:
        raise SystemExit("No standard Math_Worksheet_Builder_v*.html file found")
    return max(apps, key=version_key)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--app", help="standard HTML filename; latest is selected when omitted")
    parser.add_argument("--samples", type=int, default=6)
    parser.add_argument("--browser", help="optional Chromium/Chrome executable")
    args = parser.parse_args()

    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise SystemExit("Playwright is required: pip install -r requirements-dev.txt") from exc

    root = Path(args.root).resolve()
    app = root / args.app if args.app else find_latest_app(root)
    if not app.is_file():
        raise SystemExit(f"Missing app: {app}")

    handler = functools.partial(QuietHandler, directory=str(root))
    with socketserver.TCPServer(("127.0.0.1", 0), handler) as server:
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f"http://127.0.0.1:{server.server_address[1]}/{app.name}"
        with sync_playwright() as pw:
            launch: dict[str, object] = {"headless": True}
            if args.browser:
                launch["executable_path"] = args.browser
            browser = pw.chromium.launch(**launch)
            page = browser.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=120_000)
            page.wait_for_function(
                "typeof Gens !== 'undefined' && typeof UNITS !== 'undefined' "
                "&& typeof fnv1a === 'function' && typeof xorshift32 === 'function'"
            )
            for filename, selectors in GROUPS.items():
                rows = page.evaluate(JS, {"selectors": selectors, "samples": args.samples})
                (root / filename).write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
                print(f"wrote {filename}: {len(rows)} rows")
            browser.close()
        server.shutdown()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
