#!/usr/bin/env python3
"""Rebuild the offline HTML and optionally the Go gateway."""
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


def version_key(path: Path) -> tuple[int, ...]:
    match = re.search(r"_v([0-9_]+)\.html$", path.name)
    return tuple(int(part) for part in match.group(1).split("_")) if match else (0,)


def latest_app(root: Path) -> Path:
    apps = [path for path in root.glob("Math_Worksheet_Builder_v*.html") if "_OFFLINE" not in path.stem]
    if not apps:
        raise SystemExit("No standard Math_Worksheet_Builder_v*.html file found")
    return max(apps, key=version_key)


def run(command: list[str], cwd: Path, env: dict[str, str] | None = None) -> None:
    print("+", " ".join(command))
    subprocess.run(command, cwd=cwd, env=env, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--app", help="standard HTML filename; latest is selected when omitted")
    parser.add_argument("--skip-gateway", action="store_true")
    parser.add_argument("--gateway-os", default="windows")
    parser.add_argument("--gateway-arch", default="amd64")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    app = root / args.app if args.app else latest_app(root)
    mathjax = root / "vendor/mathjax/tex-svg.js"
    builder = root / "make_offline_build.py"
    chat_source = root / "chat/LocalChat.html"
    chat_embed = root / "gateway/localchat.html"

    for needed in (app, mathjax, builder):
        if not needed.is_file():
            print(f"ERROR: missing {needed}", file=sys.stderr)
            return 2

    run([sys.executable, str(builder), str(app), str(mathjax)], root)

    if chat_source.is_file():
        chat_embed.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(chat_source, chat_embed)
        print(f"synced {chat_source.relative_to(root)} -> {chat_embed.relative_to(root)}")

    if not args.skip_gateway:
        go = shutil.which("go")
        if not go:
            print("WARN: Go not found; skipped gateway build")
        else:
            env = os.environ.copy()
            env["GOOS"] = args.gateway_os
            env["GOARCH"] = args.gateway_arch
            run([go, "build", "-o", "tutor-gateway.exe", "."], root / "gateway", env)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
