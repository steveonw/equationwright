#!/usr/bin/env python3
"""Run all independent audits and write a combined JSON summary."""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

AUDITS = [
    ("general", "audit.py", "audit_corpus.json"),
    ("applied_calculus", "ac_audit.py", "ac_corpus.json"),
    ("differential_equations_1", "de_audit.py", "de_corpus.json"),
    ("differential_equations_2", "de2_audit.py", "de2_corpus.json"),
    ("health_professions", "hp_audit.py", "hp_corpus.json"),
    ("linear_algebra_1", "la_audit.py", "la_corpus.json"),
    ("linear_algebra_2", "la2_audit.py", "la2_corpus.json"),
    ("quantitative_reasoning", "qr_audit.py", "qr_corpus.json"),
    ("statistical_reasoning", "s155_audit.py", "s155_corpus.json"),
    ("statistics_2", "st2_audit.py", "st2_corpus.json"),
    ("statistics_engine", "stats_engine_audit.py", None),
]

TOTAL_PATTERNS = [
    re.compile(r"^TOTAL\s+(\d+)\s+(\d+)\s+(\d+)\s*$", re.M),
    re.compile(r"^TOTAL\s+v=(\d+)\s+m=(\d+)\s+u=(\d+)\s*$", re.M),
]


@dataclass
class Result:
    name: str
    status: str
    verified: int = 0
    mismatches: int = 0
    unchecked: int = 0
    returncode: int = 0
    script: str = ""
    corpus: str = ""
    message: str = ""


def parse_total(text: str) -> tuple[int, int, int] | None:
    for pattern in TOTAL_PATTERNS:
        matches = list(pattern.finditer(text))
        if matches:
            return tuple(int(value) for value in matches[-1].groups())
    return None


def run_one(root: Path, python: str, name: str, script_name: str, corpus_name: str | None) -> Result:
    script = root / script_name
    if not script.is_file():
        return Result(name, "MISSING_SCRIPT", script=script_name, corpus=corpus_name or "")
    if corpus_name and not (root / corpus_name).is_file():
        return Result(name, "MISSING_CORPUS", script=script_name, corpus=corpus_name)

    proc = subprocess.run(
        [python, script.name],
        cwd=root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    output = proc.stdout
    if proc.returncode != 0:
        return Result(name, "ERROR", returncode=proc.returncode, script=script_name,
                      corpus=corpus_name or "", message=output[-3000:])

    if corpus_name is None:
        passed = len(re.findall(r"^PASS:", output, re.M))
        failed = len(re.findall(r"^FAIL:", output, re.M))
        return Result(name, "FAIL" if failed else "PASS", passed, failed, 0,
                      proc.returncode, script_name, "", output[-3000:] if failed else "")

    total = parse_total(output)
    if total is None:
        return Result(name, "UNPARSED", script=script_name, corpus=corpus_name,
                      message=output[-3000:])
    verified, mismatches, unchecked = total
    status = "FAIL" if mismatches else ("WARN" if unchecked else "PASS")
    return Result(name, status, verified, mismatches, unchecked, proc.returncode,
                  script_name, corpus_name)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--summary", default="audit_summary.json")
    parser.add_argument("--allow-missing", action="store_true")
    parser.add_argument("--fail-on-unchecked", action="store_true")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    results = [run_one(root, args.python, *audit) for audit in AUDITS]
    width = max(len(result.name) for result in results)
    print(f"{'audit':{width}s}  status           verified mismatch unchecked")
    for result in results:
        print(
            f"{result.name:{width}s}  {result.status:15s} "
            f"{result.verified:8d} {result.mismatches:8d} {result.unchecked:9d}"
        )

    summary = {
        "results": [asdict(result) for result in results],
        "totals": {
            "verified": sum(result.verified for result in results),
            "mismatches": sum(result.mismatches for result in results),
            "unchecked": sum(result.unchecked for result in results),
        },
    }
    (root / args.summary).write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")

    missing = any(result.status.startswith("MISSING") for result in results)
    errors = any(result.status in {"ERROR", "UNPARSED", "FAIL"} for result in results)
    unchecked = any(result.unchecked for result in results)
    if errors or (unchecked and args.fail_on_unchecked):
        return 1
    if missing and not args.allow_missing:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
