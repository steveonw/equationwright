# Contributing

1. Work from source files, not a generated offline release.
2. Give every generator a stable `key`, numeric `vec`, answer, and worked steps.
3. Add realistic distractors when a generator is used in quiz mode.
4. Run the in-app self-test with fixed seeds.
5. Export the audit corpora and run `python scripts/run_all_audits.py`.
6. Rebuild the standard and offline releases.
7. Do not include real student names, results, model files, or credentials.

Course changes should document the affected course, unit, learning outcome,
generator keys, test seeds, and faculty-review status.
