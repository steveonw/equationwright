# Unit ID vocabulary (authoritative — extracted from the app)

Blueprint `counts` keys and results `unit` values MUST come from this table.
A blueprint may only use units whose Mode matches its `mode` field (or any unit if mode is `MIX`).
`PC_Conics` is also available in `TRIG` mode (cross-listed).

| Mode | Unit ID | Label |
|------|---------|-------|
| CA | `CA_Linear` | Linear Equations & Inequalities |
| CA | `CA_Quadratics` | Quadratic Functions |
| CA | `CA_Polynomials` | Polynomial Functions |
| CA | `CA_Rational` | Rational Functions |
| CA | `CA_ExpLog` | Exponential & Logarithmic |
| CA | `CA_Systems` | Systems of Equations |
| CA | `CA_Functions` | Function Operations |
| TRIG | `TRIG_Angles` | Angle Conversions |
| TRIG | `TRIG_UnitCircle` | Unit Circle & Trig Values |
| TRIG | `TRIG_Identities` | Trig Identities |
| TRIG | `TRIG_Equations` | Solving Trig Equations |
| TRIG | `TRIG_Triangle` | Law of Sines & Cosines |
| TRIG | `TRIG_Polar` | Polar Coordinates |
| PC | `PC_Conics` | Conic Sections |
| PC | `PC_Sequences` | Sequences & Series |
| PC | `PC_Vectors` | Vectors (Intro) |
| C1 | `C1_Limits` | Limits |
| C1 | `C1_Continuity` | Continuity |
| C1 | `C1_Derivatives` | Derivatives |
| C1 | `C1_Apps` | Derivative Applications |
| C1 | `C1_Integrals` | Integrals (Intro) |
| C2 | `C2_Tech` | Integration Techniques |
| C2 | `C2_Improper` | Improper Integrals |
| C2 | `C2_Series` | Sequences & Series |
| C2 | `C2_ParamPolar` | Parametric / Polar |
| C2 | `C2_AppsInt` | Applications of Integration |
| C3 | `C3_Vectors` | Vectors & Geometry |
| C3 | `C3_Partials` | Partial Derivatives |
| C3 | `C3_MultInt` | Multiple Integrals |
| C3 | `C3_VecCalc` | Vector Calculus |
